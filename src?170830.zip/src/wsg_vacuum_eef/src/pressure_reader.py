#!/usr/bin/env python

import rospy
from std_msgs.msg import Float64


pub1 = rospy.Publisher('/wsg_vacuum/pressure_kPa', Float64, queue_size=1)
pub2 = rospy.Publisher('/wsg_vacuum/pressure_bar', Float64, queue_size=1)

def callback(data):
    # rospy.loginfo(rospy.get_caller_id() + "I heard %s", data.data)
    p1 = ((data.data - 0.120)/27)*1000 * (3/3.3) + 15
    pub1.publish(p1)
    p2 = p1 * 0.01
    pub2.publish(p2)
    if p2 > 1.1 :
      color = "\033[91m"
    elif p2 > 0.8 :
      color = "\033[0m"
    elif p2 > 0.5 :
      color = "\033[95m"
    elif p2 > 0.3 :
      color = "\033[94m"
    else :
      color = "\033[92m"
      
    print color+"%10.2f\033[0m\033[1m" %p2 + " bar\033[0m\t"+ color+"%10.4f\033[0m\033[1m kPa\033[0m" %p1
    
    
def Converter():

    # In ROS, nodes are uniquely named. If two nodes with the same
    # node are launched, the previous one is kicked off. The
    # anonymous=True flag means that rospy will choose a unique
    # name for our 'Converter' node so that multiple listeners can
    # run simultaneously.
    rospy.init_node('pressure_reader', anonymous=True)

    rospy.Subscriber("/rpi_analog/voltage_scaled", Float64, callback)

    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()

if __name__ == '__main__':
    converter = Converter()