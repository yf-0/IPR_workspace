rosrun moveit_ikfast create_ikfast_moveit_plugin.py r3 arm r3_ikfast_arm_plugin /home/dennis/ros_ws/src/iirob_kuka/r3_ikfast_arm_plugin/src/r3_arm_ikfast_solver.cpp
