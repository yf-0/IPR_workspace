#!/usr/bin/env python

# Based on: https://github.com/joemcmanus/analog

import os, time
import subprocess
import rospy
import std_msgs.msg as msgs


class RPiAnalog():

  def __init__(self):

    rospy.init_node('rpi_analog', log_level=rospy.INFO)

    # Type of Boards. (Allowed values: RPi, RaspberryPi, BBB, BeagleBoneBlack, UpBoard)
    self.type = rospy.get_param("~board_type", "")

    # Used only with RPi, RaspberryPi, BBB, BeagleBoneBlack
    self.rate = int(rospy.get_param("~rate", 50))

    # Used only with RPi, RaspberryPi, BBB, BeagleBoneBlack
    self.pins = rospy.get_param("~pins", [])

    rospy.loginfo("Configuring for " + self.type + "  at rate of " + str(self.rate) + " Hz")

    if type in ["RPi", "RaspberryPi", "BBB", "BeagleBoneBlack"]:
      self.pub_voltage_raw = {}
      self.pub_voltage_scaled = {}

      for pin in self.pins:
        self.pub_voltage_raw[pin] = rospy.Publisher('~voltage_pin_raw', msgs.Float64, queue_size=1)
        self.pub_voltage_scaled[pin] = rospy.Publisher('~voltage_pin_scaled', msgs.Float64, queue_size=1)

        #if pin == 0:
          #checkAnalogPin(pin)

    else:
      self.pub_voltage_raw = rospy.Publisher('~voltage_raw', msgs.Float64, queue_size=1)
      self.pub_voltage_scaled = rospy.Publisher('~voltage_scaled', msgs.Float64, queue_size=1)

    rospy.Timer(rospy.Duration(1.0/self.rate), self.read_analg)
    rospy.spin()

  def read_analg(self, event):

    if type in ["RPi", "RaspberryPi", "BBB", "BeagleBoneBlack"]:
      for pin in self.pins:
        self.read_and_publish(self.pub_voltage_raw[pin], self.pub_voltage_scaled[pin], str(pin))

    else:
      self.read_and_publish(self.pub_voltage_raw, self.pub_voltage_scaled)

  def read_and_publish(self, pub_raw, pub_scaled, pin=""):
    #Access the raw voltage reading
        path="/sys/bus/iio/devices/iio:device0/in_voltage" + pin + "_raw"
        sysRaw =subprocess.check_output(['/bin/cat', path], stderr=subprocess.STDOUT)
        #The raw voltage reading needs to be multiplied by the scale, get the scale
        path="/sys/bus/iio/devices/iio:device0/in_voltage" + pin + "_scale"
        sysScale=subprocess.check_output(['/bin/cat', path ], stderr=subprocess.STDOUT)

        pub_raw.publish(float(sysRaw))
        pub_scaled.publish(float(float(sysRaw) * float(sysScale) / 1000))


  # This is not tested
  #def checkAnalogPin(pin):
      ##First lets check to see if the 22K pull up resister is set on Pin 0
      ##See bug report: https://github.com/intel-iot-devkit/mraa/issues/390
      #fixGpio=subprocess.check_output(['/bin/cat', '/sys/kernel/debug/gpio'], stderr=subprocess.STDOUT)
      #gpio49=re.search(r'gpio-49.*', fixGpio)
      #if hasattr(gpio49, 'group'):
          #status=str(gpio49.group(0)).split()
          ##If it is set to in exit
          #if status[3] == "in":
              #return
          #else:
              #print("Pull up resister set to hi, attempting to change.")
              #fh=open("/sys/class/gpio/gpio49/direction", "w")
              #fh.write('in')
              #fh.close()
              ##For some reason it does not update until you read, so lets read
              #pin.read()

      #fixGpio=subprocess.check_output(['/bin/cat', '/sys/kernel/debug/gpio'], stderr=subprocess.STDOUT)
      #gpio49=re.search(r'gpio-49.*', fixGpio)
      #if hasattr(gpio49, 'group'):
          #status=str(gpio49.group(0)).split()
          #if status[3] == "out":
            #print("Still showing as output, this will cause bad readings.")


if __name__ == '__main__':
    rpiAnalog = RPiAnalog()
