/*****************************************************************************
 *
 * Copyright 2016 Intelligent Industrial Robotics (IIROB) Group,
 * Institute for Anthropomatics and Robotics (IAR) -
 * Intelligent Process Control and Robotics (IPR),
 * Karlsruhe Institute of Technology (KIT)
 *
 * Author: Dennis Hartmann
 *         Denis Štogl, email: denis.stogl@kit.edu
 *
 * Date of creation: 2016
 *
 * +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 *
 * Redistribution and use in source and binary forms,
 * with or without modification, are permitted provided
 * that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the copyright holder nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 *
 * This package is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This package is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this package. If not, see <http://www.gnu.org/licenses/>.
*****************************************************************************/

#include "iirob_ik/inverse_kinematic.h"
#define IKFAST_HAS_LIBRARY
#include "iirob_ik/ikfast.h"

InverseKinematic::InverseKinematic(ros::NodeHandle nh)
  : urdf_(new urdf::Model()), nh_(nh)
{
  // ...initialize contents of urdf
  urdf_->initParam("/robot_description");
  // Data structures

  worst_best_ssd_ = 0.0;
  joint_count_ = 0;


  std::vector<std::string> joints_;
  if (!nh_.getParam("joint_names", joints_))
  {
    ROS_ERROR("Failed to get parameter \"joint_names\".");
    return;
  }
  joint_count_ = joints_.size();

  std::vector<boost::shared_ptr<const urdf::Joint> > urdf_joint;

  for (int i = 0; i < joint_count_; ++i)
  {
    urdf_joint.push_back(urdf_->getJoint(joints_[i]));
  }

  joint_limits_.resize(joint_count_);
  for (int i = 0; i < joint_count_; ++i)
  {

    if (!urdf_joint[i])
    {
      ROS_ERROR("Can't find arm_%d_joint", i);
      return;
    }
    bool urdf_limits_ok = getJointLimits(urdf_joint[i], joint_limits_[i]);


    ROS_INFO("Limits for \"%s\":%.5f min %.5f max",urdf_joint[i]->name.c_str(),joint_limits_[i].min_position, joint_limits_[i].max_position);
  }
}

std::list<std::vector<double> > InverseKinematic::getIKsolutions(geometry_msgs::Pose pose)
{
  IkReal EETranslation[3], EERotation[9];
  double qw = pose.orientation.w;
  double qx = pose.orientation.x;
  double qy = pose.orientation.y;
  double qz = pose.orientation.z;
  const double n = 1.0/sqrt(qx*qx+qy*qy+qz*qz+qw*qw);
  qw *= n;
  qx *= n;
  qy *= n;
  qz *= n;

  EERotation[0] = 1.0 - 2.0*qy*qy - 2.0*qz*qz;
  EERotation[1] = 2.0*qx*qy - 2.0*qz*qw;
  EERotation[2] = 2.0*qx*qz + 2.0*qy*qw;
  EERotation[3] = 2.0*qx*qy + 2.0*qz*qw;
  EERotation[4] = 1.0 - 2.0*qx*qx - 2.0*qz*qz;
  EERotation[5] = 2.0*qy*qz - 2.0*qx*qw;
  EERotation[6] = 2.0*qx*qz - 2.0*qy*qw;
  EERotation[7] = 2.0*qy*qz + 2.0*qx*qw;
  EERotation[8] = 1.0 - 2.0*qx*qx - 2.0*qy*qy;

  EETranslation[0] = pose.position.x;
  EETranslation[1] = pose.position.y;
  EETranslation[2] = pose.position.z;

  ikfast::IkSolutionList<double> solutions;


  std::vector<double> solutionValues(joint_count_);
  std::list<std::vector<double> > solutionList;

  //computes IK solutions and stores them in "solutions", third parameter is used for free joints
  bool Success = ComputeIk(EETranslation, EERotation, NULL, solutions);

  if (!Success)
  {

    ROS_ERROR("IK did not find a solution!");
    return solutionList;
  }

  unsigned int numberSolutions = (int)solutions.GetNumSolutions();

  //tries to get a config by comparing the absolute difference in each joint with the current joint values in each joint
  //then checks if the needed velocity for the corresponding movement is lower than MaxJointVel_
  for (std::size_t i = 0; i < numberSolutions; ++i)
  {
    //CurrentSolutionDifferenceSum = 0;
    const ikfast::IkSolutionBase<double>& solution = solutions.GetSolution(i);

    solution.GetSolution(&solutionValues[0], NULL);

    ROS_DEBUG("%.15f, %.15f, %.15f, %.15f, %.15f, %.15f", solutionValues[0], solutionValues[1], solutionValues[2], solutionValues[3], solutionValues[4], solutionValues[5]);

    if (is_legal_solution(solutionValues))
    {
      solutionList.push_back(solutionValues);
    }
  }

  for (std::list<std::vector<double> >::iterator itr = solutionList.begin(); itr != solutionList.end(); ++itr)
  {
    ROS_DEBUG("IK solution: %.15f, %.15f, %.15f, %.15f, %.15f, %.15f", (*itr)[0], (*itr)[1], (*itr)[2], (*itr)[3], (*itr)[4], (*itr)[5]);
  }
  if (solutionList.empty())
  {
    ROS_ERROR("No legal IK solution available!");
  }

  return solutionList;
}

double SSD(const std::vector<double>& a, const/**/ std::vector<double>& b)
{
  if (a.size() != b.size())
    return -1.0;

  double ssd = 0.0;

  for (int i = 0; i < a.size(); ++i)
  {
    ssd += (a[i] - b[i]) * (a[i] - b[i]);
  }

  return ssd;
}

std::vector<double> InverseKinematic::getBestIKSolution(geometry_msgs::Pose pose, std::vector<double> current_joint_values, bool checkAbsolute)
{
  std::vector<double> solution;
  std::list<std::vector<double> > solutionList = getIKsolutions(pose);
  if (solutionList.empty())
  {
    ROS_ERROR("Called with empty IK Solution list!");
    return solution;
  }
  double bestSSD = std::numeric_limits<double>::max();
  std::list<std::vector<double> >::iterator best_itr;
  for (std::list<std::vector<double> >::iterator itr = solutionList.begin(); itr != solutionList.end(); ++itr)
  {
    double ssd = SSD(current_joint_values,*itr);
    if (ssd < bestSSD)
    {
      bestSSD = ssd;
      best_itr = itr;

    }
    ROS_DEBUG("SSD: %f", ssd);
  }

  if (bestSSD > worst_best_ssd_)
    worst_best_ssd_ = bestSSD;
  ROS_DEBUG("SSD of best solution: %f", bestSSD);
  ROS_DEBUG("Best IK solution: %.15f, %.15f, %.15f, %.15f, %.15f, %.15f", (*best_itr)[0], (*best_itr)[1], (*best_itr)[2], (*best_itr)[3], (*best_itr)[4], (*best_itr)[5]);

  //TODO choose limit for check absolute values
  if (!checkAbsolute || bestSSD < 0.01)
  {
    solution = *best_itr;
  }
  else
  {
    ROS_ERROR("Next joint values too far away! Current Joint Values: %.15f, %.15f, %.15f, %.15f, %.15f, %.15f", current_joint_values[0], current_joint_values[1], current_joint_values[2], current_joint_values[3], current_joint_values[4], current_joint_values[5]);
  }
  return solution;
}


bool InverseKinematic::is_legal_solution(std::vector<double>& solution)
{
  for (int i = 0; i < solution.size(); ++i)
  {
    if (solution[i] < joint_limits_[i].min_position || solution[i] > joint_limits_[i].max_position)
    {
      ROS_DEBUG("IK Solution for joint %d illegal! min %4f, max %4f, actual %4f", i+1,joint_limits_[i].min_position, joint_limits_[i].max_position, solution[i]);
      return false;
    }

  }

  return true;
}



std::vector<std::vector<double> > InverseKinematic::transformPathtoJoints(geometry_msgs::PoseArray& pose_array, std::vector<double> current_joint_values)
{
  std::vector<std::vector<double> > joint_path(pose_array.poses.size());
  joint_path[0] = getBestIKSolution(pose_array.poses[0], current_joint_values);

  if (joint_path[0].empty())
  {
    ROS_ERROR("Start Pose has no valid IK solution! Aborting Path.");
    joint_path.resize(0);
  }
  else
  {
    for (int i = 1; i < pose_array.poses.size(); ++i)
    {
      joint_path[i] = getBestIKSolution(pose_array.poses[i], joint_path[i-1]);
      if (joint_path[i].empty())
      {
        ROS_ERROR("Pose in path has no valid IK solution! Aborting Path.");
        joint_path.resize(i-1);
        break;
      }
    }
  }
  ROS_INFO("Worst difference in joint angles: %.5f", worst_best_ssd_);

  return joint_path;
}
