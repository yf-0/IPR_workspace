#include <ros/ros.h>
#include <rosbag/bag.h>

#include "std_msgs/String.h"
#include "std_msgs/Int32.h"
#include <visualization_msgs/Marker.h>
#include <cmath>

#include <tf/LinearMath/Vector3.h>
#include <tf/transform_datatypes.h>

#include <sstream>
#include <iostream>
#include <yf_vacuum_cups/cup_dim.h>

int
main (int argc, char** argv)
{ 
  std::cerr << "cups into yaml" << std::endl;
  
   float f_nan = std::numeric_limits<float>::quiet_NaN();

  ros::init (argc, argv, "cup_vis");
  ros::NodeHandle nh; 
  ros::Rate r(20);
  
  yf_vacuum_cups::cup_dim cup_dim_;
    cup_dim_.radius = 0.015;	cup_dim_.lengthen = 0.030;	cup_dim_.bellows = 1.5;		cup_dim_.stroke = 0.008;	cup_dim_.bend = 0.002;	

  nh.deleteParam("cups");
  
  nh.setParam("cups/1/name", "SGP_24");
  nh.setParam("cups/1/radius", 0.012);
  nh.setParam("cups/1/lengthen", 0);
  nh.setParam("cups/1/height", 0.0108);
  nh.setParam("cups/1/stroke", 0.0017);
  nh.setParam("cups/1/minCurvR", f_nan);
  nh.setParam("cups/1/bellows", 0);
  nh.setParam("cups/1/bend", 0.0017);
  
  nh.setParam("cups/2/name", "SAOB_60x30");
  nh.setParam("cups/2/radius", 0.0155);
  nh.setParam("cups/2/lengthen", 0.0296);
  nh.setParam("cups/2/height", 0.025);
  nh.setParam("cups/2/stroke", 0.007);
  nh.setParam("cups/2/minCurvR", 0.018);
  nh.setParam("cups/2/bellows", 1.5);
  nh.setParam("cups/2/bend", 0.002);
  
  nh.setParam("cups/3/name", "FSGB_25");
  nh.setParam("cups/3/radius", 0.0115);
  nh.setParam("cups/3/lengthen", 0);
  nh.setParam("cups/3/height", 0.051);
  nh.setParam("cups/3/stroke", 0.022);
  nh.setParam("cups/3/minCurvR", 0.025);
  nh.setParam("cups/3/bellows", 3.5);
  nh.setParam("cups/3/bend", 0.004);
  
  nh.setParam("cups/4/name", "FG_20");
  nh.setParam("cups/4/radius", 0.0225);
  nh.setParam("cups/4/lengthen", 0);
  nh.setParam("cups/4/height", 0.0221);
  nh.setParam("cups/4/stroke", 0.009);
  nh.setParam("cups/4/minCurvR", 0.03);
  nh.setParam("cups/4/bellows", 2.5);
  nh.setParam("cups/4/bend", 0.002);
  
  nh.setParam("cups/5/name", "FGA_33");
  nh.setParam("cups/5/radius", 0.015);
  nh.setParam("cups/5/lengthen", 0);
  nh.setParam("cups/5/height", 0.031);
  nh.setParam("cups/5/stroke", 0.009);
  nh.setParam("cups/5/minCurvR", 0.04);
  nh.setParam("cups/5/bellows", 1.5);
  nh.setParam("cups/5/bend", 0.003);
  
  nh.setParam("cups/6/name", "FGA_25");
  nh.setParam("cups/6/radius", 0.01125);
  nh.setParam("cups/6/lengthen", 0);
  nh.setParam("cups/6/height", 0.029);
  nh.setParam("cups/6/stroke", 0.009);
  nh.setParam("cups/6/minCurvR", 0.02);
  nh.setParam("cups/6/bellows", 1.5);
  nh.setParam("cups/6/bend", 0.0025);
  
  nh.setParam("cups/7/name", "SGON_45x15");
  nh.setParam("cups/7/radius", 0.0072);
  nh.setParam("cups/7/lengthen", 0.015);
  nh.setParam("cups/7/height", 0.026);
  nh.setParam("cups/7/stroke", 0.002);
  nh.setParam("cups/7/minCurvR", 0.01);
  nh.setParam("cups/7/bellows", 0);
  nh.setParam("cups/7/bend", 0.002);
  
  nh.setParam("cups/8/name", "FSG_12");
  nh.setParam("cups/8/radius", 0.006);
  nh.setParam("cups/8/lengthen", 0);
  nh.setParam("cups/8/height", 0.027);
  nh.setParam("cups/8/stroke", 0.007);
  nh.setParam("cups/8/minCurvR", 0.013);
  nh.setParam("cups/8/bellows", 2.5);
  nh.setParam("cups/8/bend", 0.002);
  
  nh.setParam("cups/9/name", "FGA_11");
  nh.setParam("cups/9/radius", 0.00502);
  nh.setParam("cups/9/lengthen", 0);
  nh.setParam("cups/9/height", 0.016);
  nh.setParam("cups/9/stroke", 0.004);
  nh.setParam("cups/9/minCurvR", 0.01);
  nh.setParam("cups/9/bellows", 1.5);
  nh.setParam("cups/9/bend", 0.003);
  
  nh.setParam("cups/10/name", "FGA_14");
  nh.setParam("cups/10/radius", 0.00625);
  nh.setParam("cups/10/lengthen", 0);
  nh.setParam("cups/10/height", 0.0155);
  nh.setParam("cups/10/stroke", 0.005);
  nh.setParam("cups/10/minCurvR", 0.013);
  nh.setParam("cups/10/bellows", 1.5);
  nh.setParam("cups/10/bend", 0.003);
  
  nh.setParam("cups/11/name", "FGA_14");
  nh.setParam("cups/11/radius", 0.00625);
  nh.setParam("cups/11/lengthen", 0);
  nh.setParam("cups/11/height", 0.0155);
  nh.setParam("cups/11/stroke", 0.005);
  nh.setParam("cups/11/minCurvR", 0.013);
  nh.setParam("cups/11/bellows", 1.5);
  nh.setParam("cups/11/bend", 0.003);
  
  
}