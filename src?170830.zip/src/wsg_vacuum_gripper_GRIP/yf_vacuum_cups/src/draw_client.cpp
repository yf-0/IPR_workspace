#include <ros/ros.h>
#include <rosbag/bag.h>
#include "std_msgs/String.h"

#include <tf/LinearMath/Vector3.h>
#include <tf/transform_datatypes.h>

#include <sstream>
#include <iostream>

#include <yf_vacuum_cups/cup_dim.h>
#include <yf_vacuum_cups/srv_draw_cup.h>

bool tfIntoSrv(tf::Transform const &tf_from, yf_vacuum_cups::srv_draw_cup &srv_to)
{
//  geometry_msgs::Transform tf_msg;
  tf::transformTFToMsg(tf_from, srv_to.request.transformstamped.transform);
//  srv_to.request.transform = tf_msg;
  return true;	// maybe add detection of invalid tf?
}

bool cupdimMsgIntoSrv(yf_vacuum_cups::cup_dim const &dim_from, yf_vacuum_cups::srv_draw_cup &srv_to)
{
  srv_to.request.radius = dim_from.radius;
  srv_to.request.lengthen = dim_from.lengthen;
  srv_to.request.bellows = dim_from.bellows;
  srv_to.request.stroke = dim_from.stroke;
  srv_to.request.bend = dim_from.bend;
  return true;
}


int
main (int argc, char** argv)
{ 

  ros::init (argc, argv, "cup_vis_client");
  ros::NodeHandle nh; 
  ros::Rate r(20);
  
  ros::ServiceClient client = nh.serviceClient<yf_vacuum_cups::srv_draw_cup>("/draw_cups_srv/draw");
  
  // input of all cups dimensions
  std::vector<yf_vacuum_cups::cup_dim> v_cup_dim_;	// vector of all cups
  yf_vacuum_cups::cup_dim cup_dim_ ;
  cup_dim_.radius = 0.0125;	cup_dim_.lengthen = 0.0;	cup_dim_.bellows = 3.0;		cup_dim_.stroke = 0.030;	cup_dim_.bend = 0.002;
  v_cup_dim_.push_back(cup_dim_);	
  cup_dim_.radius = 0.015;	cup_dim_.lengthen = 0.030;	cup_dim_.bellows = 1.5;		cup_dim_.stroke = 0.008;	cup_dim_.bend = 0.001;
  v_cup_dim_.push_back(cup_dim_);	

  // input of desired tf
  tf::Transform tf_s (tf::Transform(tf::Quaternion(tf::Vector3(0.1,0.2,-0.4), 1.9),tf::Vector3(-0.208,-0.12,0.23)));

  // define srv: srvD with tf and cupdim
  yf_vacuum_cups::srv_draw_cup srvD;
  tfIntoSrv(tf_s, srvD);
  cupdimMsgIntoSrv(v_cup_dim_[0], srvD);
  
  if (client.call(srvD))
  {
    ROS_INFO("called");
  }
  else
  {
    ROS_ERROR("Failed to call service");
    return 1;
  }

  return 0;
  
}