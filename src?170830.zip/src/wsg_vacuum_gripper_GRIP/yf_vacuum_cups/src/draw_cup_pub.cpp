#include <ros/ros.h>
#include <rosbag/bag.h>
#include "std_msgs/String.h"
#include "std_msgs/Int32.h"
#include <visualization_msgs/Marker.h>
#include <cmath>

#include <tf/LinearMath/Vector3.h>
#include <tf/transform_datatypes.h>

#include <sstream>
#include <iostream>
#include <yf_vacuum_cups/cup_dim.h>


int
main (int argc, char** argv)
{ 

  ros::init (argc, argv, "cup_vis_pub");
  ros::NodeHandle nh; 
  ros::Rate r(20);
  rosbag::Bag bag;
  bag.open("test.bag", rosbag::bagmode::Write);
  
    std_msgs::String str;
    str.data = std::string("foo");

    bag.write("chatter", ros::Time::now(), str);
//    bag.write("numbers", ros::Time::now(), i);

  
  ros::Publisher pub_cup = nh.advertise<yf_vacuum_cups::cup_dim>( "cup_dim", 10 );
  ros::Publisher pub_tf = nh.advertise<geometry_msgs::Transform>( "cup_tf", 10 );

  tf::Transform tf_s (tf::Transform(tf::Quaternion(tf::Vector3(0.3,0.5,0.8), 0.9),tf::Vector3(-0.208,0.02,-0.13)));

  std::vector<yf_vacuum_cups::cup_dim> v_cup_dim_;
  yf_vacuum_cups::cup_dim cup_dim_ ;
  cup_dim_.radius = 0.0125;	cup_dim_.lengthen = 0.0;	cup_dim_.bellows = 3.0;		cup_dim_.stroke = 3.0;		cup_dim_.bend = 1;
  v_cup_dim_.push_back(cup_dim_);	
  cup_dim_.radius = 0.015;	cup_dim_.lengthen = 0.030;	cup_dim_.bellows = 1.5;		cup_dim_.stroke = 0.008;	cup_dim_.bend = 1;
  v_cup_dim_.push_back(cup_dim_);	
  
  
  
  geometry_msgs::Transform tf_cup_;
   tf::transformTFToMsg(tf_s, tf_cup_);
//  tf_cup_.header.frame_id = "/camera_link";
  
    bag.write("cup_msg", ros::Time::now(), cup_dim_);
    
    bag.close();
  
  while (ros::ok())
  {
  
    pub_cup.publish(cup_dim_);
    pub_tf.publish(tf_cup_);
    
    r.sleep();

  }
}