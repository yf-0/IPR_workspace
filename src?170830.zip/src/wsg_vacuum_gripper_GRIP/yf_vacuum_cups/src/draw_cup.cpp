#include <ros/ros.h>
#include "std_msgs/String.h"
#include <visualization_msgs/Marker.h>
#include <cmath>

#include <tf/LinearMath/Vector3.h>
#include <tf/transform_datatypes.h>

#include <sstream>
#include <iostream>
#include <yf_vacuum_cups/cup_dim.h>

int
main (int argc, char** argv)
{ 
  std::cerr << "draw cups" << std::endl;

  ros::init (argc, argv, "cup_vis");
  ros::NodeHandle nh; 
  ros::Rate r(20);
  
  ros::Publisher vis_pub = nh.advertise<visualization_msgs::Marker>( "cup_vis", 10 );

  yf_vacuum_cups::cup_dim cup_dim_;
  tf::Transform tf_cup_;

  float f = 0.0;
  while (ros::ok())
  {
    
    visualization_msgs::Marker points, line_strip, line_list;
    visualization_msgs::Marker disk_on, disk_bk, point_c, dir_suck, outline_on, outline_bk;
    
//     points.header.frame_id = line_strip.header.frame_id = line_list.header.frame_id = "/camera_link";
    points.header.stamp = line_strip.header.stamp = line_list.header.stamp = ros::Time::now();
    points.ns = line_strip.ns = line_list.ns = "points_and_lines";
    points.action = line_strip.action = line_list.action = visualization_msgs::Marker::ADD;
    points.pose.orientation.w = line_strip.pose.orientation.w = line_list.pose.orientation.w = 1.0;

    disk_on.header.frame_id 	= disk_bk.header.frame_id 	= point_c.header.frame_id 	= dir_suck.header.frame_id
				= outline_on.header.frame_id	= outline_bk.header.frame_id					= "/camera_link";
    disk_on.header.stamp 	= disk_bk.header.stamp 		= point_c.header.stamp 		= dir_suck.header.stamp	
				= outline_on.header.stamp	= outline_bk.header.stamp					= ros::Time::now();
    disk_on.ns 			= disk_bk.ns 			= point_c.ns 			= dir_suck.ns	
				= outline_on.ns 		= outline_bk.ns 						= "sucker";
    disk_on.action 		= disk_bk.action 		= point_c.action 		= dir_suck.action	
				= outline_on.action		= outline_bk.action						= visualization_msgs::Marker::ADD;
    disk_on.pose.orientation.w 	= disk_bk.pose.orientation.w 	= point_c.pose.orientation.w 	= dir_suck.pose.orientation.w
				= outline_on.pose.orientation.w	= outline_bk.pose.orientation.w   				= 1.0;
    


    points.id = 0;
    line_strip.id = 1;
    line_list.id = 2;
    disk_on.id = 3;
    disk_bk.id = 4;
    point_c.id = 5;
    dir_suck.id = 6;
    outline_on.id = 7;
    outline_bk.id = 8;

    points.type = visualization_msgs::Marker::POINTS;
    line_strip.type = visualization_msgs::Marker::LINE_STRIP;
    line_list.type = visualization_msgs::Marker::LINE_LIST;   
    
    point_c.type = visualization_msgs::Marker::POINTS;


    // POINTS markers use x and y scale for width/height respectively
    points.scale.x = 0.2;
    points.scale.y = 0.2;

    // LINE_STRIP/LINE_LIST markers use only the x component of scale, for the line width
    line_strip.scale.x = 0.1;
    line_list.scale.x = 0.1;

    // Points are green
    points.color.g = 1.0f;
    points.color.a = 1.0;

    // Line strip is blue
    line_strip.color.b = 1.0;
    line_strip.color.a = 0.4;

    // Line list is red
    line_list.color.r = 1.0;
    line_list.color.a = 0.6;

    
    
    
    geometry_msgs::Pose pose1, pose2;    	//Point position Quaternion orientation
    geometry_msgs::Point pp;  
    float xx,yy,zz, rx,ry,rz;	//  center point position 3d and orientation vector 3d
    pp.x = pp.y = pp.z = 0;
    rx = ry = 0; rz = 1;
    
    
    
    pose1.position = pp;
    tf::Transform tf_d1, tf_d2, tf_bk;
    tf::Transform tf_s (tf::Quaternion(0,0,0,1),tf::Vector3(0,0,-0.01));
    //tf_bk.setOrigin(tf::Vector3(0,0,-0.003));
    tf_bk = tf::Transform(tf::Quaternion(0,0,0,1),tf::Vector3(0,0,-0.01));
    //tf_d1 = tf::Transform(tf::Quaternion(tf::Vector3(1,1,0), 0.5),tf::Vector3(0,0,0));
    //tf_d1.setOrigin(tf::Vector3(0,0,0.0));
    //tf_d1.setRotation( tf::Quaternion(tf::Vector3(1,1,0), 0.5));
    
    
    disk_on.type = visualization_msgs::Marker::CYLINDER;
    disk_on.scale.x = 0.025;	disk_on.scale.y = 0.025; 	disk_on.scale.z = 0.01;
    disk_on.color.r = 0.0;	disk_on.color.g = 0.0;	disk_on.color.b = 0.6;	disk_on.color.a = 0.5;
    
    disk_bk.type = visualization_msgs::Marker::CYLINDER;
    disk_bk.scale.x = 0.2;	disk_bk.scale.y = 0.2;	disk_bk.scale.z = 0.01;		
    disk_bk.color.r = 0.0;	disk_bk.color.g = 0.5;	disk_bk.color.b = 0.9;	disk_bk.color.a = 0.5;
    
    outline_on.type = visualization_msgs::Marker::LINE_STRIP;
    outline_on.scale.x = 0.003;			
    outline_on.color.r = 0.0;	outline_on.color.g = 0.5;	outline_on.color.b = 0.9;	outline_on.color.a = 0.5;
    
    outline_bk.type = visualization_msgs::Marker::LINE_STRIP;
    outline_bk.scale.x = 0.003;			
    outline_bk.color.r = 0.0;	outline_bk.color.g = 0.0;	outline_bk.color.b = 0.6;	outline_bk.color.a = 0.5;
    
    dir_suck.type = visualization_msgs::Marker::ARROW;
    dir_suck.scale.x = 0.002;	dir_suck.scale.y = 0.006;	dir_suck.scale.z = 0.02;
    dir_suck.color.r = 1.0;	dir_suck.color.g = 0.8;		dir_suck.color.b = 0.0;		dir_suck.color.a = 0.8;
    
    
    tf::Vector3 v1(0.1, 0.2, 0.3);
    tf::Vector3 v12(+0.006, -0.19, -0.4);
    tf::Vector3 v2 = v1+v12;
    
    
    geometry_msgs::Point p1;
    p1.x = v1.x(); p1.y = v1.y(); p1.z = v1.z();
//    p1.x = 0.1; p1.y = 0.2; p1.z = 0.3;
    dir_suck.points.push_back(p1);
    
    
    geometry_msgs::Point p2;
    p2.x = v2.x(); p2.y = v2.y(); p2.z = v2.z();
//    p2.x = 0.13; p2.y = 0.07; p2.z = 0.4;
    dir_suck.points.push_back(p2);
    vis_pub.publish(dir_suck);
    
    tf::Vector3 vec_z(0.0, 0.0, 1.0);
    tf::Vector3 vec_right = v12.cross(vec_z);
    vec_right.normalize();
    tf::Quaternion q(vec_right, -1.0*acos(v12.dot(vec_z)/v12.length ())); //////////////////
    q.normalize();
    std::cout<<q.getAngle()*180/3.14;
    tf_d1 = tf::Transform(q,v1);
    
    tf::poseTFToMsg(tf_d1, pose1);
    disk_on.pose = pose1;
    vis_pub.publish(disk_on);
    
    tf_d2 = tf_d1*tf_bk;
    tf::poseTFToMsg(tf_d2, pose2);
    disk_bk.pose = pose2;
    vis_pub.publish(disk_bk);
      
    uint outline_pts;
    float cup_radius = 0.02;
    float cup_lengthen = 0.05;
    float cup_retreat = 0.004;
    
    float ii_density = 0.0035;
    uint i_round  = (int)(cup_radius*M_PI/ii_density);
    uint i_length = (int)(cup_lengthen/ii_density);		// in x direction
    
    std::cout << i_round << " in " << cup_radius << std::endl;
    std::cout << i_length << " in " << cup_lengthen << std::endl;
      
    geometry_msgs::Point p;
    p.z = 0.1;
    for (uint32_t i = 0; i <= i_round; i++)    {  
      p.x = cup_radius * sin(M_PI * i / i_round) + 0.5*cup_lengthen;
      p.y = cup_radius * cos(M_PI * i / i_round);
      p.z = 0;
      outline_on.points.push_back(p);
      p.z = cup_retreat;
      outline_bk.points.push_back(p);
      //line_list.points.push_back(p);
      //points.points.push_back(p);
    }
    for (uint i = 0; i < i_length; i++)    {
      p.x = -cup_lengthen * i / i_length + 0.5*cup_lengthen;
      p.y = -cup_radius;
      p.z = 0;
      outline_on.points.push_back(p);
      p.z = cup_retreat;
      outline_bk.points.push_back(p);
      //line_list.points.push_back(p);  
      //points.points.push_back(p);    
    }
    for (uint32_t i = 0; i <= i_round; i++)    {
      p.x = cup_radius * sin(M_PI * i / i_round+M_PI) - 0.5*cup_lengthen;
      p.y = cup_radius * cos(M_PI * i / i_round+M_PI);
      p.z = 0;
      outline_on.points.push_back(p);
      p.z = cup_retreat;
      outline_bk.points.push_back(p);
      //line_list.points.push_back(p);
      //points.points.push_back(p);
    }
    for (uint i = 0; i < i_length; i++)    {
      p.x = cup_lengthen * i / i_length - 0.5*cup_lengthen;
      p.y = cup_radius;
      p.z = 0;
      outline_on.points.push_back(p);
      p.z = cup_retreat;
      outline_bk.points.push_back(p);
      //line_list.points.push_back(p); 
      //points.points.push_back(p);     
    }
    p.x = 0.5*cup_lengthen;
    p.y = cup_radius;
    p.z = 0;
    outline_on.points.push_back(p);
    p.z = cup_retreat;
    outline_bk.points.push_back(p);
      //points.points.push_back(p);
    
    vis_pub.publish(outline_on);
    vis_pub.publish(outline_bk);


    //vis_pub.publish(points);
    //vis_pub.publish(line_strip);
    //vis_pub.publish(line_list);
    r.sleep();

  }
}