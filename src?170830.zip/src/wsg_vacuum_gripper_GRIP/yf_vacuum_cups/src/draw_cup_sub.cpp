#include <ros/ros.h>
#include "std_msgs/String.h"
#include <visualization_msgs/Marker.h>
#include <cmath>

#include <tf/LinearMath/Vector3.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>

#include <sstream>
#include <iostream>
#include <yf_vacuum_cups/cup_dim.h>
#include <yf_vacuum_cups/msg_cup_draw.h>



class sub_cup_draw_msg
{

  private:
    ros::NodeHandle n_;
//     std::vector<ros::Publisher> pub_each;
    ros::Publisher pub_one;
    ros::Subscriber sub_;
    
    yf_vacuum_cups::msg_cup_draw draw_msg_;
    visualization_msgs::Marker dir_suck, disk_on, disk_bk, point_c, outline_on, outline_bk;
    
  public:
    sub_cup_draw_msg()
    {
      std::cerr << "sub_cup_draw_msg initialized : " << std::endl;
      //Topic you want to publish
      

      //Topic you want to subscribe
//      sub_ = n_.subscribe("/seg_plane_array", 1, &sub_cupmsg_tf_draw::callback, this);
      sub_ = n_.subscribe("/cup_draw", 20, &sub_cup_draw_msg::callback, this);
    
    }
    
    void callback(const yf_vacuum_cups::msg_cup_draw &msg)
    {
      uint id (msg.cupId);
      std::string NameSeg2;
      NameSeg2 = ("/cup_draw/Markers/" + std::to_string(id));
      
//       if (pub_each.size()<id+1)
// 	pub_each.resize (id+1, n_.advertise<visualization_msgs::Marker>(NameSeg2, 8, false));
//       else
// 	pub_each[id] = n_.advertise<visualization_msgs::Marker>(NameSeg2, 8, false);
    pub_one = n_.advertise<visualization_msgs::Marker>(NameSeg2, 8, false);
    
    // ini all Maker elements
    visualization_msgs::Marker 	dir_suck,	// sucking direction, z axis 
				disk_bd, 	// bend
				disk_sc, 	// screw
				point_c, 	// ehhhh
				outline_on, 	// original contact rim
				outline_bk;	// contact rim retreated (stroke)
      
    disk_bd.header.frame_id 	= disk_sc.header.frame_id 	= point_c.header.frame_id 	= dir_suck.header.frame_id
				= outline_on.header.frame_id	= outline_bk.header.frame_id					= msg.transformstamped.child_frame_id;
    ROS_INFO_STREAM( msg.transformstamped.child_frame_id);
    disk_bd.header.stamp 	= disk_sc.header.stamp 		= point_c.header.stamp 		= dir_suck.header.stamp	
				= outline_on.header.stamp	= outline_bk.header.stamp					= ros::Time::now();
    disk_bd.ns 			= disk_sc.ns 			= point_c.ns 			= dir_suck.ns	
				= outline_on.ns 		= outline_bk.ns 						= "sucker";
    disk_bd.action 		= disk_sc.action 		= point_c.action 		= dir_suck.action	
				= outline_on.action		= outline_bk.action						= visualization_msgs::Marker::MODIFY; //ADD
//    disk_bd.pose.orientation.w 	= disk_sc.pose.orientation.w 	= point_c.pose.orientation.w 	= dir_suck.pose.orientation.w
//				= outline_on.pose.orientation.w	= outline_bk.pose.orientation.w   				= 1.0;
    
    dir_suck.id = 0;	disk_bd.id = 1;		disk_sc.id = 2;	
    point_c.id = 3;	outline_on.id = 4;	outline_bk.id = 5;
    
    // input tf from msg
    tf::Transform msg_tf; msg_tf.setIdentity();
    //tf::transformMsgToTF(msg.transformstamped.transform, msg_tf);
    
    float radius ;
    float diameter ;
    float lengthen ;
    float height ;
    float stroke ;
    float minCurvR ;
    float bellows ;
    float bend ;
    std::string name;
    
    ros::NodeHandle priv_nh("~");
    
    if (msg.cupN == 0)
    {  
      ROS_INFO_STREAM("use cup dim from srv input") ;
      radius 	= msg.radius;
      lengthen	= msg.lengthen;
      height	= msg.height;
      stroke 	= msg.stroke;
      minCurvR	= msg.minCurvR;
      bellows 	= msg.bellows;
      bend 	= msg.bend;
    }
    else
    {
      std::string s_param = ("/cups/" + std::to_string(msg.cupN));
      if (	priv_nh.getParam(s_param+"/name",   name)
	    && 	priv_nh.getParam(s_param+"/radius", radius)
	    && 	priv_nh.getParam(s_param+"/lengthen", lengthen)
	    && 	priv_nh.getParam(s_param+"/height", height)
	    && 	priv_nh.getParam(s_param+"/stroke", stroke)
	    && 	priv_nh.getParam(s_param+"/minCurvR", minCurvR)
	    && 	priv_nh.getParam(s_param+"/bellows", bellows)
	    && 	priv_nh.getParam(s_param+"/bend", bend)) 
	ROS_INFO_STREAM("@ '"<<NameSeg2<<"' + '"<<s_param<<"'");
      else
      {
	ROS_INFO_STREAM("@ '"<<NameSeg2<<"' + '"<< s_param <<"' failed") ;
	radius 	= 0.01;
	lengthen= 0.00;
	height	= 0.01;
	stroke 	= 0.05;
	minCurvR= 0.04;
	bellows = 0.00;
	bend 	= 0.05;
	
      }
    }
    diameter 	= 2.0*radius;
      
    // set up all Maker elements
    dir_suck.type = visualization_msgs::Marker::ARROW;
    dir_suck.scale.x = 0.03;	dir_suck.scale.y = 0.0015;	dir_suck.scale.z = 0.0015;
    dir_suck.color.r = 1.0;	dir_suck.color.g = 0.8;		dir_suck.color.b = 0.0;		dir_suck.color.a = 0.8;
    
    disk_bd.type = visualization_msgs::Marker::CYLINDER;
    disk_bd.scale.x = diameter;	disk_bd.scale.y = diameter; 	disk_bd.scale.z = 0.001;
    disk_bd.color.r = 0.0;	disk_bd.color.g = 0.0;		disk_bd.color.b = 0.6;		disk_bd.color.a = 0.7;
    
    disk_sc.type = visualization_msgs::Marker::CYLINDER;
    disk_sc.scale.x = 0.01;	disk_sc.scale.y = 0.01; 	disk_sc.scale.z = 0.01;		
    disk_sc.color.r = 0.8;	disk_sc.color.g = 0.8;		disk_sc.color.b = 0.9;		disk_sc.color.a = 0.5;
    
    outline_on.type = visualization_msgs::Marker::LINE_STRIP;
    outline_on.scale.x = 0.003;			
    outline_on.color.r = 0.0;	outline_on.color.g = 0.0;	outline_on.color.b = 0.6;	outline_on.color.a = 0.7;
    
    outline_bk.type = visualization_msgs::Marker::LINE_STRIP;
    outline_bk.scale.x = 0.003;			
    outline_bk.color.r = 0.0;	outline_bk.color.g = 0.4;	outline_bk.color.b = 0.8;	outline_bk.color.a = 0.7;

    
    tf::Transform x2z (tf::Quaternion(tf::Vector3(0,1,0),M_PI_2),tf::Vector3(0,0,0));
    geometry_msgs::Pose pose0,pose1, pose2;
    //tf::Transform tf_n (msg_tf*x2z);
    //tf::Transform tf_d1 (msg_tf);
//    tf::Transform tf_d2 (tf::Quaternion(0,0,0,1),tf::Vector3(0,0,0));
    tf::Transform tf_height (tf::Quaternion(0,0,0,1),tf::Vector3(0,0,-(height-0.5*disk_sc.scale.z)));
    tf::Transform tf_bend (tf::Quaternion(0,0,0,1),tf::Vector3(0,0,-bend));
	  
    tf::poseTFToMsg(x2z, pose0);
    dir_suck.pose = pose0;
    
    tf_bend = tf_bend;
    tf::poseTFToMsg(tf_bend, pose1);
    disk_bd.pose = pose1;
    
    tf_height = tf_height;
    tf::poseTFToMsg(tf_height, pose2);
    disk_sc.pose = pose2;
      
    
    float ii_density = 0.0035;
    
    uint i_round  = (int)(radius*M_PI/ii_density);
    uint i_length = (int)(lengthen/ii_density);
    
    tf::Point v3_p;
    geometry_msgs::Point p;
    for (uint32_t i = 0; i <= i_round; i++)    {  
      v3_p.setValue ( radius * sin(M_PI * i / i_round) + 0.5*lengthen,
		      radius * cos(M_PI * i / i_round),
		      0);
      tf::pointTFToMsg(v3_p, p);
      
      outline_on.points.push_back(p);
      v3_p.setZ(-stroke);
      tf::pointTFToMsg(v3_p, p);
      outline_bk.points.push_back(p);
      //line_list.points.push_back(p);
      //points.points.push_back(p);
    }
    for (uint i = 0; i < i_length; i++)    {
      v3_p.setValue ( -lengthen * i / i_length + 0.5*lengthen,
		      -radius,
		      0);
      tf::pointTFToMsg(v3_p, p);
      outline_on.points.push_back(p);
      v3_p.setZ(-stroke);
      tf::pointTFToMsg(v3_p, p);
      outline_bk.points.push_back(p);
      //line_list.points.push_back(p);  
      //points.points.push_back(p);    
    }
    for (uint32_t i = 0; i <= i_round; i++)    {      
      v3_p.setValue ( radius * sin(M_PI * i / i_round+M_PI) - 0.5*lengthen,
		      radius * cos(M_PI * i / i_round+M_PI),
		      0);
      tf::pointTFToMsg(v3_p, p);
      outline_on.points.push_back(p);
      v3_p.setZ(-stroke);
      tf::pointTFToMsg(v3_p, p);
      outline_bk.points.push_back(p);
      //line_list.points.push_back(p);
      //points.points.push_back(p);
    }
    for (uint i = 0; i < i_length; i++)    {
      v3_p.setValue ( lengthen * i / i_length - 0.5*lengthen,
		      radius,
		      0);
      tf::pointTFToMsg(v3_p, p);
      outline_on.points.push_back(p);
      v3_p.setZ(-stroke);
      tf::pointTFToMsg(v3_p, p);
      outline_bk.points.push_back(p);
      //line_list.points.push_back(p); 
      //points.points.push_back(p);     
    }
      v3_p.setValue ( 0.5*lengthen,
		      radius,
		      0);
      tf::pointTFToMsg(v3_p, p);
    outline_on.points.push_back(p);
      v3_p.setZ(-stroke);
      tf::pointTFToMsg(v3_p, p);
    outline_bk.points.push_back(p);
      //points.points.push_back(p);
    

    // publishing this cup
//     while(pub_each[id].getNumSubscribers()==0) {   ROS_ERROR("Waiting for subscibers"); sleep(10); }
    static tf::TransformBroadcaster br;
    geometry_msgs::TransformStamped tfs_(msg.transformstamped);
    tfs_.header.stamp = ros::Time::now();
    br.sendTransform(tfs_);
//     pub_each[id].publish(dir_suck);
//     pub_each[id].publish(disk_bd);
//     pub_each[id].publish(disk_sc);
//     pub_each[id].publish(outline_on);
//     pub_each[id].publish(outline_bk);
    pub_one.publish(dir_suck);
    pub_one.publish(disk_bd);
    pub_one.publish(disk_sc);
    pub_one.publish(outline_on);
    pub_one.publish(outline_bk);
    
    
    ros::spinOnce();
    
    }

};


int
main (int argc, char** argv)
{ 
  std::cerr << "drawing cup with tf." << std::endl;
  
  ros::init (argc, argv, "draw_cups_sub");
  
//  ros::NodeHandle nh;
//  ros::Subscriber sub1 = nh.subscribe("/seg_plane_array",4,pub_divided_topics);
    
  sub_cup_draw_msg SubObject;
  
  ros::spin();
  return (0);
}