#include <cmath>
#include <limits>
#include <iostream>
#include <string>
#include <boost/concept_check.hpp>

#include <ros/ros.h>
#include "std_msgs/String.h"
#include <std_msgs/Int32.h>

#include <tf/LinearMath/Vector3.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>

#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>

#include <boost/thread.hpp>

#include <actionlib/server/simple_action_server.h>
#include <yf_visualise/act_pub_cloudAction.h>

float frame_rate_g;
tf::TransformBroadcaster *br;

class pub_group
{
public:
  
  ros::Publisher Pub_cloud;
  sensor_msgs::PointCloud2 cloud_in;
  std::string topic_name;
  float frame_rate = 10;
  float life_span;
  int counter;
  tf::StampedTransform stf;
  
  
  pub_group()
  {}
  
  ~pub_group()
  {}
  
  pub_group(const yf_visualise::act_pub_cloudGoalConstPtr &goal)
  {
    ros::NodeHandlePtr nh_ = boost::make_shared<ros::NodeHandle>();
       
    topic_name = goal->topic_name.data;
    Pub_cloud = nh_->advertise<sensor_msgs::PointCloud2>(topic_name,7, true);
    cloud_in = goal->cloud_in;    
    life_span = goal->life_span;
    counter = (int)life_span;

    tf::transformStampedMsgToTF(goal->tfs_world2table, stf);
    if (stf.child_frame_id_.length()>0)
    {
      
      stf.stamp_ = ros::Time::now()/* + sleeper*/;
      br->sendTransform(stf);
      br->sendTransform(stf);
      br->sendTransform(stf);
    }    
  }
  
  char check_exist(const yf_visualise::act_pub_cloudGoalConstPtr &goal)
  {
    ros::NodeHandlePtr nh_ = boost::make_shared<ros::NodeHandle>();
     
    if (topic_name != goal->topic_name.data) return 0;
    
    std::cout << "\033[96m"" \treplace""\033[0m";
    
    Pub_cloud = nh_->advertise<sensor_msgs::PointCloud2>(topic_name,7, true);
    cloud_in = goal->cloud_in;    
    life_span = goal->life_span;
    counter = (int)life_span;    

    tf::transformStampedMsgToTF(goal->tfs_world2table, stf);
    if (stf.child_frame_id_.length()>0)
    {
//       tf::TransformBroadcaster br;
      stf.stamp_ = ros::Time::now()/* + sleeper*/;
      br->sendTransform(stf);
      br->sendTransform(stf);
      br->sendTransform(stf);
    }    
    return 1;
  }
  
  int publish()
  {
    ros::Duration sleeper(1.0/10);
    
    if (stf.child_frame_id_.length()>0)
    {
//       tf::TransformBroadcaster br;
      stf.stamp_ = ros::Time::now() + sleeper;
      br->sendTransform(stf);
    }
    
    cloud_in.header.stamp = ros::Time::now()/* + sleeper*/;
    Pub_cloud.publish(cloud_in);
      std::cout << "\n" << topic_name << "\t" <<counter <<"  "<<stf.child_frame_id_ ;
    counter --;

    sleeper.sleep();
//       std::cout<< "sleep done " <<"\n" ;
    return counter;
  }
  
  int wipe()
  {
    ros::Duration sleeper(1.0/frame_rate);
    cloud_in.data.clear();
    cloud_in.header.stamp = ros::Time::now()/* + sleeper*/;
    Pub_cloud.publish(cloud_in);
      ROS_WARN_STREAM("wipe " << topic_name);
    counter --;
//     	sleeper.sleep();
//       std::cout<< "sleep done " <<"\n" ;
    return counter;
  }
};

class pcl_pub_Action
{
protected:

//   ros::NodeHandle nh_;
  ros::NodeHandlePtr nh_ = boost::make_shared<ros::NodeHandle>();
  actionlib::SimpleActionServer<yf_visualise::act_pub_cloudAction> as_;
  std::string action_name_;
  // create messages that are used to published feedback/result
  yf_visualise::act_pub_cloudFeedback feedback_;
  yf_visualise::act_pub_cloudResult result_;
  ros::Subscriber sub_;
  
  std::vector <pub_group> v_pub_group;
  ros::Publisher Pub_cloud;
  sensor_msgs::PointCloud2 cloud_in;
  std::string topic_name;
  float frame_rate = frame_rate_g;
  float life_span;
  
  int I = 0;

public:

  pcl_pub_Action(std::string name) :
    as_(*nh_, name, false),
//     as_(nh_, name, boost::bind(&pcl_pub_Action::executeCB, this, _1), false),
    action_name_(name)
  {
    as_.registerGoalCallback(boost::bind(&pcl_pub_Action::executeCB, this));
    as_.registerPreemptCallback(boost::bind(&pcl_pub_Action::preemptCB, this));    
    sub_ = nh_->subscribe("/static_publisher_clock", 1, &pcl_pub_Action::runningCB, this);
    
    as_.start();
  }

  ~pcl_pub_Action(void)
  {
  }
  
  void preemptCB(/*const yf_visualise::act_pub_cloudGoalConstPtr &goal*/)
  {
//     ROS_INFO("%s: Preempted", action_name_.c_str());
    if(as_.isActive())
    {
      as_.setPreempted();
    }
    
  }
  
  void runningCB(const std_msgs::Int32::ConstPtr &msg)
  {
//     while (ros::ok() && v_pub_group.size()>0)
//     ROS_INFO(".");
//     for (uint I = 0; I < v_pub_group.size(); I++)
      
    {
      
      if (v_pub_group.size() > 0)
      {
	I = I % v_pub_group.size();
	if (v_pub_group[I].publish() == 0) 
	{
	  std::cout << "\033[93m"" \tdel""\033[0m";
	  v_pub_group.erase(v_pub_group.begin() + I);
	  I--;
	}
      }
      I++;
    }    
  }
    
  void executeCB(/*const yf_visualise::act_pub_cloudGoalConstPtr &goal*/)
  {
    
//     ROS_INFO("executeCB");
//     if (std::find(v_topic_name.begin(), v_topic_name.end(), goal->topic_name.data) != v.end())
    auto goal = as_.acceptNewGoal();
    if (goal->topic_name.data == "~")
    {
//       ROS_ERROR_STREAM( "publisher cleared");
      for (uint i = 0; i < v_pub_group.size(); i++)
      {
	v_pub_group[i].wipe();
      }
      
      v_pub_group.clear();   
      as_.setSucceeded(result_);
      return;
    }
    
    {
      uint existed = 0;
      for (uint i = 0; i < v_pub_group.size(); i++)
      {
	existed += v_pub_group[i].check_exist(goal);
      }
      
      if (existed == 0)
      {
	  std::cout << "\033[94m"" \tnew""\033[0m";
	v_pub_group.push_back(pub_group(goal));
      }
    }
/*   
    std::cout << ".";
    for (uint i = 0; i < v_pub_group.size(); i++)
    {
      if(!as_.isActive())break;
      
      if (as_.isPreemptRequested() || !ros::ok())
      {
        ROS_INFO("%s: Preempted", action_name_.c_str());
        as_.setPreempted();
//         success = false;
        break;
      }
      
      if (v_pub_group[i].publish() == 0) 
      {
	ROS_WARN("del one");
	v_pub_group.erase(v_pub_group.begin() + i);
	i--;
      }
 
      ros::Duration(1.0/frame_rate).sleep();
//       ros::Duration(0.50).sleep();
    }    */
   
//     if(true)
//     {
//       ROS_WARN_STREAM( topic_name << "publish ends");
//       as_.setSucceeded(result_);
//     }
  }


};


int main(int argc, char** argv)
{
  
  ros::init(argc, argv, "static_PC_PubAction");
  std::cerr << ros::this_node::getName() <<  " init " << std::endl;
  
  
  ros::NodeHandle priv_nh("~");
  if (priv_nh.getParam ("frame_rate", frame_rate_g)) {}
  br = new tf::TransformBroadcaster();

  pcl_pub_Action Actioner(ros::this_node::getName());
  ROS_INFO("static_PointCloud_PubSrv set...");
  ros::spin();

  return 0;
}
