#include <cmath>
#include <limits>
#include <iostream>
#include <typeinfo>
#include <iomanip>
#include <ctime>

#include <ros/ros.h>
#include <std_msgs/Int32.h>

int
main (int argc, char** argv)
{
  ros::init (argc, argv, "clock", ros::init_options::AnonymousName);
  ros::NodeHandle nh("~");
  ros::Publisher pub_ = nh.advertise<std_msgs::Int32>("/static_publisher_clock", 1,true);
  
  float rate = 10;
  
  if (nh.getParam ("rate", rate)) {}
  
  ros::Rate Rate(rate);
  
  std_msgs::Int32 msg; 
  msg.data = 0;

  while (ros::ok())
  {
    pub_.publish(msg);
    Rate.sleep();
  }
  
  
  ros::spin();
  
  return (1);
}