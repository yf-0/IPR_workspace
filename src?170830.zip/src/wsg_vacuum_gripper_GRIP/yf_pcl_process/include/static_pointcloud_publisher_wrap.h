#include <cmath>
#include <limits>
#include <iostream>
#include <string>
#include <boost/concept_check.hpp>

#include <ros/ros.h>
#include "std_msgs/String.h"

#include <tf/LinearMath/Vector3.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>

#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>

#include <boost/thread.hpp>

#include <yf_visualise/act_pub_cloudAction.h>


bool static_PointCloud_publish_tf (std::string name_, pcl::PointCloud<pcl::PointXYZ>::ConstPtr cloud, tf::StampedTransform stf_w2t, std::string frame_id = "", float life_span_ = 300.0)
{
//     ros::NodeHandle nh("~");
    actionlib::SimpleActionClient<yf_visualise::act_pub_cloudAction> ac("static_PC_PubAction", true);
    
//     ROS_INFO("Waiting for action server to start.");
    // wait for the action server to start
    ac.waitForServer(ros::Duration(1.0)); //will wait for infinite time

//     ROS_INFO("Action server started, sending goal.");
    // send a goal to the action
    yf_visualise::act_pub_cloudGoal goal;
    goal.topic_name.data = name_;
    goal.life_span = life_span_;
    tf::transformStampedTFToMsg(stf_w2t, goal.tfs_world2table);
    pcl::toROSMsg(*cloud, goal.cloud_in);
    if (frame_id.length() != 0) goal.cloud_in.header.frame_id = frame_id;
    ac.sendGoal(goal);

    //wait for the action to return
//     ros::Duration(5.5).sleep();
//     ac.cancelGoal();
    
//     bool finished_before_timeout = ac.waitForResult(ros::Duration(1.0));

//     if (finished_before_timeout)
//     {
//       actionlib::SimpleClientGoalState state = ac.getState();
//       ROS_INFO("Action finished: %s",state.toString().c_str());
//     }
//     else
//     {
//       actionlib::SimpleClientGoalState state = ac.getState();
//       ROS_INFO("Action did not finish before the time out.");
//       ROS_INFO("Action not finished: %s",state.toString().c_str());
//     }
    
    
}

bool static_PointCloud_publish_tf (std::string name_, pcl::PointCloud<pcl::PointXYZI>::ConstPtr cloud, tf::StampedTransform stf_w2t, std::string frame_id = "", float life_span_ = 300.0)
{
//     ros::NodeHandle nh("~");
    actionlib::SimpleActionClient<yf_visualise::act_pub_cloudAction> ac("static_PC_PubAction", true);
    
//     ROS_INFO("Waiting for action server to start.");
    // wait for the action server to start
    ac.waitForServer(ros::Duration(1.0)); //will wait for infinite time

//     ROS_INFO("Action server started, sending goal.");
    // send a goal to the action
    yf_visualise::act_pub_cloudGoal goal;
    goal.topic_name.data = name_;
    goal.life_span = life_span_;
    tf::transformStampedTFToMsg(stf_w2t, goal.tfs_world2table);
    pcl::toROSMsg(*cloud, goal.cloud_in);
    if (frame_id.length() != 0) goal.cloud_in.header.frame_id = frame_id;
    ac.sendGoal(goal);

    //wait for the action to return
//     ros::Duration(5.5).sleep();
//     ac.cancelGoal();
    
//     bool finished_before_timeout = ac.waitForResult(ros::Duration(1.0));

//     if (finished_before_timeout)
//     {
//       actionlib::SimpleClientGoalState state = ac.getState();
//       ROS_INFO("Action finished: %s",state.toString().c_str());
//     }
//     else
//     {
//       actionlib::SimpleClientGoalState state = ac.getState();
//       ROS_INFO("Action did not finish before the time out.");
//       ROS_INFO("Action not finished: %s",state.toString().c_str());
//     }
    
    
}


bool static_PointCloud_publish (std::string name_, pcl::PointCloud<pcl::PointXYZ>::ConstPtr cloud, std::string frame_id = "", float life_span_ = 37.0)
{
  tf::StampedTransform stf;
  static_PointCloud_publish_tf (name_, cloud, stf, frame_id , life_span_);
}
