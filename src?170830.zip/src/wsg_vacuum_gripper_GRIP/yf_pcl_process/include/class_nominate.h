#include <cmath>
#include <limits>
#include <iostream>

#include <ros/ros.h>
#include <rosbag/bag.h>
#include <rosbag/view.h>

#include <visualization_msgs/Marker.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>

#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/project_inliers.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/search/search.h>
#include <pcl/search/kdtree.h>
#include <pcl/search/organized.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/features/integral_image_normal.h>
#include "pcl_ros/transforms.h"
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/extract_polygonal_prism_data.h>
#include <pcl/segmentation/region_growing.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl/surface/concave_hull.h>
#include <pcl/segmentation/organized_multi_plane_segmentation.h>
#include <pcl/segmentation/organized_connected_component_segmentation.h>
#include <pcl/segmentation/planar_region.h>
#include <pcl/segmentation/comparator.h>
#include <pcl/impl/point_types.hpp>

#include <tf/LinearMath/Vector3.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <tf_conversions/tf_eigen.h>

#include <Eigen/Core> 
#include <Eigen/Geometry> 
#include <Eigen/SVD>
#include <Eigen/Dense>

#include <yf_vacuum_cups/cup_dim.h>
#include <yf_vacuum_cups/srv_draw_cup.h>
#include <yf_vacuum_cups/msg_cup_draw.h>
#include <yf_pcl_process/msg_Grip.h>



class nominate// : public yf_VacuumGripScene
{
  private:
    const float f_nan = NAN;
    const pcl::PointXYZ PointXYZ_nan = pcl::PointXYZ(NAN,NAN,NAN);
    const float rad2deg = 180/M_PI, deg2rad = M_PI/180;
    const tf::Point v3_000 = tf::Point(0,0,0);
    const tf::Point v3_100 = tf::Point(1,0,0);
    const tf::Point v3_010 = tf::Point(0,1,0);
    const tf::Point v3_001 = tf::Point(0,0,1);
    const tf::Quaternion q_u = tf::Quaternion(0,0,0,1);
    const tf::Transform tf_u = tf::Transform(q_u, v3_000);    

  public:
    
    yf_VacuumGripScene *V_Scene_lc;
    
    float resolution_projection = 0.005; // in meter, 0.002 ~>2mm
    
    nominate()
    { 
    };
    
    nominate(yf_VacuumGripScene *V_)
    {
//       this->cloud = V_.cloud;
//       this->normals = V_.normals;
//       this->cloud_with_normals = V_.cloud_with_normals;
//       this->cloud_border = V_.cloud_border;
//       this->cloud_inlander = V_.cloud_inlander;
//       this->idx_valid = V_.idx_valid;
//       this->idx_border = V_.idx_border;
//       this->idx_inlander = V_.idx_inlander;
// 
//       this->massCenter = V_.massCenter;
//       this->stf_Table2Tool = V_.stf_Table2Tool;
//       
//       this->v_stf_Tool2CupBases = V_.v_stf_Tool2CupBases;
//       this->v_cup_dim_N = V_.v_cup_dim_N;
//       this->v_cup_dim = V_.v_cup_dim;
//       
// 
//       this->NSphere_viewAngles = V_.NSphere_viewAngles;
//       this->NSphere_viewAngles_stf = V_.NSphere_viewAngles_stf;
      V_Scene_lc = V_;	
      V_Scene_lc->init_v_stf_Tool2CupBases();
    };
    
    class iterator_O
    {
      public:
	float phy;	// atan2(dy,dx) slope of the two points
	int dx, dy;	// vector of p1p2, x2-x1,y2-y1
	float cosP, sinP;
	float dx05, dy05;    
	
	iterator_O(float _phy, int _dx, int _dy, float _cosP, float _sinP): phy(_phy), dx(_dx), dy(_dy), cosP(_cosP), sinP(_sinP)
	{
	  dx05 = 0.5*dx;	  dy05 = 0.5*dy;
	}
	
	iterator_O(int _dx, int _dy): dx(_dx), dy(_dy)
	{
	  phy = atan2(dy, dx);
	  cosP = cos(phy);	  sinP = sin(phy);
	  dx05 = 0.5*dx;	  dy05 = 0.5*dy;
	}      
    };
    
    float cfgY, cfgZ, cfgX_max, cfgX_min;
    std::vector<iterator_O> nominate__v_iterator_O ;	// iterate half a circle
    
    class pair_by_iterator
    {
      public:
	uint itX;	// iterator
	float mx, my;	// vector of p1p2, x2-x1,y2-y1
	float d0M_pl;	// distance from (0,0) to perpendicular bisector (folding line)
	float d0M_pd;	// distance from (0,0) to the line p1p2
	uint xy1, xy2;
	
	pair_by_iterator(uint _itX, iterator_O it, int _ix1, int _iy1, uint _xy1, uint _xy2): itX(_itX), xy1(_xy1), xy2(_xy2)
	{
	  mx = it.dx05+_ix1;	my = it.dy05+_iy1;
	  d0M_pl = it.cosP*mx + it.sinP*my;
	  d0M_pd = -it.sinP*mx + it.cosP*my;
	}
    };
    
    uint nominate__set_v_iterator_O(float cfgY, std::vector<iterator_O> &v_iterator_O)
    {
      float R = cfgY/resolution_projection;
            
      float dt = asin(0.5/R);
      float theta(0.0);

      float dxx, dyy;

      v_iterator_O.clear();
#if 0
            
      int dx_c = 32767, dy_c = 32767;
      int dx_cc, dy_cc;
      int dx_f = 32767, dy_f = 32767;
      int dx_ff, dy_ff;
      
      while (theta < M_PI)
      {
	dxx = R*cos(theta); dyy = R*sin(theta);
	
	dx_cc = (dxx>=0)?ceil(dxx):floor(dxx);	
	dy_cc = (dyy>=0)?ceil(dyy):floor(dyy);
	  
	if ((dx_cc != dx_c) || (dy_cc != dy_c))
	{
	  dx_c = dx_cc;
	  dy_c = dy_cc;
	  v_iterator_O.push_back(iterator_O(dx_c,dy_c));
	  std::cout<<dx_cc<<","<<dy_cc <<"\n";
	}
	
	dx_ff = (int)dxx;	dy_ff = (int)dyy; 
	if ((dx_ff != dx_f) || (dy_ff != dy_f))
	{
	  dx_f = dx_ff;
	  dy_f = dy_ff;
	  v_iterator_O.push_back(iterator_O(dx_f,dy_f));
	  std::cout<<dx_ff<<","<<dy_ff <<"\n";	  
	}
	
	theta += dt;
      }
#else
      int dx_r = 32767, dy_r = 32767;
      int dx_rr, dy_rr;
      while (theta < M_PI)
      {
	dxx = R*cos(theta); dyy = R*sin(theta);
	
	dx_rr = round(dxx);	
	dy_rr = round(dyy);
	if (dx_rr<0 && dy_rr==0) break;
	if ((dx_rr != dx_r) || (dy_rr != dy_r))
	{
	  dx_r = dx_rr;
	  dy_r = dy_rr;
	  v_iterator_O.push_back(iterator_O(dx_r,dy_r));
//  	  std::cout<<dx_r<<","<<dy_r <<"\n";	  
	  
	}
	
	theta += dt;
      }
#endif
//       std::cout<<"v_iteratorO with "<< v_iterator_O.size() <<" vectors \n";	
    }
           
    uint get_ProjectplainMapPcl (uint viewAngleN, pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_Pjr, float threathhold_angle = M_PI/18)	// returns an image of projected points with samilar normals to normal on normalsphere
    {
//       ROS_INFO_STREAM(ros::Time::now()-V_Scene_lc->RosTimeBegin<<"   projection - "<<viewAngleN);
      if (viewAngleN >= V_Scene_lc->NSphere_viewAngles_stf.size()) 
      {
	cloud_Pjr->clear();
	return 0;
      }
      float threathhold_cos = cos(threathhold_angle);
      //resolution_projection; 
      tf::Quaternion qA (V_Scene_lc->NSphere_viewAngles_stf[viewAngleN].getRotation());
      tf::Point pA = tf::Transform(qA, v3_000) * -v3_001;
      
      tf::Transform tf_View (qA, V_Scene_lc->massCenter);
      tf::Transform oA (tf_View.inverse());
      
      
      std::vector< std::pair <int, int> > mapList;
      
      int mapXmin=32767,mapXmax=-32767,mapYmin=32767,mapYmax=-32767;
      float z_avg = 0; 
      for (size_t i : *(V_Scene_lc->idx_inlander))
      {
	pcl::Normal PN_pcl = V_Scene_lc->normals->points[i];
	tf::Point PN (PN_pcl.normal_x,PN_pcl.normal_y,PN_pcl.normal_z);
	if (tf::tfDot(PN,pA) > threathhold_cos)	// if angles are close	//////////////shall relate to cup_dim
	{ 
	  pcl::PointXYZ P_pcl = V_Scene_lc->cloud->points[i];
	  tf::Point P (P_pcl.x,P_pcl.y,P_pcl.z);
	  tf::Point xy = oA * P;
	  
	  int x = round(xy.x()/resolution_projection);
	  if (x < mapXmin) mapXmin = x;	  if (x > mapXmax) mapXmax = x;
	  int y = round(xy.y()/resolution_projection);
	  if (y < mapYmin) mapYmin = y;	  if (y > mapYmax) mapYmax = y;
	  
// 	  float z = xy.z();
// 	  if (z < z_avg) z_avg = z;
	  z_avg += xy.z();
	  
	  mapList.push_back(std::make_pair (x, y));
	}
      }
      std::cout << "xy projection:   Xmn "<< mapXmin<<"    Xmx "<< mapXmax<<"   Ymn "<< mapYmin<<"   Ymx "<<mapYmax<<"\n";

      z_avg = z_avg/mapList.size();
      tf::Transform tf_height = tf::Transform(q_u,z_avg*v3_001);
      tf_View *= tf_height;	pA = tf_View.getOrigin();
      V_Scene_lc->NSphere_viewAngles_stf[viewAngleN].setData(tf_View);
      
//       std::set< std::pair <int, int> > s ( mapList.begin(), mapList.end() );
//       mapList.assign( s.begin(), s.end() );
      
//       ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   projection - "<<viewAngleN << "   - reset viewangle");
      
      size_t count = 0;
      pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_Pj (new pcl::PointCloud<pcl::PointXYZ>);
      cloud_Pjr->clear();
      
      int Xs = (mapXmax-mapXmin+1), Ys = (mapYmax-mapYmin+1);
      cloud_Pj->width = Xs;	cloud_Pjr->width = Xs;
      cloud_Pj->height = Ys;	cloud_Pjr->height = Ys;
      
      for (size_t i = 0; i<Xs*Ys; i++) 
      {
	cloud_Pj->points.push_back(PointXYZ_nan);
	cloud_Pjr->points.push_back(PointXYZ_nan);
      }
      for (auto Pt :  mapList)
      {
	int xx (Pt.first-mapXmin), yy (Pt.second-mapYmin);
	if (isnan(cloud_Pj->at(xx, yy).x))
	{
	  pcl::PointXYZ Ppj(Pt.first*resolution_projection, Pt.second*resolution_projection,0);
	  cloud_Pj->points[yy*Xs+xx] = Ppj;
	  count ++;
	}
      }
      
      pcl::IndicesPtr pointIdxInander_pp (new std::vector <int>);
      
      for (int x = 1; x<Xs-1; x++)
      for (int y = 1; y<Ys-1; y++)
      {	 
	size_t i = y*Xs+x;
	if (!isnan(cloud_Pj->points[i].x))
	{
	  int i1 = i-1, i2 = i+1, i3 = i-Xs, i4 = i+Xs;
	  if (!isnan(cloud_Pj->points[i1].x)&&!isnan(cloud_Pj->points[i2].x)&&!isnan(cloud_Pj->points[i3].x)&&!isnan(cloud_Pj->points[i4].x))
	  {
	    pointIdxInander_pp->push_back(i);	
	    cloud_Pjr->points[i] = cloud_Pj->points[i];
	  } 
	}	
      }
      
      cloud_Pjr->sensor_origin_ = Eigen::Vector4f(pA.x(),pA.y(),pA.z(),1.0);
      cloud_Pjr->sensor_orientation_ = Eigen::Quaternionf(qA.w(),qA.x(),qA.y(),qA.z());
      cloud_Pjr->header.frame_id = "/table_frame";
//       *cloud_Pjr = *cloud_Pj;
      
       std::cout << "\033[1mprojected to viewAngle "<< viewAngleN << " : " << count << " points in "<<Xs <<" * " <<Ys<<" array\033[0m\n";
      
//       ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   projection - "<<viewAngleN << "   - fin");
      return mapList.size();
    }
    
    uint nominate__searchPairs(pcl::PointCloud<pcl::PointXYZ>::ConstPtr cloud_Pjr, std::vector<iterator_O> v_iterator_O, std::vector <pair_by_iterator> &v_Pairs)
    {
      uint W = cloud_Pjr->width, H = cloud_Pjr->height;
      v_Pairs.clear();
      
      for (size_t iy = 0; iy<H; iy++)
      for (size_t ix = 0; ix<W; ix++)
      {
	uint xy = ix + iy*W;
	if (isnan(cloud_Pjr->at(xy).x)) continue;
	  
	for (uint it = 0; it < v_iterator_O.size(); it++)
	{
	  auto iterator = v_iterator_O[it];
	  uint ix2 = ix+iterator.dx , iy2 = iy+iterator.dy;
	  if ((ix2<0)||(ix2>=W)||(iy2>=H)) continue;	// out of range
	  uint xy2 =  ix2 + iy2*W;
	  if (isnan(cloud_Pjr->at(xy2).x)) continue;
// 	  std::cout<<ix <<","<< iy <<" - "<< ix2 <<","<< iy2 <<"\n";	
	  v_Pairs.push_back(pair_by_iterator(it, iterator, ix, iy,xy,xy2));
	  
	}
      }
      
      std::sort(v_Pairs.begin(), v_Pairs.end(), [](pair_by_iterator P1, pair_by_iterator P2) 
	    { return (P1.itX < P2.itX); } );
    }
    
    uint nominate__find_RectPair(std::vector<iterator_O> v_iterator_O, std::vector <pair_by_iterator> v_Pairs, std::vector < std::pair <int, int> > &v_RectPair, float R, float cfgX_min, float cfgX_max)
    {
      v_RectPair.clear();
//       v_RectPair.push_back(std::make_pair(0,0));
      
      float X_min = cfgX_min/resolution_projection;
      float X_max = cfgX_max/resolution_projection;
      std::cout<< "X_min "<<X_min << "   cfgX_min "<<cfgX_min<<"\n";
      std::cout<< "X_max "<<X_max << "   cfgX_max "<<cfgX_max<<"\n";
      
      float theta_limit = 5.0*deg2rad;		// tolorrance of 5°
//       std::cout<<"theta_limit = "<<theta_limit*rad2deg<<"°\n";
      
      for (uint i1 = 0; i1 < v_Pairs.size(); i1++)
      {
	
// 	std::cout<<"\n Pr "<< i1 <<" has neibours : ";
	
	pair_by_iterator Pr1 = v_Pairs[i1];
	
	uint d0M_pd_min = i1, d0M_pd_max = i1;
	
	std::vector <uint> v_PairIdx_sort {i1};
	
	uint i2 = i1; 
	while (1)
	{
	  i2 = (i2 + 1)%v_Pairs.size();
	  pair_by_iterator Pr2 = v_Pairs[i2];
	  int d_itX = abs(Pr2.itX - Pr1.itX+v_iterator_O.size())%v_iterator_O.size();
	  if (d_itX > 1) break;	// it~it2 are the region with same phy

	  v_PairIdx_sort.push_back(i2);
	}	  // it~it2 are the region with similar phy
	
	uint i11 = (i2 > i1)?i2:32767;
	
	while (1)
	{
	  i2 = (i2 + 1)%v_Pairs.size();
	  pair_by_iterator Pr2 = v_Pairs[i2];
	  float d_phy = fmod((v_iterator_O[Pr2.itX].phy - v_iterator_O[Pr1.itX].phy + M_PI),M_PI);
	  if (d_phy > theta_limit) break;	// it~it2 are the region with similar phy*/
	  int d_itX = abs(Pr2.itX - Pr1.itX+v_iterator_O.size())%v_iterator_O.size();
	  if (d_itX > 2) break;	// it~it2 are the region with similar phy
// 	  std::cout << i2 <<" ";

 	    v_PairIdx_sort.push_back(i2);
	}	  // it~it2 are the region with similar phy
	
//  	std::cout <<v_iterator_O[ v_Pairs[v_PairIdx_sort.back()].itX].phy*rad2deg<<"°  " << v_PairIdx_sort.size()<<"\n";
	if (v_PairIdx_sort.size() < 2) continue;
	
	std::sort(  std::begin(v_PairIdx_sort), 
		    std::end(v_PairIdx_sort),
		    [&](int ii1, int ii2) { return v_Pairs[ii1].d0M_pl < v_Pairs[ii2].d0M_pl; } );    
	
// 	for (auto xx : v_PairIdx_sort) 	  std::cout << xx <<" ";
	
	// region i1~i2
	// looking for min-max pair-pairs (a rectangle)
	
	uint idx_pd_min = 0, idx_pd_max = 0;
	uint j1 = 0, j2 = 1;
	
	
	while (j2 < v_PairIdx_sort.size())
	{
	  const float j1_pl = v_Pairs[v_PairIdx_sort[j1]].d0M_pl;	  const float j2_pl = v_Pairs[v_PairIdx_sort[j2]].d0M_pl;
	  const float j1_pd = v_Pairs[v_PairIdx_sort[j1]].d0M_pd;	  const float j2_pd = v_Pairs[v_PairIdx_sort[j2]].d0M_pd;
	  
	  
	  if (j2_pl-j1_pl > 1)		// d0M_pl difference over 1 pixels, this region finished
	  {
	    
	    float dif_pd_minmax = fabs(v_Pairs[v_PairIdx_sort[idx_pd_max]].d0M_pd-v_Pairs[v_PairIdx_sort[idx_pd_min]].d0M_pd);
// 	    std::cout << "dif_pd_minmax "<< dif_pd_minmax <<"\n";
	    if (dif_pd_minmax > X_min)		// cfgX is big enough 
	    { 
// 	      std::cout << "\n************************ get new rectangle ************************\n";
	      if (v_RectPair.size() < 1) 
	      {
		v_RectPair.push_back(std::make_pair(v_PairIdx_sort[idx_pd_min], v_PairIdx_sort[idx_pd_max]));
	      }
	      else
	      {
		auto rt_back = v_RectPair.back();
		if (rt_back.first != v_PairIdx_sort[idx_pd_min] || rt_back.second != v_PairIdx_sort[idx_pd_max])	// if not already detected
		{
		  const float idx_min_phy= v_iterator_O[v_Pairs[v_PairIdx_sort[idx_pd_min]].itX].phy;
		  const float back_phy= v_iterator_O[v_Pairs[rt_back.first].itX].phy;
		  const bool phy_diff = fabs(back_phy - idx_min_phy) > M_PI/12.0;			// exclude those with similar phy
		  const float idx_min_pl = v_Pairs[v_PairIdx_sort[idx_pd_min]].d0M_pl;
		  const float back_pl = v_Pairs[rt_back.first].d0M_pl;
		  const bool d0M_pl_diff = fabs(back_pl - idx_min_pl) > 40;			// exclude those with similar d0M_pl
		  if (phy_diff || d0M_pl_diff/* || v_RectPair.size() <= 1*/) 						// if not similar -> nominate a new one	
		  {
		    v_RectPair.push_back(std::make_pair(v_PairIdx_sort[idx_pd_min], v_PairIdx_sort[idx_pd_max]));
  // 		  std::cout <<"     ["<< v_PairIdx_sort[idx_pd_min] <<" "<< v_PairIdx_sort[idx_pd_max] << "]\t"<<idx_min_phy*rad2deg<<"   "<<idx_min_pl<<"   "<<dif_pd_minmax<<"\n";		  
		  }
		  else									// if similar -> take the one with larger diff_pd
		  {
		    float dif_pd_back = v_Pairs[rt_back.second].d0M_pd-v_Pairs[rt_back.first].d0M_pd;
		    if (dif_pd_minmax > dif_pd_back)
		    {
		      v_RectPair.pop_back();
		      v_RectPair.push_back(std::make_pair(v_PairIdx_sort[idx_pd_min], v_PairIdx_sort[idx_pd_max]));
  // 		    std::cout <<"        {"<< v_PairIdx_sort[idx_pd_min] <<" "<< v_PairIdx_sort[idx_pd_max] << "}\t"<<idx_min_phy*rad2deg<<"   "<<idx_min_pl<<"   "<<dif_pd_minmax<<"\n";	
		    }
		  }
		}
	      }

	    }
	    
	    j1 ++;	// j1 = j2;
// 	    j1 = std::max(j1+1, std::min(idx_pd_min, idx_pd_max));
	    j2 = j1+1;
	    idx_pd_max = j1; 
	    idx_pd_min = j1; 
	  }
	  else 
	  {
	    if (j2_pd < v_Pairs[v_PairIdx_sort[idx_pd_min]].d0M_pd) idx_pd_min = j2;
	    if (j2_pd > v_Pairs[v_PairIdx_sort[idx_pd_max]].d0M_pd) idx_pd_max = j2;	  
	    j2++;
	  }
// 	  std::cout << j1 <<" "<< j2 << "\t";

	}
	
	if (i11>i1)	i1 = i11;
	else 		break;
      }    
      
      ////////////////////////////////////// all rectangles found
      
//       std::cout<<"\nall nominees:\n";
      std::sort(v_RectPair.begin(), v_RectPair.end(), [&](std::pair <int, int> P1, std::pair <int, int> P2) 
	    { return (v_Pairs[P1.second].d0M_pd-v_Pairs[P1.first].d0M_pd > v_Pairs[P2.second].d0M_pd-v_Pairs[P2.first].d0M_pd); } );
      for (auto it : v_RectPair) 
      {
	std::cout<<"   \033[93m["<<it.first<<" "<<it.second<< "]\t"<<v_Pairs[it.second].d0M_pd-v_Pairs[it.first].d0M_pd<<"\t"<< v_iterator_O[v_Pairs[it.second].itX].phy * rad2deg<<"°\033[0m\n";
      }
    }
    
    uint nominate__find_Triangles(pcl::PointCloud<pcl::PointXYZ>::ConstPtr cloud_Pjr, std::vector<iterator_O> v_iterator_O, std::vector <pair_by_iterator> v_Pairs, std::vector < std::pair <std::pair <int, int>, std::pair <int, int>> > &v_TriangleSet, float R, float cfgX_min, float cfgX_max)
    {
      v_TriangleSet.clear();
//       v_TriangleSet.push_back(std::make_pair(0,0));
      
      float X_min = cfgX_min/resolution_projection;
      float X_max = cfgX_max/resolution_projection;
      std::cout<< "X_min "<<X_min << "   cfgX_min "<<cfgX_min<<"\n";
      std::cout<< "X_max "<<X_max << "   cfgX_max "<<cfgX_max<<"\n";
    
      
      for (uint i1 = 0; i1 < v_Pairs.size(); i1++)
      {
	
// 	std::cout<<"\n Pr "<< i1 <<" has neibours : ";
	
	pair_by_iterator Pr1 = v_Pairs[i1];
	
	uint d0M_pd_min = i1, d0M_pd_max = i1;
	
	std::vector <uint> v_PairIdx_sort {i1};
	
	uint i2 = i1; 
	while (1)
	{
	  i2 = (i2 + 1)%v_Pairs.size();
	  pair_by_iterator Pr2 = v_Pairs[i2];
	  int d_itX = abs(Pr2.itX - Pr1.itX+v_iterator_O.size())%v_iterator_O.size();
	  if (d_itX > 2) break;	// it~it2 are the region with same phy

	  v_PairIdx_sort.push_back(i2);
	}	  // it~it2 are the region with similar phy
	
	uint i11 = (i2 > i1)?i2:32767;
	
  	std::cout << "   \033[93m" << v_iterator_O[ v_Pairs[v_PairIdx_sort.back()].itX].phy*rad2deg<<"°  " << v_PairIdx_sort.size()<<"\033[0m\n";
	if (v_PairIdx_sort.size() < 1) continue;
	
	std::sort(  std::begin(v_PairIdx_sort), 
		    std::end(v_PairIdx_sort),
		    [&](int ii1, int ii2) { return abs(v_Pairs[ii1].d0M_pd) < abs(v_Pairs[ii2].d0M_pd); } );    

	
	uint idx_pd_min = 0, idx_pd_max = 0;
	
	
	
	for (uint j1 = 0; j1 < v_PairIdx_sort.size(); j1++)
	{
	  const int x1_ = v_Pairs[v_PairIdx_sort[j1]].xy1 % cloud_Pjr->width;	  const int y1_ = floor( v_Pairs[v_PairIdx_sort[j1]].xy1 / cloud_Pjr->width );
	  const int x2_ = v_Pairs[v_PairIdx_sort[j1]].xy2 % cloud_Pjr->width;	  const int y2_ = floor( v_Pairs[v_PairIdx_sort[j1]].xy2 / cloud_Pjr->width );
	  const float j1_pl = v_Pairs[v_PairIdx_sort[j1]].d0M_pl;
	  const float j1_pd = v_Pairs[v_PairIdx_sort[j1]].d0M_pd;
	  const float j1_cosP = v_iterator_O[v_Pairs[v_PairIdx_sort[j1]].itX].cosP;
	  const float j1_sinP = v_iterator_O[v_Pairs[v_PairIdx_sort[j1]].itX].sinP;
	  
// 	    std::cout <<" phy = " << v_iterator_O[v_Pairs[v_PairIdx_sort[j1]].itX].phy;
	  
	  int missing_cup = 0;
	  for (float d = X_max; d > X_min; d -= 1)
	  {
// 	    std::cout <<" d = " << d;
	    int dx = round(d * j1_sinP), dy = -round(d*j1_cosP);
	    
	    int xx = x1_ + dx, yy = y1_ + dy;
	    if ( xx < cloud_Pjr->width && xx > 0 && yy < cloud_Pjr->height && yy > 0 ) 
	    {
	      uint xy_new = yy * cloud_Pjr->width + xx;
	      if (!isnan(cloud_Pjr->at(xy_new).x))	
	      {
		missing_cup = 1;
		v_TriangleSet.push_back(
		    std::make_pair(std::make_pair(v_Pairs[v_PairIdx_sort[j1]].xy1, v_Pairs[v_PairIdx_sort[j1]].xy2), 
				   std::make_pair(xy_new                         , 0                               )	)
		);
// 		std::cerr << " pushed ";
		d = 0;
		break;
	      }
	    }
	    
	    xx = x1_ - dx, yy = y1_ - dy;
	    if ( xx < cloud_Pjr->width && xx > 0 && yy < cloud_Pjr->height && yy > 0 ) 
	    {
	      uint xy_new = yy * cloud_Pjr->width + xx;
	      if (!isnan(cloud_Pjr->at(xy_new).x))	
	      {
		missing_cup = 3;
		v_TriangleSet.push_back(
		    std::make_pair(std::make_pair(xy_new                         , 0                              ), 
				   std::make_pair(v_Pairs[v_PairIdx_sort[j1]].xy1, v_Pairs[v_PairIdx_sort[j1]].xy2)	)
		);
// 		std::cerr << " pushed ";
		d = 0;
		break;
	      }
	    }
	    
	    xx = x2_ + dx, yy = y2_ + dy;
	    if ( xx < cloud_Pjr->width && xx > 0 && yy < cloud_Pjr->height && yy > 0 ) 
	    {
	      uint xy_new = yy * cloud_Pjr->width + xx;
	      if (!isnan(cloud_Pjr->at(xy_new).x))	
	      {
		missing_cup = 2;
		v_TriangleSet.push_back(
		    std::make_pair(std::make_pair(v_Pairs[v_PairIdx_sort[j1]].xy1, v_Pairs[v_PairIdx_sort[j1]].xy2), 
				   std::make_pair(0                              , xy_new                         )	)
		);
// 		std::cerr << " pushed ";
		d = 0;
		break;
	      }
	    }
	    
	    xx = x2_ - dx, yy = y2_ - dy;
	    if ( xx < cloud_Pjr->width && xx > 0 && yy < cloud_Pjr->height && yy > 0 ) 
	    {
	      uint xy_new = yy * cloud_Pjr->width + xx;
	      if (!isnan(cloud_Pjr->at(xy_new).x))	
	      {
		missing_cup = 4;
		v_TriangleSet.push_back(
		    std::make_pair(std::make_pair(0                              , xy_new                         ), 
				   std::make_pair(v_Pairs[v_PairIdx_sort[j1]].xy1, v_Pairs[v_PairIdx_sort[j1]].xy2)	)
		);
// 		std::cerr << " pushed ";
		d = 0;
		break;
	      }
	    }
	  }
	  
	  if (missing_cup != 0) break;

	}
	
	if (i11>i1)	i1 = i11;
	else 		break;
      }    
      
      ////////////////////////////////////// all rectangles found
      
//       std::cout<<"\nall nominees:\n";
//       std::sort(v_TriangleSet.begin(), v_TriangleSet.end(), [&](std::pair <int, int> P1, std::pair <int, int> P2) 
// 	    { return (v_Pairs[P1.second].d0M_pd-v_Pairs[P1.first].d0M_pd > v_Pairs[P2.second].d0M_pd-v_Pairs[P2.first].d0M_pd); } );
//       for (auto it : v_TriangleSet) std::cout<<"\t["<<it.first<<" "<<it.second<< "]\t"<<v_Pairs[it.second].d0M_pd-v_Pairs[it.first].d0M_pd<<"\t"<< v_iterator_O[v_Pairs[it.second].itX].phy * rad2deg<<"°\n";
      
    }
    
    uint nominate__RectPair_to_stf_table2cupbase0(float cfgZ, uint pr1, uint pr2, std::vector <pair_by_iterator> v_Pairs, std::vector<iterator_O> v_iterator_O, pcl::PointCloud<pcl::PointXYZ>::ConstPtr cloud_Pjr, float &cfgX, tf::StampedTransform &stf_table2cupbase0)
    {
      
      tf::Point table_pjpl_v3 (cloud_Pjr->sensor_origin_[0], cloud_Pjr->sensor_origin_[1], cloud_Pjr->sensor_origin_[2]);
      tf::Quaternion table_pjpl_q (cloud_Pjr->sensor_orientation_.x(),cloud_Pjr->sensor_orientation_.y(),cloud_Pjr->sensor_orientation_.z(),cloud_Pjr->sensor_orientation_.w());
  
      tf::Transform tf_table_pjpl (table_pjpl_q, table_pjpl_v3);
      
      uint i1(v_Pairs[pr1].xy1),i2(v_Pairs[pr1].xy2),i3(v_Pairs[pr2].xy1),i4(v_Pairs[pr2].xy2);
//        ROS_INFO_STREAM(" "<<pr1<<" "<<pr2<<" ");
    
      pcl::PointXYZ pt1 = cloud_Pjr->at(i1),
		    pt2 = cloud_Pjr->at(i2),
		    pt3 = cloud_Pjr->at(i3),
		    pt4 = cloud_Pjr->at(i4);
		    
		    
      float cfgX2 = sqrt((pt1.x-pt3.x)*(pt1.x-pt3.x)+(pt1.y-pt3.y)*(pt1.y-pt3.y));
      float cfgX3 = sqrt((pt2.x-pt4.x)*(pt2.x-pt4.x)+(pt2.y-pt4.y)*(pt2.y-pt4.y));
      cfgX = 0.5*(cfgX2+cfgX3);
      
      float mx = 0.25* (pt1.x+pt2.x+pt3.x+pt4.x);
      float my = 0.25* (pt1.y+pt2.y+pt3.y+pt4.y);
      float theta = atan2((pt1.y+pt2.y-pt3.y-pt4.y),(pt1.x+pt2.x-pt3.x-pt4.x));
      tf::Quaternion q (v3_001, theta);
      
//       set_v_stf_Tool2CupBases_cfgXYZ(cfgX, cfgY, 0.01);
      tf::Transform tf_pjpl2cupbase0 (q, tf::Point(mx,my,-cfgZ));
//       stf_table2cupbase0.setRotation(q);
//       stf_table2cupbase0.setOrigin(tf::Point(mx,my,-get_stf_Tool2CupBases(1).getOrigin().z()));
            
      stf_table2cupbase0.child_frame_id_ = "/grip";
      stf_table2cupbase0.frame_id_ = "/table_frame";
      stf_table2cupbase0.stamp_ = ros::Time::now();
      stf_table2cupbase0.setData(tf_table_pjpl*tf_pjpl2cupbase0);
      
      
//       ROS_INFO_STREAM(" "<<mx<<" "<<my<<" "<<theta<< " " <<cfgX<<" " <<cfgX2<<" "<<cfgX3);
    }
  
    uint nominate__RectPair_to_msg_Grip(float cfgY, float cfgZ, uint pr1, uint pr2, std::vector <pair_by_iterator> v_Pairs, std::vector<iterator_O> v_iterator_O, pcl::PointCloud<pcl::PointXYZ>::ConstPtr cloud_Pjr, yf_pcl_process::msg_Grip &msg_grip_candidate)
    {
      tf::StampedTransform stf_tmp;
      float cfgX_out;
      
      nominate__RectPair_to_stf_table2cupbase0(cfgZ, pr1, pr2, v_Pairs, v_iterator_O,cloud_Pjr, cfgX_out, stf_tmp);
      
//       std::cout << "cloud_Pjr->sensor_origin_;" << cloud_Pjr->sensor_origin_ << "\n";
      
      msg_grip_candidate.cfgX = cfgX_out;	
      msg_grip_candidate.cfgY = cfgY;		
      msg_grip_candidate.cfgZ = cfgZ;	
      //////////////////////
      msg_grip_candidate.cupOn.resize(5);
      msg_grip_candidate.cupOn[0]  =7;
      msg_grip_candidate.cupOn[1]  =1;
      msg_grip_candidate.cupOn[2]  =2;
      msg_grip_candidate.cupOn[3]  =3;
      msg_grip_candidate.cupOn[4]  =4;
      
      tf::transformStampedTFToMsg( stf_tmp , msg_grip_candidate.tfs_tabel2cupbase0 );
    }  
  
    uint nominate__TriangleSet_to_msg_Grip(float cfgY, float cfgZ, std::pair <int, int> pr1, std::pair <int, int> pr2, std::vector <pair_by_iterator> v_Pairs, std::vector<iterator_O> v_iterator_O, pcl::PointCloud<pcl::PointXYZ>::ConstPtr cloud_Pjr, yf_pcl_process::msg_Grip &msg_grip_candidate)
    {
      float cfgX;
      
      msg_grip_candidate.cupOn.resize(5);
      msg_grip_candidate.cupOn[0]  =13;
      msg_grip_candidate.cupOn[1]  =1;
      msg_grip_candidate.cupOn[2]  =2;
      msg_grip_candidate.cupOn[3]  =3;
      msg_grip_candidate.cupOn[4]  =4;
            
      tf::Point table_pjpl_v3 (cloud_Pjr->sensor_origin_[0], cloud_Pjr->sensor_origin_[1], cloud_Pjr->sensor_origin_[2]);
      tf::Quaternion table_pjpl_q (cloud_Pjr->sensor_orientation_.x(),cloud_Pjr->sensor_orientation_.y(),cloud_Pjr->sensor_orientation_.z(),cloud_Pjr->sensor_orientation_.w());
  
      tf::Transform tf_table_pjpl (table_pjpl_q, table_pjpl_v3);
      
      uint i1(pr1.first),i2(pr1.second),i3(pr2.first),i4(pr2.second);
      
      pcl::PointXYZ pt1, pt2, pt3, pt4;
		    
      if (i1) pt1 = cloud_Pjr->at(i1);
      if (i2) pt2 = cloud_Pjr->at(i2);
      if (i3) pt3 = cloud_Pjr->at(i3);
      if (i4) pt4 = cloud_Pjr->at(i4);
      
      std::cout << pt1.x*1000 << " " << pt1.y*1000 << "\n";
      std::cout << pt2.x*1000 << " " << pt2.y*1000 << "\n";
      std::cout << pt3.x*1000 << " " << pt3.y*1000 << "\n";
      std::cout << pt4.x*1000 << " " << pt4.y*1000 << "\n";
		    
      float mx, my, theta; 
      tf::Transform tf_pjpl2cupbase0;
      
      if (i1 == 0)
      {
	msg_grip_candidate.cupOn[1]  = 0;
	cfgX = sqrt((pt2.x-pt4.x)*(pt2.x-pt4.x)+(pt2.y-pt4.y)*(pt2.y-pt4.y));
	
	mx = 0.5* (pt2.x+pt3.x);
	my = 0.5* (pt2.y+pt3.y);
	theta = atan2((pt4.y-pt2.y),(pt4.x-pt2.x));
	tf::Quaternion q (v3_001, theta);
	
	tf_pjpl2cupbase0 = tf::Transform(q, tf::Point(mx,my,-cfgZ));
      }
      else if (i2 == 0)
      {
	msg_grip_candidate.cupOn[2]  = 0;
	cfgX = sqrt((pt1.x-pt3.x)*(pt1.x-pt3.x)+(pt1.y-pt3.y)*(pt1.y-pt3.y));
	
	mx = 0.5* (pt1.x+pt4.x);
	my = 0.5* (pt1.y+pt4.y);
	theta = atan2((pt3.y-pt1.y),(pt3.x-pt1.x));
	tf::Quaternion q (v3_001, theta);
	
	tf_pjpl2cupbase0 = tf::Transform(q, tf::Point(mx,my,-cfgZ));
      }
      else if (i3 == 0)
      {
	msg_grip_candidate.cupOn[3]  = 0;
	cfgX = sqrt((pt2.x-pt4.x)*(pt2.x-pt4.x)+(pt2.y-pt4.y)*(pt2.y-pt4.y));
	
	mx = 0.5* (pt1.x+pt4.x);
	my = 0.5* (pt1.y+pt4.y);
	theta = atan2((pt4.y-pt2.y),(pt4.x-pt2.x));
	tf::Quaternion q (v3_001, theta);
	
	tf_pjpl2cupbase0 = tf::Transform(q, tf::Point(mx,my,-cfgZ));
      }
      else if (i4 == 0)
      {
	msg_grip_candidate.cupOn[4]  = 0;
	cfgX = sqrt((pt1.x-pt3.x)*(pt1.x-pt3.x)+(pt1.y-pt3.y)*(pt1.y-pt3.y));
	
	mx = 0.5* (pt2.x+pt3.x);
	my = 0.5* (pt2.y+pt3.y);
	theta = atan2((pt3.y-pt1.y),(pt3.x-pt1.x));
	tf::Quaternion q (v3_001, theta);
	
	tf_pjpl2cupbase0 = tf::Transform(q, tf::Point(mx,my,-cfgZ));
      }
      else return 0;
      
      std::cout << mx*1000 <<"  "<< my*1000<< "  " << theta * 180/M_PI << std::endl;
      
      std::cout <<"\033[94m" "tf_table_pjpl" "\033[0m" "\n";
      std::cout << std::fixed << std::setprecision(4) << "\033[34m""    { (" << tf_table_pjpl.getOrigin().x()<<", "<< tf_table_pjpl.getOrigin().y()<<", "<< tf_table_pjpl.getOrigin().z()<<"), ("
		  << tf_table_pjpl.getRotation().x()<<", "<< tf_table_pjpl.getRotation().y()<<", "<< tf_table_pjpl.getRotation().z()<< " | "<< tf_table_pjpl.getRotation().w()<<") }\n" "\033[0m";

      std::cout <<"\033[94m" "tf_pjpl2cupbase0" "\033[0m" "\n";
      std::cout << std::fixed << std::setprecision(4) << "\033[34m""    { (" << tf_pjpl2cupbase0.getOrigin().x()<<", "<< tf_pjpl2cupbase0.getOrigin().y()<<", "<< tf_pjpl2cupbase0.getOrigin().z()<<"), ("
		  << tf_pjpl2cupbase0.getRotation().x()<<", "<< tf_pjpl2cupbase0.getRotation().y()<<", "<< tf_pjpl2cupbase0.getRotation().z()<< " | "<< tf_pjpl2cupbase0.getRotation().w()<<") }\n" "\033[0m";

      
      tf::StampedTransform stf_tmp (tf_table_pjpl*tf_pjpl2cupbase0, ros::Time::now(), "/table_frame", "/grip3");
//       stf_tmp.child_frame_id_ = "/grip3";
//       stf_tmp.frame_id_ = "/table_frame";
//       stf_tmp.stamp_ = ros::Time::now();
//       stf_tmp.setData(tf_table_pjpl*tf_pjpl2cupbase0);
      tf::transformStampedTFToMsg( stf_tmp , msg_grip_candidate.tfs_tabel2cupbase0 );      
      
      tf::TransformBroadcaster br;
      br.sendTransform(stf_tmp); 
      sleep(0.1);
      br.sendTransform(stf_tmp); 
      sleep(0.1);
      br.sendTransform(stf_tmp); 
      sleep(0.1);
      br.sendTransform(stf_tmp); 
      sleep(0.1);
      br.sendTransform(stf_tmp); 
      sleep(0.1);
      br.sendTransform(stf_tmp); 
      sleep(0.1);
      br.sendTransform(stf_tmp); 
      sleep(0.1);
      br.sendTransform(stf_tmp); 
      sleep(0.1);
      br.sendTransform(stf_tmp); 
      sleep(0.1);
      br.sendTransform(stf_tmp); 
      sleep(0.1);
      br.sendTransform(stf_tmp); 
      sleep(0.1);
      br.sendTransform(stf_tmp); 
      sleep(0.1);
      br.sendTransform(stf_tmp); 
      sleep(0.1);
      br.sendTransform(stf_tmp); 
      sleep(0.1);
      
      std::cout <<"\033[94m" "stf_tmp" "\033[0m" "\n";
      std::cout << std::fixed << std::setprecision(4) << "\033[34m""    { (" << stf_tmp.getOrigin().x()<<", "<< stf_tmp.getOrigin().y()<<", "<< stf_tmp.getOrigin().z()<<"), ("
		  << stf_tmp.getRotation().x()<<", "<< stf_tmp.getRotation().y()<<", "<< stf_tmp.getRotation().z()<< " | "<< stf_tmp.getRotation().w()<<") }\n" "\033[0m";

		  
// 	std::cout << "msg_grip_candidate.tfs_tabel2cupbase0\n" << msg_grip_candidate.tfs_tabel2cupbase0;	  
      
      /////////////////////////////////////////
      
      
      msg_grip_candidate.cfgX = cfgX;	
      msg_grip_candidate.cfgY = cfgY;		
      msg_grip_candidate.cfgZ = cfgZ;	
      //////////////////////

      
    }  
    
    uint nominate__get_v_grip_nominees_Rect_PjPl_cfgY(float cfgY, uint PjPl_N, pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_Pjr, std::vector< yf_pcl_process::msg_Grip > &v_grip_nominees, float cfgX_min = 0.04, float cfgX_max = 0.210, float cfgZ = 0)	// nominate cadidates of grip stf according to projectplain
    {
      std::cout<<"nominating grips for Project Plain"<< PjPl_N <<"\n";
      
      get_ProjectplainMapPcl(PjPl_N, cloud_Pjr, M_PI/180*30);
      
      ////////////////////////////////////////////////////// constructing iterator
      uint W = cloud_Pjr->width, H = cloud_Pjr->height;
      
//       float cfgY(0.05), cfgX_min(0.05), cfgZ(0.01);

      float R = cfgY/resolution_projection; float X_min = cfgX_min/resolution_projection; float X_max = cfgX_max/resolution_projection;
//       std::cout<<"'R = "<< R <<"\n";
//       std::vector<iterator_O> v_iterator_O;	// iterate half a circle

//       nominate__set_v_iterator_O(cfgY, v_iterator_O);
      if (nominate__v_iterator_O.size() == 0)
	nominate__set_v_iterator_O(cfgY, nominate__v_iterator_O);
      
      ////////////////////////////////////////////////////////// searching for pairs 

      std::vector <pair_by_iterator> v_Pairs {};
      nominate__searchPairs(cloud_Pjr, nominate__v_iterator_O, v_Pairs);
//       std::cout << v_Pairs.size() <<" pairs of points with distance R =cfgY = "<<cfgY<<"\n";
      /////////////////////////////////////////////////////////////// all pairs stored in v_l_Pairs
      
      std::vector <std::pair <int, int> > v_RectPair {std::make_pair(0,0)};
      nominate__find_RectPair(nominate__v_iterator_O, v_Pairs, v_RectPair, R , cfgX_min, cfgX_max);
      ///////////////////////////////////////////////////////////////////// found all rectangles as candidates
      
      
      float cfgX_out;
      
      V_Scene_lc->set_v_stf_Tool2CupBases_tfBase0(tf::Transform(tf::Quaternion(v3_100, M_PI/4), 0.1*v3_001));
//       set_v_stf_Tool2CupBases_cfgZ(0.03);
      yf_pcl_process::msg_Grip msg_grip_candidate {};
      uint i = 1;
      int if_search_triangle = 1;
      
//       v_RectPair.clear();	// force 3-cup grip
      
      if (v_RectPair.size()>0)
	for (auto it: v_RectPair)
	{
	  nominate__RectPair_to_msg_Grip(cfgY, cfgZ, it.first, it.second, v_Pairs, nominate__v_iterator_O,cloud_Pjr, msg_grip_candidate);
	  
	  msg_grip_candidate.name = "Grip_4_" + std::to_string(v_grip_nominees.size());
	  v_grip_nominees.push_back(msg_grip_candidate);
	  if (msg_grip_candidate.cfgX > 1.5*cfgX_min) if_search_triangle = 0;
	}
      
      if (if_search_triangle)
      {
	// look for 3-points grip
	std::cout <<"\033[93m""look for 3-points grip""\033[0m\n";
	std::vector <std::pair <std::pair <int, int>, std::pair <int, int>> > v_TriangleSet;
	nominate__find_Triangles(cloud_Pjr, nominate__v_iterator_O, v_Pairs, v_TriangleSet, R, cfgX_min, cfgX_max);
	std::cout <<"\033[95m""found "<< v_TriangleSet.size() <<" 3-points grip""\033[0m\n";
	if (v_TriangleSet.size()>0)
	{
	  for (auto it: v_TriangleSet)
	  {
	    
// 	    std::cout << "\033[96m"<< it.first.first <<" " << it.first.second <<" " << it.second.first <<" " << it.second.second <<" " << "\033[m\n";
// 	    int xy, xx, yy ;
// 	    xy = it.first.first; xx = xy % cloud_Pjr->width; yy = floor(xy / cloud_Pjr->width);
// 	    std::cout << "\033[96m"<< xy <<" : " << xx <<" " << yy <<" "<< "\033[m\n";
// 	    xy = it.first.second; xx = xy % cloud_Pjr->width; yy = floor(xy / cloud_Pjr->width);
// 	    std::cout << "\033[96m"<< xy <<" : " << xx <<" " << yy <<" "<< "\033[m\n";
// 	    xy = it.second.first; xx = xy % cloud_Pjr->width; yy = floor(xy / cloud_Pjr->width);
// 	    std::cout << "\033[96m"<< xy <<" : " << xx <<" " << yy <<" "<< "\033[m\n";
// 	    xy = it.second.second; xx = xy % cloud_Pjr->width; yy = floor(xy / cloud_Pjr->width);
// 	    std::cout << "\033[96m"<< xy <<" : " << xx <<" " << yy <<" "<< "\033[m\n";
	    
	    
	    nominate__TriangleSet_to_msg_Grip(cfgY, cfgZ, it.first, it.second, v_Pairs, nominate__v_iterator_O,cloud_Pjr, msg_grip_candidate);
    // 	std::cout<<msg_grip_candidate.cupOn[0]<< "  =====================\n";
	    
	    msg_grip_candidate.name = "Grip_3_" + std::to_string(v_grip_nominees.size());
	    v_grip_nominees.push_back(msg_grip_candidate);
	  }
	  	
	  std::sort(  std::begin(v_grip_nominees), 
		      std::end(v_grip_nominees),
		      [](yf_pcl_process::msg_Grip ii1, yf_pcl_process::msg_Grip ii2) { return ii1.cfgX > ii2.cfgX; } );
	}
	
	
      }
	  
    }
    
    
    
    
    uint nominate__get_v_grip_nominees_Rect_all_cfgY(float cfgY, float cfgX_min, float cfgX_max, std::vector< yf_pcl_process::msg_Grip > &v_grip_nominees)
    {

      V_Scene_lc->init_v_stf_Tool2CupBases();
      pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_pj (new pcl::PointCloud<pcl::PointXYZ>);
      
      for (uint PjPl_N = 1; PjPl_N < V_Scene_lc->NSphere_viewAngles_stf.size(); PjPl_N++)
      {
	nominate__get_v_grip_nominees_Rect_PjPl_cfgY(cfgY, PjPl_N, cloud_pj, v_grip_nominees, cfgX_min, cfgX_max>0?cfgX_max:0.210, 0);
      }
      return 1;
    }
      
    
    
    
    
    
    
    
    
    
    
    class matchPattern_rect_tri
    {
      
      public:
	// 2___|___4
	// 1   |   3
	uint itX_12;	// iterator of dir +Y
	
    //    float cos_x, sin_x;   // dir in +x (24/13)
    //    float cos_y, sin_y;   // dir in +y (12/34)
	float cX;
	
	std::vector<std::pair<float,float>> V1n;
	int dx_min, dx_max,dy_min,dy_max;
	
	int rn_cupN;
	float rn_mx, rn_my, rn_theta;	// vector to projected cupbase0
	std::vector <int> rn_v_xy_N;
	
	matchPattern_rect_tri(const iterator_O &iterator_, const uint &itX_12_, const float &cX_):
	itX_12(itX_12_),cX(cX_),
	dx_max(0),dx_min(0),dy_min(0),dy_max(0),
	rn_cupN(0)
	{
	    V1n.resize(5);
	    rn_v_xy_N.resize(5,-1);
	    rn_mx = NAN; rn_my = NAN; rn_theta = NAN;
	    
	    //if (nominate__v_iterator_O.size()>itX_12_)
	    {
		rn_theta = iterator_.phy;
		float cos_y = iterator_.cosP, sin_y = iterator_.sinP;
		float cos_x = sin_y                              , sin_x = -cos_y;      // rotate -90°
		
		V1n[1] = std::make_pair(0, 0);
		V1n[2] = std::make_pair(iterator_.dx, iterator_.dy);
		V1n[3] = std::make_pair(cX*cos_x, cX*sin_x);
		V1n[4] = std::make_pair(V1n[2].first+V1n[3].first, V1n[2].second+V1n[3].second);
		V1n[0] = std::make_pair(0.5*(V1n[4].first), 0.5*(V1n[4].second));
		for (uint i=2; i<5;i++)
		{ // get boundary
		  if (ceil(V1n[i].first)  > dx_max) dx_max = ceil(V1n[i].first);
		  if (floor(V1n[i].first) < dx_min) dx_min = floor(V1n[i].first);
		  if (ceil(V1n[i].second) > dy_max) dy_max = ceil(V1n[i].second);
		  if (floor(V1n[i].second)< dy_min) dy_min = floor(V1n[i].second);
		}
	    }
	    
	}

	
// 	void init_matchPattern_rect_tri(const uint &itX_12_, const float &cX_)
// 	{
// 	  itX_12 = itX_12_; cX = cX_;
// 	  dx_max = 0; dx_min = 0; dy_min = 0; dy_max = 0;
// 	  rn_cupN = 0;
// 	  
// 	    V1n.resize(5);
// 	    rn_v_xy_N.resize(5,-1);
// 	    rn_mx = NAN; rn_my = NAN; rn_theta = NAN;
// 	    
// 	    //if (nominate__v_iterator_O.size()>itX_12_)
// 	    {
// 		rn_theta = nominate__v_iterator_O[itX_12_].phy;
// 		float cos_y = nominate__v_iterator_O[itX_12_].cosP, sin_y = nominate__v_iterator_O[itX_12_].sinP;
// 		float cos_x = sin_y                              , sin_x = -cos_y;      // rotate -90°
// 		
// 		V1n[1] = std::make_pair(0, 0);
// 		V1n[2] = std::make_pair(nominate__v_iterator_O[itX_12_].dx, nominate__v_iterator_O[itX_12_].dy);
// 		V1n[3] = std::make_pair(cX*cos_x, cX*sin_x);
// 		V1n[4] = std::make_pair(V1n[2].first+V1n[3].first, V1n[2].second+V1n[3].second);
// 		V1n[0] = std::make_pair(0.5*(V1n[4].first), 0.5*(V1n[4].second));
// 		for (uint i=2; i<5;i++)
// 		{ // get boundary
// 		  if (ceil(V1n[i].first)  > dx_max) dx_max = ceil(V1n[i].first);
// 		  if (floor(V1n[i].first) < dx_min) dx_min = floor(V1n[i].first);
// 		  if (ceil(V1n[i].second) > dy_max) dy_max = ceil(V1n[i].second);
// 		  if (floor(V1n[i].second)< dy_min) dy_min = floor(V1n[i].second);
// 		}
// 	    }
// 	    
// 	}
      
      
    };

    int nominate__check_occupation(pcl::PointCloud<pcl::PointXYZ>::ConstPtr cloud_Pjr, const matchPattern_rect_tri &mP_in, std::vector<matchPattern_rect_tri> &v_mP_out)
    {
	int region_x_min  = 0 - mP_in.dx_min;                   // uint xi = region_x_min
	int region_x_max = cloud_Pjr->width - mP_in.dx_max;     // xi < region_x_max
	int region_y_min  = 0 - mP_in.dy_min;
	int region_y_max = cloud_Pjr->height - mP_in.dx_max;
	
	if (region_x_min > region_x_max) return 0;
	if (region_y_min > region_y_max) return 0;
	
	bool found4 = false;
	
	for (uint yi = region_y_min; yi < region_y_max; yi++)
	for (uint xi = region_x_min; xi < region_x_max; xi++)
	{
	  std::vector< int > v_cupOn(5, -1);
	  char count_cups = 0;
	
	  for (uint cupi = 1; cupi < 5; cupi ++)
	  {
	    bool cup_valid = false;
	    for (int X = xi+floor(mP_in.V1n[cupi].first); X <= xi+ceil(mP_in.V1n[cupi].first); X++)   // +0,+1
	    for (int Y = yi+floor(mP_in.V1n[cupi].second); Y <= yi+ceil(mP_in.V1n[cupi].second); Y++) // +0,+1
	    {
		if (X < 0 || X > cloud_Pjr->width || Y < 0 || Y > cloud_Pjr->height) continue; // if out of bound
		
		uint xy = Y * cloud_Pjr->width + X;
		if ( ! isnan(cloud_Pjr->at(xy).x) ) // can add other contrains
		{
		    v_cupOn[cupi] = xy;
		    cup_valid = true;
		    Y+=2; X+=2;         // found one! break loop of X,Y
		}
		else
		{
		    //v_cupOn[cupi] = -xy; // store nan point too
		    //v_cupOn[cupi] = -1; // store point as -1 'invalid'
		}
	    }
	    if (cup_valid) count_cups ++;
	    if ( cupi - count_cups >= 2 ) cupi = 5;  // if two invalid, break
	  }
	      
	  if (count_cups >= 3)  // if a good match found
	  {
	      
	    matchPattern_rect_tri mP_new = mP_in;
	    mP_new.rn_cupN = 0;
	    
	    float mx_14 = NAN, my_14 = NAN;
	    if (v_cupOn[1]>=0 && v_cupOn[4]>=0)
	    {
	      mx_14 = cloud_Pjr->at(v_cupOn[1]).x + cloud_Pjr->at(v_cupOn[4]).x;
	      my_14 = cloud_Pjr->at(v_cupOn[1]).y + cloud_Pjr->at(v_cupOn[4]).y;
	    }
	      
	    float mx_23 = NAN, my_23 = NAN;
	    if (v_cupOn[2]>=0 && v_cupOn[3]>=0)
	    {
	      mx_23 = cloud_Pjr->at(v_cupOn[2]).x + cloud_Pjr->at(v_cupOn[3]).x;
	      my_23 = cloud_Pjr->at(v_cupOn[2]).y + cloud_Pjr->at(v_cupOn[3]).y;
	    }
	      
	    if (isnan(mx_14))
	    {
	      mP_new.rn_mx = (mx_23) * 0.5;
	      mP_new.rn_my = (my_23) * 0.5;
	    }
	    else if (isnan(mx_23))
	    {
	      mP_new.rn_mx = (mx_14) * 0.5;
	      mP_new.rn_my = (my_14) * 0.5;
	    }
	    else
	    {
	      mP_new.rn_mx = (mx_14+mx_23) * 0.25;
	      mP_new.rn_my = (my_14+my_23) * 0.25;
	    }
	      
	    mP_new.rn_theta = nominate__v_iterator_O[mP_in.itX_12].phy - M_PI_2;
	    
	    for (uint cupi = 1; cupi < 5; cupi++)
	    {
	      if ( v_cupOn[cupi] >= 0 ) // valid cup
	      {
		mP_new.rn_v_xy_N[cupi] = v_cupOn[cupi];
		mP_new.rn_cupN ++;
	      }
	      else
	      {
		//mP_new.rn_v_xy_N[cupi] = -1;
	      }
	    }
	    
	    if (v_mP_out.size()<1)
	      v_mP_out.push_back(mP_new);
	    else
	    {
		matchPattern_rect_tri mP_back = v_mP_out.back();
		bool if_more_cups = mP_new.rn_cupN > mP_back.rn_cupN ;
		bool if_closer2center = mP_new.rn_mx + mP_new.rn_my > mP_back.rn_mx + mP_back.rn_my ;
		bool if_phy_changed = fabs(mP_new.rn_theta - mP_back.rn_theta) > 0.5; // angle difference over 30°
		bool if_cfgX_similar = (mP_new.cX / mP_back.cX) > 0.75 ; // cfg decrease less than 25%
		
		if (if_phy_changed)
		{
		    v_mP_out.push_back(mP_new);
		}
		else if (if_more_cups)
		{
		  if (if_cfgX_similar)
		  {
		    v_mP_out.pop_back();
		    v_mP_out.push_back(mP_new);
		  }
		  else
		  {
		    v_mP_out.push_back(mP_new);
		  }
		}
		else if (if_closer2center)
		{
		    v_mP_out.pop_back();
		    v_mP_out.push_back(mP_new);
		}
	    }
	      
	  }
	}
	return v_mP_out.size();
    };

    int nominate__find_matchPattern_cX(pcl::PointCloud<pcl::PointXYZ>::ConstPtr cloud_Pjr, matchPattern_rect_tri mP_in, std::vector<matchPattern_rect_tri> &v_mP_out, float cX_max = 0, float cX_min = 0)
    {
	if (cX_max == 0) cX_max = std::max(cloud_Pjr->width, cloud_Pjr->height);
	
	for (float cX_ = cX_max; cX_ > cX_min; cX_ -= 1.0)
	{
	    mP_in.cX = cX_;
	    bool got_match = nominate__check_occupation(cloud_Pjr, mP_in, v_mP_out);
	    
	    if (got_match) return 1;
	}
	return 0;
    }

    uint nominate__matchPattern_to_msg_Grip(pcl::PointCloud<pcl::PointXYZ>::ConstPtr cloud_Pjr, matchPattern_rect_tri mP_in, yf_pcl_process::msg_Grip &msg_grip_out)
    {
	float cfgX = 0;
	
	msg_grip_out.cupOn.resize(5);
	msg_grip_out.cupOn[0] = 17;
	msg_grip_out.cupOn[1] = 0;
	msg_grip_out.cupOn[2] = 0;
	msg_grip_out.cupOn[3] = 0;
	msg_grip_out.cupOn[4] = 0;
	
	tf::Point table_pjpl_v3 (cloud_Pjr->sensor_origin_[0], cloud_Pjr->sensor_origin_[1], cloud_Pjr->sensor_origin_[2]);
	tf::Quaternion table_pjpl_q (cloud_Pjr->sensor_orientation_.x(),cloud_Pjr->sensor_orientation_.y(),cloud_Pjr->sensor_orientation_.z(),cloud_Pjr->sensor_orientation_.w());
	tf::Transform tf_table_pjpl (table_pjpl_q, table_pjpl_v3);
	
	std::vector < int > v_cup_xy = mP_in.rn_v_xy_N;
	
	std::vector <pcl::PointXYZ> Pt(5);
	for (uint i=1; i<5; i++)
	{
	    if (mP_in.rn_v_xy_N[i]>=0)
	    {
	      msg_grip_out.cupOn[i] = i;
	      Pt[i] = cloud_Pjr->at(mP_in.rn_v_xy_N[i]);
	    }
	    else
	    {
	      
	    }
	    std::cout << Pt[i].x*1000 << " " << Pt[i].y*1000 << "\n";
	}
	
	tf::Quaternion q (v3_001, mP_in.rn_theta);    
	tf::Transform tf_pjpl2cupbase0 = tf::Transform(q, tf::Point(mP_in.rn_mx,mP_in.rn_my,-cfgZ));
	
	tf::StampedTransform stf_tmp (tf_table_pjpl*tf_pjpl2cupbase0, ros::Time::now(), "/table_frame", "/gripT");
	tf::transformStampedTFToMsg( stf_tmp , msg_grip_out.tfs_tabel2cupbase0 );
	
	msg_grip_out.cfgX = mP_in.cX * resolution_projection;
	msg_grip_out.cfgY = cfgY;
	msg_grip_out.cfgZ = cfgZ;
    }

    int nominate__find_matchPattern_all_cfgY(pcl::PointCloud<pcl::PointXYZ>::ConstPtr cloud_Pjr, std::vector< yf_pcl_process::msg_Grip > &v_grip_nominees, float cfgY_, float cfgX_max_, float cfgX_min_)
    {
        cfgY = cfgY_;
        cfgZ = 0;
	cfgX_max = cfgX_max_;
	cfgX_min = cfgX_min_;
      
      
	float cX_min = cfgX_min/resolution_projection;
	float cX_max = cfgX_max/resolution_projection;
	std::cout<< "cX_min "<< cX_min << "   cfgX_min "<< cfgX_min <<"\n";
	std::cout<< "cX_max "<< cX_max << "   cfgX_max "<< cfgX_max <<"\n";
	
	if (nominate__v_iterator_O.size()<1)
	  nominate__set_v_iterator_O(cfgY, nominate__v_iterator_O);
	
	std::vector<matchPattern_rect_tri> v_mP_out {};
	    
	for (uint i = 0; i < nominate__v_iterator_O.size(); i++)
	{
	  std::cout << "matchPattern_rect_tri mP_in   "<< i << "\n";
	  matchPattern_rect_tri mP_in(nominate__v_iterator_O[i], i, 0);
	  nominate__find_matchPattern_cX(cloud_Pjr, mP_in, v_mP_out, cX_max, cX_min);
	}
	
	yf_pcl_process::msg_Grip msg_grip_candidate {};
	for (auto &it : v_mP_out)
	{
	  nominate__matchPattern_to_msg_Grip(cloud_Pjr, it, msg_grip_candidate);

	    msg_grip_candidate.name = "Grip_T_" + std::to_string(v_grip_nominees.size());
	    v_grip_nominees.push_back(msg_grip_candidate);
	}
	
	return v_grip_nominees.size();
    }
    
    
    
    uint nominate__get_v_grip_nominees_matchPattern_PjPl_cfgY(float cfgY, uint PjPl_N, pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_Pjr, std::vector< yf_pcl_process::msg_Grip > &v_grip_nominees, float cfgX_min = 0.04, float cfgX_max = 0.210, float cfgZ = 0)	// nominate cadidates of grip stf according to projectplain
    {
      std::cout<<"nominating grips for Project Plain"<< PjPl_N <<"\n";
      
      get_ProjectplainMapPcl(PjPl_N, cloud_Pjr, M_PI/180*30);
      
      nominate__find_matchPattern_all_cfgY(cloud_Pjr, v_grip_nominees, cfgY, cfgX_max, cfgX_min);
    }
    
    uint nominate__get_v_grip_nominees_matchPattern_all_cfgY(float cfgY, float cfgX_min, float cfgX_max, std::vector< yf_pcl_process::msg_Grip > &v_grip_nominees)
    {

      V_Scene_lc->init_v_stf_Tool2CupBases();
      pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_pj (new pcl::PointCloud<pcl::PointXYZ>);
      
      for (uint PjPl_N = 1; PjPl_N < V_Scene_lc->NSphere_viewAngles_stf.size(); PjPl_N++)
      {
	nominate__get_v_grip_nominees_matchPattern_PjPl_cfgY(cfgY, PjPl_N, cloud_pj, v_grip_nominees, cfgX_min, cfgX_max>0?cfgX_max:0.210, 0);
      }
      return 1;
    }    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    void save_viewAngles(yf_VacuumGripScene *V_)
    {
//       V_.NSphere_viewAngles = this->NSphere_viewAngles;
      V_->NSphere_viewAngles_stf = V_Scene_lc->NSphere_viewAngles_stf;
    }
    
      
};