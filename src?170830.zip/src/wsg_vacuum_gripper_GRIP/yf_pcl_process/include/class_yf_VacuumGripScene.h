#include <cmath>
#include <limits>
#include <iostream>

#include <ros/ros.h>
#include <rosbag/bag.h>
#include <rosbag/view.h>

#include <visualization_msgs/Marker.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>

#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/project_inliers.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/search/search.h>
#include <pcl/search/kdtree.h>
#include <pcl/search/organized.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/features/integral_image_normal.h>
#include "pcl_ros/transforms.h"
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/extract_polygonal_prism_data.h>
#include <pcl/segmentation/region_growing.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl/surface/concave_hull.h>
#include <pcl/segmentation/organized_multi_plane_segmentation.h>
#include <pcl/segmentation/organized_connected_component_segmentation.h>
#include <pcl/segmentation/planar_region.h>
#include <pcl/segmentation/comparator.h>
#include <pcl/impl/point_types.hpp>

#include <tf/LinearMath/Vector3.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <tf_conversions/tf_eigen.h>

#include <Eigen/Core> 
#include <Eigen/Geometry> 
#include <Eigen/SVD>
#include <Eigen/Dense>

#include <yf_vacuum_cups/cup_dim.h>
#include <yf_vacuum_cups/srv_draw_cup.h>
#include <yf_vacuum_cups/msg_cup_draw.h>


class yf_VacuumGripScene
{
  protected:
    ros::NodeHandle nh; 
  
  public:
    const float f_nan = NAN;
    const pcl::PointXYZ PointXYZ_nan = pcl::PointXYZ(NAN,NAN,NAN);
    const float rad2deg = 180/M_PI, deg2rad = M_PI/180;
    const tf::Point v3_000 = tf::Point(0,0,0);
    const tf::Point v3_100 = tf::Point(1,0,0);
    const tf::Point v3_010 = tf::Point(0,1,0);
    const tf::Point v3_001 = tf::Point(0,0,1);
    const tf::Quaternion q_u = tf::Quaternion(0,0,0,1);
    const tf::Transform tf_u = tf::Transform(q_u, v3_000);
    
    ros::Time RosTimeBegin = ros::Time::now();
    
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud; //(new pcl::PointCloud<pcl::PointXYZ>);
    pcl::PointCloud <pcl::Normal>::Ptr normals;  
    pcl::PointCloud<pcl::PointNormal>::Ptr cloud_with_normals; 
//     pcl::PointCloud<pcl::PointXYZRGBNormal>::Ptr cloud_XYZRGBNormal; 
    
    tf::Point massCenter;

    std::vector<tf::Point> NSphere_viewAngles;
    std::vector<tf::StampedTransform> NSphere_viewAngles_stf;

    pcl::IndicesPtr idx_valid;
    pcl::IndicesPtr idx_border;
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_border;
    pcl::IndicesPtr idx_inlander; 			// points far away from borders or big curves
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_inlander;
    

    
    
    char if_use_GlobalTABLE = 0;
    char if_exist_stf_World2Table = 0;
    char if_exist_stf_World2Flange = 0;
    char if_exist_stf_Flange2Sensor = 0;
    
    tf::StampedTransform stf_World2Table;
    tf::StampedTransform stf_World2Flange;
    tf::StampedTransform stf_Flange2Sensor;
    tf::StampedTransform stf_x2Table;
    tf::Transform tf_Sensor2Table, tf_Table2Sensor;  
    tf::Point N_table; float d_table, table_trim_offset = 0;
    
    tf::Transform tf_Table2Tool, tf_Tool2Table;  
    tf::StampedTransform stf_Table2Tool, stf_Tool2Table;
    
    std::vector<tf::StampedTransform> v_stf_Tool2CupBases;
    std::vector<uint> v_cup_dim_N;
    std::vector<yf_vacuum_cups::cup_dim> v_cup_dim;
    
    pcl::PointCloud<pcl::Label>::Ptr cloud_label ;	// 999:border, 888:underTable 777:bigCurveture, 0:nan, 0~100:inlander, 100~200:inlanderMargin
    std::vector<pcl::PointIndices> label_indices;
    uint trim_x_min= 640, trim_y_min= 480, trim_x_max= 0, trim_y_max= 0;
    
    pcl::search::OrganizedNeighbor<pcl::PointXYZ> tree_cloud;
    pcl::search::OrganizedNeighbor<pcl::PointXYZ> tree_inlander;
    float curv_Mx ;					// border curvature threshold mx
    
    uint cupN;
    yf_vacuum_cups::cup_dim cup_dim_ ;
    float GRIPPER_cfgX_MAX, GRIPPER_cfgX_MIN;
    float GRIPPER_cfgY_CONST;
    
    yf_VacuumGripScene():
      cloud (new pcl::PointCloud<pcl::PointXYZ>),
      normals (new pcl::PointCloud <pcl::Normal>),
      cloud_with_normals (new pcl::PointCloud<pcl::PointNormal>), 
      idx_valid (new std::vector <int>),
      idx_border (new std::vector <int>),
      cloud_border (new pcl::PointCloud<pcl::PointXYZ>),
      idx_inlander (new std::vector <int>), 
      cloud_inlander (new pcl::PointCloud<pcl::PointXYZ>),
      cloud_label (new pcl::PointCloud<pcl::Label>)
    {
      ROS_INFO_STREAM("new obj yf_VacuumGripScene") ;
      //ros::NodeHandle priv_nh("~");
      //f_nan = std::numeric_limits<float>::quiet_NaN();
      //PointXYZ_nan = pcl::PointXYZ(f_nan,f_nan,f_nan);
      
      RosTimeBegin = ros::Time::now();
      
      	cup_dim_.radius 	= 0.01;
	cup_dim_.lengthen	= 0.0;
	cup_dim_.height		= 0.01;
	cup_dim_.stroke 	= 0.009;
	cup_dim_.minCurvR	= 0.04;
	cup_dim_.bellows 	= 0.0;
	cup_dim_.bend 		= 0.05;
	cup_dim_.rimangle	= 0.523599;
	
      init_v_stf_Tool2CupBases();	
      
      GRIPPER_cfgX_MAX = 0.210; GRIPPER_cfgX_MIN = 0.030;
      GRIPPER_cfgY_CONST = 0.070;
    }   
    
    yf_VacuumGripScene(pcl::PointCloud<pcl::PointXYZ>::Ptr inputt):
      cloud (new pcl::PointCloud<pcl::PointXYZ>),
      normals (new pcl::PointCloud <pcl::Normal>),
      cloud_with_normals (new pcl::PointCloud<pcl::PointNormal>),    
      idx_valid (new std::vector <int>),
      idx_border (new std::vector <int>),
      cloud_border (new pcl::PointCloud<pcl::PointXYZ>),
      idx_inlander (new std::vector <int>), 
      cloud_inlander (new pcl::PointCloud<pcl::PointXYZ>),
      cloud_label (new pcl::PointCloud<pcl::Label>)
    {
      ROS_INFO_STREAM("new obj yf_VacuumGripScene") ;
      //ros::NodeHandle priv_nh("~");
      //f_nan = std::numeric_limits<float>::quiet_NaN();
      //PointXYZ_nan = pcl::PointXYZ(f_nan,f_nan,f_nan);
      
      stf_Table2Tool = tf::StampedTransform(tf_Sensor2Table, ros::Time::now(), "/table_frame", "/tool_frame");
      
      //pcl::copyPointCloud(*inputt, *cloud);
      *cloud = *inputt;
//       pcl::removeNaNFromPointCloud(*cloud, *idx_valid);
//      ROS_INFO_STREAM(idx_valid->size()<<" from "<<cloud->size()) ;

      RosTimeBegin = ros::Time::now();
      
      	cup_dim_.radius 	= 0.01;
	cup_dim_.lengthen	= 0.0;
	cup_dim_.height		= 0.01;
	cup_dim_.stroke 	= 0.009;
	cup_dim_.minCurvR	= 0.04;
	cup_dim_.bellows 	= 0.0;
	cup_dim_.bend 		= 0.05;
	cup_dim_.rimangle	= 0.523599;
	
      init_v_stf_Tool2CupBases();
      
      GRIPPER_cfgX_MIN = 0.030; GRIPPER_cfgX_MAX = 0.210; 
      GRIPPER_cfgY_CONST = 0.070;
      
      cloud_label->resize(cloud->size());
      cloud_label->height = cloud->height; cloud_label->width = cloud->width; 

      trim_x_min= cloud->width, trim_y_min= cloud->height;
    }
    
    void setInputCloud (pcl::PointCloud<pcl::PointXYZ>::Ptr inputt)
    {
      cloud->clear();
      cloud = inputt; 
      normals->clear();
      cloud_with_normals->clear();
      idx_valid->clear();
      idx_border->clear();
      cloud_border->clear();
      idx_inlander->clear();
      cloud_inlander->clear();
      cloud_label->clear();
      cloud_label->resize(cloud->size());
      cloud_label->height = cloud->height; cloud_label->width = cloud->width; 
      trim_x_min= cloud->width, trim_y_min= cloud->height;

    }
    
    void setPlanningCfgs (float cfgY = 0.070, float cfgX_min = 0.030, float cfgX_max = 0.210)
    {
      GRIPPER_cfgX_MIN = cfgX_min; GRIPPER_cfgX_MAX = cfgX_max; 
      GRIPPER_cfgY_CONST = cfgY;      
    }
    
    bool calc_norm()
    {
      pcl::IntegralImageNormalEstimation<pcl::PointXYZ, pcl::Normal> normal_estimator;
      normal_estimator.setNormalEstimationMethod (normal_estimator.COVARIANCE_MATRIX); //AVERAGE_DEPTH_CHANGE, SIMPLE_3D_GRADIENT, AVERAGE_3D_GRADIENT, COVARIANCE_MATRIX
      normal_estimator.setBorderPolicy(normal_estimator.BORDER_POLICY_MIRROR); //BORDER_POLICY_MIRROR, BORDER_POLICY_IGNORE
      normal_estimator.setMaxDepthChangeFactor(0.01f);
      //normal_estimator.setDepthDependentSmoothing(true);
      normal_estimator.setNormalSmoothingSize(9.0);			//factor which influences the size of the area used to smooth normals

      normal_estimator.setInputCloud (cloud);
      normal_estimator.useSensorOriginAsViewPoint ();
      normal_estimator.compute (*normals);     
    }
     
    bool combine_cloud_normal()
    {	
//      *cloud_with_normals = pcl::PointCloud<pcl::PointNormal>(); 
      cloud_with_normals->clear();
      pcl::copyPointCloud(*cloud, *cloud_with_normals);
      pcl::copyPointCloud(*normals, *cloud_with_normals); 
      return 1;
    }
    
    bool combine_cloud_normal(pcl::PointCloud<pcl::PointXYZ>::ConstPtr cloud_in, pcl::PointCloud<pcl::Normal>::ConstPtr norms_in, pcl::PointCloud<pcl::PointNormal>::Ptr cloud_out)
    {	
//      pcl::PointCloud<pcl::PointNormal>::Ptr cloud_with_normals2; 
      //*cloud_with_normals = pcl::PointCloud<pcl::PointNormal>(); 
      cloud_out->clear();
      pcl::copyPointCloud(*cloud_in, *cloud_out);
      pcl::copyPointCloud(*norms_in, *cloud_out); 
      //cloud_out = cloud_with_normals2;
      return 1;
    }

    
    tf::Point calc_massCenter()
    {
//       pcl::removeNaNFromPointCloud(*cloud, *idx_valid);
      return calc_massCenter(cloud);
    }    
    
    tf::Point calc_massCenter(pcl::PointCloud<pcl::PointXYZ>::ConstPtr cloud_raw)
    {
      tf::Point CM(0,0,0);
      float countValid(0);
      
      pcl::PointXYZ p;
      for (size_t i = 0; i < cloud_raw->size(); i++)
      {
	float wight_xy = (normals->points[i].normal_z);
	p = cloud_raw->points[i];
	if (isnan(p.x) || isnan(wight_xy)) continue;
	countValid += wight_xy; // 1.0;
	CM = CM + wight_xy * tf::Point(p.x, p.y, 0.5*p.z);
      }
      
      std::cout<<"\033[96m" "countValid "<<countValid<<"\033[0m" "\n";
	
      CM = CM / countValid;
      massCenter = CM;
      
      std::cout<<"\033[96m" "Center of Mass : "<< CM.x()<<" "<< CM.y()<<" "<< CM.z()<< "\033[0m" " \n";
      
      return CM;
    }
    
    bool save2_pcd()
    {
     pcl::io::savePCDFileASCII ("test_pcd.pcd", *cloud);
//      std::cerr << "Saved " << cloud_with_normals->points.size () << " data points to test_pcd.pcd." << std::endl;
    }
        
    bool save2_pcd_inlander()
    {
     pcl::io::savePCDFileASCII ("cloud_inlander.pcd", *cloud_inlander);
//      std::cerr << "Saved " << cloud_with_normals->points.size () << " data points to test_pcd.pcd." << std::endl;
    }
    
    void setCupDim(uint cupN_)
    {
      ros::NodeHandle priv_nh("~");
      std::string s_param = ("/cups/" + std::to_string(cupN_));
      if (cupN_ != 0)
      {
	if (priv_nh.getParam(s_param+"/name",   cup_dim_.name)) {}
	if (priv_nh.getParam(s_param+"/radius", cup_dim_.radius)) {}
	if (priv_nh.getParam(s_param+"/lengthen", cup_dim_.lengthen)) {}
	if (priv_nh.getParam(s_param+"/height", cup_dim_.height)) {}
	if (priv_nh.getParam(s_param+"/stroke", cup_dim_.stroke)) {}
	if (priv_nh.getParam(s_param+"/minCurvR", cup_dim_.minCurvR)) {}
	if (priv_nh.getParam(s_param+"/bellows", cup_dim_.bellows)) {}
	if (priv_nh.getParam(s_param+"/bend", cup_dim_.bend)) {}
	if (priv_nh.getParam(s_param+"/rimangle", cup_dim_.rimangle)) {}
	
// 	  ROS_INFO_STREAM("load config '"<< s_param <<"'") ;
      }	
      else
      {
	cup_dim_.radius 	= 0.01;
	cup_dim_.lengthen	= 0.0;
	cup_dim_.height		= 0.01;
	cup_dim_.stroke 	= 0.009;
	cup_dim_.minCurvR	= 0.04;
	cup_dim_.bellows 	= 0.0;
	cup_dim_.bend 		= 0.05;
	cup_dim_.rimangle	= 0.523599;
      }
      
      v_cup_dim_N.resize(5, cupN_);
      v_cup_dim.resize(5, cup_dim_);
    }    
        
    void setCupDim1234(uint cupN1_,uint cupN2_,uint cupN3_,uint cupN4_)
    {
      v_cup_dim_N.resize(5);
      v_cup_dim_N[1] = (cupN1_);
      v_cup_dim_N[2] = (cupN2_);
      v_cup_dim_N[3] = (cupN3_);
      v_cup_dim_N[4] = (cupN4_);
      
      v_cup_dim.resize(5, cup_dim_);
      v_cup_dim[1] = getCupDim(cupN1_);
      v_cup_dim[2] = getCupDim(cupN2_);
      v_cup_dim[3] = getCupDim(cupN3_);
      v_cup_dim[4] = getCupDim(cupN4_);
    }    
    
    yf_vacuum_cups::cup_dim getCupDim(uint cupN_)
    {
      ros::NodeHandle priv_nh("~");
      yf_vacuum_cups::cup_dim cupDim_2;
      std::string s_param = ("/cups/" + std::to_string(cupN_));
      if (cupN_ != 0)
      {
	if (	priv_nh.getParam(s_param+"/name",   cupDim_2.name)
	    && 	priv_nh.getParam(s_param+"/radius", cupDim_2.radius)
	    && 	priv_nh.getParam(s_param+"/lengthen", cupDim_2.lengthen)
	    && 	priv_nh.getParam(s_param+"/height", cupDim_2.height)
	    && 	priv_nh.getParam(s_param+"/stroke", cupDim_2.stroke)
	    && 	priv_nh.getParam(s_param+"/minCurvR", cupDim_2.minCurvR)
	    && 	priv_nh.getParam(s_param+"/bellows", cupDim_2.bellows)
	    && 	priv_nh.getParam(s_param+"/bend", cupDim_2.bend)
	    && 	priv_nh.getParam(s_param+"/rimangle", cupDim_2.rimangle)) 
	{}
// 	  ROS_INFO_STREAM("load config '"<< s_param <<"'") ;
      }	
      else
      {
	cupDim_2.radius 	= 0.01;
	cupDim_2.lengthen	= 0.0;
	cupDim_2.height		= 0.01;
	cupDim_2.stroke 	= 0.009;
	cupDim_2.minCurvR	= 0.04;
	cupDim_2.bellows 	= 0.0;
	cupDim_2.bend 		= 0.05;
	cupDim_2.rimangle	= 0.523599;
      }
      return cupDim_2;
    }
    

    bool set_stf_Flange2Sensor( const tf::StampedTransform &STF )
    { 
	stf_Flange2Sensor = STF;
	if_exist_stf_Flange2Sensor = 3;
    }
    bool wait_get_stf_Flange2Sensor( ros::NodeHandle &nh , uint count = 3)
    { 
	tf::TransformListener listener;
      while ( nh.ok() && count > 0) 
      {
	bool yep = true;
	
// 	  ROS_INFO_STREAM(".");	
	listener.waitForTransform("/tool0", "/camera_depth_optical_frame", ros::Time(0), ros::Duration(1));
	try { listener.lookupTransform("/tool0", "/camera_depth_optical_frame", ros::Time(0), stf_Flange2Sensor);    }    
	catch (tf::TransformException &ex) { ROS_ERROR("%s",ex.what());    yep = false;	}
	if (yep)
	{
 	  if_exist_stf_Flange2Sensor = 2;
	  return true;
	} 
	count--;
      }
      return false;
    }    

    bool wait_get_stf_World2Flange( ros::NodeHandle &nh , uint count = 3)
    { 
	tf::TransformListener listener;
      while ( nh.ok() && count > 0) 
      {
	bool yep = true;
	
// 	  ROS_INFO_STREAM(".");
	
	listener.waitForTransform("/world", "/tool0", ros::Time(0), ros::Duration(1));
	try { listener.lookupTransform("/world", "/tool0", ros::Time(0), stf_World2Flange);    }    
	catch (tf::TransformException &ex) { ROS_ERROR("%s",ex.what());    yep = false;	}
	if (yep)
	{
	  if_exist_stf_World2Flange = 2;
	  return true;
	} 
	count--;
      }
      return false;
    }    
    
    bool set_stf_World2Table( const tf::StampedTransform &STF )
    { 
	stf_World2Table = tf::StampedTransform(STF, ros::Time::now(), "/world", "/table_frame");
        stf_x2Table = tf::StampedTransform(STF, ros::Time::now(), "/world", "/table_frame");
	if_exist_stf_World2Table = 3;
    }
    bool wait_get_stf_World2Table( ros::NodeHandle &nh , uint count = 3)
    { 
      tf::TransformListener listener;
      while ( nh.ok() && count > 0) 
      {
	bool yep = true;
	
	listener.waitForTransform("/world", "/r5_cell_table_link", ros::Time(0), ros::Duration(1));
	try { listener.lookupTransform("/world", "/r5_cell_table_link", ros::Time(0), stf_World2Table);    }    
	catch (tf::TransformException &ex) { ROS_ERROR("%s",ex.what());    yep = false;	}
	if (yep)
	{
	  stf_x2Table = tf::StampedTransform(stf_World2Table, ros::Time::now(), "/world", "/table_frame");
	  stf_World2Table.child_frame_id_ = "/table_frame";

	  if_exist_stf_World2Table = 2;
	  return true;
	} 
	count--;
      }
      return false;
    }    
    
    bool set_Tf_World2Table(tf::Transform tf_W2T)
    {
      tf::TransformListener listener;
      
      tf::StampedTransform stf_base2Sensor (stf_World2Flange * stf_Flange2Sensor, ros::Time::now(), "/world", "/camera_depth_optical_frame");
      
      tf_Sensor2Table = stf_base2Sensor.inverse() * tf_W2T;
      stf_x2Table = tf::StampedTransform(tf_W2T, ros::Time::now(), "/world", "/table_frame");
      tf_Table2Sensor = tf_Sensor2Table.inverse();
      
      tf::Transform tf_st (tf_Sensor2Table.getRotation(), v3_000);
      N_table = tf_st*-v3_001;
      d_table = - tf_Table2Sensor.getOrigin().z();
      std::cout << "N_table:"<< N_table.x()<<" "<< N_table.y()<<" "<< N_table.z()<<" "<<"  d_table:"<< d_table<<"\n";
      
      if_use_GlobalTABLE = 1;
      if_exist_stf_World2Table = 1;
      return true;
    }
    
    bool get_Table_SAC(tf::Point &N_table0, float &d_table0)
    {
      float vox_r = 0.01f;
      
    ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   vox - ");
      pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_vox (new pcl::PointCloud<pcl::PointXYZ>);
      pcl::VoxelGrid<pcl::PointXYZ> sor;
      sor.setInputCloud (cloud);
      sor.setLeafSize (vox_r, vox_r, vox_r);
      sor.filter (*cloud_vox);
    ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   vox - finished");  
	
    
    ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   sac on vox - ");
      pcl::ModelCoefficients::Ptr vox_plane_coef (new pcl::ModelCoefficients);
      pcl::PointIndices::Ptr vox_plane_inliers (new pcl::PointIndices);
      pcl::PointCloud<pcl::PointXYZ>::Ptr outliers (new pcl::PointCloud<pcl::PointXYZ>);

      pcl::SACSegmentation<pcl::PointXYZ> segv;
      segv.setOptimizeCoefficients (true);
      segv.setModelType (pcl::SACMODEL_PLANE);
      segv.setMethodType (pcl::SAC_RANSAC);
      segv.setDistanceThreshold (0.02);
      segv.setMaxIterations(200);
      segv.setInputCloud (cloud_vox);
      segv.segment (*vox_plane_inliers, *vox_plane_coef);
      N_table0 = (tf::Point(vox_plane_coef->values[0],vox_plane_coef->values[1],vox_plane_coef->values[2])); d_table0 = vox_plane_coef->values[3];
    ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   sac on vox - finished"); 
    }
    
//     tf::StampedTransform get_TfS_Sensor2Table()
//     {
// //       return tf::StampedTransform(tf_Sensor2Table, ros::Time::now(), "/camera_depth_optical_frame", "/table_frame");
//       return stf_Sensor2Table;
//     }
//     
//     tf::StampedTransform get_TfS_Sensor2Table(tf::Point &N_table0, float &d_table0) 
//     {
//       set_Tf_Sensor2Table(N_table0, d_table0);
// //       return tf::StampedTransform(tf_Sensor2Table, ros::Time::now(), "/camera_depth_optical_frame", "/table_frame");
//       return stf_Sensor2Table;
//     }

    
    
    tf::Transform set_Tf_Sensor2Table() 
    {
      if (if_exist_stf_World2Flange && if_exist_stf_World2Table && if_exist_stf_Flange2Sensor)
      {
	tf_Sensor2Table = (stf_World2Flange*stf_Flange2Sensor).inverse() * stf_World2Table;
	std::cout << "\033[34m""  set_Tf_Sensor2Table =\n";
	std::cout << std::fixed << std::setprecision(4) << "      { (" << tf_Sensor2Table.getOrigin().x()<<", "<< tf_Sensor2Table.getOrigin().y()<<", "<< tf_Sensor2Table.getOrigin().z()<<"), ("
		  << tf_Sensor2Table.getRotation().x()<<", "<< tf_Sensor2Table.getRotation().y()<<", "<< tf_Sensor2Table.getRotation().z()<< " | "<< tf_Sensor2Table.getRotation().w()<<") }\n";

	tf_Table2Sensor = tf_Sensor2Table.inverse();   	
	std::cout << "  tf_Table2Sensor =\n";
	std::cout << std::fixed << std::setprecision(4) << "      { (" << tf_Table2Sensor.getOrigin().x()<<", "<< tf_Table2Sensor.getOrigin().y()<<", "<< tf_Table2Sensor.getOrigin().z()<<"), ("
		  << tf_Table2Sensor.getRotation().x()<<", "<< tf_Table2Sensor.getRotation().y()<<", "<< tf_Table2Sensor.getRotation().z()<< " | "<< tf_Table2Sensor.getRotation().w()<<") }\n";
	
	tf::Transform tf_Sensor2Table_rot(tf_Sensor2Table.getRotation(), v3_000);
	N_table = tf_Sensor2Table_rot*(-v3_001);
	d_table = - tf_Table2Sensor.getOrigin().z();
 	std::cout << "  N_table & d_table : " << N_table.x() <<" " << N_table.y() <<" " << N_table.z() <<" " << d_table <<"\033[0m""\n";
  //       stf_Table2Sensor = tf::StampedTransform(tf_Table2Sensor, ros::Time::now(), "/table_frame", "/camera_depth_optical_frame");
      }
      return tf_Sensor2Table;
    }
    
    tf::Transform set_Tf_Sensor2Table(tf::Point &N_table0, float &d_table0) 
    {
      //tf_Sensor2Table.setIdentity();
//       pcl::ModelCoefficients::Ptr coefficients_plane (new pcl::ModelCoefficients);

//       N_table = N_table0; d_table=d_table0;
      tf::Point Pxyz = tf::Point(0,0,(float)-d_table0/N_table0.z());
      tf::Point Pnorm = N_table0;
      if (tf::tfDot(Pnorm,Pxyz)<0.0) 	Pnorm = -Pnorm;
      
      tf::Quaternion q;
      tf::Vector3 v;
//       tf::Point e_x (tf::Point(1,0,0)); tf::Point e_z (tf::Point(0,0,1));
      v = tf::tfCross(Pnorm,v3_001);    v.normalize();
      q = tf::Quaternion(v, -1.0*tf::tfAngle(Pnorm, v3_001)); 
      v = tf::quatRotate(q, v3_100); v.setZ(0);
      if (tf::tfDot(tf::tfCross(v3_100, v),Pnorm)>0.0)
	q = q*tf::Quaternion(v3_001, -1.0*tf::tfAngle(v3_100, v)); 
      else
	q = q*tf::Quaternion(v3_001, +1.0*tf::tfAngle(v3_100, v));
      //q.normalize();

//       tf_Sensor2Table = tf::Transform(q,Pxyz);
      tf_Sensor2Table = tf::Transform(q,Pxyz) * tf::Transform(tf::Quaternion(1,0,0,0),tf::Point(0,0,0));
      stf_x2Table = tf::StampedTransform(tf_Sensor2Table, ros::Time::now(), "/camera_depth_optical_frame", "/table_frame");
      tf_Table2Sensor = tf_Sensor2Table.inverse();    
//       stf_Table2Sensor = tf::StampedTransform(tf_Table2Sensor, ros::Time::now(), "/table_frame", "/camera_depth_optical_frame");
      
      return tf_Sensor2Table;
    }

#if 0
    bool calc_stf_x2Table_fromWorld( ros::NodeHandle &nh )
    {
      if (if_use_GlobalTABLE) 	return true;
      // turn stf_Sensor2Table into stf_World2Table for stf_x2Table
      if ( nh.ok() && stf_x2Table.frame_id_ != "/kr5_link1") 
      {
	bool yep = true;
	
// 	  ROS_INFO_STREAM(".");
	tf::TransformListener listener;
	
	tf::StampedTransform stf_world2Sensor;
	listener.waitForTransform("/kr5_link1", "/camera_depth_optical_frame", ros::Time(0), ros::Duration(0.50));
	try { listener.lookupTransform("/kr5_link1", "/camera_depth_optical_frame", ros::Time(0), stf_world2Sensor);    }    
	catch (tf::TransformException &ex) { ROS_ERROR("%s",ex.what());    yep = false;	}
	if (yep)
	{
	  ROS_INFO_STREAM("changed");
	  stf_x2Table = tf::StampedTransform(stf_world2Sensor * tf_Sensor2Table, ros::Time::now(), "/kr5_link1", "/table_frame");
	  return true;
	} 
	
  //       try { listener.lookupTransform("/kr5_link1", "/kr5_flansch",ros::Time(0), stf_world2Sensor);    }    
  //       catch (tf::TransformException &ex) { ROS_ERROR("%s",ex.what());    yep = false;	}
  //       if (yep)
  //       {
  // 	stf_x2Table = tf::StampedTransform(stf_world2Sensor * tf_Flange2Sensor * tf_Sensor2Table, ros::Time::now(), "/kr5_link1", "/table_frame");
  // 	return true;
  //       }
	
      }
      return false;
    }
#endif
    
    bool relocateCloud_toTableFrame(bool trimUnderTable) 			// this could be improved to be faster
    {    
//       idx_valid->clear();
      pcl_ros::transformPointCloud(*cloud, *cloud, tf_Table2Sensor);
      cloud->header.frame_id = "/table_frame";
      if (trimUnderTable)
      {	for (size_t i = 0; i < cloud->size() ; ++i)
	  if ( cloud->points[ i ].z < -0.001 )
	    cloud->points[ i ] = PointXYZ_nan;
// 	  else
// 	    idx_valid.push_back(i);
      }
      tf::Quaternion q(tf_Table2Sensor.getRotation());
      tf::Point p(tf_Table2Sensor.getOrigin());
      
      cloud->sensor_origin_ = Eigen::Vector4f(p.x(),p.y(),p.z(),1.0);
      cloud->sensor_orientation_ = Eigen::Quaternionf(q.w(),q.x(),q.y(),q.z());
       
      return true;
    }
    
#if 0
    bool relocateCloud_to_World_and_GlobalTABLE(bool trimUnderTable = false) 			// this could be improved to be faster
    {    
      ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   relocate - ");
//       idx_valid->clear();
      	
      bool yep = true;
	
      tf::TransformListener listener;
      
      tf::StampedTransform stf_Sensor2World;
      listener.waitForTransform("/world","/camera_depth_optical_frame", ros::Time(0), ros::Duration(1.0));
      try { listener.lookupTransform("/world","/camera_depth_optical_frame", ros::Time(0), stf_Sensor2World);    }    
      catch (tf::TransformException &ex) { ROS_ERROR("%s",ex.what());    yep = false;	}
      if (yep)
      {
	pcl_ros::transformPointCloud(*cloud, *cloud, stf_Sensor2World);
	cloud->header.frame_id = "/world";
	
	tf::StampedTransform stf_World2Sensor (stf_Sensor2World.inverse(), ros::Time::now(), "/world", "/camera_depth_optical_frame");
	tf::Quaternion q(stf_World2Sensor.getRotation());
	tf::Point p(stf_World2Sensor.getOrigin());
	
	cloud->sensor_origin_ = Eigen::Vector4f(p.x(),p.y(),p.z(),1.0);
	cloud->sensor_orientation_ = Eigen::Quaternionf(q.w(),q.x(),q.y(),q.z());
	
	normal_estimator.setViewPoint(p.x(),p.y(),p.z());
	ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   relocate - fin");  
	
	stf_x2Table = tf::StampedTransform(tf::Transform(q_u, 0.3*v3_001), ros::Time::now(), "/world", "/table_frame");
	if_use_GlobalTABLE = 1;
	return true;
      } 
      return false;
    }
#endif
      
    void set_table_trim_offset(float table_trim_offset_)
    {
      table_trim_offset=table_trim_offset_;
    }  
    float get_table_trim_offset()
    {
      return table_trim_offset;
    }  
      
//     bool label_object_onTable_cam(int x, int y, uint current_label, int remaining_depth = 320, uint Pid_old = 0)	//return the block and list of all cloud inside
    bool label_object_onTable_cam(int x, int y, uint current_label, uint Pid_old = 0)	//return the block and list of all cloud inside
    {
//       ROS_INFO_STREAM(x<<"-"<<y);
      
      uint W (cloud->width), H (cloud->height); 
      if (x < 0 || x >= W) return false; // out of bounds
      if (y < 0 || y >= H) return false; // out of bounds
      
      uint Pid = y*W+x;
      if (cloud_label->points[Pid].label!=0) return false;	// already registered
      
      if (isnan(cloud->points[Pid].x)||isnan(cloud->points[Pid].y)||isnan(cloud->points[Pid].z)) 				// is nan
      {
	cloud_label->points[Pid_old].label = 999;
      	return false;
      }
      
//       tf::Point pt (tf::Point(,cloud->points[Pid].y,cloud->points[Pid].z));
//       if ( (-tf::tfDot(pt,N_table)-d_table) < table_trim_offset ) 	// under table
      if ( (-cloud->points[Pid].x*N_table.getX()
	    -cloud->points[Pid].y*N_table.getY()
	    -cloud->points[Pid].z*N_table.getZ()-d_table) < table_trim_offset ) 	// under table
      {
	cloud_label->points[Pid_old].label = 888;
	return false;
      }
      
      if (x>trim_x_max) trim_x_max= x;
      if (x<trim_x_min) trim_x_min= x;
      if (y>trim_y_max) trim_y_max= y;
      if (y<trim_y_min) trim_y_min= y;
      
//       if (current_label >= 1 && current_label < 100) current_label = current_label*100;
	
      cloud_label->points[Pid].label = current_label;
// 	ROS_INFO_STREAM("+");
      
//       if (remaining_depth < 1) return true; 
//       int remaining_depth_1 = remaining_depth -1;      
//       label_object_onTable_cam(x-1, y , current_label, remaining_depth_1, Pid);
//       label_object_onTable_cam(x, y-1 , current_label, remaining_depth_1, Pid);
//       label_object_onTable_cam(x+1, y , current_label, remaining_depth_1, Pid);
//       label_object_onTable_cam(x, y+1 , current_label, remaining_depth_1, Pid);
      
      label_object_onTable_cam(x-1, y , current_label,  Pid);
      label_object_onTable_cam(x, y-1 , current_label,  Pid);
      label_object_onTable_cam(x+1, y , current_label,  Pid);
      label_object_onTable_cam(x, y+1 , current_label,  Pid);
      
      return true;
    }
      
      
    bool label_object_onTable_global(int x, int y, uint current_label, uint Pid_old = 0)	//return the block and list of all cloud inside
    {
//       ROS_INFO_STREAM(x<<"-"<<y);
      
      uint W (cloud->width), H (cloud->height); 
      if (x < 0 || x >= W) return false; // out of bounds
      if (y < 0 || y >= H) return false; // out of bounds
      
      uint Pid = y*W+x;
      if (cloud_label->points[Pid].label!=0) return false;	// already registered
      if (isnan(cloud->points[Pid].x)) 				// is nan
      {
	cloud_label->points[Pid_old].label = 999;
// 	ROS_INFO_STREAM("+");
      	return false;
      }
      
      if ( cloud->points[Pid].z < table_trim_offset ) 	// under table
      {
	cloud_label->points[Pid_old].label = 888;
	return false;
      }
      
      if (x>trim_x_max) trim_x_max= x;
      if (x<trim_x_min) trim_x_min= x;
      if (y>trim_y_max) trim_y_max= y;
      if (y<trim_y_min) trim_y_min= y;
      
      cloud_label->points[Pid].label = current_label;
      
      label_object_onTable_global(x-1, y , current_label,Pid);
      label_object_onTable_global(x+1, y , current_label,Pid);
      label_object_onTable_global(x, y-1 , current_label,Pid);
      label_object_onTable_global(x, y+1 , current_label,Pid);
      
      return true;
    }      
    
    uint label_object_onTable_global_2(int X, int Y, uint current_label)	//return the block and list of all cloud inside
    {
//       ROS_INFO_STREAM(x<<"-"<<y);
      cloud_label->clear();
      cloud_label->resize(cloud->size());
      cloud_label->height = cloud->height; cloud_label->width = cloud->width; 
      
      std::vector < std::pair <int, int> > ngb {std::make_pair(1,0),std::make_pair(0,1),std::make_pair(-1,0),std::make_pair(0,-1)};
      
      uint W (cloud->width), H (cloud->height); 
      if (X < 0 || X >= W) return 0; // out of bounds
      if (Y < 0 || Y >= H) return 0; // out of bounds
      
      uint Pid = Y*W+X;
      
      std::vector <std::pair <int, int>> idx_frontline {std::make_pair(X,Y)};
      std::vector <std::pair <int, int>> idx_frontline_next {};
      
      int x, y;
      uint count = 0;
      
      while (idx_frontline.size() > 0)
      {
//        ROS_WARN_STREAM(idx_frontline.size());
	for (uint i = 0; i <idx_frontline.size(); i++)
	{
	  for (std::pair <int, int> it : ngb)
	  {
	    x = idx_frontline[i].first + it.first;
	    y = idx_frontline[i].second + it.second;
	    
	    if (x < 0 || x >= W)  continue; // out of bounds
	    if (y < 0 || y >= H)  continue; // out of bounds

	    if (cloud_label->at(x,y).label!=0) continue;	// already registered
	    if (isnan(cloud->at(x,y).z)) 				// is nan
	    {
	      cloud_label->at(idx_frontline[i].first,idx_frontline[i].second).label = 999;
      // 	ROS_INFO_STREAM("+");
	      continue;
	    }
//     	    ROS_INFO_STREAM(-cloud->at(x,y).x*N_table.getX()
// 		  -cloud->at(x,y).y*N_table.getY()
// 		  -cloud->at(x,y).z*N_table.getZ()-d_table);
            if ( (-cloud->at(x,y).x*N_table.getX()
		  -cloud->at(x,y).y*N_table.getY()
		  -cloud->at(x,y).z*N_table.getZ()-d_table) < table_trim_offset ) 	// under table
	    {
	      cloud_label->at(idx_frontline[i].first, idx_frontline[i].second).label = 888;
	      continue;
	    }
	    
	    if (idx_frontline[i].first>trim_x_max) trim_x_max= idx_frontline[i].first;
	    if (idx_frontline[i].first<trim_x_min) trim_x_min= idx_frontline[i].first;
	    if (idx_frontline[i].second>trim_y_max) trim_y_max= idx_frontline[i].second;
	    if (idx_frontline[i].second<trim_y_min) trim_y_min= idx_frontline[i].second;
	    
	    cloud_label->at(x,y).label = current_label;
	    idx_frontline_next.push_back(std::make_pair(x,y));
	    count ++;
	  }
	}
	idx_frontline = idx_frontline_next;
	idx_frontline_next.clear();
      }
            
      return count;
    }
      
    bool label_object_regardlessTable(int x, int y, uint current_label, uint Pid_old = 0)	//return the block and list of all cloud inside
    {
//       ROS_INFO_STREAM(x<<"-"<<y);
      
      uint W (cloud->width), H (cloud->height); 
      if (x < 0 || x >= W) return false; // out of bounds
      if (y < 0 || y >= H) return false; // out of bounds
      
      uint Pid = y*W+x;
      if (cloud_label->points[Pid].label!=0) return false;	// already registered
      if (isnan(cloud->points[Pid].x)) 			// is nan
      {
	cloud_label->points[Pid_old].label = 999;
// 	ROS_INFO_STREAM("+");
      	return false;
      }
      
      if (x>trim_x_max) trim_x_max= x;
      if (x<trim_x_min) trim_x_min= x;
      if (y>trim_y_max) trim_y_max= y;
      if (y<trim_y_min) trim_y_min= y;
      
      cloud_label->points[Pid].label = current_label;
      
      label_object_regardlessTable(x-1, y , current_label,Pid);
      label_object_regardlessTable(x+1, y , current_label,Pid);
      label_object_regardlessTable(x, y-1 , current_label,Pid);
      label_object_regardlessTable(x, y+1 , current_label,Pid);
      
      return true;
    }
      
    uint trim_cloud_label()	//return the block and list of all cloud inside
    {
      int W (cloud->width), H (cloud->height); 
      int W2 (trim_x_max-trim_x_min+1), H2 (trim_y_max-trim_y_min+1); 
      if (W2<0) 
      {
	ROS_ERROR("empty point to lable");
	return 0;
      }

      std::cout << trim_x_min<<"-"<<trim_x_max<<" ; "<<trim_y_min<<"-"<<trim_y_max;
      pcl::PointCloud<pcl::PointXYZ>::Ptr cloud2 (new pcl::PointCloud<pcl::PointXYZ>);
      pcl::PointCloud<pcl::Label>::Ptr cloud_label2 (new pcl::PointCloud<pcl::Label>);
      idx_valid->clear();
      cloud2->width = W2; cloud2->height = H2;
      cloud_label2->width = W2; cloud_label2->height = H2;
      uint ID = 0;
      for (uint y=trim_y_min; y<=trim_y_max; y++)
	for (uint x=trim_x_min; x<=trim_x_max; x++)
	{
	  uint Pid = y*W+x;
	  if (cloud_label->points[Pid].label ==0) 
	    cloud2->points.push_back(PointXYZ_nan);
	  else
	  {
	    if (cloud_label->points[Pid].label >=777) 
	    {
	      idx_border->push_back(ID);
	    }
	    cloud2->points.push_back(cloud->points[Pid]);
	    idx_valid->push_back(ID);
	  }
	  
	  cloud_label2->points.push_back(cloud_label->points[Pid]);
	  
	  ID ++;
	}
	  
//       for (uint i=0; i<cloud->size(); i++) if (label->points[i].label ==0) cloud->points[i]= PointXYZ_nan; 
      std::cout<<"\033[33m\033[1m\n" << cloud2->size()<<" points in cloud with "<<idx_valid->size()<<" valid\033[0m\n";

      cloud->clear();
      *cloud = *cloud2;
      cloud_label->clear();
      *cloud_label = *cloud_label2;
      return cloud->size();
    }
      
    int calc_border_inlander(float curv_Mx_in = 0.004, float borderRadius = 0.008)	///////////////////////////////////////////
    {
    
//	pcl::copyPointCloud(*cloud, *cloud_inlander);
	*cloud_inlander = *cloud;
	idx_inlander->clear();
	
	curv_Mx = curv_Mx_in;
	
	tree_inlander.setInputCloud(cloud_inlander);
		//	better be place somewhere else as well, in case calc_border_inlander is skiped
	
	
	std::cout<<"\033[1m" "border contains "<<idx_border->size()<<"\t regardless curvature\033[0m"<<std::endl;
	for (size_t i = 0; i < cloud->size (); ++i)
	{
	  if (isnan(normals->points[i].curvature)) continue;
	  
	  if ((normals->points[i].curvature > curv_Mx))		// curvature = dT/ds ~=	theta*1/ds ~ 1/R
	  {
	    idx_border->push_back(i);
	    cloud_label->points[i].label = 777;
	    //cloud_border->push_back(cloud->points[i]);
	  }
	}
	std::cout<<"\033[1m""border contains "<<idx_border->size() <<"\t considering curvature\033[0m"<<std::endl;
	
//       ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   filtering - big curvature extracted");
	
	for (size_t i = 0; i < idx_border->size (); ++i)
	{
	  //if (!isnan(cloud->points[idx_border->at(i)].x))		// curvature = dT/ds ~=	theta*1/ds ~ 1/R
	  {
	  
	    std::vector<float> pointRadiusSquaredDistanceInlander;
	    pcl::IndicesPtr pointIdxInander (new std::vector <int>);
	    if ( tree_inlander.radiusSearch (cloud->points[idx_border->at(i)], borderRadius, *pointIdxInander, pointRadiusSquaredDistanceInlander) > 0 )
	    {
    //	  std::cout<<tree.radiusSearch (cloud->points[i], 0.016, *pointIdxInander, pointRadiusSquaredDistanceInlander)<<" ";
	      uint cur_over_count  = 0;
	      for (size_t ii = 0; ii < pointIdxInander->size (); ++ii)
	      {
		//idx_inlander->push_back(pointIdxInander->at(ii));
		cloud_inlander->points[ pointIdxInander->at(ii) ] = PointXYZ_nan;		// temporary set points inner-rim to nan
		cloud_label->points[ pointIdxInander->at(ii) ].label = 111; 			// label as not inlander
	      }
	    }
	    
	  }
	    //cloud_lN->points.push_back(normals->points[ (*idx_find_out)[i] ]);
	}
	
// 	pcl::removeNaNFromPointCloud(*cloud_inlander, *idx_inlander);
	for (size_t i = 0; i < cloud_inlander->size (); ++i)
	{
	  if (!isnan(cloud_inlander->at(i).x)) 
	  {
	    idx_inlander->push_back(i);
// 	    cloud_label->points[i].label = 17;	// label inlander
	  }
	  
	}
	
	std::cout<<"\033[96m" "inlanders contains "<<idx_inlander->size()<<"\033[0m"<<std::endl;

	return idx_inlander->size();
//       ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   filtering - fin");
	      
    }
    
    pcl::PointCloud<pcl::PointXYZ>::Ptr get_cloud_border()
    {
      pcl::copyPointCloud(*cloud, *idx_border, *cloud_border);
      return cloud_border;
    }
    
    void set_stf_Table2Tool (tf::Transform tf_)
    {
      stf_Table2Tool = tf::StampedTransform(tf_, ros::Time::now(), "/table_frame", "/tool_frame");
    }   
    
    void set_stf_Table2Tool (tf::StampedTransform stf_)
    {
      stf_Table2Tool = tf::StampedTransform(stf_, ros::Time::now(), "/table_frame", "/tool_frame");
      //stf_Table2Tool = stf_;
    }
    
    void init_v_stf_Tool2CupBases()		// set_v_stf_Tool2CupBases
    {
      v_stf_Tool2CupBases.resize(5);
      set_v_stf_Tool2CupBases(tf::Transform(q_u,tf::Point(0,0,0.1)), 0.1,0.07,0.00);
    }

    void init_v_stf_Tool2CupBases(tf::Transform tf_)		// set_v_stf_Tool2CupBases
    {
      v_stf_Tool2CupBases.resize(5);
      set_v_stf_Tool2CupBases(tf_, 0.1,0.07,0.00);
    }
    
    void set_v_stf_Tool2CupBases(tf::Transform tf_tool2cupbase0, float cfgX, float cfgY = 0.070, float cfgZ = 0.00)		// set_v_stf_Tool2CupBases
    {
      v_stf_Tool2CupBases.resize(5);
      
      set_v_stf_Tool2CupBases_tfBase0(tf_tool2cupbase0);
      set_v_stf_Tool2CupBases_cfgXYZ(cfgX,cfgY,cfgZ);
      
//       float cfgX2(fabs(cfgX)/2.0), cfgY2(fabs(cfgY/2.0));
//       v_stf_Tool2CupBases[0] = tf::StampedTransform(tf_tool2cupbase0, ros::Time::now(),"/tool_frame","/cupbase_frame/0");	// suction orientation ref
//       v_stf_Tool2CupBases[1] = tf::StampedTransform(tf::Transform(q_u,tf::Point(-cfgX2,-cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/1");
//       v_stf_Tool2CupBases[2] = tf::StampedTransform(tf::Transform(q_u,tf::Point(-cfgX2, cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/2");
//       v_stf_Tool2CupBases[3] = tf::StampedTransform(tf::Transform(q_u,tf::Point( cfgX2,-cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/3");
//       v_stf_Tool2CupBases[4] = tf::StampedTransform(tf::Transform(q_u,tf::Point( cfgX2, cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/4");
    }
    
    void set_v_stf_Tool2CupBases_tfBase0(tf::Transform tf_tool2cupbase0)		// set_v_stf_Tool2CupBases
    {
//       v_stf_Tool2CupBases.resize(5);
      v_stf_Tool2CupBases[0] = tf::StampedTransform(tf_tool2cupbase0, ros::Time::now(),"/tool_frame","/cupbase_frame/0");	// suction orientation ref
    }
    
    void set_v_stf_Tool2CupBases_cfgXYZ(float cfgX, float cfgY, float cfgZ)		// set_v_stf_Tool2CupBases
    {
//       v_stf_Tool2CupBases.resize(5);
      float cfgX2(fabs(cfgX)/2.0), cfgY2(fabs(cfgY/2.0));
      v_stf_Tool2CupBases[1] = tf::StampedTransform(tf::Transform(q_u,tf::Point(-cfgX2,-cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/1");
      v_stf_Tool2CupBases[2] = tf::StampedTransform(tf::Transform(q_u,tf::Point(-cfgX2, cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/2");
      v_stf_Tool2CupBases[3] = tf::StampedTransform(tf::Transform(q_u,tf::Point( cfgX2,-cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/3");
      v_stf_Tool2CupBases[4] = tf::StampedTransform(tf::Transform(q_u,tf::Point( cfgX2, cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/4");
    }
    
    void set_v_stf_Tool2CupBases_cfgXY(float cfgX, float cfgY)		// set_v_stf_Tool2CupBases
    {
//       v_stf_Tool2CupBases.resize(5);
//       float cfgX2(fabs(cfgX)/2.0), cfgY2(fabs(cfgY/2.0));
      float cfgZ = v_stf_Tool2CupBases[1].getOrigin().z();
      set_v_stf_Tool2CupBases_cfgXYZ(cfgX,cfgY,cfgZ);
//       v_stf_Tool2CupBases[1] = tf::StampedTransform(tf::Transform(q_u,tf::Point(-cfgX2,-cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/1");
//       v_stf_Tool2CupBases[2] = tf::StampedTransform(tf::Transform(q_u,tf::Point(-cfgX2, cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/2");
//       v_stf_Tool2CupBases[3] = tf::StampedTransform(tf::Transform(q_u,tf::Point( cfgX2,-cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/3");
//       v_stf_Tool2CupBases[4] = tf::StampedTransform(tf::Transform(q_u,tf::Point( cfgX2, cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/4");
    }
    
    void set_v_stf_Tool2CupBases_cfgX(float cfgX)		// set_v_stf_Tool2CupBases
    {
//       v_stf_Tool2CupBases.resize(5);
      float cfgY = fabs(2.0*v_stf_Tool2CupBases[1].getOrigin().y());
//       float cfgX2(fabs(cfgX)/2.0), cfgY2(fabs(cfgY));
      float cfgZ = v_stf_Tool2CupBases[1].getOrigin().z();
      set_v_stf_Tool2CupBases_cfgXYZ(cfgX,cfgY,cfgZ);
//       v_stf_Tool2CupBases[1] = tf::StampedTransform(tf::Transform(q_u,tf::Point(-cfgX2,-cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/1");
//       v_stf_Tool2CupBases[2] = tf::StampedTransform(tf::Transform(q_u,tf::Point(-cfgX2, cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/2");
//       v_stf_Tool2CupBases[3] = tf::StampedTransform(tf::Transform(q_u,tf::Point( cfgX2,-cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/3");
//       v_stf_Tool2CupBases[4] = tf::StampedTransform(tf::Transform(q_u,tf::Point( cfgX2, cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/4");
    }
    
    void set_v_stf_Tool2CupBases_cfgZ(float cfgZ)		// set_v_stf_Tool2CupBases
    {
//       v_stf_Tool2CupBases.resize(5);
      float cfgX = fabs(2.0*v_stf_Tool2CupBases[1].getOrigin().x());
      float cfgY = fabs(2.0*v_stf_Tool2CupBases[1].getOrigin().y());
      set_v_stf_Tool2CupBases_cfgXYZ(cfgX,cfgY,cfgZ);
//       float cfgX2(fabs(cfgX)), cfgY2(fabs(cfgY));
//       v_stf_Tool2CupBases[1] = tf::StampedTransform(tf::Transform(q_u,tf::Point(-cfgX2,-cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/1");
//       v_stf_Tool2CupBases[2] = tf::StampedTransform(tf::Transform(q_u,tf::Point(-cfgX2, cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/2");
//       v_stf_Tool2CupBases[3] = tf::StampedTransform(tf::Transform(q_u,tf::Point( cfgX2,-cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/3");
//       v_stf_Tool2CupBases[4] = tf::StampedTransform(tf::Transform(q_u,tf::Point( cfgX2, cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/4");
    }
    
    tf::StampedTransform get_stf_Tool2CupBases(uint i)		// set_v_stf_Tool2CupBases
    {
      if (i<0 || i>5) return v_stf_Tool2CupBases[0];
      v_stf_Tool2CupBases[i].stamp_ = ros::Time::now();
      tf::StampedTransform stf_tmp(v_stf_Tool2CupBases[0]*v_stf_Tool2CupBases[i], ros::Time::now(),"/tool_frame","/cupbase_frame/"+std::to_string(i));
      return stf_tmp;
    }
        
    yf_vacuum_cups::msg_cup_draw genDrawMsg(const uint cupid_, const tf::StampedTransform stf_table2tool, const tf::StampedTransform stf_tool2cup, const uint cupN_= 0) 
    {
      
    }
    
    yf_vacuum_cups::msg_cup_draw genDrawMsg(const uint cupid_, const tf::StampedTransform stf_, const uint cupN_= 0) 
    {
      yf_vacuum_cups::msg_cup_draw cupDraw_msg;
      cupDraw_msg.cupId = cupid_; 
      tf::transformStampedTFToMsg(stf_, cupDraw_msg.transformstamped);    
      cupDraw_msg.transformstamped.header.stamp = ros::Time::now();
      cupDraw_msg.cupN = cupN_;
      return cupDraw_msg;
    }
    
    yf_vacuum_cups::msg_cup_draw genDrawMsg(const uint cupid_, const tf::Transform tf_, const uint cupN_= 0) 
    {
      yf_vacuum_cups::msg_cup_draw cupDraw_msg;
      tf::StampedTransform stf_ = (tf::StampedTransform(tf_, ros::Time::now(), "/table_frame", "/cups_frame/"+std::to_string(cupid_)));
      cupDraw_msg.cupId = cupid_; 
      tf::transformStampedTFToMsg(stf_, cupDraw_msg.transformstamped);    
      cupDraw_msg.cupN = cupN_;
      return cupDraw_msg;
    }
    
    void draw_norm_mordel( pcl::PointNormal searchPointNorm, tf::Point N_axis, tf::Point K, pcl::ModelCoefficients::ConstPtr coefficients_cylinder , visualization_msgs::Marker &cylin, visualization_msgs::Marker &sPnorm)
    {     
//       ROS_INFO_STREAM("draw_norm_mordel") ;
//      ros::NodeHandle priv_nh("~");
//      ros::Publisher vis_pub = priv_nh.advertise<visualization_msgs::Marker>( "cup_vis2", 10 , true);
      
      tf::Point vTmp; tf::Quaternion q;
//      visualization_msgs::Marker cylin, sPnorm;
      cylin.header.frame_id = sPnorm.header.frame_id = "/table_frame";
      cylin.header.stamp = sPnorm.header.stamp 	= ros::Time::now();
      cylin.ns = sPnorm.ns  =  "sucker";
      cylin.action = sPnorm.action = visualization_msgs::Marker::ADD;
      cylin.id = 9; sPnorm.id = 10;
      cylin.type = visualization_msgs::Marker::CYLINDER;
      cylin.scale.x =coefficients_cylinder->values[6]*2;	cylin.scale.y = coefficients_cylinder->values[6]*2; 	cylin.scale.z = 0.1;
      cylin.color.r = 0.7;	cylin.color.g = 0.7;	cylin.color.b = 0.7;	cylin.color.a = 0.3;
      sPnorm.type = visualization_msgs::Marker::ARROW;
      sPnorm.scale.x = 0.002;	sPnorm.scale.y = 0.004;		sPnorm.scale.z = 0.0;
      sPnorm.color.r = 1.0;	sPnorm.color.g = 0.0;		sPnorm.color.b = 0.8;		sPnorm.color.a = 0.8;
      geometry_msgs::Pose pose1;
      tf::Transform tf_d1;
      tf_d1.setOrigin(K);
      vTmp = N_axis.cross(v3_001);
      vTmp.normalize();
      q = tf::Quaternion(vTmp, -1.0*acos(N_axis.dot(v3_001)/N_axis.length ())); //////////////////
      tf_d1.setRotation(q);
      tf::poseTFToMsg(tf_d1, pose1);
      cylin.pose = pose1;
      
      geometry_msgs::Point searchPointMsg,searchPointMsg2;
      searchPointMsg.x = searchPointNorm.x; searchPointMsg.y = searchPointNorm.y; searchPointMsg.z = searchPointNorm.z;
      searchPointMsg2.x=searchPointNorm.x+searchPointNorm.normal_x*0.02; searchPointMsg2.y=searchPointNorm.y+searchPointNorm.normal_y*0.02; searchPointMsg2.z=searchPointNorm.z+searchPointNorm.normal_z*0.02;
      sPnorm.points.push_back(searchPointMsg);    
      sPnorm.points.push_back(searchPointMsg2); 
  
//      vis_pub.publish(cylin);
//      vis_pub.publish(sPnorm);
      
//       ros::spin();
    }
    
     void draw_CenterOfMass(visualization_msgs::Marker &CM)
    {     
//       ROS_INFO_STREAM("draw_CenterOfMass") ;
      
      float r1 = 0.006;
      visualization_msgs::Marker cm;
      cm.header.frame_id = "/table_frame";
      cm.header.stamp 	= ros::Time::now();
      cm.ns  =  "CenterOfMass";
      cm.action = visualization_msgs::Marker::ADD;
      cm.id = 400;
      cm.type = visualization_msgs::Marker::SPHERE;
      cm.scale.x = r1;	cm.scale.y = r1;		cm.scale.z = r1;
      cm.pose.position.x = massCenter.x();
      cm.pose.position.y = massCenter.y();
      cm.pose.position.z = massCenter.z();
      cm.color.r = 1;	cm.color.g = 1;	cm.color.b = 1;	cm.color.a = 1;
      CM = cm;
    }
    
    
    void draw_NormalSphere_projection(std::vector<visualization_msgs::Marker> &porjectionPlain)
    {     
//       ROS_INFO_STREAM("draw_NormalSphere_projection") ;
      
      float d1 = 0.2;
      
      for (uint i = 1; i<NSphere_viewAngles_stf.size(); i++)
      {
	visualization_msgs::Marker plainX;
// 	std::string frameName = "/PjPl/" + std::to_string(i);
	std::string frameName = NSphere_viewAngles_stf[i].child_frame_id_;
	plainX.header.frame_id = frameName;
	plainX.header.stamp 	= ros::Time::now();
	plainX.ns  =  "NormalSphere_projection";
	plainX.action = visualization_msgs::Marker::ADD;
	plainX.id = i+300;
	plainX.type = visualization_msgs::Marker::CUBE;
	plainX.scale.x = 0.2;	plainX.scale.y = 0.15;		plainX.scale.z = 0.000;
	if (i == 1)
	  {	plainX.color.r = 1;	plainX.color.g = 0.5;	plainX.color.b = 0.5;	plainX.color.a = 0.15;}
	else if (i == 2)
	  {	plainX.color.r = 1;	plainX.color.g = 1;	plainX.color.b = 0.4;	plainX.color.a = 0.15;}
	else if (i == 3)
	  {	plainX.color.r = 0.5;	plainX.color.g = 1;	plainX.color.b = 0.5;	plainX.color.a = 0.15;}
 	else if (i == 4)
	  {	plainX.color.r = 0.5;	plainX.color.g = 0.5;	plainX.color.b = 1;	plainX.color.a = 0.15;}
	else
	  {	plainX.color.r = 1;	plainX.color.g = 0.4;	plainX.color.b = 1;	plainX.color.a = 0.15;}
	
// 	tf::Point vA = NSphere_viewAngles[i];
	geometry_msgs::Pose P;
	
// 	P.position.x = vA.x() * d1; 
// 	P.position.y = vA.y() * d1;
// 	P.position.z = vA.z() * d1;
	
	tf::Quaternion oA;
	float phi, theta; 
// 	phi = asin(vA.z()); theta = atan2(vA.y(),vA.x()); // 
// 	oA = tf::Quaternion(tf::Vector3(0,0,1), theta) * tf::Quaternion(tf::Vector3(0,1,0), M_PI-phi) ;
// 	P.orientation.x = oA.x();
// 	P.orientation.y = oA.y();
// 	P.orientation.z = oA.z();
// 	P.orientation.w = oA.w();
	
	plainX.pose = P;
	porjectionPlain.push_back(plainX);
      }
    }
    
};
