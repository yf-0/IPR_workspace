#include <ros/ros.h>
#include <tf/LinearMath/Vector3.h>
#include <std_msgs/Float64MultiArray.h>


void tf_2_Float64MultiArray (tf::StampedTransform stf_, std_msgs::Float64MultiArray &ary_)
{
  tf::Point Pos(stf_.getOrigin());
  double r,p,y;
  stf_.getBasis().getRPY (r,p,y);
  ary_.data = {Pos.x(),Pos.y(),Pos.z(),r,p,y};
};

void tf_2_Float64MultiArray (tf::Transform stf_, std_msgs::Float64MultiArray &ary_)
{
  tf::Point Pos(stf_.getOrigin());
  double r,p,y;
  stf_.getBasis().getRPY (r,p,y);
  ary_.data = {Pos.x(),Pos.y(),Pos.z(),r,p,y};
};

std_msgs::Float64MultiArray tf_2_Float64MultiArray (tf::StampedTransform stf_)
{
  std_msgs::Float64MultiArray ary_;
  tf_2_Float64MultiArray (stf_, ary_);
  return ary_;
}

std_msgs::Float64MultiArray tf_2_Float64MultiArray (tf::Transform stf_)
{
  std_msgs::Float64MultiArray ary_;
  tf_2_Float64MultiArray (stf_, ary_);
  return ary_;
}
