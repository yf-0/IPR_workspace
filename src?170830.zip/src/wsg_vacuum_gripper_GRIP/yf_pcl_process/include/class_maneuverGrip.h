#include <cmath>
#include <limits>
#include <iostream>

#include <ros/ros.h>
#include <rosbag/bag.h>
#include <rosbag/view.h>

#include <visualization_msgs/Marker.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>

#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/project_inliers.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/search/search.h>
#include <pcl/search/kdtree.h>
#include <pcl/search/organized.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/features/integral_image_normal.h>
#include "pcl_ros/transforms.h"
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/extract_polygonal_prism_data.h>
#include <pcl/segmentation/region_growing.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl/surface/concave_hull.h>
#include <pcl/segmentation/organized_multi_plane_segmentation.h>
#include <pcl/segmentation/organized_connected_component_segmentation.h>
#include <pcl/segmentation/planar_region.h>
#include <pcl/segmentation/comparator.h>
#include <pcl/impl/point_types.hpp>

#include <tf/LinearMath/Vector3.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <tf_conversions/tf_eigen.h>

#include <Eigen/Core> 
#include <Eigen/Geometry> 
#include <Eigen/SVD>
#include <Eigen/Dense>

#include <yf_vacuum_cups/cup_dim.h>
#include <yf_vacuum_cups/srv_draw_cup.h>
#include <yf_vacuum_cups/msg_cup_draw.h>
#include <yf_pcl_process/msg_Grip.h>




static std::function <void(float , float &, float &)> min12 = [](float a, float &min1, float &min2)	// ranking 1.st min and 2.nd min
{
    if      (a<min1)	{ min2 = min1; min1 = a; }
    else if (a<min2) 	{ min2 = a;}
};      
      
static std::function <void(float , float &, float &)> max12 = [](float a, float &max1, float &max2)	// ranking 1.st min and 2.nd min
{
    if      (a>max1)	{ max2 = max1; max1 = a; }
    else if (a>max2) 	{ max2 = a;}
};

float R_xy(float x, float y)
{
  return sqrt(x*x+y*y);
}

float R_xy2(float x, float y)
{
  if (x > y)   return sqrt(0.941246*x + 0.41*y);
  else	       return sqrt(0.941246*y + 0.41*x);
}

tf::TransformBroadcaster *br;

class maneuverGrip : public yf_VacuumGripScene
{
//    
  
  class TendGradient
  {
    public:
      tf::Point tend_moveXY;
      float tend_moveTheta;
      float tend_cfgX;
      
      TendGradient():tend_moveTheta(0),tend_cfgX(0) {tend_moveXY.setZero(); };
      TendGradient(tf::Point a, float b, float c):tend_moveXY(a),tend_moveTheta(b),tend_cfgX(c) {};
      
    TendGradient operator+(const TendGradient &b)
    {
      return TendGradient(tend_moveXY+b.tend_moveXY, tend_moveTheta+b.tend_moveTheta, tend_cfgX + b.tend_cfgX);
    }
    
    TendGradient operator*(const float &b)
    {
      return TendGradient(b* tend_moveXY, tend_moveTheta*b, tend_cfgX * b);
    }
    
    TendGradient operator-(const TendGradient &b)
    {
      return TendGradient(tend_moveXY-b.tend_moveXY, tend_moveTheta-b.tend_moveTheta, tend_cfgX - b.tend_cfgX);
    }
    
    float len()
    {
      return sqrt(sqr());
    }
    
    float sqr()
    {
      return (tend_moveXY.length2() + tend_moveTheta*tend_moveTheta + tend_cfgX*tend_cfgX);
    }
    
    TendGradient scaled(const float &s)
    {
      return TendGradient(s* tend_moveXY, s*tend_moveTheta, 0);
    }
    
    
    TendGradient add_TendMassCenter(const TendGradient &b)
    {
      tf::Point Fmc;
      float Fcx = 0;
      
      float len = tend_moveXY.length();
      if (len < 0.001)	// 1mm
      {     
	tf::Point e_tendXY = tend_moveXY/len;
	float Xdot = tf::tfDot(b.tend_moveXY, e_tendXY);
	Fmc = b.tend_moveXY - e_tendXY*Xdot;
      }
      
      if (tend_cfgX > 0.01)
	Fcx = b.tend_cfgX;
      
      return TendGradient(tend_moveXY+Fmc, tend_moveTheta, tend_cfgX + Fcx);
    }
    
    
  };
  
  private:
    const float f_nan = NAN;
    const pcl::PointXYZ PointXYZ_nan = pcl::PointXYZ(NAN,NAN,NAN);
    const float rad2deg = 180/M_PI, deg2rad = M_PI/180;
    const tf::Point v3_000 = tf::Point(0,0,0);
    const tf::Point v3_100 = tf::Point(1,0,0);
    const tf::Point v3_010 = tf::Point(0,1,0);
    const tf::Point v3_001 = tf::Point(0,0,1);
    const tf::Quaternion q_u = tf::Quaternion(0,0,0,1);
    const tf::Transform tf_u = tf::Transform(q_u, v3_000); 
    const tf::StampedTransform stf_u = tf::StampedTransform(tf_u, ros::Time(0), "", "");  
    
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_projected_all;
    
  
  protected:
    yf_pcl_process::msg_Grip msg_grip_in;
    yf_pcl_process::msg_Grip msg_grip_now;
  std::ostream setprecision(int arg1);
    
  public:
    
    yf_pcl_process::msg_Grip msg_grip_out;
    yf_pcl_process::msg_Grip msg_grip_tend;
    
    tf::Point v3_msg_grip_now_dir;
    
    std::vector < pcl::IndicesPtr > v_idx_ring ;
    std::vector < pcl::IndicesPtr > v_idx_ring_inlander ;
    std::vector < tf::Transform > v_tf_table2cupbase ;
    std::vector < tf::StampedTransform > v_stf_table2ring ;
    std::vector < tf::StampedTransform > v_v3_norm_ring ;
    std::vector < uint > v_cupOn ;
    
    std::vector < tf::Point > v_PathDir ;
    
    maneuverGrip()    {};
    
    maneuverGrip(yf_VacuumGripScene *V_):
      cloud_projected_all (new pcl::PointCloud<pcl::PointXYZ>)
    {
//       this = V_;
//       
      this->cloud = V_->cloud;
      this->normals = V_->normals;
      this->cloud_label = V_->cloud_label;
//       this->cloud_with_normals = V_->cloud_with_normals;
      this->cloud_border = V_->cloud_border;
      this->cloud_inlander = V_->cloud_inlander;
      this->idx_valid = V_->idx_valid;
      this->idx_border = V_->idx_border;
      this->idx_inlander = V_->idx_inlander;

      this->massCenter = V_->massCenter;
//       this->stf_Table2Tool = V_->stf_Table2Tool;
      
      this->v_stf_Tool2CupBases[0] = V_->v_stf_Tool2CupBases[0];
      this->v_cup_dim_N = V_->v_cup_dim_N;
      this->v_cup_dim = V_->v_cup_dim;
      this->cup_dim_ = V_->cup_dim_;
      
      this->curv_Mx = V_->curv_Mx;
      
//       cloud_projected_all->resize(cloud->size());
//       cloud_projected_all->height = cloud->height;
//       cloud_projected_all->width = cloud->width;
//       
      *cloud_projected_all = *cloud;
      
      this->tree_cloud.setInputCloud(this->cloud);
      this->tree_inlander.setInputCloud(this->cloud_inlander);
//       this->set_v_stf_Tool2CupBases_cfgXYZ
      
      v_idx_ring.resize(5);
      v_stf_table2ring.resize(5, stf_u);
      v_tf_table2cupbase.resize(5, tf_u);
      v_v3_norm_ring.resize(5, stf_u);
      v_cupOn.resize(5, 0);
      float r2 = sqrt(2);
      v_PathDir.resize(8);
      v_PathDir[0] = tf::Point(1,0,0);
      v_PathDir[1] = tf::Point(r2,r2,0);
      v_PathDir[2] = tf::Point(0,1,0);
      v_PathDir[3] = tf::Point(-r2,r2,0);
      v_PathDir[4] = tf::Point(-1,0,0);
      v_PathDir[5] = tf::Point(-r2,-r2,0);
      v_PathDir[6] = tf::Point(0,-1,0);
      v_PathDir[7] = tf::Point(r2,-r2,0);
      
      br = new tf::TransformBroadcaster();
      
      std::cout << "\033[91m" "maneuverGrip" "\033[0m" << "\n";
    };
    
    
    class cupPath		// optional directions of movement
    {
      public:
	uint dirN = 8;
	std::vector<float> v_path {0.0,0.0, 0.0,0.0,  0.0,0.0, 0.0,0.0} ;	// this is for possible path; maped in 8 directions, 0°, 45° ...... 270° , 315°, 1:path ~ 0:blocked, [-22.5°,22.5°), [22.5°,45°)......
	std::vector<float> v_ang {0.0,0.0, 0.0,0.0,  0.0,0.0, 0.0,0.0} ;	// this is for angular deviation; maped like above
// 	std::vector<tf::Point> v_dir;	// maped in 8 directions, 0°, 45° ...... 270° , 315°, 1:path ~ 0:blocked [-22.5°,22.5°), [22.5°,45°)......
// 	tf::Point screw;			// torque applied to cup according to cupbaseframe[0]      
	
	cupPath(uint k = 8) : dirN(k)
	{
	  v_path.resize(k, 0.0);
	  v_ang.resize(k, 0.0);
// 	  v_dir.resize(k);
// 	  float rt2 = sqrt(2);
// 	  v_dir[0] = tf::Point(1,0,0);
	  //{v3_100,tf::Point(rt2,rt2,0), v3_010,tf::Point(-rt2,rt2,0),  -v3_100,tf::Point(-rt2,-rt2,0), -v3_010,tf::Point(rt2,-rt2,0)};
	};
	
	uint erase()
	{
	  auto ers  = [](float &a){ a = 0.0; };
	  for (auto &it : v_path)
	    ers(it);
	  for (auto &it : v_ang)
	    ers(it);
	}
    };
    
    class Grip_Perform
    {
      public:
	yf_pcl_process::msg_Grip grip;
	bool got_Perform;
	
	tf::Point v3_toMassCenter;
	std::vector <float> v_rz;	// angular deviation between cupBase and ring
	std::vector <float> v_dxy;	// distance between cupbase and ring center in xy
	std::vector <float> v_dz;	// distance between cupbase and ring center in xy
	
	std::vector <cupPath> v_CupPath;
// 	std::vector <cupPath> v_CupPath_anglar;
	std::vector <float> v_AirTight;
	float fitDeviation;
	
	float improve; 
	float score;
	
	uint interations;
	int previousActionType;	// (<=-1:any; 0~7:xy(0~7), 10:cfgX, 20:theta)
	float previousActionScale;
	
	uint bad; 
	
	//////////////////////////////////////
	
	Grip_Perform():got_Perform(false), interations(0) 
	{
	  v_rz.resize(5);
	  v_dxy.resize(5);
	  v_dz.resize(5);
	  v_CupPath.resize(5);
// 	  v_CupPath_anglar.resize(5);
	  v_AirTight.resize(5);
	};
	
	Grip_Perform(yf_pcl_process::msg_Grip grip_) 
	: grip(grip_), got_Perform(false), interations(0)
	{
	  v_rz.resize(5);
	  v_dxy.resize(5);
	  v_dz.resize(5);
	  v_CupPath.resize(5);
// 	  v_CupPath_anglar.resize(5);
	  v_AirTight.resize(5);
	};
    };
    
    uint print_Grip_Perform (const Grip_Perform & obj)
    {
      // write obj to stream
      std::cout << "\n\033[1m" "Iterations:  ""\033[33m"  << obj.interations<< "\033[0m";
      
      print_MsgGrip(obj.grip);
      
      std::cout<<std::setprecision(7) << "\033[1m" "Evaluation:\n  fitDeviation (mm): " "\033[0m" ;
      if (obj.fitDeviation > 0.04)        	std::cout<< "\033[31m" << obj.fitDeviation*1000 << "\033[0m\n";
      else if (obj.fitDeviation > 0.01)		std::cout<< "\033[33m" << obj.fitDeviation*1000 << "\033[0m\n";
      else if (obj.fitDeviation > 0.004)	std::cout<< "\033[0m"  << obj.fitDeviation*1000 << "\033[0m\n";
      else					std::cout<< "\033[32m" << obj.fitDeviation*1000 << "\033[0m\n";
	
      for (uint i = 1; i<obj.v_CupPath.size(); i++)
      {
	std::cout <<"\033[1m" "  Gripper " << i ;
	if (obj.v_AirTight[i] < 0)
	  std::cout <<std::setprecision(2)<<"\033[93m" " ~ "  << obj.v_AirTight[i] << "\033[0m\033[1m" << " : " "\033[0m" ;
	else
	  std::cout <<std::setprecision(2)<<"\033[93m" " ~  " << obj.v_AirTight[i] << "\033[0m\033[1m" << " : " "\033[0m" ;
	
	for (auto it : obj.v_CupPath[i].v_path)
	{
	  if (it < 0)
	    std::cout <<std::setprecision(0)<<"\033[31m"<< round(it) << ".\033[0m ";
	  else if (it < 0.25)
	    std::cout <<std::setprecision(1)<<"\033[31m"<< it << "\033[0m ";
	  else if (it < 0.5)
	    std::cout <<std::setprecision(1)<<"\033[33m"<< it << "\033[0m ";
	  else if (it < 0.75)
	    std::cout <<std::setprecision(1)<<"\033[0m"<< it << "\033[0m ";
	  else 
	    std::cout <<std::setprecision(1)<<"\033[32m"<< it << "\033[0m ";
	}
	

	
	std::cout <<std::setprecision(1)<<"\033[1m"  "  rz: " "\033[0m"  << obj.v_rz[i] * rad2deg<< "°";
	
	std::cout <<std::setprecision(1)<<"\033[1m"  ";  dxy: " "\033[0m" ;
	if (obj.v_dxy[i] > 0.005)	std::cout << "\033[31m"  << obj.v_dxy[i] * 1000<< "mm\033[0m";
	else if (obj.v_dxy[i] > 0.002)	std::cout << "\033[33m"  << obj.v_dxy[i] * 1000<< "mm\033[0m";
	else				std::cout << "\033[0m"   << obj.v_dxy[i] * 1000<< "mm\033[0m";
	
	
	std::cout <<std::setprecision(1)<<"\033[1m"  ";  dz: " "\033[0m" ;
	if (obj.v_dz[i] > 0.005)	std::cout << "\033[31m"  << obj.v_dz[i] * 1000<< "mm\033[0m";
	else if (obj.v_dz[i] > 0.002)	std::cout << "\033[33m"  << obj.v_dz[i] * 1000<< "mm\033[0m";
	else				std::cout << "\033[0m"   << obj.v_dz[i] * 1000<< "mm\033[0m";
	
	  std::cout << "\n                      ";
	for (auto it : obj.v_CupPath[i].v_ang)
	{
	  if (it < 0)
	    std::cout <<std::setprecision(0)<<"\033[31m"<< round(it) << ".\033[0m ";
	  else if (it < 0.25)
	    std::cout <<std::setprecision(1)<<"\033[31m"<< it << "\033[0m ";
	  else if (it < 0.5)
	    std::cout <<std::setprecision(1)<<"\033[33m"<< it << "\033[0m ";
	  else if (it < 0.75)
	    std::cout <<std::setprecision(1)<<"\033[0m"<< it << "\033[0m ";
	  else 
	    std::cout <<std::setprecision(1)<<"\033[32m"<< it << "\033[0m ";
	}
        std::cout << "\n";
	
      }
      std::cerr <<"\033[1m\033[93m" "  SCORE: "<< obj.score << "\033[0m";
      std::cout <<"\n";
      
//       std::cout << "Tree:\n  " << (obj.dad)->grip.name << "  \n";
      
      return 0;
    }
    
    uint print_MsgGrip( yf_pcl_process::msg_Grip msg_grip_ )
    {
      std::cout<<"\n"<< "\033[1m" "Grip name : " "\033[0m" <<msg_grip_.name<<"\n";
      std::cout<<std::setprecision(1)<<"\033[1m""  Grip cfg  : x: ""\033[0m" <<msg_grip_.cfgX*100<<" cm\033[1m""   y: ""\033[0m"<<msg_grip_.cfgY*100<<" cm\033[1m""   z: ""\033[0m"<<msg_grip_.cfgZ*100<<" cm\n";
      std::cout<<"\033[1m" "  Grip on?  : ""\033[0m" <<msg_grip_.cupOn[1]<<" "<<msg_grip_.cupOn[2]<<" "<<msg_grip_.cupOn[3]<<" "<<msg_grip_.cupOn[4]<<" "<<"\n";
//       std::cout<<std::setprecision(5)<<"  Grip tf  : \n" <<msg_grip_.tfs_tabel2cupbase0<<"\n";
      std::cout<<"\033[1m""  Transfrom : ""\033[0m" << msg_grip_.tfs_tabel2cupbase0.header.frame_id << "  \033[1m -> \033[0m  " << msg_grip_.tfs_tabel2cupbase0.child_frame_id <<"\n";
      std::cout<<std::setprecision(4)<<"\033[1m""     translation (mm) : x: ""\033[0m"<< 1000*msg_grip_.tfs_tabel2cupbase0.transform.translation.x<<"\t""\033[1m""y: ""\033[0m"<< 1000*msg_grip_.tfs_tabel2cupbase0.transform.translation.y<<"\t""\033[1m""z: ""\033[0m"<< 1000*msg_grip_.tfs_tabel2cupbase0.transform.translation.z<<"\n";
      std::cout<<std::setprecision(4)<<"\033[1m""     rotation         : x: ""\033[0m"<< msg_grip_.tfs_tabel2cupbase0.transform.rotation.x<<"  \t""\033[1m""y: ""\033[0m"<< msg_grip_.tfs_tabel2cupbase0.transform.rotation.y<<"\t""\033[1m""z: ""\033[0m"<< msg_grip_.tfs_tabel2cupbase0.transform.rotation.z<<"\t""\033[1m""w: ""\033[0m"<< msg_grip_.tfs_tabel2cupbase0.transform.rotation.w<<"\n";
      
    }
    
    uint set_MsgGrip( yf_pcl_process::msg_Grip msg_grip_ )
    {
      msg_grip_in = msg_grip_;
      msg_grip_now = msg_grip_;
      tf::StampedTransform stf_tabel2cupbase0;
      tf::transformStampedMsgToTF(msg_grip_.tfs_tabel2cupbase0, stf_tabel2cupbase0);
      set_v_stf_Tool2CupBases_cfgXYZ(msg_grip_in.cfgX, msg_grip_in.cfgY, msg_grip_in.cfgZ);
      set_stf_Table2Tool(stf_tabel2cupbase0 * v_stf_Tool2CupBases[0].inverse()); 
      
      v_tf_table2cupbase.resize(v_stf_Tool2CupBases.size());
      v_tf_table2cupbase[0] = stf_tabel2cupbase0;
      for (uint i = 1; i < 5; i++)
      {
	v_cupOn[i] = msg_grip_in.cupOn[i];
	v_tf_table2cupbase[i] = stf_tabel2cupbase0 * v_stf_Tool2CupBases[i];
 	
	if (!v_cupOn[i])
	{  
	  continue;
	} 
	
      }
      
#if 0
      // make a projected mirror of the cloud
      tf::Quaternion q;
      tf::Transform tf_;
      tf::transformMsgToTF(msg_grip_.tfs_tabel2cupbase0.transform,tf_);
      v3_msg_grip_now_dir = tf::Transform(tf_.getRotation(), v3_000)*v3_001;
      
//       std::cout << cloud_projected_all->width << " "<< cloud_projected_all->height << "-----------------------------\n";
      pcl::ModelCoefficients::Ptr coefficients (new pcl::ModelCoefficients ());
      coefficients->values.resize (4);
      coefficients->values[0] = v3_msg_grip_now_dir.getX();
      coefficients->values[1] = v3_msg_grip_now_dir.getY();
      coefficients->values[2] = v3_msg_grip_now_dir.getZ();
      coefficients->values[3] = -tf_.getOrigin().length();
      
      pcl::ProjectInliers<pcl::PointXYZ> proj;
      proj.setModelType (pcl::SACMODEL_PLANE);
      proj.setInputCloud (cloud);
      proj.setModelCoefficients (coefficients);
      proj.filter (*cloud_projected_all);
      cloud_projected_all->height = cloud->height;
      cloud_projected_all->width = cloud->width;
      
      tree_cloud.setInputCloud(cloud_projected_all);
      tree_inlander.setInputCloud(cloud_projected_all, idx_inlander);
#endif
      
    }    
    
    uint apply_MsgGrip( yf_pcl_process::msg_Grip msg_grip_ )
    {
      set_MsgGrip(msg_grip_);

      apply_MsgGrip();
    }
    
    uint apply_MsgGrip()
    { 
      if (v_cupOn[1]) setget_tf_table2ring_cupX(1);
      if (v_cupOn[2]) setget_tf_table2ring_cupX(2);
      if (v_cupOn[3]) setget_tf_table2ring_cupX(3);
      if (v_cupOn[4]) setget_tf_table2ring_cupX(4);
    }
    
    
    float findall_tf_table2ring_near_MsgGrip()
    {
      float L;
      if (v_cupOn[1]) L = find_tf_table2ring_near_MsgGrip(1).getZ();
      if (v_cupOn[2]) L = std::max((float)find_tf_table2ring_near_MsgGrip(2).getZ(),L);
      if (v_cupOn[3]) L = std::max((float)find_tf_table2ring_near_MsgGrip(3).getZ(),L);
      if (v_cupOn[4]) L = std::max((float)find_tf_table2ring_near_MsgGrip(4).getZ(),L);
      return L;
    }    
    
//     float find_tf_table2ring_near_MsgGrip(uint cupX)
    tf::Point find_tf_table2ring_near_MsgGrip(uint cupX)
    {
      if (v_cupOn[cupX] == 0) 
      {
	v_stf_table2ring[cupX].setData(v_tf_table2cupbase[cupX]);
	return v3_000;
      }
      else
      {
	pcl::IndicesPtr idx_find_out (new std::vector <int>); 
	std::vector<float> dump;
	
	tf::Point searchPoint_ (v_tf_table2cupbase[cupX].getOrigin());
	pcl::PointXYZ searchPoint(searchPoint_.x(),searchPoint_.y(),searchPoint_.z());
	
	tree_inlander.nearestKSearch (searchPoint, 1, *idx_find_out, dump);
	int id_center = idx_find_out->at(0);
// 	std::cout << "id_center  "<< id_center << "---------------\n";
	pcl::PointXYZ Pt_center_ = cloud->points[id_center];
	tf::Point Pt_center(Pt_center_.x,Pt_center_.y,Pt_center_.z);
	
	pcl::Normal N_center_ = normals->points[id_center];
	tf::Point N_center(N_center_.normal_x,N_center_.normal_y,N_center_.normal_z);
	
// 	pcl::IndicesPtr idx_ring (new std::vector <int>);	// segmentation of surface which (may) have contact with the vacuum cup

// 	idx_ring->insert(idx_ring->begin(),id_center);
// 	*idx_ring = {id_center};
	
// 	v_idx_ring[cupX]->insert(v_idx_ring[cupX]->begin(),id_center);
	v_stf_table2ring[cupX].setOrigin(Pt_center);
	v_stf_table2ring[cupX].setRotation(v_tf_table2cupbase[cupX].getRotation());
	
	tf::Point tf_dev = Pt_center-searchPoint_;
	
//   	std::cout <<"cupX "<< cupX<<": "<< fabs((tf::tfCross(N_center,(Pt_center-searchPoint_))).z())<<"   ";
// 	return fabs((tf::tfCross(N_center,(tf_dev))).z()); 	// distance in xy
//       return (Pt_center-searchPoint_).length();
	
	
	tf::Transform searchPoint_tf (v_tf_table2cupbase[cupX].getRotation().inverse(), v3_000);
	return tf::Point(searchPoint_tf * tf_dev);
      }
    }
        
        
    float fit_MsgGrip()
    {
      tf::StampedTransform dump;
      return fit_MsgGrip( dump );
    }
    
    float fit_MsgGrip( tf::StampedTransform &stf_table2cupbase00 )
    {
//     ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   start fitting -");
      tf::Point Y_center; // center of contact points
      tf::Point X_center; // center of configured cupbase points
      tf::Point XY; // center of configured cupbase points
      Eigen::MatrixXd X(3,4);
      Eigen::MatrixXd Y(3,4);
      
      
//       X_center = (v_tf_table2cupbase[1].getOrigin()+v_tf_table2cupbase[2].getOrigin()+v_tf_table2cupbase[3].getOrigin()+v_tf_table2cupbase[4].getOrigin())*0.25; // center of configured cupbase points
      X_center = v_tf_table2cupbase[0].getOrigin(); // center of configured cupbase points
      Y_center = (v_stf_table2ring[1].getOrigin()+v_stf_table2ring[2].getOrigin()+v_stf_table2ring[3].getOrigin()+v_stf_table2ring[4].getOrigin())*0.25; // center of contact points
      XY = (Y_center - X_center);
      
      for (uint i = 1; i < 5; i++)
      {
	if (v_cupOn[i])
	{
	  tf::Point Ptmp = v_tf_table2cupbase[i].getOrigin();
	  X.block<3,1>(0,i-1) << Ptmp.x()-X_center.x(), Ptmp.y()-X_center.y(), Ptmp.z()-X_center.z();
	  Ptmp = v_stf_table2ring[i].getOrigin();
	  Y.block<3,1>(0,i-1) << Ptmp.x()-Y_center.x(), Ptmp.y()-Y_center.y(), Ptmp.z()-Y_center.z();
	} 
	else 
	{
	  X.block<3,1>(0,i-1) << 0,0,0;
	  Y.block<3,1>(0,i-1) << 0,0,0;
	}
	
      }
      
//        std::cout<<std::setprecision(1) <<"\n ****************  X(mm) \n"<< X*1000 <<"\n";
//        std::cout<<std::setprecision(1) <<"\n ****************  Y(mm) \n"<< Y*1000 <<"\n";
      
      Eigen::MatrixXd H = Y*(X.transpose()); 
      Eigen::JacobiSVD<Eigen::MatrixXd> svd(H, Eigen::ComputeThinU | Eigen::ComputeThinV);
      const Eigen::MatrixXd U = svd.matrixU();
      const Eigen::MatrixXd V = svd.matrixV();
      Eigen::Matrix3d S ;  S<< 1,0,0,0,1,0,0,0,(U*V.transpose()).determinant();
      const Eigen::MatrixXd R = U*S*V.transpose();
      
      tf::Matrix3x3 MR( R(0,0),R(0,1),R(0,2),
			R(1,0),R(1,1),R(1,2),
			R(2,0),R(2,1),R(2,2));
      tf::Quaternion Q; 
      MR.getRotation(Q);
      
      tf::Quaternion Q2(v_tf_table2cupbase[0].getRotation());
      tf::Transform Tr2 (Q2.inverse(), v3_000);
      tf::Transform TR (Q*Q2, XY);
      
      Eigen::MatrixXd D = (Y - R*X);
      float d = D.norm();
//         std::cout<<std::setprecision(6) <<"fitting error is : d = "<< d << "   ,   D = \n" <<D<<"\n";
//        std::cout<<std::setprecision(6) <<"fitting error is : d = "<< d << "\n";
      
      stf_table2cupbase00 = tf::StampedTransform(v_tf_table2cupbase[0]*Tr2*TR, ros::Time::now(), "/table_frame", msg_grip_now.tfs_tabel2cupbase0.child_frame_id+"#");    
      return d;
    }
      
    float fit_MsgGrip( Grip_Perform & GP_rt)
    {
      tf::StampedTransform stf_table2cupbase00;
      float d = fit_MsgGrip(stf_table2cupbase00);
//         std::cout<<std::setprecision(6) <<"fitting error is : d = "<< d << "   ,   D = \n" <<D<<"\n";
//        std::cout<<std::setprecision(6) <<"fitting error is : d = "<< d << "\n";
      
      v_tf_table2cupbase[0] = stf_table2cupbase00;
      for (uint i = 1; i < 5; i++)
      {
	  v_tf_table2cupbase[i] = stf_table2cupbase00 * v_stf_Tool2CupBases[i];
      }
      
      set_stf_Table2Tool(stf_table2cupbase00*v_stf_Tool2CupBases[0].inverse());
      
      // save the fitted stf_table2cupbase00 to msg_grip_now
      tf::transformStampedTFToMsg( stf_table2cupbase00 , msg_grip_now.tfs_tabel2cupbase0 );
      
      tf::transformStampedTFToMsg( stf_table2cupbase00 , GP_rt.grip.tfs_tabel2cupbase0 );
      
      GP_rt.fitDeviation = d;
      
//     ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   start fitting - fin");
      return d; 	// return fitting rate
    }
  
  //move_tends (rt, tend_moveXY, tend_moveTheta, tend_cfgX))
    yf_pcl_process::msg_Grip move_tends (yf_pcl_process::msg_Grip &msg, const tf::Point tend_moveXY, const float tend_moveTheta, const float tend_cfgX)
    {
      yf_pcl_process::msg_Grip rt = msg;
//       const float rotationAngle = atan2(tend_moveTheta*2.0, R_xy2(msg.cfgY,msg.cfgX));  ///////////////
      const float rotationAngle = atan2(tend_moveTheta*4.0, R_xy(msg.cfgY,msg.cfgX));
      std::ostringstream st;
      st<<std::fixed<<std::setprecision(1) << "tends:[("<< 1000*tend_moveXY.x()<<", "<<1000*tend_moveXY.y()<<"), <"<<1000*tend_cfgX<<">, ("<<rotationAngle*rad2deg<<"°)]";
//       st<<std::fixed<<std::setprecision(1) << "tends:[("<< 1000*tend_moveXY.x()<<", "<<1000*tend_moveXY.y()<<"), <"<<1000*tend_cfgX<<">, ("<<1000*tend_moveTheta<<")]";
      rt.name = rt.name +" "+ st.str()+";";
      tf::Transform tf_d(tf::Quaternion(v3_001, rotationAngle), tend_moveXY);
      tf::StampedTransform stf_tabel2cupbase0;
      tf::transformStampedMsgToTF(msg_grip_in.tfs_tabel2cupbase0, stf_tabel2cupbase0);
      
      stf_tabel2cupbase0.setData( stf_tabel2cupbase0 * tf_d );
      tf::transformStampedTFToMsg(stf_tabel2cupbase0, rt.tfs_tabel2cupbase0);
      
      rt.cfgX += tend_cfgX;
      if (rt.cfgX > GRIPPER_cfgX_MAX) rt.cfgX = GRIPPER_cfgX_MAX;
      if (rt.cfgX < GRIPPER_cfgX_MIN) rt.cfgX = GRIPPER_cfgX_MIN;
      
      return rt;
    }
      
  
    yf_pcl_process::msg_Grip move_xy (yf_pcl_process::msg_Grip msg, int dir, float delta)
    {
      yf_pcl_process::msg_Grip rt = msg;
      std::ostringstream st;
      st<<std::fixed<<std::setprecision(1)<<1000*delta;
      rt.name = rt.name + " xy_" + std::to_string(dir) + ":"+st.str()+";";
      float theta = dir*0.25*M_PI;
      tf::Point v3_d(delta*cos(theta),delta*sin(theta),0);
      tf::Transform tf_d(q_u, v3_d);
      tf::StampedTransform stf_tabel2cupbase0;
      tf::transformStampedMsgToTF(msg_grip_in.tfs_tabel2cupbase0, stf_tabel2cupbase0);
      
      stf_tabel2cupbase0.setData( stf_tabel2cupbase0 * tf_d );
      tf::transformStampedTFToMsg(stf_tabel2cupbase0, rt.tfs_tabel2cupbase0);
      
      return rt;
    }
      
      
    yf_pcl_process::msg_Grip move_theta2 (yf_pcl_process::msg_Grip msg, float delta)
    {
      yf_pcl_process::msg_Grip rt = msg;
      const float rotationAngle = atan2(delta*2.0, R_xy2(msg.cfgY,msg.cfgX));
      std::ostringstream st;
      st<<std::fixed<<std::setprecision(1)<<rotationAngle*rad2deg;
      rt.name = rt.name + " Th:"+st.str()+"°;";
      tf::Transform tf_d(tf::Quaternion(v3_001, rotationAngle), v3_000);
      tf::StampedTransform stf_tabel2cupbase0;
      tf::transformStampedMsgToTF(msg_grip_in.tfs_tabel2cupbase0, stf_tabel2cupbase0);
      
      stf_tabel2cupbase0.setData( stf_tabel2cupbase0 * tf_d );
      tf::transformStampedTFToMsg(stf_tabel2cupbase0, rt.tfs_tabel2cupbase0);
      
      return rt;
    }
    
    yf_pcl_process::msg_Grip move_theta (yf_pcl_process::msg_Grip msg, float delta)
    {
      yf_pcl_process::msg_Grip rt = msg;
      std::ostringstream st;
      st<<std::fixed<<std::setprecision(1)<<delta*rad2deg;
      rt.name = rt.name + " Th:"+st.str()+"°;";
      tf::Transform tf_d(tf::Quaternion(v3_001, delta), v3_000);
      tf::StampedTransform stf_tabel2cupbase0;
      tf::transformStampedMsgToTF(msg_grip_in.tfs_tabel2cupbase0, stf_tabel2cupbase0);
      
      stf_tabel2cupbase0.setData( stf_tabel2cupbase0 * tf_d );
      tf::transformStampedTFToMsg(stf_tabel2cupbase0, rt.tfs_tabel2cupbase0);
      
      return rt;
    }
  
    yf_pcl_process::msg_Grip move_cfgX (yf_pcl_process::msg_Grip msg, float delta)
    {
      yf_pcl_process::msg_Grip rt = msg;
      std::ostringstream st;
      st<<std::fixed<<std::setprecision(1)<<1000*delta;
      rt.name = rt.name + " cX:"+st.str()+";";

      rt.cfgX += delta;
      if (rt.cfgX > GRIPPER_cfgX_MAX) rt.cfgX = GRIPPER_cfgX_MAX;
      if (rt.cfgX < GRIPPER_cfgX_MIN) rt.cfgX = GRIPPER_cfgX_MIN;
      
      return rt;
    }
    

    float try_Grip_get_Perform(Grip_Perform &result_)
    {
      try_Grip_get_Perform(result_.grip, result_);
    }
      
    float try_Grip_get_Perform(yf_pcl_process::msg_Grip grip_, Grip_Perform &result_)
    {
//       std::cout << "\n\n++++++++++++++++++++++try_Grip_get_Perform+++++++++++++++++++++\n  ";
	
      // init grip 
//       if (result_.got_Perform) return 1.0;
//       result_.grip = grip_;
      set_MsgGrip(grip_);
      

      
      // try fitting
      float L;
      L = findall_tf_table2ring_near_MsgGrip();
//       std::cout << "L = "<< L << "\n";
      fit_MsgGrip(result_);
//       std::cout << "  result_.fitDeviation "<<result_.fitDeviation<<"\n";

       
      result_.score = 0.0;
      
      result_.v_dxy.resize(5);
      for (uint i = 1; i<5; i++)
      {
// 	if (grip_.cupOn[i])

          tf::Point v3_dev = find_tf_table2ring_near_MsgGrip(i);
// 	  result_.v_dxy[i] = sqrt( v3_dev.getX()*v3_dev.getX() + v3_dev.getY()*v3_dev.getY() );
	  result_.v_dxy[i] = R_xy( v3_dev.getX(), v3_dev.getY() );
	  result_.v_dz[i] = v3_dev.getZ();
	  
	  // if no good nearby points found, shut off the vacuum for this cup
	  if (result_.v_dxy[i] > 0.05)	// > 5cm
	  {
	    result_.grip.cupOn[i] = 0;
	  }
	  else if (result_.v_dxy[i] < 0.002) // < 2mm
	  {
	    result_.grip.cupOn[i] = i;
	  }
      }

      result_.v3_toMassCenter = massCenter - v_tf_table2cupbase[0].getOrigin();
      
      // look for rings
      float int_leak = 0.0;
      int cupOn_count = 0;
      for (uint i = 1; i < 5; i++)
      {
	if (v_cupOn[i])
	{
	  cupOn_count ++;
	  float rz;
	  tf::Transform tf_table2ring = get_tf_table2ring (get_idx_ring(i), v_tf_table2cupbase[i], v_cup_dim[i], rz);
	  v_stf_table2ring[i] = tf::StampedTransform(tf_table2ring, ros::Time::now(),"/table_frame","/cups_frame/"+std::to_string(i));
	  result_.v_CupPath[i] = get_cupPath(i);
	  
	  result_.v_rz[i] = rz;
	  if (result_.v_rz[i] > 0.5) int_leak += 0.2;	//////////////////
	  
	  result_.v_AirTight[i] = 1.0 * std::accumulate(result_.v_CupPath[i].v_path.begin(), result_.v_CupPath[i].v_path.end(), 0.0f) / 8.0;
	  if (result_.v_AirTight[i] < 0.5) int_leak += 0.1;
	  
	  if (result_.v_dz[i] > v_cup_dim[i].stroke) result_.v_AirTight[i] = 0;
	  if (result_.v_dz[i] < -v_cup_dim[i].stroke) result_.v_AirTight[i] = 0;
	  
	  result_.score += result_.v_AirTight[i];
	}
	else
	{
	  v_stf_table2ring[i] = tf::StampedTransform(v_tf_table2cupbase[i], ros::Time::now(),"/table_frame","/cups_frame/"+std::to_string(i));
	  result_.v_CupPath[i] = cupPath();
	  result_.v_rz[i] = 0;
	  result_.v_AirTight[i] = 0;
	}
	
      }
      
      if (int_leak > 1)
	result_.score = -int_leak;
      if (result_.fitDeviation > 0.040)	//	if 4 grippers can't fit on point cloud
	result_.score = -10;

      result_.score = result_.score/cupOn_count; 
      
      if (cupOn_count < 3) result_.score = -1;
      
      result_.got_Perform = true;
    }   
    
    
    float compare_Grip_Perform (const Grip_Perform &A, const Grip_Perform &B)	// if A better than B , a>b
    {
//      yf_pcl_process::msg_Grip grip;
// 	std::vector <float> v_rz;	// angular deviation between cupBase and ring
// 	std::vector <float> v_dxy;	// distance between cupbase and ring center in xy
// 	std::vector <cupPath> v_path;
// 	float fitDeviation;
// 	
// 	uint interations;
// 	
// 	uint bad; 
      float improved = 0;
      uint toobad = 0;
      
      if (A.v_rz.size() == B.v_rz.size() && A.v_rz.size() == 5)
	for (uint i = 1; i<5; i++)	// angle dif
	{
// 	  if (A.v_rz[i] > 0.174) return 0;	
	  if (B.v_rz[i] > 0.08)
	  {
	    if (A.v_rz[i] < B.v_rz[i]-0.04) 	improved += 1; 	// if angle deviation get over 2.3° closer
	    if (A.v_rz[i] > B.v_rz[i]+0.04) 	improved -= 2; 	// if angle deviation get over 2.3° away
	  }
	    
	    
	  if (B.v_dxy[i] > 0.002){
	    float ba = A.v_dxy[i] - B.v_dxy[i];
	    if (ba < 0.001) 	improved += 10; 	// if fitting get over 1mm closer
	    if (ba > -0.001) 	improved -= 20; 	// if fitting get over 1mm away
	  }
	  
	  float sumA = 0, sumB = 0, sumba;	// 0.0 ~ 8.0
	  for (auto &p : A.v_CupPath[i].v_path)	sumA += p;
	  for (auto &p : B.v_CupPath[i].v_path)	sumB += p;
	  
	  {
	    sumba = 0.125*(sumA-sumB);	// 0.0~1.0
	    if (sumba > +0.1) 		improved += 100*sumba; 	// if path is better than "not too much worse"
	    if (sumba < -0.1) 		improved -= 200*sumba; 	// if path is better than "not too much worse"
	  }
	}
	
      return improved;
      
    }
    
    
    cupPath get_cupPath (uint cupX)
    {
      if (v_idx_ring[cupX]->size()<2) setget_tf_table2ring_cupX(cupX);	// init idx_ring and stf for cupX
//       tf::Transform tf_ringX (v_stf_table2ring[cupX].inverse());
      tf::Transform tf_ringX (v_stf_table2ring[cupX].inverse());
      tf::Transform tf_ring_base_X (tf_ringX * v_tf_table2cupbase[cupX]);
      tf::Point P_ringX (tf::Transform(v_tf_table2cupbase[cupX].getRotation(),v3_000) * -v3_001);
      pcl::PointXYZ pt0 = cloud->at(v_idx_ring[cupX]->at(0));
      ///////////////////	check the overlap of idx_ring and cloud_inlander
      float ring_count = v_idx_ring[cupX]->size();
      float rimangle_cupX = 0.5 * v_cup_dim[cupX].rimangle;
      
      cupPath cP, cPsum;
      uint inlander_sum = 0;
      for (uint i = 1; i < ring_count; i++)
      {
	uint idx = v_idx_ring[cupX]->at(i);
	
	pcl::PointXYZ ptBarrier = cloud->at(idx);
	tf::Point tfP_ (ptBarrier.x,ptBarrier.y,ptBarrier.z);
	tf::Point tfP_barrier = tf_ringX*tfP_;
	float theta = atan2(tfP_barrier.y(),tfP_barrier.x());
// 	uint pathN = round(theta*rad2deg/45);
	uint pathN = round(theta/M_PI_4);	// theta/45°
	pathN = pathN % 8;
	cPsum.v_path[pathN] += 1.0;
	

	if (cloud_label->points[idx].label > 20)		
	{
	  cP.v_path[pathN] += 0;	  	//	IF border
	}
	else if (cloud_label->points[idx].label > 0)
	{
// 	    std::cout << cloud_label->points[idx].label << " ";
// 	  if ( tfP_barrier.z() < 0 )	// if contacting
	    if (cloud_label->points[idx].label > 10)		
	    {
	      cP.v_path[pathN] += 0.5;         // IF valid but in margin
	    }
	    else 
	    {
	      cP.v_path[pathN] += 1.0;         // IF valid and is inlander
	    }
	  
	  tf::Point Pnorm(normals->at(idx).normal_x,normals->at(idx).normal_y,normals->at(idx).normal_z);
	  float Pcurv = normals->at(idx).curvature/curv_Mx;
	  
	  float angN = fabs(tf::tfAngle(Pnorm, P_ringX));
	  if (!isnan(angN))
	  {
	    cPsum.v_ang[pathN] += 1.0;
	    cP.v_ang[pathN] += 1.0;
	    // considering avoiding big orientation difference
	    if (angN < rimangle_cupX)			// < cos(45°)
	    {
  //  	    std::cout<< angN * rad2deg<<"°  "<< rimangle_cupX * rad2deg<<"°  "<< angN / rimangle_cupX<<"  \n";
	      cP.v_ang[pathN] -= 0.3 * angN / rimangle_cupX;
	    }
	    else 
	    {
	      cP.v_ang[pathN] += 0.7 - angN / rimangle_cupX ;
	    }
	    
	    // considering avoiding big curvature
	    if (!isnan(Pcurv))
	    {
	      cP.v_ang[pathN] -= Pcurv;
	    }
	    
	    // considering slope for reducing abs(dz), 
// 	    float dz = tfP_barrier.z() / v_cup_dim[cupX].stroke; // - ~ -1 ~ 0 ~ +1 ~ +
// 	    Pnorm = tf_ringX * Pnorm;	// normal according to cupbase, -1 ~ +1
/*	    
	    float rdz = (tf_ringX * tfP_).z() / 0.009; // too deep ~ -1 ~ 0 ~ ++ unreached
	    if (tf_ring_base_X.getOrigin().z() * rdz > 0)  
	    {
	      cP.v_ang[pathN] += abs(rdz);
	    }
	    else
	    {
	      cP.v_ang[pathN] += - abs(rdz);
	    }*/
// 	    std::cout << (tf_cupbaseX * tfP_).z() << "/" << v_cup_dim[cupX].stroke << "  ";
// 	    std::cout << (tf_cupbaseX * tfP_).z() << " ";
// 	    if (-1 < rdz && rdz < 0)			// within stroke
// 	    {
// 	      rdz = abs(rdz) ;	// abs(0 ~ 1) -> 0~1
// 	      cP.v_ang[pathN] += - rdz;
// 	    }
// 	    else 
// 	    {
// 	      rdz = abs(rdz) * 2.0;	// 2 * abs(0 ~ 1)
// 	      cP.v_ang[pathN] += - rdz ;
// 	    }
	  }
// 	  else 
// 	    cP.v_ang[pathN] += 0;
	}
      }

      for (uint i = 0; i<cP.v_path.size(); i++) 
      {
//  	std::cout<< "cup_" << cupX <<"  " <<  i << ":  \t" << cP.v_path[i]<< " / " << cPsum.v_path[i]<<"\n";
	
	cP.v_path[i] = cP.v_path[i]/cPsum.v_path[i];
	if (isnan(cP.v_path[i])) cP.v_path[i] = 0;
	
	
// 	cP.v_ang[i] = cP.v_ang[i]/cPsum.v_path[i];
// 	cP.v_ang[i] = 1.0 - cP.v_ang[i]/cPsum.v_path[i] * fabs(1.0-cP.v_path[i]);		// only consider angle if path is good enough
	
	if (cP.v_path[i] > 0.8)
	  cP.v_ang[i] = cP.v_ang[i]/cPsum.v_ang[i];		// only consider angle if path is good enough
	else
	  cP.v_ang[i] = cP.v_path[i];
	  
	if (isnan(cP.v_ang[i])) cP.v_ang[i] = 0;
// 	if (cP.v_path[i] ) cP.v_ang[i] = 0;	// only consider angle if path is good enough
      }
//       std::cout << "\n cup "<<cupX<<": \n";      
//       for (uint i = 0; i<cP.v_path.size(); i++) std::cout<<std::setprecision(1)<<"cP"<<i<<" : "<<cP.v_path[i]<<"\t";
      
      return cP;
    }
    
    
#if 0    
//     std::vector< yf_pcl_process::msg_Grip> get_v_msg_grip_tend(std::vector< yf_pcl_process::msg_Grip> & v_Rt)
    uint get_v_msg_grip_tend_copy1(std::vector< yf_pcl_process::msg_Grip> & v_Rt)
    {
//       std::vector< yf_pcl_process::msg_Grip> v_Rt ;
      yf_pcl_process::msg_Grip rt = msg_grip_now;
      // rt contains tend of maneuver in those dimensions: x, y, theta, cfgX
      
      auto min12 = [](float a, float &min1, float &min2)	// ranking 1.st min and 2.nd min
      {
	  if      (a<min1)	{ min2 = min1; min1 = a; }
	  else if (a<min2) 	{ min2 = a;}
      };      
      
      auto min123 = [](float a, float &min1, float &min2, float &min3)	// ranking 1.st min and 2.nd min
      {
	  if      (a<min1)	{ min3 = min2; min2 = min1; min1 = a; }
	  else if (a<min2) 	{ min3 = min2; min2 = a; }
	  else if (a<min3) 	{ min3 = a;}
      };      
      
      auto max12 = [](float a, float &max1, float &max2)	// ranking 1.st min and 2.nd min
      {
	  if      (a>max1)	{ max2 = max1; max1 = a; }
	  else if (a>max2) 	{ max2 = a;}
      };
      
      std::vector < cupPath > v_cupPath;
      v_cupPath.resize(5);
      for (uint i = 1; i < 5; i++)
      {
	v_cupPath[i] = get_cupPath(i);
      }
      
      
      // look for movement of x,y
      std::cout<<"\nmaneuver x,y : ";
      cupPath cupPath_Can = cupPath();
      
      {
	float K;	float k2;	 float a;
	for (uint i = 0; i< 8; i++)
	{
	  K = 7; k2 = 7;
	  a = v_cupPath[1].v_path[i]; 	min12(a, K, k2);
	  a = v_cupPath[2].v_path[i];	min12(a, K, k2);
	  a = v_cupPath[3].v_path[i];	min12(a, K, k2);
	  a = v_cupPath[4].v_path[i];	min12(a, K, k2);
	  
	  cupPath_Can.v_path[i] = 0.5*(k2+K);
	  std::cout<<cupPath_Can.v_path[i]<<"   ";
	  
	  if (cupPath_Can.v_path[i] > 0.66)
	  {
	    v_Rt.push_back(move_xy(msg_grip_now, i, cupPath_Can.v_path[i] * 0.005));
	  }
	  
	}
      }
      // look for movement of theta
      std::cout<<"\nmaneuver theta : ";
      float theta_pls, theta_mns;
      
      float alpha = atan2(msg_grip_now.cfgY, msg_grip_now.cfgX);
//       std::cout<<std::setprecision(4)<<"\n cfgX: "<<msg_grip_now.cfgX<<"     cfgY: "<<msg_grip_now.cfgY<<"     alpha: "<< alpha*rad2deg << "\n";
      
      float pathN = alpha*rad2deg/45;
      uint pathN_ceil = ceil(pathN)  ;		uint pathN_flor = floor(pathN) ;	
      float t = pathN - pathN_flor;
//       std::cout<<std::setprecision(4)<<"\n pathN: "<<pathN<<"     pathN_ceil: "<<pathN_ceil<<"     pathN_flor: "<< pathN_flor<<"     t: "<< t << "\n";
            
      // take the 2.nd min as tendency of rotation (theta)
      if (pathN_flor == 0) 
      {
	float K;	float k2;	 float a;
      // anti-clock, + theta: 
	K = 7; k2 = 7;
	
	a = v_cupPath[1].v_path[6]*(1-t)+v_cupPath[1].v_path[7]*t;	min12(a, K, k2);
	a = v_cupPath[2].v_path[6]*(1-t)+v_cupPath[2].v_path[5]*t;	min12(a, K, k2);
	a = v_cupPath[3].v_path[2]*(1-t)+v_cupPath[3].v_path[1]*t;	min12(a, K, k2);
	a = v_cupPath[4].v_path[2]*(1-t)+v_cupPath[4].v_path[3]*t;	min12(a, K, k2);
	theta_pls = 0.5*(k2+K);
	
      // clock,      - theta: 
	K = 7; k2 = 7;
	a = v_cupPath[1].v_path[2]*(1-t)+v_cupPath[1].v_path[3]*t;	min12(a, K, k2);
	a = v_cupPath[2].v_path[2]*(1-t)+v_cupPath[2].v_path[1]*t;	min12(a, K, k2);
	a = v_cupPath[3].v_path[6]*(1-t)+v_cupPath[3].v_path[5]*t;	min12(a, K, k2);
	a = v_cupPath[4].v_path[6]*(1-t)+v_cupPath[4].v_path[7]*t;	min12(a, K, k2);
	theta_mns = 0.5*(k2+K);
	
      }
      else 
      {
	float K;	float k2;	 float a;
      // anti-clock, + theta: 
	K = 7; k2 = 7;
	a = v_cupPath[1].v_path[0]*t+v_cupPath[1].v_path[7]*(1-t);	min12(a, K, k2);
	a = v_cupPath[2].v_path[4]*t+v_cupPath[2].v_path[5]*(1-t);	min12(a, K, k2);
	a = v_cupPath[3].v_path[0]*t+v_cupPath[3].v_path[1]*(1-t);	min12(a, K, k2);
	a = v_cupPath[4].v_path[4]*t+v_cupPath[4].v_path[3]*(1-t);	min12(a, K, k2);
	theta_pls = 0.5*(k2+K);
	
      // clock,      - theta: 
	K = 7; k2 = 7;
	a = v_cupPath[1].v_path[4]*t+v_cupPath[1].v_path[3]*(1-t);	min12(a, K, k2);
	a = v_cupPath[2].v_path[0]*t+v_cupPath[2].v_path[1]*(1-t);	min12(a, K, k2);
	a = v_cupPath[3].v_path[4]*t+v_cupPath[3].v_path[5]*(1-t);	min12(a, K, k2);
	a = v_cupPath[4].v_path[0]*t+v_cupPath[4].v_path[7]*(1-t);	min12(a, K, k2);
	theta_mns = 0.5*(k2+K);
	
      }
      std::cout<<std::setprecision(4)<<"\n theta_pls: "<<theta_pls<<"     theta_mns: "<<theta_mns<<"\n";
      if (theta_pls > 0.66)
      {
	v_Rt.push_back(move_theta(msg_grip_now, theta_pls * 0.05)); 	//rotate 3°
      }
      if (theta_mns > 0.66)
      {
	v_Rt.push_back(move_theta(msg_grip_now, -theta_mns * 0.05));
      }
      
      // look for movement of cfgX
      std::cout<<"\nmaneuver cfgX : ";
      float cfgX_pls, cfgX_mns;
      {
	float K;	float k2;	 float a;
      // clamping inward, - cfgX: 
	K = 7; k2 = 7;
	a = v_cupPath[1].v_path[0] + v_cupPath[3].v_path[4];	min12(a, K, k2);
	a = v_cupPath[2].v_path[0] + v_cupPath[4].v_path[4];	min12(a, K, k2);
// 	a = v_cupPath[3].v_path[4];	min12(a, K, k2);
// 	a = v_cupPath[4].v_path[4];	min12(a, K, k2);
	
	cfgX_mns = K;
	
      // spread out,      + cfgX: 
	K = 7; k2 = 7;
	a = v_cupPath[1].v_path[4] + v_cupPath[3].v_path[0];	min12(a, K, k2);
	a = v_cupPath[2].v_path[4] + v_cupPath[4].v_path[0];	min12(a, K, k2);
// 	a = v_cupPath[3].v_path[0];	min12(a, K, k2);
// 	a = v_cupPath[4].v_path[0];	min12(a, K, k2);
	
	cfgX_pls = K;
	
      }
      std::cout<<std::setprecision(4)<<"\n cfg+: "<<cfgX_pls<<"     cfgX-: "<<cfgX_mns<<"\n";
      if (cfgX_pls > 0.66)
      {
	v_Rt.push_back(move_cfgX(msg_grip_now, cfgX_pls * 0.005)); 	//rotate 3°
      }
      if (cfgX_mns > 0.66)
      {
	v_Rt.push_back(move_cfgX(msg_grip_now, -cfgX_mns * 0.005));
      }
      
//       msg_grip_now.cfgX;
      
      std::cout<<"\n v_Rt "<<v_Rt.size()<<"\n";
      
      return 1;
    }
#endif

#if 0  
    float get_v_msg_grip_tend(std::vector< maneuverGrip::Grip_Perform> & v_Rt)
    {// return 0:fail to extend, x:extensions, -1:good enough
//       std::vector< yf_pcl_process::msg_Grip> v_Rt ;
      yf_pcl_process::msg_Grip rt = msg_grip_now;
      // rt contains tend of maneuver in those dimensions: x, y, theta, cfgX
      
      auto min12 = [](float a, float &min1, float &min2)	// ranking 1.st min and 2.nd min
      {
	  if      (a<min1)	{ min2 = min1; min1 = a; }
	  else if (a<min2) 	{ min2 = a;}
      };      
      
//       auto min123 = [](float a, float &min1, float &min2, float &min3)	// ranking 1.st min and 2.nd min
//       {
// 	  if      (a<min1)	{ min3 = min2; min2 = min1; min1 = a; }
// 	  else if (a<min2) 	{ min3 = min2; min2 = a; }
// 	  else if (a<min3) 	{ min3 = a;}
//       };      
      
      auto max12 = [](float a, float &max1, float &max2)	// ranking 1.st min and 2.nd min
      {
	  if      (a>max1)	{ max2 = max1; max1 = a; }
	  else if (a>max2) 	{ max2 = a;}
      };
      
      std::vector < cupPath > v_cupPath;
      v_cupPath.resize(5);
      for (uint i = 1; i < 5; i++)
      {
	v_cupPath[i] = get_cupPath(i);
      }
      
      
      // look for movement of x,y
      std::cout<<"\nmaneuver x,y : ";
      cupPath cupPath_Can = cupPath();
      cupPath cupPath_Mus = cupPath();
      
      float path_sum = 0;
      {
	float K;	float k2;	 float a;
	float G;	float g2;	 
	for (uint i = 0; i< 8; i++)
	{
	  K = 7; k2 = 7;
	  G = 0; g2 = 0;
	  a = v_cupPath[1].v_path[i]; 	min12(a, K, k2);	max12(a, G, g2);
	  a = v_cupPath[2].v_path[i];	min12(a, K, k2);	max12(a, G, g2);
	  a = v_cupPath[3].v_path[i];	min12(a, K, k2);	max12(a, G, g2);
	  a = v_cupPath[4].v_path[i];	min12(a, K, k2);	max12(a, G, g2);
	  
	  cupPath_Can.v_path[i] = 0.5*(k2+K);
	  cupPath_Mus.v_path[i] = 0.5*(g2+G);
	  path_sum += cupPath_Can.v_path[i];
	}
      }
      
      // check ring quality
//       if ( path_sum > 0.8*8) return path_sum;   ////////////////// if good enough, stop maneuver and return current stage
      
      // look for movement of theta
      std::cout<<"\nmaneuver theta : ";
      float theta_pls_can, theta_mns_can;
      
      float alpha = atan2(msg_grip_now.cfgY, msg_grip_now.cfgX);
//       std::cout<<std::setprecision(4)<<"\n cfgX: "<<msg_grip_now.cfgX<<"     cfgY: "<<msg_grip_now.cfgY<<"     alpha: "<< alpha*rad2deg << "\n";
      
      float pathN = alpha*rad2deg/45;
      uint pathN_ceil = ceil(pathN)  ;		uint pathN_flor = floor(pathN) ;	
      float t = pathN - pathN_flor;
//       std::cout<<std::setprecision(4)<<"\n pathN: "<<pathN<<"     pathN_ceil: "<<pathN_ceil<<"     pathN_flor: "<< pathN_flor<<"     t: "<< t << "\n";
            
      // take the 2.nd min as tendency of rotation (theta)
      if (pathN_flor == 0) 
      {
	float K;	float k2;	 float a, b;	
      // anti-clock, + theta: 
	K = 7; k2 = 7;
	
	a = std::min(v_cupPath[1].v_path[6]*(1-t)+v_cupPath[1].v_path[7]*t, v_cupPath[2].v_path[6]*(1-t)+v_cupPath[2].v_path[5]*t);
	b = std::min(v_cupPath[3].v_path[2]*(1-t)+v_cupPath[3].v_path[1]*t, v_cupPath[4].v_path[2]*(1-t)+v_cupPath[4].v_path[3]*t);
	theta_pls_can = std::max(a,b);
	
      // clock,      - theta: 
	K = 7; k2 = 7;
	
	a = std::min(v_cupPath[2].v_path[2]*(1-t)+v_cupPath[2].v_path[1]*t, v_cupPath[2].v_path[2]*(1-t)+v_cupPath[2].v_path[1]*t);
	b = std::min(v_cupPath[3].v_path[6]*(1-t)+v_cupPath[3].v_path[5]*t, v_cupPath[4].v_path[6]*(1-t)+v_cupPath[4].v_path[7]*t);
	theta_mns_can = std::max(a,b);
	
      }
      else 
      {
	float K;	float k2;	 float a, b;
      // anti-clock, + theta: 
	K = 7; k2 = 7;
	a = std::min(v_cupPath[1].v_path[0]*t+v_cupPath[1].v_path[7]*(1-t), v_cupPath[3].v_path[0]*t+v_cupPath[3].v_path[1]*(1-t));
	b = std::min(v_cupPath[2].v_path[4]*t+v_cupPath[2].v_path[5]*(1-t), v_cupPath[4].v_path[4]*t+v_cupPath[4].v_path[3]*(1-t));
	theta_pls_can = std::max(a,b);
	
      // clock,      - theta: 
	K = 7; k2 = 7;
	a = std::min(v_cupPath[1].v_path[4]*t+v_cupPath[1].v_path[3]*(1-t), v_cupPath[3].v_path[4]*t+v_cupPath[3].v_path[5]*(1-t));
	b = std::min(v_cupPath[2].v_path[0]*t+v_cupPath[2].v_path[1]*(1-t), v_cupPath[4].v_path[0]*t+v_cupPath[4].v_path[7]*(1-t));
	theta_mns_can = std::max(a,b);
	
      }
      
      
      // look for movement of cfgX
      std::cout<<"\nmaneuver cfgX : ";
      float cfgX_pls_can, cfgX_mns_can;
      float cfgX_pls_mus, cfgX_mns_mus;
      {
	float K;	float k2;	 float a;
      // clamping inward, - cfgX: 
	K = 0; k2 = 0;
	max12(v_cupPath[1].v_path[4], K, k2);
	max12(v_cupPath[2].v_path[4], K, k2);
	max12(v_cupPath[3].v_path[0], K, k2);
	max12(v_cupPath[4].v_path[0], K, k2);
	cfgX_mns_mus = K+k2;
	
	K = 7; k2 = 7;
	a = v_cupPath[1].v_path[0] + v_cupPath[3].v_path[4];	min12(a, K, k2);
	a = v_cupPath[2].v_path[0] + v_cupPath[4].v_path[4];	min12(a, K, k2);
	cfgX_mns_can = K;
	
      // spread out,      + cfgX: 
	K = 0; k2 = 0;
	max12(v_cupPath[1].v_path[0], K, k2);
	max12(v_cupPath[2].v_path[0], K, k2);
	max12(v_cupPath[3].v_path[4], K, k2);
	max12(v_cupPath[4].v_path[4], K, k2);
	cfgX_pls_mus = K+k2;
	
	K = 7; k2 = 7;
	a = v_cupPath[1].v_path[4] + v_cupPath[3].v_path[0];	min12(a, K, k2);
	a = v_cupPath[2].v_path[4] + v_cupPath[4].v_path[0];	min12(a, K, k2);
	cfgX_pls_can = K;
	
      }

      v_Rt.clear();////////////////////////////
      v_Rt.push_back(maneuverGrip::Grip_Perform(msg_grip_now));
      
      // MUST
      if (cfgX_mns_mus < 0.9 && cfgX_mns_can > 0.75)	// if must -cfgX
      {
	std::cout << "must move_cfgX : "<< -cfgX_mns_can * 0.005 << std::endl;
	maneuverGrip::Grip_Perform Rt( move_cfgX(msg_grip_now, -cfgX_mns_can * 0.005) );
	v_Rt.push_back(Rt);	
	return path_sum;
      }
      if (cfgX_pls_mus < 0.9 && cfgX_pls_can > 0.75)	// if must -cfgX
      {
	std::cout << "must move_cfgX : +"<< cfgX_pls_can * 0.005 << std::endl;
  	maneuverGrip::Grip_Perform Rt( move_cfgX(msg_grip_now, cfgX_pls_can * 0.005) );//
	v_Rt.push_back(Rt);
	return path_sum;
      }
      
      // CAN
      uint tendN = 0;
      for (uint i = 0; i< 8; i++)
      {
	uint j = (i+4)%8;
// 	if (cupPath_Mus.v_path[j] < 0.2)
// 	{
// 	  std::cout << "must move_xy."<<i<<" : "<< cupPath_Can.v_path[i] * 0.005 << std::endl;
// 	  tendN++;
// 	  maneuverGrip::Grip_Perform Rt(move_xy(msg_grip_now, i, cupPath_Can.v_path[i] * 0.005));
// 	  v_Rt.push_back(Rt);	  
// 	  return path_sum;
// 	}
	  
	std::cout<<cupPath_Can.v_path[i]<<"   ";
	if (cupPath_Can.v_path[i] > 0.75)
	{
	  std::cout << "move_xy."<<i<<" : "<< cupPath_Can.v_path[i] * 0.005 << std::endl;
	  tendN++;
	  maneuverGrip::Grip_Perform Rt(move_xy(msg_grip_now, i, cupPath_Can.v_path[i] * 0.005));
	  v_Rt.push_back(Rt);
	}
      }
      
      std::cout<<std::setprecision(4)<<"\n theta_pls: "<<theta_pls_can<<"     theta_mns: "<<theta_mns_can<<"\n";
      if (theta_pls_can > 0.75)
      {
	std::cout << "move_theta : +"<< theta_pls_can * 0.05 << std::endl;
	  tendN++;
	maneuverGrip::Grip_Perform Rt( move_theta(msg_grip_now, theta_pls_can * 0.05) );//rotate 3°
	v_Rt.push_back(Rt);
      }
      if (theta_mns_can > 0.75)
      {
	std::cout << "move_theta : "<< -theta_mns_can * 0.05 << std::endl;
	  tendN++;	
	maneuverGrip::Grip_Perform Rt( move_theta(msg_grip_now, -theta_mns_can * 0.05) );
	v_Rt.push_back(Rt);
      }

      std::cout<<std::setprecision(4)<<"\n cfg+: "<<cfgX_pls_can<<"     cfgX-: "<<cfgX_mns_can<<"\n";
      if (cfgX_pls_can > 0.88)
      {
	std::cout << "move_cfgX : +"<< cfgX_pls_can * 0.005 << std::endl;
	  tendN++;
  	maneuverGrip::Grip_Perform Rt( move_cfgX(msg_grip_now, cfgX_pls_can * 0.005) );//
	v_Rt.push_back(Rt);
      }
      if (cfgX_mns_can > 0.88)
//       if (tendN < 3)	// only try reducing cfgX when there're no much options
      {
	std::cout << "move_cfgX : "<< -cfgX_mns_can * 0.005 << std::endl;
	  tendN++;
	maneuverGrip::Grip_Perform Rt( move_cfgX(msg_grip_now, -cfgX_mns_can * 0.005) );
	v_Rt.push_back(Rt);
      }
      
//       msg_grip_now.cfgX;
      
      std::cout<<"\n v_Rt "<<v_Rt.size()<<"\n";
      
      return path_sum;
    }
#endif
    float get_v_GP_for_gp( std::vector< maneuverGrip::Grip_Perform> & v_Rt)
    {
      maneuverGrip::Grip_Perform GP_in = maneuverGrip::Grip_Perform(msg_grip_in); 
//       std::cout << "wtf3";
      try_Grip_get_Perform(GP_in);
//       std::cout << "wtf4";
      get_v_GP_for_gp(GP_in, v_Rt);
    }
    
    float get_v_GP_for_gp(maneuverGrip::Grip_Perform &GP_in, std::vector< maneuverGrip::Grip_Perform> & v_Rt)
    {
      
      yf_pcl_process::msg_Grip rt = GP_in.grip;
      print_Grip_Perform(GP_in);
      // rt contains tend of maneuver in those dimensions: x, y, theta, cfgX
      

      
      std::vector < cupPath > v_cupPath;
      v_cupPath.resize(5);
      for (uint i = 1; i < 5; i++)
      {
	v_cupPath[i] = GP_in.v_CupPath[i];
      }
      
      
      // look for movement of x,y
      std::cout<<"\nmaneuver x,y : ";
      cupPath cupPath_Can = cupPath();
      cupPath cupPath_Mus = cupPath();
      
      float path_sum = 0;
      {
	float K;	float k2;	 float a;
	float G;	float g2;
	for (uint i = 0; i< 8; i++)
	{
	  K = 7; k2 = 7;
	  G = 0; g2 = 0;
	  a = v_cupPath[1].v_path[i]; 	min12(a, K, k2);	max12(a, G, g2);
	  a = v_cupPath[2].v_path[i];	min12(a, K, k2);	max12(a, G, g2);
	  a = v_cupPath[3].v_path[i];	min12(a, K, k2);	max12(a, G, g2);
	  a = v_cupPath[4].v_path[i];	min12(a, K, k2);	max12(a, G, g2);
	  
	  cupPath_Can.v_path[i] = 0.5*(k2+K);
	  cupPath_Mus.v_path[i] = 0.5*(g2+G);
	  path_sum += cupPath_Can.v_path[i];
	}
      }
      
      // check ring quality
//       if ( path_sum > 0.8*8) return path_sum;   ////////////////// if good enough, stop maneuver and return current stage
      
      // look for movement of theta
      std::cout<<"\nmaneuver theta : ";
      float theta_pls_can, theta_mns_can;
      float theta_pls_mus, theta_mns_mus;
      
      float alpha = atan2(rt.cfgY, rt.cfgX);
//       std::cout<<std::setprecision(4)<<"\n cfgX: "<<rt.cfgX<<"     cfgY: "<<rt.cfgY<<"     alpha: "<< alpha*rad2deg << "\n";
      
      float pathN = alpha*rad2deg/45;
      uint pathN_ceil = ceil(pathN)  ;		uint pathN_flor = floor(pathN) ;	
      float t = pathN - pathN_flor;
//       std::cout<<std::setprecision(4)<<"\n pathN: "<<pathN<<"     pathN_ceil: "<<pathN_ceil<<"     pathN_flor: "<< pathN_flor<<"     t: "<< t << "\n";
            
      // take the 2.nd min as tendency of rotation (theta)
      if (pathN_flor == 0) 
      {
	float K;	float k2;	 float a, b;	
	float p1,p2,p3,p4;	float m1,m2,m3,m4;
// 	K = 7; k2 = 7;
      // anti-clock, + theta: 
	p1 = v_cupPath[1].v_path[6]*(1-t)+v_cupPath[1].v_path[7]*t;
	p2 = v_cupPath[2].v_path[6]*(1-t)+v_cupPath[2].v_path[5]*t;
	p3 = v_cupPath[3].v_path[2]*(1-t)+v_cupPath[3].v_path[1]*t;
	p4 = v_cupPath[4].v_path[2]*(1-t)+v_cupPath[4].v_path[3]*t;
	
      // clock,      - theta: 
	m1 = v_cupPath[1].v_path[2]*(1-t)+v_cupPath[1].v_path[3]*t;
	m2 = v_cupPath[2].v_path[2]*(1-t)+v_cupPath[2].v_path[1]*t;
	m3 = v_cupPath[3].v_path[6]*(1-t)+v_cupPath[3].v_path[5]*t;
	m4 = v_cupPath[4].v_path[6]*(1-t)+v_cupPath[4].v_path[7]*t;
	
      // anti-clock, + theta: 
	a = 0.5*(m1+m4); //std::max(m1,m4);
	b = 0.5*(m2+m3); //std::max(m2,m3);
	theta_pls_mus = std::min(a,b);
	a = std::min(p1, p2);
	b = std::min(p3, p4);
	theta_pls_can = std::max(a,b);
	
      // clock,      - theta: 
// 	K = 7; k2 = 7;
	
	a = 0.5*(m1+m4); //std::max(p1,p4);
	b = 0.5*(m2+m3); //std::max(p2,p3);
	theta_mns_mus = std::min(a,b);
	a = std::min(m1, m2);
	b = std::min(m3, m4);
	theta_mns_can = std::max(a,b);
	
      }
      else 
      {
	float K;	float k2;	 float a, b;
	float p1,p2,p3,p4;	float m1,m2,m3,m4;
      // anti-clock, + theta: 
	p1 = v_cupPath[1].v_path[0]*t+v_cupPath[1].v_path[7]*(1-t);
	p2 = v_cupPath[2].v_path[4]*t+v_cupPath[2].v_path[5]*(1-t);
	p3 = v_cupPath[3].v_path[0]*t+v_cupPath[3].v_path[1]*(1-t);
	p4 = v_cupPath[4].v_path[4]*t+v_cupPath[4].v_path[3]*(1-t);
	
      // clock,      - theta: 
	m1 = v_cupPath[1].v_path[4]*t+v_cupPath[1].v_path[3]*(1-t);
	m2 = v_cupPath[2].v_path[0]*t+v_cupPath[2].v_path[1]*(1-t);
	m3 = v_cupPath[3].v_path[4]*t+v_cupPath[3].v_path[5]*(1-t);
	m4 = v_cupPath[4].v_path[0]*t+v_cupPath[4].v_path[7]*(1-t);
	
// 	K = 7; k2 = 7;
      // anti-clock, + theta: 
	a = 0.5*(m1+m4); //std::max(m1,m4);
	b = 0.5*(m2+m3); //std::max(m2,m3);
	theta_pls_mus = std::min(a,b);
	a = std::min(p1, p3);
	b = std::min(p2, p4);
	theta_pls_can = std::max(a,b);
	
      // clock,      - theta: 
// 	K = 7; k2 = 7;
	a = 0.5*(m1+m4); //std::max(p1,p4);
	b = 0.5*(m2+m3); //std::max(p2,p3);
	theta_mns_mus = std::min(a,b);
	a = std::min(m1, m3);
	b = std::min(m2, m4);
	theta_mns_can = std::max(a,b);
	
      }
      
      
      // look for movement of cfgX
      std::cout<<"\nmaneuver cfgX : ";
      float cfgX_pls_can, cfgX_mns_can;
      float cfgX_pls_mus, cfgX_mns_mus;
      {
	float K;	float k2;	 float a,b;
      // clamping inward, - cfgX: 
	K = 0; k2 = 0;
// 	max12(v_cupPath[1].v_path[4], K, k2);
// 	max12(v_cupPath[2].v_path[4], K, k2);
// 	max12(v_cupPath[3].v_path[0], K, k2);
// 	max12(v_cupPath[4].v_path[0], K, k2);
// 	cfgX_mns_mus = 0.5*(K+k2);
	
	a = std::max(v_cupPath[1].v_path[4],v_cupPath[3].v_path[0]);
	b = std::max(v_cupPath[2].v_path[4],v_cupPath[4].v_path[0]);
	cfgX_mns_mus = std::min(a,b);
	
	K = 7; k2 = 7;
	a = v_cupPath[1].v_path[0] + v_cupPath[3].v_path[4];	min12(a, K, k2);
	b = v_cupPath[2].v_path[0] + v_cupPath[4].v_path[4];	min12(b, K, k2);
	cfgX_mns_can = 0.5*std::min(a,b);// 0.5*K;
	
      // spread out,      + cfgX: 
	K = 0; k2 = 0;
// 	max12(v_cupPath[1].v_path[0], K, k2);
// 	max12(v_cupPath[2].v_path[0], K, k2);
// 	max12(v_cupPath[3].v_path[4], K, k2);
// 	max12(v_cupPath[4].v_path[4], K, k2);
// 	cfgX_pls_mus = 0.5*(K+k2);
	
	a = std::max(v_cupPath[1].v_path[0],v_cupPath[3].v_path[4]);
	b = std::max(v_cupPath[2].v_path[0],v_cupPath[4].v_path[4]);
	cfgX_mns_mus = std::min(a,b);
	
	K = 7; k2 = 7;
	a = v_cupPath[1].v_path[4] + v_cupPath[3].v_path[0];	min12(a, K, k2);
	b = v_cupPath[2].v_path[4] + v_cupPath[4].v_path[0];	min12(b, K, k2);
	cfgX_pls_can = 0.5*std::min(a,b);// 0.5*K;
      }

      
      /////////////////////////////start looking for movements
      v_Rt.clear();////////////////////////////
      v_Rt.push_back(maneuverGrip::Grip_Perform(msg_grip_now));
      const float step_xy = 0.005;	// 5mm
      const float step_cfgX = 0.005; 	// 5mm
//       const float step_theta = atan2(0.005, rt.cfgY+rt.cfgX);	// 5mm in rotation end
      const float step_theta = 0.005;	// 5mm in rotation end
      
      
      ////considering previousAction
//       if (GP_in.previousActionType == 0);
      
      // MUST
      // cfgX
      if (cfgX_mns_mus < 0.6 && cfgX_mns_can > 0.75)	// if must -cfgX
      {
	float scale = -cfgX_mns_can * step_cfgX;
	if (GP_in.previousActionType == 10) scale *= 0.5;
	std::cout << std::setprecision(5)<< "must move_cfgX : "<< scale << std::endl;
	maneuverGrip::Grip_Perform Rt( move_cfgX(msg_grip_now, scale) );
      	Rt.interations = GP_in.interations+1;	Rt.previousActionType = 10;	Rt.previousActionScale = scale;
	v_Rt.push_back(Rt);	
	return path_sum;
      }
      if (cfgX_pls_mus < 0.6 && cfgX_pls_can > 0.75)	// if must +cfgX
      {
	float scale = cfgX_pls_can * step_cfgX;
	if (GP_in.previousActionType == 10) scale *= 0.5;
	std::cout << std::setprecision(5)<< "must move_cfgX : +"<< scale << std::endl;
  	maneuverGrip::Grip_Perform Rt( move_cfgX(msg_grip_now, scale) );//
      	Rt.interations = GP_in.interations+1;	Rt.previousActionType = 10;	Rt.previousActionScale = scale;
	v_Rt.push_back(Rt);
	return path_sum;
      }
      
      // cfgTheta
      if (theta_mns_mus < 0.6 && theta_mns_can > 0.75)	// if must -theta
      {
	float scale = -theta_mns_can * step_theta;
	if (GP_in.previousActionType == 20) scale *= 0.5;
	std::cout << std::setprecision(5)<< "must move_theta : "<< scale << std::endl;
	maneuverGrip::Grip_Perform Rt( move_theta2(msg_grip_now, scale) );
      	Rt.interations = GP_in.interations+1;	Rt.previousActionType = 20;	Rt.previousActionScale = scale;
	v_Rt.push_back(Rt);	
	return path_sum;
      }
      if (theta_pls_mus < 0.6 && theta_pls_can > 0.75)	// if must +theta
      {
	float scale = theta_pls_can * step_theta;
	if (GP_in.previousActionType == 20) scale *= 0.5;
	std::cout << std::setprecision(5)<< "must move_theta : +"<< scale << std::endl;
  	maneuverGrip::Grip_Perform Rt( move_theta2(msg_grip_now, scale) );//
      	Rt.interations = GP_in.interations+1;	Rt.previousActionType = 20;	Rt.previousActionScale = scale;
	v_Rt.push_back(Rt);
	return path_sum;
      }
      
      
//       // CAN
      uint tendN = 0;
      for (uint i = 0; i< 8; i++)
      {
	std::cout<<cupPath_Can.v_path[i]<<"   ";
	if (cupPath_Can.v_path[i] > 0.75)
	{
	  float scale = cupPath_Can.v_path[i] * step_xy;
	  int dirSame = (GP_in.previousActionType-i)%4;
	  if (dirSame >= 0 && dirSame < 8)
	  {
	  //GP_in.previousActionType-i)%4 = 0: same direction, 2: prependiculer
	    if (dirSame == 2) {}
	    else if (dirSame == 0) scale *= 0.5;
	    else scale *= 0.714;
	  }
	  std::cout << "can move_xy."<<i<<" : "<< scale << std::endl;
	  tendN++;
	  maneuverGrip::Grip_Perform Rt(move_xy(rt, i, scale));
	  Rt.interations = GP_in.interations+1;	Rt.previousActionType = i;	Rt.previousActionScale = scale;
// 	  Rt.dad = &GP_in;
	  v_Rt.push_back(Rt);
// 	  GP_in.kids.push_back( &( v_Rt.back() ) );
	}
      }
      
      std::cout<<std::setprecision(4)<<"\n theta_pls_can: "<<theta_pls_can<<"     theta_mns_can: "<<theta_mns_can<<"\n";
      if (theta_pls_can > 0.7)
      {
	float scale = theta_pls_can * step_theta;
	if (GP_in.previousActionType == 20) scale *= 0.5;
	std::cout << "can move_theta : +"<< scale << std::endl;
	  tendN++;
	maneuverGrip::Grip_Perform Rt( move_theta2(rt, scale) );//rotate 3°
      	Rt.interations = GP_in.interations+1;	Rt.previousActionType = 20;	Rt.previousActionScale = scale;
// 	  Rt.dad = &GP_in;
	  v_Rt.push_back(Rt);
// 	  GP_in.kids.push_back( &( v_Rt.back() ) );
      }
      if (theta_mns_can > 0.7)
      {
	float scale = -theta_mns_can * step_theta;
	if (GP_in.previousActionType == 20) scale *= 0.5;
	std::cout << "can move_theta : "<< scale << std::endl;
	  tendN++;	
	maneuverGrip::Grip_Perform Rt( move_theta2(rt, scale) );
      	Rt.interations = GP_in.interations+1;	Rt.previousActionType = 20;	Rt.previousActionScale = scale;
// 	  Rt.dad = &GP_in;
	  v_Rt.push_back(Rt);
// 	  GP_in.kids.push_back( &( v_Rt.back() ) );
      }

      std::cout<<std::setprecision(4)<<"\n cfg+: "<<cfgX_pls_can<<"     cfgX-: "<<cfgX_mns_can<<"\n";
      if (cfgX_pls_can > 0.88)
      {
	float scale = cfgX_pls_can * step_cfgX;
	if (GP_in.previousActionType == 10) scale *= 0.5;
	std::cout << "can move_cfgX : +"<< scale << std::endl;
	  tendN++;
  	maneuverGrip::Grip_Perform Rt( move_cfgX(rt, scale) );//
      	Rt.interations = GP_in.interations+1;	Rt.previousActionType = 10;	Rt.previousActionScale = scale;
// 	  Rt.dad = &GP_in;
	  v_Rt.push_back(Rt);
// 	  GP_in.kids.push_back( &( v_Rt.back() ) );
      }
      if (cfgX_mns_can > 0.88)
      {
	float scale = -cfgX_mns_can * step_cfgX;
	if (GP_in.previousActionType == 10) scale *= 0.5;
	std::cout << "can move_cfgX : "<< scale << std::endl;
	  tendN++;
	maneuverGrip::Grip_Perform Rt( move_cfgX(rt, scale) );
      	Rt.interations = GP_in.interations+1;	Rt.previousActionType = 10;	Rt.previousActionScale = scale;
// 	  Rt.dad = &GP_in;
	  v_Rt.push_back(Rt);
// 	  GP_in.kids.push_back( &( v_Rt.back() ) );
      }
      
      if (path_sum > 0.95*8.0) 
      {
	tf::StampedTransform stf_;
	tf::Point Pt_cup0;
	tf::transformStampedMsgToTF(GP_in.grip.tfs_tabel2cupbase0, stf_);
	Pt_cup0 = stf_.getOrigin();
	massCenter-Pt_cup0; 
      }
//       msg_grip_now.cfgX;
      
      std::cout<<"\n v_Rt "<<v_Rt.size()<<"\n";
      
      return path_sum;      
    }
    
    ///////////
        

    float get_GP_descent_0now_1new( std::vector <maneuverGrip::Grip_Perform> & Rt)
    {
      Rt.clear();
      maneuverGrip::Grip_Perform GP_in = maneuverGrip::Grip_Perform(msg_grip_now); 
      maneuverGrip::Grip_Perform GP_out ; 
//       std::cout << "wtf3";
      try_Grip_get_Perform(GP_in);
//       std::cout << "wtf4";
      get_GP_descent(GP_in, GP_out);
      Rt.push_back(GP_in);
      Rt.push_back(GP_out);
    }        
        
    std::function <float(float&)> getForce = [&](const float in)
    {
      if (in > 1)
	return 0.0;
      else if (in >= 0)	
	return (1.0 - in*in);
      else
	return 1.0 - in;
    };
    
    void get_gradient_path(maneuverGrip::Grip_Perform &GP_in, TendGradient &tends_)
    {
      get_gradient_path(GP_in, tends_.tend_moveXY, tends_.tend_moveTheta, tends_.tend_cfgX);
    }
    
    void get_gradient_path(maneuverGrip::Grip_Perform &GP_in, tf::Point &tend_moveXY, float &tend_moveTheta, float &tend_cfgX)
    {
//					//    cups  dirs   canceling
//       float normalizer = 0.0625;	// 1/(  4  *  8  ) * 2
					//    cups  dirs(0°   45°)   
      float normalizer = 0.10355;	// 1/(  4  * ( 1  +  sqrt(2)) ) 
					//    cups  dirs(0°   45°)   
      float normalizer2 = 1;	// 1/(  4  * ( 1  +  sqrt(2)) ) 
      
      int count_effective =1;
      int count_involved  =1;
      
      float tend_moveTheta_path=0.0; 
      float tend_cfgX_path=0.0;
      tf::Point tend_moveXY_path = v3_000; 
      
      float tend_moveTheta_ang = 0.0; 
      float tend_cfgX_ang = 0.0;
      tf::Point tend_moveXY_ang = v3_000; 
      
      for (uint i = 1; i < 5; i++)
      {
	float ix = (i<3)?-0.5:0.5; float iy = (i%2!=0)?-0.5:0.5;
	tf::Point V_position (GP_in.grip.cfgX*ix, GP_in.grip.cfgY*iy, 0);
	V_position.normalize();
	
	// considering border and mobility
	for (uint j = 0; j<8; j++)
	{				
// 	  float f = normalizer*(1.0-GP_in.v_path[i].v_path[j]);	
	  float f = getForce(GP_in.v_CupPath[i].v_path[j]);	
	  if (f > 0.5) {count_effective++;};	// ignored path
	  count_involved ++;
	  tend_moveXY_path -= f*v_PathDir[j];
	  tend_moveTheta_path -= 2.0 * f*(tf::tfCross(V_position,v_PathDir[j])).z();		// half of dirs does not influence rotation (when parallel)
	  if (i<3)
	    tend_cfgX_path += f*v_PathDir[j].x()*2;
	  else 
	    tend_cfgX_path -= f*v_PathDir[j].x()*2;
	} 
	
	// considering angular deviation
	for (uint j = 0; j<8; j++)
	{				
// 	  float f = normalizer*(1.0-GP_in.v_path[i].v_path[j]);	
	  float f = getForce(GP_in.v_CupPath[i].v_ang[j]);	
	  if (f > 0.5) {count_effective++;};	// ignored path
	  count_involved ++;
	  tend_moveXY_ang -= f*v_PathDir[j];
	  tend_moveTheta_ang -= 2.0 * f*(tf::tfCross(V_position,v_PathDir[j])).z();		// half of dirs does not influence rotation (when parallel)
	  if (i<3)
	    tend_cfgX_ang += f*v_PathDir[j].x()*2;
	  else 
	    tend_cfgX_ang -= f*v_PathDir[j].x()*2;
	} 
	
      }
      normalizer = 1.0/count_effective;
      normalizer2 = 1.0/count_involved;
      normalizer = normalizer2;
//       std::cout << "normalizer = 1.0/count_effective : "<< normalizer <<"  "<<count_effective<<"\n";
      tend_moveXY_path*=normalizer; tend_moveTheta_path*=normalizer; tend_cfgX_path*=normalizer;
      tend_moveXY_ang*=normalizer; tend_moveTheta_ang*=normalizer; tend_cfgX_ang*=normalizer;
      
      std::cout << "tend_cfgX_path: "<< tend_cfgX_path;
      std::cout << "  tend_cfgX_ang: "<< tend_cfgX_ang<<"\n";
      
      tend_moveXY = (tend_moveXY_path + tend_moveXY_ang) * 0.5;
      if (tend_moveXY.length2() > 1) tend_moveXY.normalize();
      
      tend_moveTheta = (tend_moveTheta_path + tend_moveTheta_ang) * 0.5;
      if (tend_moveTheta > 1) tend_moveTheta = 1;
      else if (tend_moveTheta < -1) tend_moveTheta = -1;

      tend_cfgX = (tend_cfgX_path + tend_cfgX_ang) * 1;
      if (tend_cfgX > 1) tend_cfgX = 1;
      else if (tend_cfgX < -1) tend_cfgX = -1;
      
    }
    
    void get_gradient_balance(maneuverGrip::Grip_Perform &GP_in, TendGradient &tends_)
    { 
      tends_.tend_moveTheta=0.0; tends_.tend_cfgX=0.0;
      tends_.tend_moveXY = v3_000; 
      
      tf::StampedTransform stf_;
      tf::transformStampedMsgToTF(GP_in.grip.tfs_tabel2cupbase0, stf_);
      tends_.tend_moveXY = stf_.inverse() * massCenter;
      tends_.tend_moveXY.setZ(0);
      
      float len2 = tends_.tend_moveXY.length2();
      
      if ( len2 > 0.000025) 
      {
	tends_.tend_moveXY = tends_.tend_moveXY.normalized();
      }
      else
      {
	tends_.tend_moveXY = tends_.tend_moveXY * 200;
      }
      
//       std::cout << "tend_moveXY = : "<< tends_.tend_moveXY.x()*1000 <<"  "<< tends_.tend_moveXY.y()*1000 <<"\n";
//       tends_.tend_cfgX = fabs(2.0*tends_.tend_moveXY.x()) ;
    }

    
    void add_moveScaleTends_to_GP(maneuverGrip::Grip_Perform GP_in, maneuverGrip::Grip_Perform &rt, const TendGradient tends_)
    {
      maneuverGrip::Grip_Perform rt2 (move_tends(GP_in.grip, tends_.tend_moveXY, tends_.tend_moveTheta, tends_.tend_cfgX));
      rt2.interations = GP_in.interations+1;	rt2.previousActionType = 71;	rt2.previousActionScale = 0;
      rt = rt2;
    }
    
    void add_moveScaleTends_to_GP(maneuverGrip::Grip_Perform GP_in, maneuverGrip::Grip_Perform &rt, const tf::Point s_moveXY, const float s_moveTheta, const float s_cfgX)
    {
      maneuverGrip::Grip_Perform rt2 (move_tends(GP_in.grip, s_moveXY, s_moveTheta, s_cfgX));
      rt2.interations = GP_in.interations+1;	rt2.previousActionType = 71;	rt2.previousActionScale = 0;
      rt = rt2;
    }
    
    float get_GP_descent(maneuverGrip::Grip_Perform &GP_in, maneuverGrip::Grip_Perform & Rt_)
    {
      
//       yf_pcl_process::msg_Grip rt = GP_in.grip;
//       print_Grip_Perform(GP_in);
      
      
      const float step = 0.005;	// 5mm
//       const float step_cfgX = 0.005; 	// 5mm
//       const float step_theta = atan2(0.005, GP_in.grip.cfgY+GP_in.grip.cfgX);	// 5mm in rotation end
//       const float step_theta = 0.005;	// 5mm in rotation end
      
      // rt contains tend of maneuver in those dimensions: x, y, theta, cfgX
            
      tf::Point tend_moveXY (0,0,0); 
      float tend_moveTheta=0.0, tend_cfgX=0.0;
      
      TendGradient g_p, g_b, S;
      get_gradient_balance(GP_in, g_b);
      get_gradient_path(GP_in, g_p);
      
//       S = (g_p+g_b) * step;
      S = g_p.add_TendMassCenter(g_b) * step;
      
      add_moveScaleTends_to_GP(GP_in, Rt_, S);

      // look for movement of x,y
//       std::cout<<"\nmaneuver x,y : ";
      cupPath cupPath_Can = cupPath();
      cupPath cupPath_Mus = cupPath();
      
      float path_sum = 0;
      
      // check ring quality
      if (path_sum > 0.95*8.0) 
      {
	tf::StampedTransform stf_;
	tf::Point Pt_cup0;
	tf::transformStampedMsgToTF(GP_in.grip.tfs_tabel2cupbase0, stf_);
	Pt_cup0 = stf_.getOrigin();
	massCenter-Pt_cup0; 
      }
//       msg_grip_now.cfgX;
      
      return path_sum;      
    }
    
    void optimize_GD_ordinary(maneuverGrip::Grip_Perform IN_org, maneuverGrip::Grip_Perform &OUT_, uint ManeuverIterations = 7)
    {
      std::cout <<  "\nTRY OPTIMIZE GRIP\n";
      maneuverGrip::Grip_Perform in = IN_org;
      maneuverGrip::Grip_Perform  out ;         
      uint further = true;
      
      float evaluation_;
      
      while (further && ManeuverIterations > 0) 
      {
// 	print_Grip_Perform(in);
	get_GP_descent(in,out);
	try_Grip_get_Perform(out);
	
	evaluation_ = out.score;
	in = out;
	ManeuverIterations --;
      }
      
      OUT_ = in;
    }
    
    
    
    void optimize_GD_ADAM(maneuverGrip::Grip_Perform IN_org, maneuverGrip::Grip_Perform &OUT_, uint ManeuverIterations = 7)
    {
      std::cout <<  "\nTRY OPTIMIZE GRIP\n ";
      maneuverGrip::Grip_Perform in = IN_org;
      maneuverGrip::Grip_Perform out ;
      std::vector< maneuverGrip::Grip_Perform > v_out {};         
      uint further = true;
      
      float step = 0.007;
      float b1 = 0.9, b2 = 0.999;
      float B1 = 1 , B2 = 1;
      float ee = 0.00000001;
      float evaluation_;
      TendGradient g, g_p, g_b, g_old,S;
      TendGradient m,M;
      float v,V;
      uint t = 0;
      
      
      while (further && ManeuverIterations > 0) 
      {
	print_Grip_Perform(in);
	
	const float step_xy = step;	// 5mm
	const float step_cfgX = step; 	// 5mm
// 	const float step_theta = atan2(step, in.grip.cfgY+in.grip.cfgX);	// 5mm in rotation end
        
	
	t++;
	tf::Point tend_moveXY (0,0,0); 
	float tend_moveTheta=0.0, tend_cfgX=0.0;
	//https://arxiv.org/pdf/1412.6980.pdf
	//Get gradients w.r.t. stochastic objective at timestep t
	g_old = g;
	get_gradient_balance(in, g_b);
	get_gradient_path(in, g_p);
	
	g = g_p.add_TendMassCenter(g_b) ;
	if (1){
	  m = m*b1 + g*(1-b1);			// Update biased first moment estimate
	  v = v*b2 + (g.sqr())*((1-b2));		// Update biased second raw moment estimate
	  
	  B1 *= b1;				// calc B1 = b1^t
	  M = m*(1/(1-B1));				// Compute bias-corrected first moment estimate
	  B2 *= b2;				// calc B2 = b2^t
	  V = v*(1/(1-B2));				// Compute bias-corrected second raw moment estimate
	  S = M*(step/(sqrt(V)+ee));		// Update parameters
	}
	else
	{
	  m = m.scaled(0.9)+g*step;
	  S = m;		// Update parameters
	}
	add_moveScaleTends_to_GP(in, out, S);
// 	add_moveScaleTends_to_GP(in, out, g);
	
	try_Grip_get_Perform(out);
	
	evaluation_ = out.score;
	in = out;
	ManeuverIterations --;
      }
      
      OUT_ = in;
    }
    
    
    int trim_leaf_GP(std::vector < maneuverGrip::Grip_Perform > & v_Rt_GP)
    {
      if (v_Rt_GP.size()<1) return 0;
      std::vector <uint> toErase = {};
//       float improve;
//       std::vector <float> v_improves (v_Rt_GP.size());
//       std::vector <uint>  v_idx_sort (v_Rt_GP.size());
      
      try_Grip_get_Perform(v_Rt_GP[0]);
//       print_Grip_Perform (v_Rt_GP[0]);
      
      for (uint i = 1; i < v_Rt_GP.size(); i++)
      {
	try_Grip_get_Perform(v_Rt_GP[i]);
//  	print_Grip_Perform (v_Rt_GP[i]);
	
// 	if (v_Rt_GP[i].bad) toErase.push_back(i);
	
// 	std::cout << "compare "<< i << "  \n";
 	v_Rt_GP[i].improve = compare_Grip_Perform(v_Rt_GP[i], v_Rt_GP[0]);
// 	improve = v_Rt_GP[i].improve ;
// 	v_idx_sort[i] = i;
// 	v_improves[i] = improve;
// 	std::cout << "compare "<< i << "  : "<<v_Rt_GP[i].grip.name<<"  \timprove: " <<improve<<" \t-> ";
 	
	
// 	if (improve < 1) 
// 	{
// 	  std::cout << "erase "<< i << "\n";
//  	  toErase.push_back(i);
// 	}
// 	else
// 	{
// 	  std::cout << "aprove "<< i << "\n";
// 	}
	// if obj is bad or there are no improvement
// 	break;
      }
      
      std::sort(  std::begin(v_Rt_GP)+1, 
		  std::end(v_Rt_GP),
		  [&](maneuverGrip::Grip_Perform gp1, maneuverGrip::Grip_Perform gp2) { return gp1.improve > gp2.improve; } );  
	      
      
      for (uint i = 1; i < v_Rt_GP.size(); i++)
      {
	std::cout << "compare "<< i << "  : "<<v_Rt_GP[i].grip.name<<"  \timprove: " <<v_Rt_GP[i].improve<<" \t-> ";
	if (v_Rt_GP[i].improve < 1) 
	{
	  std::cout << "erase "<< i << "\n";
//  	  toErase.push_back(i);
	}
	else
	{
	  std::cout << "aprove "<< i << "\n";
	}
      
//        for (int i = toErase.size()-1; i>=0; i--)
//        {
// // 	  std::cout << "erase "<< toErase[i] << "  ";
// 	  v_Rt_GP.erase(v_Rt_GP.begin()+toErase[i]);
       }
       std::cout <<"\n --------------- AFTER ERASE --------------- \n";
       if (v_Rt_GP.size() < 1)
       {
	 std::cout << "maneuver over!\n";
	 return 0;
       }
       
//        for (uint i = 1; i < v_Rt_GP.size(); i++)	print_Grip_Perform (v_Rt_GP[i]);
       
       return v_Rt_GP.size()-1;
    }    
    
    float apply_tend(yf_pcl_process::msg_Grip Rt_Msg)
    {
       std::cout << "apply_tend  ";
       
      float fitDeviation;
      set_MsgGrip(Rt_Msg);
//        std::cout << "set  ";
      apply_MsgGrip();
//        std::cout << "apply_MsgGrip  ";
      fitDeviation = fit_MsgGrip();
//        std::cout << "fit_MsgGrip  ";
      return fitDeviation;
    }
    
    
    class cupTend		// tendancy of movement, avoiding obstacles according to cupHinder
    {
      public:
	tf::Point poke;		// linear force applied to cup according to cupbaseframe[N]
	tf::Point screw;		// torque applied to cup according to cupbaseframe[0]      
	
	cupTend(): poke(tf::Point(0,0,0)),screw(tf::Point(0,0,0)) 		{};
	cupTend(tf::Point poke_, tf::Point screw_): poke(poke_), screw(screw_) 	{};
    };
    
    cupTend set_cupTend(tf::Point poke_, int cupX)
    {
      cupTend tmp;
      tmp.poke = poke_;
      tf::Point L = v_stf_Tool2CupBases[cupX].getOrigin();
      tmp.screw = tf::tfCross(L, poke_);
      return tmp;
    }
    
    cupTend get_cupTend_rand (uint cupX)
    {
      setget_tf_table2ring_cupX(cupX);	// init idx_ring and stf for cupX
      // v_idx_ring(cupX) & v_stf_table2ring[cupX] available now
      get_cupPath(cupX);
      
    }
    
/////////////////////////////basis
    pcl::IndicesPtr get_idx_ring(uint cupX)    
    { 
      pcl::IndicesPtr idx_ring (new std::vector <int>);
      // if cup off
      if (!v_cupOn[cupX]) return (idx_ring);
	
      tf::Transform searchPoint = v_tf_table2cupbase[cupX];
      idx_ring = get_idx_ring(searchPoint, v_cup_dim[cupX]);  
      v_idx_ring[cupX] = pcl::IndicesPtr(idx_ring);
      return idx_ring;
    }
/*    
    pcl::IndicesPtr get_idx_ring(tf::Point searchPoint )    
    { 
      pcl::PointXYZ searchPoint2(searchPoint.x(),searchPoint.y(),searchPoint.z());
      return get_idx_ring(searchPoint2, cup_dim_);  
    }*/

    pcl::IndicesPtr get_idx_ring(const tf::Transform &searchPoint, const yf_vacuum_cups::cup_dim &cup_lc )
    { 
      if (cup_lc.lengthen < 0.001)
      {
	tf::Point SPt (searchPoint.getOrigin());
	pcl::PointXYZ searchPoint2(SPt.x(),SPt.y(),SPt.z());
	
	
	//       std::cout <<" get_idx_ring :" << ros::Time::now()-RosTimeBegin << " ~ ";
	float rim_in = 0.95*cup_lc.radius-0.0014; 
	if (rim_in < 0.005) rim_in = 0.0;
// 	float rim_out = 1.05*(cup_lc.radius+0.5*cup_lc.lengthen)+0.0014;	// setting search region for the contact rim
	float rim_out = 1.05*(cup_lc.radius)+0.0014;	// setting search region for the contact rim
	
	pcl::IndicesPtr idx_find_out (new std::vector <int>), idx_find_in (new std::vector <int>); 
	pcl::IndicesPtr idx_ring (new std::vector <int>);	// segmentation of surface which (may) have contact with the vacuum cup
	std::vector<float> dump;
	
// 	tree_inlander.setInputCloud(cloud, idx_inlander);
#if 0
	tree_inlander.nearestKSearch (searchPoint2, 1, *idx_find_out, dump);
#else
	tree_inlander.nearestKSearch (searchPoint2, 100, *idx_find_out, dump);
	float r_min = 1; uint min_id;
	
	tf::Transform inv_searchpoint = searchPoint.inverse();
	for (auto & it : *idx_find_out)
	{
// 	    std::cout << "to z axis\n";
	  tf::Point p(cloud->at(it).x, cloud->at(it).y, cloud->at(it).z);
	  p = inv_searchpoint*p;
	  float dxy = R_xy2(p.getX(), p.getY());
	  if (dxy < r_min)
	  {
	    r_min = dxy;
	    (*idx_find_out)[0] = it;
	    if (r_min < 0.0007) break;
// 	    std::cout << "nearest to z axis\n";
	   
	  } 
	   
	}
#endif
	size_t id_center = idx_find_out->at(0); 	pcl::PointXYZ Pt_center = cloud->points[id_center];
	
	if ( tree_cloud.radiusSearch (Pt_center, rim_out, *idx_find_out, dump) > 0 )	{}	//nullptr
#if 0
	if ( tree_cloud.radiusSearch (Pt_center, rim_in, *idx_find_in, dump) > 0 )	{}
	std::set_difference(idx_find_out->begin(), idx_find_out->end(), idx_find_in->begin(), idx_find_in->end(), 
			    std::inserter(*idx_ring, idx_ring->begin()));
#else
	*idx_ring = *idx_find_out;
#endif
	
	idx_ring->insert(idx_ring->begin(),id_center);
	return idx_ring;
      }
      else	// not updated 
      {
	pcl::IndicesPtr idx_cb (new std::vector <int>);
	float dx = cup_lc.lengthen;
	tf::Point dxL (dx,0,0);
	uint k = round(cup_lc.lengthen/cup_lc.radius)+1;
// 	for (float i = -0.5*(k); i<0.6*(k); i+=1.0)
// 	{
// 	  tf::Point SPt (searchPoint*(i/k*dxL));
// 	  pcl::PointXYZ searchPoint2(SPt.x(),SPt.y(),SPt.z());
// 	  std::cout << i << "*";
// 	  pcl::IndicesPtr idx_t(get_idx_ring(searchPoint2, cup_lc));  
// 	  idx_cb->insert(idx_cb->end(), idx_t->begin(), idx_t->end()); 
// 	}
	
	tf::Point SPt (searchPoint.getOrigin());
	pcl::PointXYZ searchPoint2(SPt.x(),SPt.y(),SPt.z());
	pcl::IndicesPtr idx_t(get_idx_ring(searchPoint2, cup_lc));  
	idx_cb->insert(idx_cb->end(), idx_t->begin(), idx_t->end()); 

	SPt = searchPoint*(+0.5*dxL);
	searchPoint2 =pcl::PointXYZ(SPt.x(),SPt.y(),SPt.z());
	idx_t = (get_idx_ring2(searchPoint2, cup_lc));  
	idx_cb->insert(idx_cb->end(), idx_t->begin(), idx_t->end()); 
	
	SPt = searchPoint*(-0.5*dxL);
	searchPoint2 =pcl::PointXYZ(SPt.x(),SPt.y(),SPt.z());
	idx_t = (get_idx_ring2(searchPoint2, cup_lc));  
	idx_cb->insert(idx_cb->end(), idx_t->begin(), idx_t->end()); 
	
	int ct = idx_cb->at(0);
	
// 	std::cout << idx_cb->size()<<" = size\n";
	std::sort(idx_cb->begin(), idx_cb->end()); 
	auto last = std::unique(idx_cb->begin(), idx_cb->end());
	idx_cb->erase(last, idx_cb->end());
// 	std::cout << idx_cb->size()<<" = size\n";
	idx_cb->insert(idx_cb->begin(),ct);
	return idx_cb;
      }
    }    
    
//     pcl::IndicesPtr get_idx_ring(pcl::PointXYZ searchPoint )    {      return get_idx_ring(searchPoint, cup_dim_);    }
    
    pcl::IndicesPtr get_idx_ring(const pcl::PointXYZ &searchPoint, const yf_vacuum_cups::cup_dim &cup_lc )
    {
//       std::cout <<" get_idx_ring :" << ros::Time::now()-RosTimeBegin << " ~ ";
	float rim_in = 0.95*cup_lc.radius-0.0014; 
// 	float rim_out = 1.05*(cup_lc.radius+0.5*cup_lc.lengthen)+0.0014;	// setting search region for the contact rim
	float rim_out = 1.05*(cup_lc.radius)+0.0014;	// setting search region for the contact rim
	if (rim_in < 0.005) rim_in = 0.0;
	
	pcl::IndicesPtr idx_find_out (new std::vector <int>), idx_find_in (new std::vector <int>); 
	pcl::IndicesPtr idx_ring (new std::vector <int>);	// segmentation of surface which (may) have contact with the vacuum cup
	std::vector<float> dump;
	
// 	tree_inlander.setInputCloud(cloud, idx_inlander);
#if 1
	tree_inlander.nearestKSearch (searchPoint, 1, *idx_find_out, dump);
#else
	tree_inlander.nearestKSearch (searchPoint, 100, *idx_find_out, dump);
	float r_min = 1; uint min_id;
	for (auto & it : *idx_find_out)
	{
	  tf::Point p(cloud->at(it).x, cloud->at(it).y, cloud->at(it).z);
	  if ((*p)<r_min)
	}
#endif
	size_t id_center = idx_find_out->at(0); 	pcl::PointXYZ Pt_center = cloud->points[id_center];
	
	if ( tree_cloud.radiusSearch (Pt_center, rim_out, *idx_find_out, dump) > 0 )	{}	//nullptr
#if 0
	if ( tree_cloud.radiusSearch (Pt_center, rim_in, *idx_find_in, dump) > 0 )	{}
	std::set_difference(idx_find_out->begin(), idx_find_out->end(), idx_find_in->begin(), idx_find_in->end(), 
			    std::inserter(*idx_ring, idx_ring->begin()));
#else
	*idx_ring = *idx_find_out;
#endif
	
	idx_ring->insert(idx_ring->begin(),id_center);
	
//       std::cout<<ros::Time::now()-RosTimeBegin<<"\n";

      return idx_ring;
    }

    
    pcl::IndicesPtr get_idx_ring2(const pcl::PointXYZ searchPoint, const yf_vacuum_cups::cup_dim cup_lc )
    {
//       std::cout <<" get_idx_ring :" << ros::Time::now()-RosTimeBegin << " ~ ";
	float rim_in = 0.95*cup_lc.radius-0.0014; 
// 	float rim_out = 1.05*(cup_lc.radius+0.5*cup_lc.lengthen)+0.0014;	// setting search region for the contact rim
	float rim_out = 1.05*(cup_lc.radius)+0.0014;	// setting search region for the contact rim
	if (rim_in < 0.005) rim_in = 0.0;
	
	pcl::IndicesPtr idx_find_out (new std::vector <int>), idx_find_in (new std::vector <int>); 
	pcl::IndicesPtr idx_ring (new std::vector <int>);	// segmentation of surface which (may) have contact with the vacuum cup
	std::vector<float> dump;
	
	if ( tree_cloud.radiusSearch (searchPoint, rim_out, *idx_find_out, dump) > 0 )	{}	//nullptr
#if 0
	if ( tree_cloud.radiusSearch (Pt_center, rim_in, *idx_find_in, dump) > 0 )	{}
	std::set_difference(idx_find_out->begin(), idx_find_out->end(), idx_find_in->begin(), idx_find_in->end(), 
			    std::inserter(*idx_ring, idx_ring->begin()));
#else
	*idx_ring = *idx_find_out;
#endif
	
      return idx_ring;
    }
    
    tf::Transform get_tf_table2ring_cupX(const uint cupX)
    {
      tf::Transform tf_table2ring = get_tf_table2ring (get_idx_ring(cupX), v_tf_table2cupbase[0], v_cup_dim[cupX]);
//       v_stf_table2ring[cupX] = tf::StampedTransform(tf_table2ring, ros::Time::now(),"/tool_frame","/cups_frame/"+std::to_string(cupX));
      return tf_table2ring;
    }
    
    tf::Transform setget_tf_table2ring_cupX(const uint cupX)
    {
      tf::Transform tf_table2ring = get_tf_table2ring (get_idx_ring(cupX), v_tf_table2cupbase[0], v_cup_dim[cupX]);
      v_stf_table2ring[cupX] = tf::StampedTransform(tf_table2ring, ros::Time::now(),"/tool_frame","/cups_frame/"+std::to_string(cupX));
      return tf_table2ring;
    }
    
    tf::Transform get_tf_table2ring (pcl::IndicesPtr idx_ring, tf::Transform tf_tool_loc, yf_vacuum_cups::cup_dim cup_lc)
    {
      float rz;
      return get_tf_table2ring (idx_ring, tf_tool_loc, cup_lc, rz);
    }
    
    tf::Transform get_tf_table2ring (pcl::IndicesPtr idx_ring, tf::Transform tf_tool_loc, yf_vacuum_cups::cup_dim cup_lc, float &rz)	// return the transform from frame to ring, regarding the best fit of cylinder
    {
      tf::Point Pxyz = tf::Point(cloud->points[idx_ring->at(0)].x,cloud->points[idx_ring->at(0)].y,cloud->points[idx_ring->at(0)].z);
      
      float tmpfit;
      tf::Point Pnorm = get_v3_norm_ring(idx_ring, cup_lc, tmpfit, rz);
//       std::cout<< std::setprecision(5) <<  "                    Pnorm : " << Pnorm.x()<<" " << Pnorm.y()<<" " << Pnorm.z()<<" \n"; 
      
      tf::Transform tf_tool_R(tf_tool_loc.getRotation().inverse(), v3_000);
      tf::Point Pnorm_4_tool = tf_tool_R*Pnorm;
      
      tf::Quaternion q;
      tf::Vector3 v;
//       std::cout<< std::setprecision(5) << "e_z : " << e_z.x()<<" " << e_z.y()<<" " << e_z.z()<<" \n"; 
      v = tf::tfCross(v3_001, Pnorm_4_tool);    v.normalize();
//       std::cout<< std::setprecision(5)<< "v : " << v.x()<<" " << v.y()<<" " << v.z() << " ~ "<<tf::tfAngle(Pnorm_4_tool, v3_001)*rad2deg<<"° \n"; 
      q = tf::Quaternion(v, rz);

      tf::Transform tf_Znorm = tf::Transform(tf_tool_loc.getRotation()*q,Pxyz);
      
      return tf_Znorm;
    }
    
    
    tf::Point get_v3_norm_ring(pcl::IndicesPtr idx_ring, yf_vacuum_cups::cup_dim cup_lc)
    {
      float tmpfit, tmprz;
      return get_v3_norm_ring(idx_ring, cup_lc, tmpfit, tmprz);
    }
    
    tf::Point get_v3_norm_ring(pcl::IndicesPtr idx_ring, yf_vacuum_cups::cup_dim cup_lc, float &fitDeviation, float &rz)
    {

      tf::Point Pxyz = tf::Point(cloud->points[idx_ring->at(0)].x,cloud->points[idx_ring->at(0)].y,cloud->points[idx_ring->at(0)].z);
      fitDeviation = 0;
      if (idx_ring->size() < 3) 
      {
	tf::Point Pnorm2 = -tf::Point(normals->points[idx_ring->at(0)].normal_x,normals->points[idx_ring->at(0)].normal_y,normals->points[idx_ring->at(0)].normal_z);
	return Pnorm2;
      }
      
//     ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   SAC plane");
//       pcl::SACSegmentationFromNormals<pcl::PointXYZ, pcl::Normal> seg; 
      pcl::SACSegmentation<pcl::PointXYZ> seg; 
      pcl::ModelCoefficients::Ptr coefficients_plane (new pcl::ModelCoefficients);
      pcl::PointIndices::Ptr inliers_plane (new pcl::PointIndices);
	
      seg.setOptimizeCoefficients (true);
      seg.setModelType (pcl::SACMODEL_PLANE);
      seg.setMethodType (pcl::SAC_RANSAC);
      seg.setMaxIterations (10);
//       seg.setEpsAngle(0.052);		// 3°
      seg.setDistanceThreshold (cup_lc.bend);		// plane deformation allowance
//       seg.setDistanceThreshold (0.0001);		// plane deformation allowance
      seg.setInputCloud (cloud);
//       seg.setInputNormals (normals);		//cloud_lN
      seg.setIndices(idx_ring);
      seg.segment (*inliers_plane, *coefficients_plane);
//     ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   SAC plane - fin");
    
//        std::cerr << "inliners: " << inliers_plane->indices.size() << "/"<< idx_ring->size() << std::endl;
      fitDeviation = (float) inliers_plane->indices.size()/idx_ring->size();
//       *idx_ring = inliers_plane->indices;
      tf::Point Pnorm = tf::Point(tf::Point(coefficients_plane->values[0],coefficients_plane->values[1],coefficients_plane->values[2]));
      tf::Point Pnorm2 = tf::Transform(v_tf_table2cupbase[0].getRotation(), v3_000) * (v3_001);
//       tf::Point Pnorm2 = tf::Point(normals->points[idx_ring->at(0)].normal_x,normals->points[idx_ring->at(0)].normal_y,normals->points[idx_ring->at(0)].normal_z);
      
      rz = tf::tfAngle(Pnorm, Pnorm2);
      if (rz>M_PI_2) 	{Pnorm = -Pnorm; rz = M_PI - rz; }
//       std::cout<< std::setprecision(5) << "Pnorm : " << Pnorm.x()<<" " << Pnorm.y()<<" " << Pnorm.z()<<" \n"; 
      return Pnorm;
    }
    
//     pcl::PointCloud<pcl::PointXYZ>::Ptr get_cloud_trsf_ring(pcl::PointXYZ P)    
//     {      return get_cloud_trsf_ring(P, cup_dim_);    }
    
//     pcl::PointCloud<pcl::PointXYZ>::Ptr get_cloud_trsf_ring(pcl::PointXYZ P, yf_vacuum_cups::cup_dim cup_lc)
//     {
//       pcl::IndicesPtr idx_ring = get_idx_ring(P, cup_lc);
//       tf::Transform tf_Znorm = get_tf_table2ring(idx_ring, cup_lc);
//       return get_cloud_trsf_ring(idx_ring);
//     }
// 
//     pcl::PointCloud<pcl::PointXYZ>::Ptr get_cloud_trsf_ring(pcl::IndicesPtr idx_ring, yf_vacuum_cups::cup_dim cup_lc)
//     {
//       tf::Transform tf_Znorm = get_tf_table2ring(idx_ring, cup_lc);
//       pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_ring (new pcl::PointCloud<pcl::PointXYZ>(*cloud, *(idx_ring)));
// 
//       pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_tfed (new pcl::PointCloud<pcl::PointXYZ>);
//       pcl_ros::transformPointCloud(*cloud_ring, *cloud_tfed, tf_Znorm.inverse());
//       return cloud_tfed;
//       
//     }
    
    
    pcl::PointCloud<pcl::PointXYZ>::Ptr get_cloud_allring() 
    {
      pcl::IndicesPtr idx_allring (new std::vector <int>);
      pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_allring (new pcl::PointCloud<pcl::PointXYZ>); 
//       ROS_INFO_STREAM("get_cloud_allring");
      if (v_cupOn[1])      idx_allring->insert( idx_allring->end(), v_idx_ring[1]->begin(), v_idx_ring[1]->end() );
      if (v_cupOn[2])      idx_allring->insert( idx_allring->end(), v_idx_ring[2]->begin(), v_idx_ring[2]->end() );
      if (v_cupOn[3])      idx_allring->insert( idx_allring->end(), v_idx_ring[3]->begin(), v_idx_ring[3]->end() );
      if (v_cupOn[4])      idx_allring->insert( idx_allring->end(), v_idx_ring[4]->begin(), v_idx_ring[4]->end() );
      pcl::copyPointCloud(*cloud, *idx_allring, *cloud_allring);    
//       ROS_INFO_STREAM("get_cloud_allring ---------");
      
      return cloud_allring;
    }    
        
};