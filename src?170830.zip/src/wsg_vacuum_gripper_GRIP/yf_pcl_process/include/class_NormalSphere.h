#include <cmath>
#include <limits>
#include <iostream>

#include <ros/ros.h>
#include <rosbag/bag.h>
#include <rosbag/view.h>

#include <visualization_msgs/Marker.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>

#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/project_inliers.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/search/search.h>
#include <pcl/search/kdtree.h>
#include <pcl/search/organized.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/features/integral_image_normal.h>
#include "pcl_ros/transforms.h"
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/extract_polygonal_prism_data.h>
#include <pcl/segmentation/region_growing.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl/surface/concave_hull.h>
#include <pcl/segmentation/organized_multi_plane_segmentation.h>
#include <pcl/segmentation/organized_connected_component_segmentation.h>
#include <pcl/segmentation/planar_region.h>
#include <pcl/segmentation/comparator.h>
#include <pcl/impl/point_types.hpp>

#include <tf/LinearMath/Vector3.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <tf_conversions/tf_eigen.h>

#include <Eigen/Core> 
#include <Eigen/Geometry> 
#include <Eigen/SVD>
#include <Eigen/Dense>

#include <yf_vacuum_cups/cup_dim.h>
#include <yf_vacuum_cups/srv_draw_cup.h>
#include <yf_vacuum_cups/msg_cup_draw.h>

// #include "class_yf_VacuumGripScene.h"

class NormalSphere// : public yf_VacuumGripScene
{  
  
  private:
    const float f_nan = NAN;
    const pcl::PointXYZ PointXYZ_nan = pcl::PointXYZ(NAN,NAN,NAN);
    const float rad2deg = 180/M_PI, deg2rad = M_PI/180;
    const tf::Point v3_000 = tf::Point(0,0,0);
    const tf::Point v3_100 = tf::Point(1,0,0);
    const tf::Point v3_010 = tf::Point(0,1,0);
    const tf::Point v3_001 = tf::Point(0,0,1);
    const tf::Quaternion q_u = tf::Quaternion(0,0,0,1);
    const tf::Transform tf_u = tf::Transform(q_u, v3_000);   
    
  public:
    
    yf_VacuumGripScene *V_Scene_lc;
    
    uint NSphere_binSize[11] = {1,6,12,18,24,28, 31, 34, 35, 36, 35}; // based on 2*pi*sin(phi)/10° 
    std::vector<uint> NSphere_binSizeSum {0,1,7,19,37,61,89,120,154,189,225,260};
    uint NSphere_binPhyMax = 6;	// x*10°, from 0°~75°, can be changed
    std::vector<float> NSphere_bin_count;		// normals belonging to bin(phi, theta)
    float NSphere_allsum = 0;
    std::vector<pcl::IndicesPtr> NSphere_bin_list;		// list of all points (idx) whose normals belonging to bin(phi, theta)
//     tf::Point NSphere_bin_coreV[260];	// unit vectors of the core of each bin // in table_frame
    std::vector<tf::Point> NSphere_bin_coreV;
    float NSphere_bin_center[260][2];	// bin(phi, theta)
    std::vector<uint> NSphere_bin_label;	// bin(label)
 

    ~NormalSphere()
    {};
    
    NormalSphere()
    {};
    
    NormalSphere(yf_VacuumGripScene *V_)
    {
//       this->cloud = V_.cloud;
//       this->normals = V_.normals;
//       this->cloud_with_normals = V_.cloud_with_normals;
//       this->cloud_border = V_.cloud_border;
//       this->cloud_inlander = V_.cloud_inlander;
//       this->idx_valid = V_.idx_valid;
//       this->idx_border = V_.idx_border;
//       this->idx_inlander = V_.idx_inlander;
// 
//       this->stf_Table2Tool = V_.stf_Table2Tool;
      V_Scene_lc = V_;
    };
  
    
    void init_NormalSphere()
    {
      NSphere_bin_count.resize(NSphere_binSizeSum[NSphere_binPhyMax+1],0.0);
      NSphere_bin_list.resize(NSphere_binSizeSum[NSphere_binPhyMax+1],pcl::IndicesPtr());
      NSphere_bin_label.resize(NSphere_binSizeSum[NSphere_binPhyMax+1],0);
      NSphere_bin_coreV.resize(NSphere_binSizeSum[NSphere_binPhyMax+1]);
      
      for (uint i = 0; i<= NSphere_binPhyMax; i++)
      {
	for (uint j = NSphere_binSizeSum[i]; j<NSphere_binSizeSum[i+1]; j++)
	{
	  NSphere_bin_center[j][0] = i*10.0*M_PI/180.0;
	  NSphere_bin_center[j][1] = 2.0*M_PI/NSphere_binSize[i]*(j-NSphere_binSizeSum[i]);
	}
	
      }

      for (uint i = 0; i<NSphere_binSizeSum[NSphere_binPhyMax+1]; i++)	// in table_frame
      {
	float phi = NSphere_bin_center[i][0], theta = NSphere_bin_center[i][1];
	NSphere_bin_coreV[i] = tf::Point(cos(theta)*sin(phi),sin(theta)*sin(phi),cos(phi));
      }
      
    }
    
    uint count_binNormalSphere(float phi10 , float theta, size_t Pid)
    {
    
	uint phi_ = floor(phi10);	// step, 
	float phi_b = phi10-phi_; float phi_a = 1-phi_b;	// weight for bin a and b
	//27° ~ 2, a:0.3->(20°), b:0.7->(30°)
	//2° ~ 0, a:0.8->(0°), b:0.2->(10°)
//   	ROS_INFO_STREAM(phi10<<" "<<phi_<<" "<<phi_a<<" "<<phi_b);
 	if(phi10 < NSphere_binPhyMax+0.5)	
	  NSphere_allsum += 1;

	if(phi_ == 0)	// -5°~5°, 5°~15°
	{
	  NSphere_bin_count[0] += phi_a;
// 	    ROS_INFO_STREAM(phi_a);
	  
	  float theta60 = (theta / 60.0);
	  uint theta_ = floor(theta60);	// 0,1,2,3,4,5
	  float theta_b = theta60-theta_; float theta_a = 1-theta_b;	// weight for bin a and b
	  NSphere_bin_count[1+theta_] += phi_b*theta_a;
	  NSphere_bin_count[1+(theta_+1)%6] += phi_b*theta_b;
// 	    ROS_INFO_STREAM(1+theta_<<" "<<phi_b*theta_a<<" "<<1+(theta_+1)%6<<" "<<phi_b*theta_b);
	  
// 	  binNSphere_list[0]->push_back(Pid);
	}
	else if (phi_ == NSphere_binPhyMax)	// largest phi 
	{
	  float thetaX = (theta / (360.0/NSphere_binSize[phi_]));
	  uint theta_ = floor(thetaX);	// binIndex 0,1,2,3,4,5....
	  float theta_b = thetaX-theta_; float theta_a = 1-theta_b;	// weight for bin a and b
	  NSphere_bin_count[NSphere_binSizeSum[phi_]+theta_] += theta_a;
	  NSphere_bin_count[NSphere_binSizeSum[phi_]+(theta_+1)%NSphere_binSize[phi_]] += theta_b;
	} 
	else	// 
	{
	  float thetaX = (theta / (360.0/NSphere_binSize[phi_]));
	  uint theta_ = floor(thetaX);	// binIndex 0,1,2,3,4,5
	  float theta_b = thetaX-theta_; float theta_a = 1-theta_b;	// weight for bin a and b
	  NSphere_bin_count[NSphere_binSizeSum[phi_]+theta_] += phi_a*theta_a;
	  NSphere_bin_count[NSphere_binSizeSum[phi_]+(theta_+1)%NSphere_binSize[phi_]] += phi_a*theta_b;
// 	    ROS_INFO_STREAM(theta60<<" "<<theta_<<" "<<theta_a<<" "<<theta_b);
	  
	  thetaX = (theta / (360.0/NSphere_binSize[phi_+1]));
	  theta_ = floor(thetaX);	// binIndex 0,1,2,3,4,5,..11
	  theta_b = thetaX-theta_; theta_a = 1-theta_b;	// weight for bin a and b
	  NSphere_bin_count[NSphere_binSizeSum[phi_+1]+theta_] += phi_b*theta_a;
	  NSphere_bin_count[NSphere_binSizeSum[phi_+1]+(theta_+1)%NSphere_binSize[phi_+1]] += phi_b*theta_b;
// 	    ROS_INFO_STREAM(theta30<<" "<<theta_<<" "<<theta_a<<" "<<theta_b);
	}
	

	
	return 1;
    }
    
    
    void calc_NormalSphere()
    {
      calc_NormalSphere(V_Scene_lc->normals);
    }
    
    void calc_NormalSphere(pcl::PointCloud<pcl::Normal>::ConstPtr normals_loc)
    {
      for (size_t i = 0; i < normals_loc->size() ; ++i)
      {
#if 0
	// use vector
	tf::Point N = tf::Point(normals->points[i].normal_x,normals->points[i].normal_y,normals->points[i].normal_z);
	
	float ang = pcl::rad2deg(tf::tfAngle(binNSphere_coreV[j],N));	// in degree : ang(°)
	if (ang>15)
	  break;
	else if (ang<5)
	  binNSphere_count += 1.0;
	else
#endif
	// use phi theta
// 	tf::Point N = tf::Point(normals->points[i].normal_x,normals->points[i].normal_y,normals->points[i].normal_z);
	float phi10 = acos(normals_loc->points[i].normal_z) *18/M_PI;				// in 10degree : (*10°) , mostly will point to negative in table_frame
// 	ROS_INFO_STREAM("~"<<phi10);
	if (isnan(phi10)||phi10>(NSphere_binPhyMax+0.5)) continue;
	float theta = atan2(normals_loc->points[i].normal_y,normals_loc->points[i].normal_x) *180/M_PI; // in degree : (°), -180°~180°
	if (theta<0) theta += 360;	// in degree : (°), 0°~360°
	
//   	ROS_INFO_STREAM(phi10<<" "<<theta);
	count_binNormalSphere(phi10, theta, i);
      }
      
    }    
    
    void calc_NormalSphere(const pcl::IndicesPtr normals_idx)
    {
//       ROS_INFO_STREAM("calc_NormalSphere~~"<<normals_idx->size());
      for (size_t ii = 0; ii < normals_idx->size() ; ++ii)
      {
	size_t i = normals_idx->at(ii);
#if 0
	// use vector
	tf::Point N = tf::Point(normals->points[i].normal_x,normals->points[i].normal_y,normals->points[i].normal_z);
	
	float ang = pcl::rad2deg(tf::tfAngle(binNSphere_coreV[j],N));	// in degree : ang(°)
	if (ang>15)
	  break;
	else if (ang<5)
	  binNSphere_count += 1.0;
	else
#endif
	// use phi theta
// 	tf::Point N = tf::Point(normals->points[i].normal_x,normals->points[i].normal_y,normals->points[i].normal_z);
	float phi10 = acos(V_Scene_lc->normals->points[i].normal_z) *18/M_PI;				// in 10degree : (*10°) , mostly will point to negative in table_frame
// 	ROS_INFO_STREAM("~"<<phi10);
	if (isnan(phi10)||phi10>(NSphere_binPhyMax+0.5)) continue;
	float theta = atan2(V_Scene_lc->normals->points[i].normal_y,V_Scene_lc->normals->points[i].normal_x) *180/M_PI; // in degree : (°), -180°~180°
	if (theta<0) theta += 360;	// in degree : (°), 0°~360°
	
//   	ROS_INFO_STREAM(phi10<<" "<<theta);
	count_binNormalSphere(phi10, theta, i);
      }
      
    }
    
    bool label_NormalSphere_bin(uint binN, uint current_label, float bigbin_pct, tf::Point &viewAng, int depth)	//return the block and list of all cloud inside
    {
//       std::cout<<binN <<" : ";
      if (depth < 0) return false;
      if (NSphere_bin_label[binN]!=0) 					return false;	// already registered
      if (NSphere_bin_count[binN]/NSphere_allsum < 0.1*bigbin_pct)	return false;	// is smaller than 5%
      if (NSphere_bin_count[binN]/NSphere_allsum < 0.7*bigbin_pct)	depth --;   
         
      NSphere_bin_label[binN] = current_label;
      viewAng = viewAng + NSphere_bin_coreV[binN]*NSphere_bin_count[binN];
      
      if (binN == 0)
      {
	label_NormalSphere_bin(1 , current_label, bigbin_pct, viewAng, depth);
	label_NormalSphere_bin(2 , current_label, bigbin_pct, viewAng, depth);
	label_NormalSphere_bin(3 , current_label, bigbin_pct, viewAng, depth);
	label_NormalSphere_bin(4 , current_label, bigbin_pct, viewAng, depth);
	label_NormalSphere_bin(5 , current_label, bigbin_pct, viewAng, depth);
	label_NormalSphere_bin(6 , current_label, bigbin_pct, viewAng, depth);
      }
      else
      {
	uint phi_ = std::upper_bound(NSphere_binSizeSum.begin(),NSphere_binSizeSum.end(), binN) - NSphere_binSizeSum.begin() -1;
	uint theta_ = binN - NSphere_binSizeSum[phi_];	float theta = (float)theta_ / NSphere_binSize[phi_];
 	
// 	std::cout<<binN <<' '<< phi_<<' '<< theta_<<" "<<NSphere_binSize[phi_]<<"\n";
	
	label_NormalSphere_bin(NSphere_binSizeSum[phi_]+(NSphere_binSize[phi_]+theta_-1)%NSphere_binSize[phi_], current_label, bigbin_pct, viewAng, depth);
	label_NormalSphere_bin(NSphere_binSizeSum[phi_]+(theta_+1)%NSphere_binSize[phi_], current_label, bigbin_pct, viewAng, depth);
	theta_ = floor(theta * NSphere_binSize[phi_-1]); 
	label_NormalSphere_bin(NSphere_binSizeSum[phi_-1]+(theta_)%NSphere_binSize[phi_-1], current_label, bigbin_pct, viewAng, depth);
	theta_ = ceil(theta * NSphere_binSize[phi_-1]); 
	label_NormalSphere_bin(NSphere_binSizeSum[phi_-1]+(theta_)%NSphere_binSize[phi_-1], current_label, bigbin_pct, viewAng, depth);
	theta_ = floor(theta * NSphere_binSize[phi_+1]);
	label_NormalSphere_bin(NSphere_binSizeSum[phi_+1]+(theta_)%NSphere_binSize[phi_+1], current_label, bigbin_pct, viewAng, depth);
	theta_ = ceil(theta * NSphere_binSize[phi_+1]);
	label_NormalSphere_bin(NSphere_binSizeSum[phi_+1]+(theta_)%NSphere_binSize[phi_+1], current_label, bigbin_pct, viewAng, depth);
	
      }

      return true;
    }
    
    uint get_clusterNormalSphere ()	// returns where most normals point towards
    {
      std::cout << "\033[01m""cluster""\033[0m"<<std::endl;
      std::vector<int> binNSphere_count_sort(NSphere_bin_count.size());
      std::size_t n(0);
      std::generate(std::begin(binNSphere_count_sort), std::end(binNSphere_count_sort), [&]{ return n++; });
      
      std::sort(  std::begin(binNSphere_count_sort), 
		  std::end(binNSphere_count_sort),
		  [&](int i1, int i2) { return NSphere_bin_count[i1] > NSphere_bin_count[i2]; } );    
      
      
      float bigbin_pct = NSphere_bin_count[binNSphere_count_sort[0]]/NSphere_allsum;
      float threadhold_expand  = 0.1 * bigbin_pct;
      float threadhold_cound_as_root = std::max(0.05, 1.5*threadhold_expand);
      
      
      float binSum_tmp = 0.0;
      uint bin83 = 0;
      for (bin83 = 0; bin83<binNSphere_count_sort.size(); bin83++)
      {
	uint v = binNSphere_count_sort[bin83];
	float portion = NSphere_bin_count[v]/NSphere_allsum;
	binSum_tmp += portion;
	if (portion< threadhold_cound_as_root) break;		// break if grow too slow (4% or less)
	
	std::cout<< std::fixed << std::setprecision(2)<<"\033[1m""   bin."<< v << "\tcount = "<<NSphere_bin_count[v] <<" ~ "<<binSum_tmp*100<<"%   \tphi = "<<NSphere_bin_center[v][0]*180/M_PI<<"\ttheta = "<<NSphere_bin_center[v][1]*180/M_PI<<"\033[0m""\n";
	if (binSum_tmp > 0.95) break;
      }
//       binNSphere_count_sort.erase(binNSphere_count_sort.begin()+bin83,binNSphere_count_sort.end());
      // sort all bins
      
      V_Scene_lc->NSphere_viewAngles = {tf::Point(0,0,1)};
      V_Scene_lc->NSphere_viewAngles_stf = { tf::StampedTransform(tf::Transform(q_u, -1 * v3_001), ros::Time::now(), "/table_frame", "/PjPl/0")};
      
      
      
      
      uint labelX = 1;
      /*
      for (uint i = 0; i < bin83; i++)		// larger angle tolorrance, lower demand for expanding
      {
	tf::Point viewAng = tf::Point(0,0,0);
	if (label_NormalSphere_bin(binNSphere_count_sort[i],labelX, bigbin_pct, viewAng,10)) 	
	{
	  std::cout<<"view "<<labelX<<" : "<<binNSphere_count_sort[i]<<"\n";
	  	  
	  viewAng.normalize();
	  NSphere_viewAngles.push_back(viewAng);
	  
	  float phi = asin(viewAng.z()), theta = atan2(viewAng.y(),viewAng.x()); 
	  tf::Transform oA (tf::Quaternion(tf::Vector3(0,0,1), theta) * tf::Quaternion(tf::Vector3(0,1,0), 1.5*M_PI-phi) , viewAng);
	  NSphere_viewAngles_stf.push_back( tf::StampedTransform(oA, ros::Time::now(), "/table_frame", "/PjPl/" + std::to_string(labelX)) );
	  
	  
	  labelX++;
	}
      }
      for (uint bb = 0; bb < NSphere_bin_label.size(); bb++) 	NSphere_bin_label[bb] = 0; 
      */
      for (uint i = 0; i < bin83; i++)		// smaller angle tolorrance, higher demand expanding
      {
	tf::Point viewAng = tf::Point(0,0,0);
	if (label_NormalSphere_bin(binNSphere_count_sort[i],labelX, bigbin_pct, viewAng,2)) 
	{
	  std::cout<<"view "<<labelX<<" : "<<binNSphere_count_sort[i]<<"\n";
	  	  
	  viewAng.normalize();
	  V_Scene_lc->NSphere_viewAngles.push_back(viewAng);
	  
	  float phi = asin(viewAng.z()), theta = atan2(viewAng.y(),viewAng.x()); 
	  tf::Transform oA (tf::Quaternion(tf::Vector3(0,0,1), theta) * tf::Quaternion(tf::Vector3(0,1,0), 1.5*M_PI-phi) , viewAng);
	  V_Scene_lc->NSphere_viewAngles_stf.push_back( tf::StampedTransform(oA, ros::Time::now(), "/table_frame", "/PjPl/" + std::to_string(labelX)) );
	  
	  
	  labelX++;
	}
	
      }
      
      return 0;
    }
            
    void save_viewAngles(yf_VacuumGripScene *V_)
    {
      V_->NSphere_viewAngles = V_Scene_lc->NSphere_viewAngles;
      V_->NSphere_viewAngles_stf = V_Scene_lc->NSphere_viewAngles_stf;
    }
    

     void draw_NormalSphere(std::vector<visualization_msgs::Marker> &arraw)
    {     
//       ROS_INFO_STREAM("draw_NormalSphere") ;
      
      float r1 = 0.07, r2 = 0.08;
      
      for (uint i = 0; i<NSphere_bin_count.size(); i++)
      {
	visualization_msgs::Marker arrawX;
	arrawX.header.frame_id = "/table_frame";
	arrawX.header.stamp 	= ros::Time::now();
	arrawX.ns  = "NormalSphere";
	arrawX.action = visualization_msgs::Marker::ADD;
	arrawX.id = i;
	arrawX.type = visualization_msgs::Marker::ARROW;
	arrawX.scale.x = 0.002;	arrawX.scale.y = 0.004;		arrawX.scale.z = 0.0;
	if (NSphere_bin_count[i] < 10) 
	  {	arrawX.color.r = 0.5;	arrawX.color.g = 0.5;	arrawX.color.b = 0.5;	arrawX.color.a = 0.3;}
	else if (NSphere_bin_label[i] == 0)
	  {	arrawX.color.r = 0.8;	arrawX.color.g = 0.8;	arrawX.color.b = 0.8;	arrawX.color.a = 0.8;}
	else if (NSphere_bin_label[i] == 1)
	  {	arrawX.color.r = 1;	arrawX.color.g = 0.5;	arrawX.color.b = 0.5;	arrawX.color.a = 0.8;}
	else if (NSphere_bin_label[i] == 2)
	  {	arrawX.color.r = 1;	arrawX.color.g = 1;	arrawX.color.b = 0.4;	arrawX.color.a = 0.8;}
	else if (NSphere_bin_label[i] == 3)
	  {	arrawX.color.r = 0.5;	arrawX.color.g = 1;	arrawX.color.b = 0.5;	arrawX.color.a = 0.8;}
	else if (NSphere_bin_label[i] == 4)
	  {	arrawX.color.r = 0.5;	arrawX.color.g = 0.5;	arrawX.color.b = 1;	arrawX.color.a = 0.8;}
	else
	  {	arrawX.color.r = 1;	arrawX.color.g = 0.4;	arrawX.color.b = 1;	arrawX.color.a = 0.8;}
	
	geometry_msgs::Point Pzero;
	Pzero.x = Pzero.y = Pzero.z = 0;
	geometry_msgs::Point N0;
	N0.x=NSphere_bin_coreV[i].x()*r1; N0.y=NSphere_bin_coreV[i].y()*r1; N0.z=NSphere_bin_coreV[i].z()*r1;
	
	
	r2 = 0.000 + 0.04*NSphere_bin_count[i]/(*std::max_element(NSphere_bin_count.begin(), NSphere_bin_count.end()));
	geometry_msgs::Point N1;
	N1.x=NSphere_bin_coreV[i].x()*r2+N0.x; N1.y=NSphere_bin_coreV[i].y()*r2+N0.y; N1.z=NSphere_bin_coreV[i].z()*r2+N0.z;
	
	arrawX.points.push_back(N0);    
	arrawX.points.push_back(N1); 
	arraw.push_back(arrawX);
      }
    }
                   
};
