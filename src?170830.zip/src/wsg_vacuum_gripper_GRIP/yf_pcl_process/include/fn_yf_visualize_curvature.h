#include <ros/ros.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>

void yf_visualize_curvature(pcl::PointCloud<pcl::PointXYZ>::ConstPtr cloud_in_xyz, pcl::PointCloud<pcl::Normal>::ConstPtr cloud_in_norm, pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_out_xyzi)
{
//  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   visualizing curvature - ");
//    pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_with_I (new pcl::PointCloud<pcl::PointXYZI>);
  cloud_out_xyzi->resize(cloud_in_xyz->size ());
  cloud_out_xyzi->height = cloud_in_xyz->height;
  cloud_out_xyzi->width = cloud_in_xyz->width;
  cloud_out_xyzi->header = cloud_in_xyz->header;
    for (size_t i = 0; i < cloud_in_xyz->size (); ++i)
    {
      pcl::PointXYZI ptxyzrgb;
      ptxyzrgb.x = cloud_in_xyz->points[i].x; ptxyzrgb.y = cloud_in_xyz->points[i].y; ptxyzrgb.z = cloud_in_xyz->points[i].z;
      ptxyzrgb.intensity = (cloud_in_norm->points[i].curvature);
      cloud_out_xyzi->points[i]=(ptxyzrgb);
    }
//  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   visualizing curvature - fin");    
}