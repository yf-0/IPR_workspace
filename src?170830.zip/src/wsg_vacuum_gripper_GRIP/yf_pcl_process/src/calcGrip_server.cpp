#include <cmath>
#include <limits>
#include <iostream>
#include <typeinfo>
#include <iomanip>
#include <ctime>

#include <ros/ros.h>
#include <rosbag/bag.h>
#include <rosbag/view.h>

#include <visualization_msgs/Marker.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>

#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>

#include <tf/LinearMath/Vector3.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <tf_conversions/tf_eigen.h>

#include <yf_vacuum_cups/cup_dim.h>
#include <yf_vacuum_cups/srv_draw_cup.h>
#include <yf_vacuum_cups/msg_cup_draw.h>
#include <yf_pcl_process/msg_Grip.h>
#include <yf_pcl_process/srv_get_avgPC.h>
#include <yf_pcl_process/srv_get_GRIPS.h> 

#include <class_yf_VacuumGripScene.h>
#include <class_NormalSphere.h>
#include <class_nominate.h>
#include <class_maneuverGrip.h>
#include <fn_yf_visualize_curvature.h>

#include <yf_movements/act_MoveTowardSuctionAction.h>
#include <actionlib/client/simple_action_client.h>
#include <actionlib/client/terminal_state.h>

#include <boost/thread.hpp>


#include "static_pointcloud_publisher_wrap.h"



// void spinThread()
// {
//   ros::spin();
// }

ros::Time RosTimeBegin ;
ros::Time RosTimeLast ;

tf::StampedTransform STF_Flange2Sensor;
tf::StampedTransform STF_World2Table;

void printTime_startnew(std::string str = "")
{
  ros::Time now = ros::Time::now();
  std::cout << std::fixed << std::setprecision(2)<<"\033[01m[" << (now-RosTimeBegin).toSec() << "s]:  "<< (now-RosTimeLast).toSec()*1000 <<"ms\033[0m   "<<str;
  RosTimeLast = now;
}

void printTime(std::string str = "")
{
  ros::Time now = ros::Time::now();
  std::cout << std::fixed << std::setprecision(2)<<"\033[0m[" << (now-RosTimeBegin).toSec() << "s]:  "<< (now-RosTimeLast).toSec()*1000 <<"ms\033[0m   "<<str;
}

bool calcGrip_Srv (yf_pcl_process::srv_get_GRIPS::Request &req, yf_pcl_process::srv_get_GRIPS::Response  &res)
{
  std::cout <<"\033[1m\033[96m" << "/////////////  calcGrip_Srv called with parameters: /////////////"<<"\033[0m" "\n";
  std::cout <<"\033[1m\033[96m" << req << "\033[0m";
  std::cout <<"\033[1m\033[96m" << "/////////////////////////////////////////////////////////////////"<<"\033[0m" "\n";
  
  /////////////////////////////////////////////////////////////
  
  float curvature_limit = req.curvature_limit;
  if (curvature_limit < 0) curvature_limit = 0.001;
  
  
  ros::NodeHandlePtr nh = boost::make_shared<ros::NodeHandle>();
  
//  
  static tf::TransformBroadcaster br;

  
  ros::Publisher pub_visCM = nh->advertise<visualization_msgs::Marker>( "/scene/vis/CM", 2 );
  ros::Publisher pub_visNS = nh->advertise<visualization_msgs::Marker>( "/scene/vis/NS", 260 );
  ros::Publisher pub_visNSPP = nh->advertise<visualization_msgs::Marker>( "/scene/vis/NSPP", 20 );
  
  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZ>);
 
  RosTimeBegin = ros::Time::now();
  RosTimeLast = ros::Time::now();
  
  std::string filename (std::to_string(ros::Time::now().sec));
  if (1) 
  {    
    ros::ServiceClient client = nh->serviceClient<yf_pcl_process::srv_get_avgPC>("/srv_get_avgPC");

    yf_pcl_process::srv_get_avgPC srvD;
    srvD.request.caller = 7;
    
    if (client.call(srvD))
    {
      ROS_INFO("called current Scene as Point Cloud");
      pcl::moveFromROSMsg(srvD.response.avg_cloud, *cloud); 	
      std::cout << "cloud->size(): " << cloud->height <<" * "<< cloud->width <<"\n";
    }
    else
    {
      ROS_ERROR("Failed to call up current Scene as Point Cloud");
      return 1;
    }
  }
//     pcl::io::savePCDFileASCII (filename+"_p.pcd", *cloud);
  printTime_startnew("acquied point cloud - \n");

  static_PointCloud_publish("~", cloud);    
  static_PointCloud_publish("/scene/cloud_org", cloud);
  
  //////////////////////////////////////////////////////////////////////////////////////

    yf_VacuumGripScene *Vtmp( new yf_VacuumGripScene(cloud) );
  printTime_startnew("set up scene - fin\n");

  //////////////////////////////////////////////////////////////////////////////////////

    if ( req.update_Transforms )
    {
      Vtmp->wait_get_stf_Flange2Sensor(*nh, 7);
      if (Vtmp->if_exist_stf_Flange2Sensor) 
      {
	STF_Flange2Sensor = Vtmp->stf_Flange2Sensor;
	std::cout << "\033[1m" "got robot stf: stf_Flange2Sensor =\n" "\033[0m";
	std::cout << std::fixed << std::setprecision(4) << "\033[0m""    { (" << STF_Flange2Sensor.getOrigin().x()<<", "<< STF_Flange2Sensor.getOrigin().y()<<", "<< STF_Flange2Sensor.getOrigin().z()<<"), ("
		  << STF_Flange2Sensor.getRotation().x()<<", "<< STF_Flange2Sensor.getRotation().y()<<", "<< STF_Flange2Sensor.getRotation().z()<< " | "<< STF_Flange2Sensor.getRotation().w()<<") }\n" "\033[0m";

      }
      else
      {
	ROS_ERROR("unable to determine sensor pose --------- exit");
	return 0;
      }
    }
    else
    {
      Vtmp->set_stf_Flange2Sensor(STF_Flange2Sensor);
      std::cout <<"\033[94m" "use previous stf_Flange2Sensor\n" "\033[0m";
      std::cout << std::fixed << std::setprecision(4) << "\033[34m""    { (" << STF_Flange2Sensor.getOrigin().x()<<", "<< STF_Flange2Sensor.getOrigin().y()<<", "<< STF_Flange2Sensor.getOrigin().z()<<"), ("
		  << STF_Flange2Sensor.getRotation().x()<<", "<< STF_Flange2Sensor.getRotation().y()<<", "<< STF_Flange2Sensor.getRotation().z()<< " | "<< STF_Flange2Sensor.getRotation().w()<<") }\n" "\033[0m";

    }
    
    
    Vtmp->wait_get_stf_World2Flange(*nh, 7);
    if (Vtmp->if_exist_stf_World2Flange) 
    {
      std::cout << "\033[1m" "got robot stf: stf_World2Flange =\n" "\033[0m";
      std::cout << std::fixed << std::setprecision(4) << "\033[0m""    { (" << Vtmp->stf_World2Flange.getOrigin().x()<<", "<< Vtmp->stf_World2Flange.getOrigin().y()<<", "<< Vtmp->stf_World2Flange.getOrigin().z()<<"), ("
		<< Vtmp->stf_World2Flange.getRotation().x()<<", "<< Vtmp->stf_World2Flange.getRotation().y()<<", "<< Vtmp->stf_World2Flange.getRotation().z()<< " | "<< Vtmp->stf_World2Flange.getRotation().w()<<") }\n" "\033[0m";

    }
    else
    {
      ROS_ERROR("unable to determine robot pose --------- exit");
      return 0;
    }
  ////////////////////////
    
    tf::Point N_table; float d_table;
    if ( req.update_Transforms )
    {   
      Vtmp->wait_get_stf_World2Table(*nh, 7);
      if (Vtmp->if_exist_stf_World2Table)
      {
	ROS_INFO("Determined table from model ");
	STF_World2Table = Vtmp->stf_World2Table;
	std::cout << "\033[1m" "got robot stf: stf_World2Table =\n" "\033[0m";
	std::cout << std::fixed << std::setprecision(4) << "\033[0m""    { (" << STF_World2Table.getOrigin().x()<<", "<< STF_World2Table.getOrigin().y()<<", "<< STF_World2Table.getOrigin().z()<<"), ("
		  << STF_World2Table.getRotation().x()<<", "<< STF_World2Table.getRotation().y()<<", "<< STF_World2Table.getRotation().z()<< " | "<< STF_World2Table.getRotation().w()<<") }\n" "\033[0m";
      }
      else
      {
	ROS_ERROR("unable to determine table from model --------- exit");
	tf::Transform tf_W2T_g (Vtmp->q_u, tf::Point(0.8200, -0.2500, 0.7060));
	Vtmp->set_Tf_World2Table(tf_W2T_g);
      }
    }
    else
    {
      Vtmp->set_stf_World2Table(STF_World2Table);
      std::cout <<"\033[94m" "use previous stf_World2Table" "\033[0m" "\n";
      std::cout << std::fixed << std::setprecision(4) << "\033[34m""    { (" << STF_World2Table.getOrigin().x()<<", "<< STF_World2Table.getOrigin().y()<<", "<< STF_World2Table.getOrigin().z()<<"), ("
		  << STF_World2Table.getRotation().x()<<", "<< STF_World2Table.getRotation().y()<<", "<< STF_World2Table.getRotation().z()<< " | "<< STF_World2Table.getRotation().w()<<") }\n" "\033[0m";
    }
    
    if (Vtmp->if_exist_stf_World2Table && Vtmp->if_exist_stf_World2Flange)
    {
      std::cout<<"\033[94m" "use gloable table" "\033[0m" << "\n";
      if (Vtmp->if_exist_stf_Flange2Sensor)
      {
	Vtmp->set_Tf_Sensor2Table();
      }
    }
    else
    {
      Vtmp->get_Table_SAC(N_table, d_table);
      std::cout<< "\033[93m" "use local table from camera\n" "\033[0m";
      Vtmp->set_Tf_Sensor2Table(N_table, d_table);
      std::cout<<"reset_Tf_Sensor2Table\n";
    }   
    
    br.sendTransform(Vtmp->stf_x2Table);
    
  printTime_startnew("acquire transforms in scene - fin\n");
    
  //////////////////////////////////////////////////////////////////////////////////////
  
    Vtmp->set_table_trim_offset(0.005f);  	// 3cm above table
    float an = 0.0, rr = 0.08;
    while (rr < 0.4)
    {
      int xx = floor((rr*cos(an)+0.5) * Vtmp->cloud->width);
      int yy = floor((rr*sin(an)+0.5) * Vtmp->cloud->height);
      
//       ROS_INFO_STREAM(rr<<"-"<<pcl::rad2deg(an) << "    " << xx<<"-" << yy);
//       if (Vtmp->label_object_onTable_cam(xx,yy,1))       		{break;};
      if (Vtmp->label_object_onTable_global_2(xx,yy,1) > 10000)
      {
	printTime("trim - one valid object found!\n");
	break;
      }  
      else if (Vtmp->label_object_onTable_global_2(xx,yy,1) > 1)       		
      {
	printTime("trim - one object found, but too small ...\n");
      }    
//       if (Vtmp->label_object_regardlessTable(xx,yy,1)) 	{};

//       an += M_PI_4;
//       if (an > 2 * M_PI) {rr += 0.1; an = 0.001; }
      rr += 0.01;
      an += 0.125 * M_PI;
    }
    
  printTime("trim - all labeled ...\n");
  
    if (!Vtmp->trim_cloud_label())
    {
      ROS_ERROR_STREAM("fail to extract object");
//       return 0;
      std::cout <<"\033[96m" "cloud contains " << Vtmp->cloud->size() << " points" << "\033[0m" <<"\n";
    }
  printTime_startnew("trim - fin\n");
  //////////////////////////////////////////////////////////////////////////////////////
    
#if 0
    bool relocated = Vtmp->relocateCloud_to_World_and_GlobalTABLE(false);
    if (!relocated) Vtmp->relocateCloud_toTableFrame(false); 
#else
    Vtmp->relocateCloud_toTableFrame(false);
//     ROS_INFO_STREAM("relocated "<< Vtmp->cloud->size() << " points");
//     ROS_WARN_STREAM("new 'sensor_origin_' is "<< Vtmp->cloud->sensor_origin_ << "");
#endif
  printTime_startnew("relocate - fin\n");
  //////////////////////////////////////////////////////////////////////////////////////
  
    Vtmp->calc_norm();
  printTime_startnew("calculate normal - fin\n");
  //////////////////////////////////////////////////////////////////////////////////////
  
#if 1
  {
//   ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   visualizing curvature - ");
    pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_with_I (new pcl::PointCloud<pcl::PointXYZI>);
    yf_visualize_curvature((Vtmp->cloud), Vtmp->normals, cloud_with_I);   
    static_PointCloud_publish_tf("/scene/cloud_with_I", cloud_with_I, Vtmp->stf_x2Table);
  printTime_startnew("visualizing curvature - fin\n");
  }
  //////////////////////////////////////////////////////////////////////////////////////
#endif  

    Vtmp->calc_massCenter();
  printTime_startnew("calculate Mass Center - fin\n");
  //////////////////////////////////////////////////////////////////////////////////////

  if (req.cup_name.data == "FSG_18_HT1_60_M5_AG")
    Vtmp->setCupDim(11);
  else if (req.cup_name.data == "FSGA_25_NK_45_M5_AG")
    Vtmp->setCupDim(12);
  else if (req.cup_name.data == "FSG_20_NK_45_M5_AG")
    Vtmp->setCupDim(13);
  else
    Vtmp->setCupDim(3);
  //     Vtmp->setCupDim1234(1,2,3,7);	// set each cup seperately
    float borderMargin = Vtmp->cup_dim_.radius + 0.001;	// margin from border
    {
      int inlander_count = Vtmp->calc_border_inlander(curvature_limit, borderMargin);	// curvature limit, radius of remove
      if (inlander_count < 1000) 
      {
	ROS_ERROR_STREAM("cloud doesn't contain enough points to work with!!");
// 	return 0;
	ros::spin();
      }
    }
  printTime_startnew("calc border & inlander - fin\n");
  static_PointCloud_publish_tf("/scene/cloud_inlander", Vtmp->cloud_inlander, Vtmp->stf_x2Table);
  static_PointCloud_publish_tf("/scene/cloud_border", Vtmp->get_cloud_border(), Vtmp->stf_x2Table);
    
  //////////////////////////////////////////////////////////////////////////////////////
    
    NormalSphere NS(Vtmp);
    NS.init_NormalSphere();
    NS.calc_NormalSphere(NS.V_Scene_lc->idx_inlander);
    NS.get_clusterNormalSphere();
    NS.save_viewAngles(Vtmp);
    
  printTime_startnew("calculate NormalSphere - fin\n");
  
  //////////////////////////////////////////////////////////////////////////////////////
    
//   ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   projection - fin");
    
    Vtmp->init_v_stf_Tool2CupBases();
    std::vector< yf_pcl_process::msg_Grip > v_grip_nominees;
    
    nominate nM(Vtmp);
    nM.nominate__get_v_grip_nominees_Rect_all_cfgY(req.cfgY, req.cfgX_min, req.cfgX_max, v_grip_nominees);
//     nM.nominate__get_v_grip_nominees_matchPattern_all_cfgY(req.cfgY, req.cfgX_min, req.cfgX_max, v_grip_nominees);	// not finished yet
    
    nM.save_viewAngles(Vtmp);
  printTime_startnew("calc rect - fin\n");
    
     pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_pj1 (new pcl::PointCloud<pcl::PointXYZ>);
     if (nM.get_ProjectplainMapPcl(1,cloud_pj1, M_PI/180*30))
       static_PointCloud_publish_tf("/scene/cloud_pjpl/1", cloud_pj1, Vtmp->NSphere_viewAngles_stf[1], "/PjPl/1");
     
     if (nM.get_ProjectplainMapPcl(2,cloud_pj1, M_PI/180*30))
       static_PointCloud_publish_tf("/scene/cloud_pjpl/2", cloud_pj1, Vtmp->NSphere_viewAngles_stf[2], "/PjPl/2");
     
     if (nM.get_ProjectplainMapPcl(3,cloud_pj1, M_PI/180*30))
       static_PointCloud_publish_tf("/scene/cloud_pjpl/3", cloud_pj1, Vtmp->NSphere_viewAngles_stf[3], "/PjPl/3");
//     pcl::io::savePCDFileASCII ("cloud_pj1.pcd", *cloud_pj1);
        
  printTime_startnew("calc rect - visualize\n");
  //////////////////////////////////////////////////////////////////////////////////////
  printTime_startnew("sim - start \n");
  
  maneuverGrip mG(Vtmp);
  
  mG.set_v_stf_Tool2CupBases_tfBase0(Vtmp->tf_u);	// a ramdom configuration of gripper
  
//   mG.set_MsgGrip(v_grip_nominees[0]);
  
  
  std::vector< maneuverGrip::Grip_Perform > v_Grip_perform {};
//    maneuverGrip::Grip_Perform Grip_optimized (v_grip_nominees[iii]);
  uint further;
  for (uint i_nominees = 0; i_nominees < v_grip_nominees.size(); i_nominees++)
  {
    v_Grip_perform.push_back(v_grip_nominees[i_nominees]);
//     mG.print_Grip_Perform(v_Grip_perform.back());
  }

  //////////////////////////////////////////////////////////////////////////////////////
    
   ros::Duration r(1);
  
  res.v_scores = {0};
  int idx_best_grip = 0;
   
  for (int i_nominees = 0; i_nominees < v_grip_nominees.size(); i_nominees++)
  {
    
    std::cout << "\033[95m" "try_Grip_get_Perform" "\033[0m" << "\n";
    mG.print_MsgGrip(v_Grip_perform[i_nominees].grip);
    mG.try_Grip_get_Perform(v_Grip_perform[i_nominees]);
//     mG.print_Grip_Perform(v_Grip_perform[i_nominees]);
    static_PointCloud_publish_tf("/scene/cloud_allring", mG.get_cloud_allring(), Vtmp->stf_x2Table);

    int maneuvers_min = req.maneuvers_max - req.maneuvers_min;
    if (req.maneuvers_max < req.maneuvers_min) maneuvers_min = 0;
    
    for (int maneuver_counter = req.maneuvers_max; ros::ok() && maneuver_counter > 0; maneuver_counter --)
    {
      std::cout << "\n\n";
      printTime_startnew();
//	std::cout << "\033[1m\033[95m" " ===================== optimize_GD_ADAM =====================" "\033[0m" << "\n";
//      mG.optimize_GD_ADAM(v_Grip_perform[i_nominees], v_Grip_perform[i_nominees], 1);
      std::cout << "\033[1m\033[95m" " =================== optimize_GD_ordinary ===================" "\033[0m" << "\n";
      mG.optimize_GD_ordinary(v_Grip_perform[i_nominees], v_Grip_perform[i_nominees], 1);
  
      std::cout << "\033[95m" "try_Grip_get_Perform" "\033[0m" << "\n";
      mG.try_Grip_get_Perform(v_Grip_perform[i_nominees]);
      mG.print_Grip_Perform(v_Grip_perform[i_nominees]);

      static_PointCloud_publish_tf("/scene/cloud_allring", mG.get_cloud_allring(), Vtmp->stf_x2Table);
	
	

      if (v_Grip_perform[i_nominees].score < 0)
      {
	maneuver_counter *= 0.3;
      }
      
      if (v_Grip_perform[i_nominees].score > 0.9 && maneuver_counter <= maneuvers_min)
      {
	maneuver_counter = 0;
      }
      
      ///////////// 
      
//       Vtmp->stf_x2Table.stamp_ =  ros::Time::now();
//       br.sendTransform(Vtmp->stf_x2Table);
      
      visualization_msgs::Marker CM_outputt;
      Vtmp->draw_CenterOfMass(CM_outputt);
	  CM_outputt.header.stamp 	= ros::Time::now();
	  pub_visCM.publish(CM_outputt);
	  
      std::vector<visualization_msgs::Marker> arraw_outputt;
      NS.draw_NormalSphere(arraw_outputt);
	for (uint i = 0; i<arraw_outputt.size(); i++)
	{
	  arraw_outputt[i].header.stamp 	= ros::Time::now();
	  pub_visNS.publish(arraw_outputt[i]);
	}
      
      std::vector<visualization_msgs::Marker> projectionPlain_outputt;
      Vtmp->draw_NormalSphere_projection(projectionPlain_outputt);
	for (uint i = 0; i<projectionPlain_outputt.size(); i++)
	{
	  Vtmp->NSphere_viewAngles_stf[i+1].stamp_ 	= ros::Time::now();
	  br.sendTransform(Vtmp->NSphere_viewAngles_stf[i+1]);
	
	  projectionPlain_outputt[i].header.stamp 	= ros::Time::now();
	  pub_visNSPP.publish(projectionPlain_outputt[i]);
	}   
	
	/////////////////
//       r.sleep();
    
  // //     ros::spinOnce();
    }
      
    if (v_Grip_perform[i_nominees].score > 0.30)
    {
      res.v_grips.push_back(v_Grip_perform[i_nominees].grip);
      
      if (idx_best_grip > 0)
	if (v_Grip_perform[i_nominees].score > v_Grip_perform[idx_best_grip].score)
	{
	  idx_best_grip = i_nominees;
	}
      else
      {
	idx_best_grip = 0;
      }
    }    
//     else if (v_Grip_perform[i_nominees].score < 0)
//     {
//       v_Grip_perform.erase(v_Grip_perform.begin() + i_nominees);
//       i_nominees--;
//     }


   if (req.order == 101 || req.order == 31) break;
  }
    std::cout << "\n" <<"\033[92m" << res.v_grips.size() << " candidates of grip" << "\033[0m" << "\n";
    ROS_INFO("published _ all finished");
//   
    ////////////////////////////////////////////// shall rank and pick the best one
//     std::sort(res.v_grips.begin(), res.v_grips.end(), [](int a, int b) {
//         return a.score > b.score;   
//     });
    ////////////////////////////////////////////// shall rank and pick the best one
    
    ////////////////////////////////////////////// lazy, here shall be more careful about processing other grips
//     res.v_grips = {v_Grip_perform[0].grip};
//     res.v_scores = {v_Grip_perform[0].score};
    res.v_grips = {v_Grip_perform[idx_best_grip].grip};
    res.v_scores = {v_Grip_perform[idx_best_grip].score};
  return 1;
}

int
main (int argc, char** argv)
{
  std::cerr << "using calcGrip_server" << std::endl;
  ros::init (argc, argv, "calc_Grip", ros::init_options::AnonymousName);
  ros::NodeHandlePtr nh = boost::make_shared<ros::NodeHandle>();
    
  ros::ServiceServer calcGrip = nh->advertiseService("/srv_CalcGrip", calcGrip_Srv);
    
        
  ros::spin();
  
  return (0);
}
