#include <cmath>
#include <limits>
#include <iostream>
#include <typeinfo>
#include <iomanip>
#include <ctime>

#include <ros/ros.h>
#include <rosbag/bag.h>
#include <rosbag/view.h>

#include <visualization_msgs/Marker.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>

#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>
// #include <pcl/filters/extract_indices.h>
// #include <pcl/filters/project_inliers.h>
// #include <pcl/filters/voxel_grid.h>
// #include <pcl/search/search.h>
// #include <pcl/search/kdtree.h>
// #include <pcl/search/organized.h>
// #include <pcl/filters/extract_indices.h>
// #include <pcl/features/integral_image_normal.h>
// #include "pcl_ros/transforms.h"
// #include <pcl/segmentation/sac_segmentation.h>
// #include <pcl/segmentation/extract_polygonal_prism_data.h>
// #include <pcl/segmentation/region_growing.h>
// #include <pcl/sample_consensus/method_types.h>
// #include <pcl/sample_consensus/model_types.h>
// #include <pcl/filters/statistical_outlier_removal.h>
// #include <pcl/surface/concave_hull.h>
// #include <pcl/segmentation/organized_multi_plane_segmentation.h>
// #include <pcl/segmentation/organized_connected_component_segmentation.h>
// #include <pcl/segmentation/planar_region.h>
// #include <pcl/segmentation/comparator.h>
// #include <pcl/impl/point_types.hpp>

#include <tf/LinearMath/Vector3.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <tf_conversions/tf_eigen.h>

// #include <Eigen/Core> 
// #include <Eigen/Geometry> 
// #include <Eigen/SVD>
// #include <Eigen/Dense>

#include <yf_vacuum_cups/cup_dim.h>
#include <yf_vacuum_cups/srv_draw_cup.h>
#include <yf_vacuum_cups/msg_cup_draw.h>
#include <yf_pcl_process/msg_Grip.h>
#include <yf_pcl_process/srv_get_avgPC.h>

#include "class_yf_VacuumGripScene.h"
#include "class_NormalSphere.h"
#include "class_nominate.h"
#include "class_maneuverGrip.h"
#include "fn_yf_visualize_curvature.h"

#include <yf_movements/act_MoveTowardSuctionAction.h>
#include <actionlib/client/simple_action_client.h>
#include <actionlib/client/terminal_state.h>
#include <boost/thread.hpp>

// #include <yf_visualise/srv_pub_cloud.h>
#include "static_pointcloud_publisher_wrap.h"

void spinThread()
{
  ros::spin();
}

int
main (int argc, char** argv)
{
  
  ros::init (argc, argv, "calc_Grip");
  ros::NodeHandle nh; 
//  
  static tf::TransformBroadcaster br;
//   ros::Publisher Pub_GRIP = nh.advertise<yf_pcl_process::msg_Grip>("/vg/Grip_Optimized", 2, true);
//   ros::Publisher Pub_cloud_org = nh.advertise<sensor_msgs::PointCloud2>("/scene/cloud_org",2, true);
//   ros::Publisher Pub_pjpl = nh.advertise<sensor_msgs::PointCloud2>("/scene/cloud_pjpl", 2, true);
//   ros::Publisher Pub_allring = nh.advertise<sensor_msgs::PointCloud2>("/scene/cloud_allring", 2, true);
//   ros::Publisher Pub_withI = nh.advertise<sensor_msgs::PointCloud2>("/scene/cloud_withI", 2, true);
//   ros::Publisher Pub_inlander = nh.advertise<sensor_msgs::PointCloud2>("/scene/cloud_inlander", 2, true);
//   ros::Publisher Pub_border = nh.advertise<sensor_msgs::PointCloud2>("/scene/cloud_border", 2, true);
  ros::Publisher Pub_DrawCups = nh.advertise<yf_vacuum_cups::msg_cup_draw>("/cup_draw", 5, true);
  
  ros::Publisher pub_visCM = nh.advertise<visualization_msgs::Marker>( "/scene/vis/CM", 2 );
  ros::Publisher pub_visNS = nh.advertise<visualization_msgs::Marker>( "/scene/vis/NS", 260 );
  ros::Publisher pub_visNSPP = nh.advertise<visualization_msgs::Marker>( "/scene/vis/NSPP", 20 );
    
  
  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZ>);
 

  std::string filename (std::to_string(ros::Time::now().sec));
  if (1) 
  {    
    ros::ServiceClient client = nh.serviceClient<yf_pcl_process::srv_get_avgPC>("/srv_get_avgPC");

    yf_pcl_process::srv_get_avgPC srvD;
    srvD.request.caller = 7;
    
    if (client.call(srvD))
    {
      ROS_INFO("called current Scene as Point Cloud");
      pcl::moveFromROSMsg(srvD.response.avg_cloud, *cloud); 	
      std::cout << "cloud->size(): " << cloud->height <<" * "<< cloud->width <<"\n";
    }
    else
    {
      ROS_ERROR("Failed to call up current Scene as Point Cloud");
      return 1;
    }
  }
//     pcl::io::savePCDFileASCII (filename+"_p.pcd", *cloud);
    

  static_PointCloud_publish("/scene/cloud_org", cloud);
  
  //////////////////////////////////////////////////////////////////////////////////////
  ros::Time RosTimeBegin = ros::Time::now();
    yf_VacuumGripScene Vtmp(cloud);

    Vtmp.wait_get_stf_Flange2Sensor(nh, 7);
    if (!Vtmp.if_exist_stf_Flange2Sensor) 
    {
      ROS_ERROR("unable to determine sensor pose --------- exit");
      return 0;
    }
    
    Vtmp.wait_get_stf_World2Flange(nh, 7);
    if (!Vtmp.if_exist_stf_World2Flange) 
    {
      ROS_ERROR("unable to determine robot pose --------- exit");
      return 0;
    }
  //////////////////////////////////////////////////////////////////////////////////////  
    
    tf::Point N_table; float d_table;
    
    Vtmp.wait_get_stf_World2Table(nh, 7);
    if (!Vtmp.if_exist_stf_World2Table)
    {
      ROS_ERROR("unable to determine table from model --------- exit");
      tf::Transform tf_B2T_g (Vtmp.q_u, 0.29*Vtmp.v3_001);
      Vtmp.set_Tf_World2Table(tf_B2T_g);
    }
    else  ROS_INFO("Determined table from model ");
    
    if (Vtmp.if_exist_stf_World2Table && Vtmp.if_exist_stf_World2Flange && 1)
    {
      std::cout<<"use gloable table\n";
      if (Vtmp.if_exist_stf_Flange2Sensor)
      {
	Vtmp.set_Tf_Sensor2Table();
      }
    }
    else
    {
      Vtmp.get_Table_SAC(N_table, d_table);
      std::cout<<"use local table from camera\n";
      Vtmp.set_Tf_Sensor2Table(N_table, d_table);
      std::cout<<"reset_Tf_Sensor2Table\n";
    }   
    br.sendTransform(Vtmp.stf_x2Table);
  
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   trim - ");
    Vtmp.set_table_trim_offset(0.01f);  	// 1cm above table
    float an=0,rr = 0;
    while (rr < 0.5)
    {
      int xx = (rr*cos(an)+0.5) * Vtmp.cloud->width;
      int yy = (rr*sin(an)+0.5) * Vtmp.cloud->height;
      if (Vtmp.label_object_onTable(xx,yy,1))       		{};
//       if (Vtmp.label_object_regardlessTable(xx,yy,1)) 	{};
      an += pcl::deg2rad(45.0);
      if (an > pcl::deg2rad(360.0)) {rr += 0.05; an = 0; }
    }
    
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   trim - all labeled");
    Vtmp.trim_cloud_label();
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   trim - fin");
    
#if 0
    bool relocated = Vtmp.relocateCloud_to_World_and_GlobalTABLE(false);
    if (!relocated) Vtmp.relocateCloud_toTableFrame(false); 
#else
    Vtmp.relocateCloud_toTableFrame(false); 
#endif
//      Vtmp.save2_pcd();
    
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   calculate normal - ");
    
    pcl::PointCloud <pcl::Normal>::Ptr normals (new pcl::PointCloud <pcl::Normal>);    
    
//     Vtmp.setInputCloud(cloud);
    Vtmp.calc_norm();
    normals = Vtmp.normals;
    ROS_INFO_STREAM(normals->size()<<"   normals calculated  - ");
       
//     Vtmp.combine_cloud_normal();
//     pcl::io::savePCDFileASCII (filename+"_pn.pcd", *(Vtmp.cloud_with_normals));
    
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   calculate normal - fin");
  
#if 1
  {
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   visualizing curvature - ");
    pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_with_I (new pcl::PointCloud<pcl::PointXYZI>);
    yf_visualize_curvature((Vtmp.cloud), Vtmp.normals, cloud_with_I);   
    static_PointCloud_publish("/scene/cloud_with_I", cloud_with_I);
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   visualizing curvature - fin");    
  }
#endif  
  
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   calculate Mass Center -");
    Vtmp.calc_massCenter();
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   calculate Mass Center - fin");
  

  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   filtering - big curvature extracted");
    Vtmp.setCupDim(3);
//     Vtmp.setCupDim1234(1,2,3,7);	// set each cup seperately
    float borderMargin = Vtmp.cup_dim_.radius * 0.7 + 0.001;	// margin from border
    Vtmp.calc_border_inlander(0.02, borderMargin);	// curvature limit, radius of remove
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   filtering - fin");
  static_PointCloud_publish("/scene/cloud_inlander", Vtmp.cloud_inlander);
  static_PointCloud_publish("/scene/cloud_border", Vtmp.get_cloud_border());
  
        
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   calculate NormalSphere -");
    
    NormalSphere NS(Vtmp);
  
    NS.init_NormalSphere();
    NS.calc_NormalSphere(NS.idx_inlander);
    
    ROS_INFO_STREAM("sum_all_norms = "<<NS.NSphere_allsum);
    
    
    NS.get_clusterNormalSphere();
    
    NS.save_viewAngles(Vtmp);
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   calculate NormalSphere - fin");
  
  
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   projection - fin");
    
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   calc rect -");
  
    Vtmp.init_v_stf_Tool2CupBases();
    std::vector< yf_pcl_process::msg_Grip > v_grip_nominees;
    
    nominate nM(Vtmp);
    nM.nominate__get_v_grip_nominees_Rect_all_cfgY(0.07, 0.03, 0.0, v_grip_nominees);
    nM.save_viewAngles(Vtmp);
    
     pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_pj1 (new pcl::PointCloud<pcl::PointXYZ>);
     nM.get_ProjectplainMapPcl(1,cloud_pj1, M_PI/180*20);
//     pcl::io::savePCDFileASCII ("cloud_pj1.pcd", *cloud_pj1);
     static_PointCloud_publish("/scene/cloud_pjpl", cloud_pj1, "/PjPl/1");
    
    uint iii = 0;
    
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   calc rect - fin");
  

  
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   set_MsgGrip  - fin "<<v_grip_nominees[iii].cupOn[0]);
  maneuverGrip mG(Vtmp);
  
  mG.set_v_stf_Tool2CupBases_tfBase0(Vtmp.tf_u);	// a ramdom configuration of gripper
  
  mG.set_MsgGrip(v_grip_nominees[iii]);
  
  
  std::vector< maneuverGrip::Grip_Perform > v_Grip_perform2 {};
   maneuverGrip::Grip_Perform Grip_optimized (v_grip_nominees[iii]);
  uint further;

     
    pcl::IndicesPtr idx_allring (new std::vector <int>);
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_allring (new pcl::PointCloud<pcl::PointXYZ>);
//     std::cout << "cloud_allring.size is "<< cloud_allring->size()<<"\n";
  
//     Vtmp.save2_pcd_inlander();
    
    

    
//   tf::StampedTransform stf_Viewer(tf::Transform(tf::Quaternion(1,0,0,0),tf::Point(0,0,0)),ros::Time::now(),"/table_frame","/table_viewer_frame");
//   tf::StampedTransform stf_Viewer(Vtmp.tf_u,ros::Time::now(),"/table_frame","/table_viewer_frame");
  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_l (new pcl::PointCloud<pcl::PointXYZ>);  

  visualization_msgs::Marker CM_outputt;
  Vtmp.draw_CenterOfMass(CM_outputt);
  std::vector<visualization_msgs::Marker> arraw_outputt;
  NS.draw_NormalSphere(arraw_outputt);
  std::vector<visualization_msgs::Marker> projectionPlain_outputt;
   Vtmp.draw_NormalSphere_projection(projectionPlain_outputt);

  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   sim - start \n");
    
  uint vis_counter = 25;
  ros::Rate r(10);
  while (ros::ok() && vis_counter > 0)
  {
    vis_counter --;
    //   mG.findall_tf_table2ring_near_MsgGrip();
    //   mG.fit_MsgGrip();
      
    //   mG.apply_MsgGrip();

//       mG.get_GP_descent_0now_1new(v_Grip_perform2);
    //    further=mG.trim_leaf_GP(v_Grip_perform2);
      
      mG.try_Grip_get_Perform_force(Grip_optimized);   
//        mG.optimize_GD_ADAM(Grip_optimized, Grip_optimized, 1);
      mG.optimize_GD_ordinary(Grip_optimized, Grip_optimized, 1);

    idx_allring->clear();
    idx_allring->insert(idx_allring->end(), mG.v_idx_ring[1]->begin(), mG.v_idx_ring[1]->end());
    idx_allring->insert(idx_allring->end(), mG.v_idx_ring[2]->begin(), mG.v_idx_ring[2]->end());
    idx_allring->insert(idx_allring->end(), mG.v_idx_ring[3]->begin(), mG.v_idx_ring[3]->end());
    idx_allring->insert(idx_allring->end(), mG.v_idx_ring[4]->begin(), mG.v_idx_ring[4]->end());
    pcl::copyPointCloud(*Vtmp.cloud, *idx_allring, *cloud_allring);
    static_PointCloud_publish("/scene/cloud_allring", cloud_allring);
    
      CM_outputt.header.stamp 	= ros::Time::now();
      pub_visCM.publish(CM_outputt);
  
    
    for (uint i = 0; i<arraw_outputt.size(); i++)
    {
      arraw_outputt[i].header.stamp 	= ros::Time::now();
      pub_visNS.publish(arraw_outputt[i]);
    }
    
    for (uint i = 0; i<projectionPlain_outputt.size(); i++)
    {
      Vtmp.NSphere_viewAngles_stf[i+1].stamp_ 	= ros::Time::now();
      br.sendTransform(Vtmp.NSphere_viewAngles_stf[i+1]);
     
      projectionPlain_outputt[i].header.stamp 	= ros::Time::now();
      pub_visNSPP.publish(projectionPlain_outputt[i]);
    }
    
//     stf_Viewer.stamp_ = ros::Time::now();
//      br.sendTransform(stf_Viewer);
     
//     Vtmp.stf_Sensor2Table.stamp_ =  ros::Time::now();
//      br.sendTransform(Vtmp.stf_Sensor2Table);
     
//     Vtmp.calc_stf_x2Table_fromWorld(nh); 
     Vtmp.stf_x2Table.stamp_ =  ros::Time::now();
     br.sendTransform(Vtmp.stf_x2Table);
     
//      mG.stf_Table2Tool.stamp_ = ros::Time::now();
//      br.sendTransform(mG.stf_Table2Tool);
     
     mG.v_stf_Tool2CupBases[0].stamp_ = ros::Time::now();
     br.sendTransform(mG.v_stf_Tool2CupBases[0]);
     mG.v_stf_Tool2CupBases[1].stamp_ = ros::Time::now();
     br.sendTransform(mG.v_stf_Tool2CupBases[1]);
     mG.v_stf_Tool2CupBases[2].stamp_ = ros::Time::now();
     br.sendTransform(mG.v_stf_Tool2CupBases[2]);
     mG.v_stf_Tool2CupBases[3].stamp_ = ros::Time::now();
     br.sendTransform(mG.v_stf_Tool2CupBases[3]);
     mG.v_stf_Tool2CupBases[4].stamp_ = ros::Time::now();
     br.sendTransform(mG.v_stf_Tool2CupBases[4]);
     
    
//     Pub_DrawCups.publish(Vtmp.genDrawMsg(1,mG.v_stf_table2ring[1],Vtmp.v_cup_dim_N[1]));
//     r.sleep();
//     Pub_DrawCups.publish(Vtmp.genDrawMsg(2,mG.v_stf_table2ring[2],Vtmp.v_cup_dim_N[2]));
//     r.sleep();
//     Pub_DrawCups.publish(Vtmp.genDrawMsg(3,mG.v_stf_table2ring[3],Vtmp.v_cup_dim_N[3]));
//     r.sleep();
//     Pub_DrawCups.publish(Vtmp.genDrawMsg(4,mG.v_stf_table2ring[4],Vtmp.v_cup_dim_N[4]));
//     r.sleep();
    
    
    sensor_msgs::PointCloud2 outputt;
    
//     pcl::toROSMsg(*cloud, outputt);
//     outputt.header.stamp = ros::Time::now();
//     Pub_cloud_org.publish(outputt);
//     r.sleep();
#if 0
    pcl::toROSMsg(*cloud_pj1, outputt);
    outputt.header.frame_id = "/PjPl/1";    
    outputt.header.stamp = ros::Time::now();
    Pub_pjpl.publish(outputt);
    r.sleep();
    
    pcl::toROSMsg(*cloud_allring, outputt);
//     outputt.header.frame_id = "/table_frame";    
    outputt.header.stamp = ros::Time::now();
    Pub_allring.publish(outputt);
    r.sleep();
    
    pcl::toROSMsg(*(Vtmp.get_cloud_border()), outputt);
//     outputt.header.frame_id = "/table_frame";    
    outputt.header.stamp = ros::Time::now();
    Pub_border.publish(outputt);
    r.sleep();
    
    pcl::toROSMsg(*cloud_with_I, outputt);
//     outputt.header.frame_id = "/table_frame";    
    outputt.header.stamp = ros::Time::now();
    Pub_withI.publish(outputt);
    r.sleep();
    
    pcl::toROSMsg(*(Vtmp.cloud_inlander), outputt);
//     outputt.header.frame_id = "/table_frame";    
    outputt.header.stamp = ros::Time::now();
    Pub_inlander.publish(outputt);
    r.sleep();
#else



#endif

    ROS_INFO("publishing");
  
// //     ros::spinOnce();
  }
    ROS_INFO("published _ all finished");
  
    if(1)
    {
      actionlib::SimpleActionClient<yf_movements::act_MoveTowardSuctionAction> ac("ACTION_Robot_try_Grip");
      boost::thread spin_thread(&spinThread);

      ROS_INFO("Waiting for action server to start.");
      ac.waitForServer();

      ROS_INFO("Action server started, sending goal.");
      // 发送目标到行为
      yf_movements::act_MoveTowardSuctionGoal goal;
      goal.order = 50;
      goal.grip = Grip_optimized.grip;
      
      ac.sendGoal(goal);

      //等待行为返回
      bool finished_before_timeout = ac.waitForResult(ros::Duration(15.0));

      if (finished_before_timeout)
      {
	actionlib::SimpleClientGoalState state = ac.getState();
	ROS_INFO("Action finished: %s",state.toString().c_str());
      }
      else
	ROS_INFO("Action did not finish before the time out.");

      // 关闭节点，在退出前加入线程
      ros::shutdown();
      spin_thread.join();
    }
    
//  viewer.showCloud(colored_cloud);
//  while (!viewer.wasStopped ()) {}

  return (0);
}
