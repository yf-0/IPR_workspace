#include <cmath>
#include <limits>
#include <iostream>

#include <ros/ros.h>
#include <rosbag/bag.h>
#include <rosbag/view.h>

#include <visualization_msgs/Marker.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>

// #include "../../../devel/include/yf_pcl_process/msg_grip_tfs_cfg.h"
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/project_inliers.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/search/search.h>
#include <pcl/search/kdtree.h>
#include <pcl/search/organized.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/features/integral_image_normal.h>
#include "pcl_ros/transforms.h"
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/extract_polygonal_prism_data.h>
#include <pcl/segmentation/region_growing.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl/surface/concave_hull.h>
#include <pcl/segmentation/organized_multi_plane_segmentation.h>
#include <pcl/segmentation/organized_connected_component_segmentation.h>
#include <pcl/segmentation/planar_region.h>
#include <pcl/segmentation/comparator.h>
#include <pcl/impl/point_types.hpp>

#include <tf/LinearMath/Vector3.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <tf_conversions/tf_eigen.h>

#include <Eigen/Core> 
#include <Eigen/Geometry> 
#include <Eigen/SVD>
#include <Eigen/Dense>

#include <yf_vacuum_cups/cup_dim.h>
#include <yf_vacuum_cups/srv_draw_cup.h>
#include <yf_vacuum_cups/msg_cup_draw.h>
#include <yf_pcl_process/msg_grip_tfs_cfg.h>

#include "class_yf_V.h"
#include "class_NormalSphere.h"
#include "class_nominate.h"
#include "class_maneuverGrip.h"






void yf_visualize_curvature(pcl::PointCloud<pcl::PointXYZ>::ConstPtr cloud_in_xyz, pcl::PointCloud<pcl::Normal>::ConstPtr cloud_in_norm, pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_out_xyzi)
{
//  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   visualizing curvature - ");
//    pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_with_I (new pcl::PointCloud<pcl::PointXYZI>);
  cloud_out_xyzi->resize(cloud_in_xyz->size ());
  cloud_out_xyzi->height = cloud_in_xyz->height;
  cloud_out_xyzi->width = cloud_in_xyz->width;
  cloud_out_xyzi->header = cloud_in_xyz->header;
    for (size_t i = 0; i < cloud_in_xyz->size (); ++i)
    {
      pcl::PointXYZI ptxyzrgb;
      ptxyzrgb.x = cloud_in_xyz->points[i].x; ptxyzrgb.y = cloud_in_xyz->points[i].y; ptxyzrgb.z = cloud_in_xyz->points[i].z;
      ptxyzrgb.intensity = (cloud_in_norm->points[i].curvature);
      cloud_out_xyzi->points[i]=(ptxyzrgb);
    }
//  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   visualizing curvature - fin");    
}

int
main (int argc, char** argv)
{
  
  ros::init (argc, argv, "calc_Grip");
  ros::NodeHandle nh; 
  ros::NodeHandle priv_nh("~");
//  
  ros::Publisher Pub_ = nh.advertise<sensor_msgs::PointCloud2>("/surface_gen", 1, true);
  ros::Publisher Pub_ring = nh.advertise<sensor_msgs::PointCloud2>("/surface_gen_ring", 1, true);
  ros::Publisher Pub_ring2 = nh.advertise<sensor_msgs::PointCloud2>("/surface_gen_ring2", 1, true);
  ros::Publisher Pub_tfed = nh.advertise<sensor_msgs::PointCloud2>("/surface_gen_tfed", 1, true);
  ros::Publisher Pub_withI = nh.advertise<sensor_msgs::PointCloud2>("/surface_gen_withI", 1, true);
  ros::Publisher Pub_filtered = nh.advertise<sensor_msgs::PointCloud2>("/surface_gen_filtered", 1, true);
  ros::Publisher Pub_phidz = nh.advertise<sensor_msgs::PointCloud2>("/surface_gen_phidz", 1, true);
  ros::Publisher Pub_inlander = nh.advertise<sensor_msgs::PointCloud2>("/surface_gen_inlander", 1, true);
  ros::Publisher Pub_border = nh.advertise<sensor_msgs::PointCloud2>("/surface_gen_border", 1, true);
  ros::Publisher Pub_vox = nh.advertise<sensor_msgs::PointCloud2>("/surface_gen_vox", 1, true);
  ros::Publisher Pub_sac1 = nh.advertise<sensor_msgs::PointCloud2>("/surface_gen_sac1", 1, true);
  ros::Publisher Pub_on = nh.advertise<sensor_msgs::PointCloud2>("/surface_gen_on", 1, true);
  ros::Publisher Pub_DrawCups = nh.advertise<yf_vacuum_cups::msg_cup_draw>("/cup_draw", 1, true);
  
   float f_nan = std::numeric_limits<float>::quiet_NaN();
   pcl::PointXYZ PointXYZ_nan (f_nan,f_nan,f_nan);
  
  uint width = 320, height = 240;
  float cur_x = 1, cur_y = -1, phs_x = -0.5, phs_y = -0.5;
  float z_height = 0.02;
  float noise_a = 0.0002, noise_b = 0.0005;
  
  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZ>);
  
  
    std::string filename ("e40.pcd");
  ROS_INFO_STREAM("   point cloud generated");
  if (1) 
  {
    tf::Transform tf_load_xz;
    tf_load_xz = tf::Transform(tf::Quaternion(tf::Vector3(1,0,0),-0.5*M_PI),tf::Vector3(0,0,0.00));
    tf_load_xz = tf::Transform(tf::Quaternion(tf::Vector3(0,0,1),-0.5*M_PI),tf::Vector3(0,0,0.0))*tf_load_xz;
    
    
    if (priv_nh.getParam("file", filename))
      ROS_INFO_STREAM ("read file "<<filename);
    
    if (pcl::io::loadPCDFile<pcl::PointXYZ> (filename, *cloud) == -1) //* load the file
    {
      ROS_INFO_STREAM ("Couldn't read file "<<filename);
      return (-1);
    }    
    else
    {
      height = cloud->height;
      width = cloud->width;
      //pcl_ros::transformPointCloud(*cloud, *cloud, tf_load_xz);
    }
  ROS_INFO_STREAM("point cloud loaded : "<<filename);
  }
  
  
  //////////////////////////////////////////////////////////////////////////////////////
  ros::Time RosTimeBegin = ros::Time::now();
    yf_V Vtmp(cloud);
  //////////////////////////////////////////////////////////////////////////////////////  

    Vtmp.wait_get_tf_Base2Flange(nh);
    
    tf::Point N_table; float d_table;
    
    tf::Transform tf_B2T_g (Vtmp.q_u, 0.29*Vtmp.v3_001);
    
    Vtmp.set_Tf_Base2Table(tf_B2T_g);
  
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   trim - ");
    bool found = false;
  
    if (Vtmp.knownTable &&1)
    {
      std::cout<<"use gloable table\n";
    }
    else
    {
      Vtmp.get_Table_SAC(N_table, d_table);
      std::cout<<"use local table from camera\n";
      Vtmp.set_Tf_Sensor2Table(N_table, d_table);
      std::cout<<"reset_Tf_Sensor2Table\n";
    }   
    
    
    float an=0,rr = 0;
    while (rr < 0.5)
    {
      int xx = (rr*cos(an)+0.5) * Vtmp.cloud->width;
      int yy = (rr*sin(an)+0.5) *Vtmp.cloud->height;
      if (Vtmp.label_object_onTable(xx,yy,1)) break;
      an += pcl::deg2rad(45.0);
      if (an > pcl::deg2rad(360.0)) {rr += 0.05; an = 0; }
    }
    
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   trim - all labeled");
    Vtmp.trim_cloud_label();
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   trim - fin");
    
#if 0
    bool relocated = Vtmp.relocateCloud_to_World_and_GlobalTABLE(false);
    if (!relocated) Vtmp.relocateCloud_toTableFrame(false); 
#else
    Vtmp.relocateCloud_toTableFrame(false); 
#endif
//      Vtmp.save2_pcd();
    
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   calculate normal - ");
    
    pcl::PointCloud <pcl::Normal>::Ptr normals (new pcl::PointCloud <pcl::Normal>);    
    
//     Vtmp.setInputCloud(cloud);
    Vtmp.calc_norm();
    normals = Vtmp.normals;
    ROS_INFO_STREAM(normals->size()<<"   normals calculated  - ");
    
    Vtmp.combine_cloud_normal();
    pcl::io::savePCDFileASCII (filename+"__.pcd", *(Vtmp.cloud_with_normals));
    
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   calculate normal - fin");
  
  
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   calculate Mass Center -");
    Vtmp.calc_massCenter();
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   calculate Mass Center - fin");
  

  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   filtering - big curvature extracted");
    Vtmp.setCupDim(7);
//     Vtmp.setCupDim1234(1,2,3,7);	// set each cup seperately
    float borderMargin = Vtmp.cup_dim_.radius + 0*0.5 * Vtmp.cup_dim_.lengthen + 0.001;	// margin from border
    Vtmp.calc_border_inlander(0.002, borderMargin);	// curvature limit, radius of remove
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   filtering - fin");
        
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   calculate NormalSphere -");
    
    NormalSphere NS(Vtmp);
  
    NS.init_NormalSphere();
    NS.calc_NormalSphere(NS.idx_inlander);
    
    ROS_INFO_STREAM("sum_all_norms = "<<NS.NSphere_allsum);
    
    
    NS.get_clusterNormalSphere();
    
    NS.save_viewAngles(Vtmp);
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   calculate NormalSphere - fin");
  
  
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   projection - fin");
    
    Vtmp.init_v_stf_Tool2CupBases();
    std::vector< yf_pcl_process::msg_grip_tfs_cfg > v_grip_nominees;
    
//     Vtmp.nominate__get_v_grip_nominees_Rect_all_cfgY(0.07, 0.04, 0.01, v_grip_nominees);

    nominate nM(Vtmp);
    nM.nominate__get_v_grip_nominees_Rect_all_cfgY(0.06, 0.04, 0.0, v_grip_nominees);
    nM.save_viewAngles(Vtmp);
    
     pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_pj1 (new pcl::PointCloud<pcl::PointXYZ>);
//      nM.get_ProjectplainMapPcl(1,cloud_pj1, M_PI/180*20);
//     pcl::io::savePCDFileASCII ("cloud_pj1.pcd", *cloud_pj1);
    
    
    uint iii = 1 ;
//     Vtmp.set_v_stf_Tool2CupBases_cfgXYZ(v_grip_nominees[iii].cfgX, v_grip_nominees[iii].cfgY, v_grip_nominees[iii].cfgZ);
//     tf::StampedTransform stf_tmp;
//     tf::transformStampedMsgToTF(v_grip_nominees[iii].tfs_tabel2cupbase0, stf_tmp);
//     Vtmp.set_stf_Table2Tool(stf_tmp*Vtmp.v_stf_Tool2CupBases[0].inverse());

    
    
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   projection - fin");
  

  
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   set_MsgGrip  - fin "<<v_grip_nominees[iii].cupOn[0]);
  maneuverGrip mG(Vtmp);
  
  mG.set_v_stf_Tool2CupBases_tfBase0(tf::Transform(tf::Quaternion(Vtmp.v3_100,0.5)*tf::Quaternion(Vtmp.v3_010,0.7), tf::Point(0.02,-0.04,0.03)));	// a ramdom configuration of gripper
  
  mG.set_MsgGrip(v_grip_nominees[iii]);
  
  
//   mG.find_tf_table2ring_near_MsgGrip(1);
//   mG.find_tf_table2ring_near_MsgGrip(2);
//   mG.find_tf_table2ring_near_MsgGrip(3);
//   mG.find_tf_table2ring_near_MsgGrip(4);
  std::cout <<  "overall distance is " <<mG.findall_tf_table2ring_near_MsgGrip();
  mG.fit_MsgGrip();
  
  mG.apply_MsgGrip();
  
//   mG.get_cupPath(1);
//   mG.get_cupPath(2);
//   mG.get_cupPath(3);
//   mG.get_cupPath(4);
  /*
  std::vector< yf_pcl_process::msg_grip_tfs_cfg> v_msgGrip2;*/
  std::vector< maneuverGrip::Grip_Perform > v_Grip_perform2 {};
  std::vector< maneuverGrip::Grip_Perform > v_Grip_perform3 {};
  uint further;
  
      std::cout << "wtf2";
//    mG.get_v_msg_grip_tend(mG.v_Grip_perform2);
   mG.get_v_GP_for_gp(v_Grip_perform2);
   further=mG.trim_leaf_GP( v_Grip_perform2);
   std::cout <<  "\n000000000000000000000\n ";
   if (further) 
   {  mG.get_v_GP_for_gp(v_Grip_perform2[1],v_Grip_perform3);
     further=mG.trim_leaf_GP( v_Grip_perform3);
   }
   std::cout <<  "\n111111111111111111111111\n ";
// 
   if (further)
   {
    mG.get_v_GP_for_gp(v_Grip_perform3[1],v_Grip_perform2);
    further=mG.trim_leaf_GP( v_Grip_perform2);
   }
   std::cout <<  "\n 222222222222222222222222\n ";
   if (further)
   {
     mG.get_v_GP_for_gp(v_Grip_perform2[1],v_Grip_perform3);
      further=mG.trim_leaf_GP( v_Grip_perform3);
   }
   std::cout <<  "\n 3333333333333333\n ";
//    mG.get_v_GP_for_gp(v_Grip_perform3[1],v_Grip_perform2);
//    mG.trim_leaf_GP( v_Grip_perform2);
//    
//    std::cout <<  "\n 44444444444444444444444444\n ";
//    mG.get_v_GP_for_gp(v_Grip_perform2[1],v_Grip_perform3);
//    mG.trim_leaf_GP( v_Grip_perform3);
//       
//    std::cout <<  "\n 5555555555555555555\n ";
//    mG.get_v_GP_for_gp(v_Grip_perform3[1],v_Grip_perform2);
//    mG.trim_leaf_GP( v_Grip_perform2);
//    
//    std::cout <<  "\n 666666666666666666666666666\n ";
//    mG.get_v_GP_for_gp(v_Grip_perform2[1],v_Grip_perform3);
//    mG.trim_leaf_GP( v_Grip_perform3);
//    
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   sim - start \n");
  
     
    pcl::IndicesPtr idx_allring (new std::vector <int>);
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_allring (new pcl::PointCloud<pcl::PointXYZ>);
    idx_allring->insert(idx_allring->end(), mG.v_idx_ring[1]->begin(), mG.v_idx_ring[1]->end());
    idx_allring->insert(idx_allring->end(), mG.v_idx_ring[2]->begin(), mG.v_idx_ring[2]->end());
    idx_allring->insert(idx_allring->end(), mG.v_idx_ring[3]->begin(), mG.v_idx_ring[3]->end());
    idx_allring->insert(idx_allring->end(), mG.v_idx_ring[4]->begin(), mG.v_idx_ring[4]->end());
    pcl::copyPointCloud(*Vtmp.cloud, *idx_allring, *cloud_allring);
//     std::cout << "cloud_allring.size is "<< cloud_allring->size()<<"\n";
    
    ros::Publisher pub_visCM = nh.advertise<visualization_msgs::Marker>( "visCM", 2 );
    ros::Publisher pub_visNS = nh.advertise<visualization_msgs::Marker>( "visNS", 260 );
    ros::Publisher pub_visNSPP = nh.advertise<visualization_msgs::Marker>( "visNSPP", 20 );
    visualization_msgs::Marker cylin, sPnorm;
  
//    pcl::PointXYZ searchPoint1 = cloud->points[170433];
//     pcl::PointXYZ searchPoint2 = cloud->points[205022];
//     tf::Transform tf_tool1 (tf::Transform(tf::Quaternion(tf::Vector3(1,0,0),0),tf::Vector3(-0.06,-0.00,-0.2)));
//     tf_tool1 = tf_tool1*(tf::Transform(tf::Quaternion(tf::Vector3(0,0,1),0.9),tf::Vector3(0,0,0)));
//     tf::StampedTransform stf_Table2Tool (tf::StampedTransform(tf_tool1,ros::Time::now(),"/table_frame","/tool_frame"));
//     Vtmp.set_stf_Table2Tool(tf_tool1);
    ROS_INFO_STREAM("set tool table frames");
//     tf::Transform tf_ring1 = mG.get_tf_to_ring_cupX(1);
//     tf::Transform tf_ring2 = mG.get_tf_to_ring_cupX(2);
//     tf::Transform tf_ring3 = mG.get_tf_to_ring_cupX(3);
//     tf::Transform tf_ring4 = mG.get_tf_to_ring_cupX(4);
    
    tf::StampedTransform stf_ring1 = mG.v_stf_table2ring[1];
    tf::StampedTransform stf_ring2 = mG.v_stf_table2ring[2];
    tf::StampedTransform stf_ring3 = mG.v_stf_table2ring[3];
    tf::StampedTransform stf_ring4 = mG.v_stf_table2ring[4];
    
//     Vtmp.save2_pcd_inlander();
    
    
#if 1
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   visualizing curvature - ");
    pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_with_I (new pcl::PointCloud<pcl::PointXYZI>);
    yf_visualize_curvature((Vtmp.cloud), Vtmp.normals, cloud_with_I);   
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   visualizing curvature - fin");    
#endif  
    
  static tf::TransformBroadcaster br;
//   tf::StampedTransform stf_Viewer(tf::Transform(tf::Quaternion(1,0,0,0),tf::Point(0,0,0)),ros::Time::now(),"/table_frame","/table_viewer_frame");
  tf::StampedTransform stf_Viewer(Vtmp.tf_u,ros::Time::now(),"/table_frame","/table_viewer_frame");
  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_l (new pcl::PointCloud<pcl::PointXYZ>);  

  visualization_msgs::Marker CM_outputt;
  Vtmp.draw_CenterOfMass(CM_outputt);
  std::vector<visualization_msgs::Marker> arraw_outputt;
  NS.draw_NormalSphere(arraw_outputt);
  std::vector<visualization_msgs::Marker> projectionPlain_outputt;
   Vtmp.draw_NormalSphere_projection(projectionPlain_outputt);

    
  uint vis_counter = 0;
  ros::Rate r(20);
  while (ros::ok())
  {
//  
//     vis_counter++;
//     vis_counter = vis_counter% Vtmp.binNormalSphere_count.size();
//           arraw_outputt[vis_counter].header.stamp 	= ros::Time::now();
//       pub_visNS.publish(arraw_outputt[vis_counter]);
    
      CM_outputt.header.stamp 	= ros::Time::now();
      pub_visCM.publish(CM_outputt);
  
    
    for (uint i = 0; i<arraw_outputt.size(); i++)
    {
      arraw_outputt[i].header.stamp 	= ros::Time::now();
      pub_visNS.publish(arraw_outputt[i]);
    }
    
    
    for (uint i = 0; i<projectionPlain_outputt.size(); i++)
    {
      Vtmp.NSphere_viewAngles_stf[i+1].stamp_ 	= ros::Time::now();
      br.sendTransform(Vtmp.NSphere_viewAngles_stf[i+1]);
     
      projectionPlain_outputt[i].header.stamp 	= ros::Time::now();
      pub_visNSPP.publish(projectionPlain_outputt[i]);
    }
    
    stf_Viewer.stamp_ = ros::Time::now();
     br.sendTransform(stf_Viewer);
     
//     Vtmp.stf_Sensor2Table.stamp_ =  ros::Time::now();
//      br.sendTransform(Vtmp.stf_Sensor2Table);
     
//     Vtmp.calc_stf_x2Table_fromWorld(nh); 
//     Vtmp.stf_x2Table.stamp_ =  ros::Time::now();
     br.sendTransform(Vtmp.stf_x2Table);
     
    mG.stf_Table2Tool.stamp_ = ros::Time::now();
     br.sendTransform(mG.stf_Table2Tool);
     
     br.sendTransform(mG.v_stf_Tool2CupBases[0]);
     br.sendTransform(mG.v_stf_Tool2CupBases[1]);
     br.sendTransform(mG.v_stf_Tool2CupBases[2]);
     br.sendTransform(mG.v_stf_Tool2CupBases[3]);
     br.sendTransform(mG.v_stf_Tool2CupBases[4]);
     
    
    Pub_DrawCups.publish(Vtmp.genDrawMsg(1,stf_ring1,Vtmp.v_cup_dim_N[1]));
    r.sleep();
    Pub_DrawCups.publish(Vtmp.genDrawMsg(2,stf_ring2,Vtmp.v_cup_dim_N[2]));
    r.sleep();
    Pub_DrawCups.publish(Vtmp.genDrawMsg(3,stf_ring3,Vtmp.v_cup_dim_N[3]));
    r.sleep();
    Pub_DrawCups.publish(Vtmp.genDrawMsg(4,stf_ring4,Vtmp.v_cup_dim_N[4]));
    r.sleep();
    
//      vis_pub.publish(cylin);
//      vis_pub.publish(sPnorm);
    
    sensor_msgs::PointCloud2 outputt;
    
    pcl::toROSMsg(*cloud, outputt);
//     outputt.header.frame_id = "/table_frame";    
//     outputt.header.frame_id = cloud->header.frame_id;    
    outputt.header.stamp = ros::Time::now();
    Pub_.publish(outputt);
    
    pcl::toROSMsg(*cloud_pj1, outputt);
//     outputt.header.frame_id = "/PjPl/1";    
    outputt.header.stamp = ros::Time::now();
    Pub_ring.publish(outputt);
    
    pcl::toROSMsg(*cloud_allring, outputt);
//     outputt.header.frame_id = "/table_frame";    
    outputt.header.stamp = ros::Time::now();
    Pub_ring2.publish(outputt);
    
    pcl::toROSMsg(*(Vtmp.get_cloud_border()), outputt);
//     outputt.header.frame_id = "/table_frame";    
    outputt.header.stamp = ros::Time::now();
    Pub_border.publish(outputt);
    
//     pcl::toROSMsg(*cloud_tfed, outputt);
//     outputt.header.frame_id = "/table_frame";
//     Pub_tfed.publish(outputt);
    
    pcl::toROSMsg(*cloud_with_I, outputt);
//     outputt.header.frame_id = "/table_frame";    
    outputt.header.stamp = ros::Time::now();
    Pub_withI.publish(outputt);
    
//     pcl::toROSMsg(*cloud_phidz, outputt);
//     outputt.header.frame_id = "/table_frame";
//     Pub_phidz.publish(outputt);
    
    pcl::toROSMsg(*(Vtmp.cloud_inlander), outputt);
//     outputt.header.frame_id = "/table_frame";    
    outputt.header.stamp = ros::Time::now();
    Pub_inlander.publish(outputt);
    
    
//     pcl::toROSMsg(*cloud_vox, outputt);
//     outputt.header.frame_id = "/table_frame";
//     Pub_vox.publish(outputt);
    
  
    ros::spinOnce();
  }
    ROS_INFO("published _ all finished");
  
//  viewer.showCloud(colored_cloud);
//  while (!viewer.wasStopped ()) {}

  return (0);
}
