#include <cmath>
#include <limits>
#include <iostream>

#include <ros/ros.h>
#include <rosbag/bag.h>
#include <rosbag/view.h>

#include <visualization_msgs/Marker.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>

// #include "../../../devel/include/yf_pcl_process/msg_grip_tfs_cfg.h"
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/project_inliers.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/search/search.h>
#include <pcl/search/kdtree.h>
#include <pcl/search/organized.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/features/integral_image_normal.h>
#include "pcl_ros/transforms.h"
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/extract_polygonal_prism_data.h>
#include <pcl/segmentation/region_growing.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl/surface/concave_hull.h>
#include <pcl/segmentation/organized_multi_plane_segmentation.h>
#include <pcl/segmentation/organized_connected_component_segmentation.h>
#include <pcl/segmentation/planar_region.h>
#include <pcl/segmentation/comparator.h>
#include <pcl/impl/point_types.hpp>

#include <tf/LinearMath/Vector3.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <tf_conversions/tf_eigen.h>

#include <Eigen/Core> 
#include <Eigen/Geometry> 
#include <Eigen/SVD>
#include <Eigen/Dense>

#include <yf_vacuum_cups/cup_dim.h>
#include <yf_vacuum_cups/srv_draw_cup.h>
#include <yf_vacuum_cups/msg_cup_draw.h>
#include <yf_pcl_process/msg_grip_tfs_cfg.h>


class yf_V
{
  protected:
    ros::NodeHandle nh; 
  
  public:
//     float f_nan = std::numeric_limits<float>::quiet_NaN();
    const float f_nan = NAN;
    const pcl::PointXYZ PointXYZ_nan = pcl::PointXYZ(NAN,NAN,NAN);
    const float rad2deg = 180/M_PI, deg2rad = M_PI/180;
    const tf::Point v3_000 = tf::Point(0,0,0);
    const tf::Point v3_100 = tf::Point(1,0,0);
    const tf::Point v3_010 = tf::Point(0,1,0);
    const tf::Point v3_001 = tf::Point(0,0,1);
    const tf::Quaternion q_u = tf::Quaternion(0,0,0,1);
    const tf::Transform tf_u = tf::Transform(q_u, v3_000);
    
    
    ros::Time RosTimeBegin = ros::Time::now();
    
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud; //(new pcl::PointCloud<pcl::PointXYZ>);
    pcl::PointCloud <pcl::Normal>::Ptr normals;  
    pcl::PointCloud<pcl::PointNormal>::Ptr cloud_with_normals; 
    
    tf::Point massCenter;

    std::vector<tf::Point> NSphere_viewAngles;
    std::vector<tf::StampedTransform> NSphere_viewAngles_stf;

    pcl::IndicesPtr idx_valid;
    pcl::IndicesPtr idx_border;
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_border;
    pcl::IndicesPtr idx_inlander; 			// points far away from borders or big curves
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_inlander;
    
    tf::Point N_table; float d_table;
    tf::Transform tf_Sensor2Table, tf_Table2Sensor;  
    tf::StampedTransform stf_Sensor2Table, stf_Table2Sensor;
    tf::Transform tf_Table2Tool, tf_Tool2Table;  
    tf::StampedTransform stf_Table2Tool, stf_Tool2Table;
    
    std::vector<tf::StampedTransform> v_stf_Tool2CupBases;
    std::vector<uint> v_cup_dim_N;
    std::vector<yf_vacuum_cups::cup_dim> v_cup_dim;
    
    pcl::PointCloud<pcl::Label>::Ptr label ;
    std::vector<pcl::PointIndices> label_indices;
    uint trim_x_min= 640, trim_y_min= 480, trim_x_max= 0, trim_y_max= 0;
    
    pcl::IntegralImageNormalEstimation<pcl::PointXYZ, pcl::Normal> normal_estimator;
    pcl::search::OrganizedNeighbor<pcl::PointXYZ> tree_cloud;
    pcl::search::OrganizedNeighbor<pcl::PointXYZ> tree_inlander;
    float curv_Mx ;					// border curvature threshold mx
    
    uint cupN;
    yf_vacuum_cups::cup_dim cup_dim_ ;
    
    yf_V():
      cloud (new pcl::PointCloud<pcl::PointXYZ>),
      normals (new pcl::PointCloud <pcl::Normal>),
      cloud_with_normals (new pcl::PointCloud<pcl::PointNormal>), 
      idx_valid (new std::vector <int>),
      idx_border (new std::vector <int>),
      cloud_border (new pcl::PointCloud<pcl::PointXYZ>),
      idx_inlander (new std::vector <int>), 
      cloud_inlander (new pcl::PointCloud<pcl::PointXYZ>),
      label (new pcl::PointCloud<pcl::Label>)
    {
      ROS_INFO_STREAM("new obj yf_V") ;
      //ros::NodeHandle priv_nh("~");
      //f_nan = std::numeric_limits<float>::quiet_NaN();
      //PointXYZ_nan = pcl::PointXYZ(f_nan,f_nan,f_nan);
      
      tf_Sensor2Table.setIdentity();      tf_Table2Sensor.setIdentity();
      
      normal_estimator.setNormalEstimationMethod (normal_estimator.COVARIANCE_MATRIX); //AVERAGE_DEPTH_CHANGE, SIMPLE_3D_GRADIENT, AVERAGE_3D_GRADIENT, COVARIANCE_MATRIX
      normal_estimator.setBorderPolicy(normal_estimator.BORDER_POLICY_MIRROR); //BORDER_POLICY_MIRROR, BORDER_POLICY_IGNORE
      normal_estimator.setMaxDepthChangeFactor(0.01f);
      //normal_estimator.setDepthDependentSmoothing(true);
      normal_estimator.setNormalSmoothingSize(9.0);			//factor which influences the size of the area used to smooth normals

      RosTimeBegin = ros::Time::now();
      
      	cup_dim_.radius 	= 0.01;
	cup_dim_.lengthen	= 0.0;
	cup_dim_.height		= 0.01;
	cup_dim_.stroke 	= 0.05;
	cup_dim_.minCurvR	= 0.04;
	cup_dim_.bellows 	= 0.0;
	cup_dim_.bend 		= 0.05;
	
      init_v_stf_Tool2CupBases();	
    }   
    
    yf_V(pcl::PointCloud<pcl::PointXYZ>::Ptr inputt):
      cloud (new pcl::PointCloud<pcl::PointXYZ>),
      normals (new pcl::PointCloud <pcl::Normal>),
      cloud_with_normals (new pcl::PointCloud<pcl::PointNormal>),    
      idx_valid (new std::vector <int>),
      idx_border (new std::vector <int>),
      cloud_border (new pcl::PointCloud<pcl::PointXYZ>),
      idx_inlander (new std::vector <int>), 
      cloud_inlander (new pcl::PointCloud<pcl::PointXYZ>),
      label (new pcl::PointCloud<pcl::Label>)
    {
      ROS_INFO_STREAM("new obj yf_V") ;
      //ros::NodeHandle priv_nh("~");
      //f_nan = std::numeric_limits<float>::quiet_NaN();
      //PointXYZ_nan = pcl::PointXYZ(f_nan,f_nan,f_nan);
      
      tf_Sensor2Table.setIdentity();      tf_Table2Sensor.setIdentity();
      stf_Table2Tool = tf::StampedTransform(tf_Sensor2Table, ros::Time::now(), "/table_frame", "/tool_frame");
      
      normal_estimator.setNormalEstimationMethod (normal_estimator.COVARIANCE_MATRIX); //AVERAGE_DEPTH_CHANGE, SIMPLE_3D_GRADIENT, AVERAGE_3D_GRADIENT, COVARIANCE_MATRIX
      normal_estimator.setBorderPolicy(normal_estimator.BORDER_POLICY_MIRROR); //BORDER_POLICY_MIRROR, BORDER_POLICY_IGNORE
      normal_estimator.setMaxDepthChangeFactor(0.01f);
      //normal_estimator.setDepthDependentSmoothing(true);
      normal_estimator.setNormalSmoothingSize(9.0);			//factor which influences the size of the area used to smooth normals
      
      //pcl::copyPointCloud(*inputt, *cloud);
      *cloud = *inputt;
      pcl::removeNaNFromPointCloud(*cloud, *idx_valid);
//      ROS_INFO_STREAM(idx_valid->size()<<" from "<<cloud->size()) ;

      RosTimeBegin = ros::Time::now();
      
      	cup_dim_.radius 	= 0.01;
	cup_dim_.lengthen	= 0.0;
	cup_dim_.height		= 0.01;
	cup_dim_.stroke 	= 0.05;
	cup_dim_.minCurvR	= 0.04;
	cup_dim_.bellows 	= 0.0;
	cup_dim_.bend 		= 0.05;
	
      init_v_stf_Tool2CupBases();
      label->resize(cloud->size());
      trim_x_min= cloud->width, trim_y_min= cloud->height;
    }
    
    void setInputCloud (pcl::PointCloud<pcl::PointXYZ>::Ptr inputt)
    {
      cloud = inputt; 
      pcl::removeNaNFromPointCloud(*cloud, *idx_valid);
    }
    
    bool calc_norm()
    {
      normal_estimator.setInputCloud (cloud);
      normal_estimator.useSensorOriginAsViewPoint ();
      normal_estimator.compute (*normals);     
    }
     
    bool combine_cloud_normal()
    {	
//      *cloud_with_normals = pcl::PointCloud<pcl::PointNormal>(); 
      cloud_with_normals->clear();
      pcl::copyPointCloud(*cloud, *cloud_with_normals);
      pcl::copyPointCloud(*normals, *cloud_with_normals); 
      return 1;
    }
    
    bool combine_cloud_normal(pcl::PointCloud<pcl::PointXYZ>::ConstPtr cloud_in, pcl::PointCloud<pcl::Normal>::ConstPtr norms_in, pcl::PointCloud<pcl::PointNormal>::Ptr cloud_out)
    {	
//      pcl::PointCloud<pcl::PointNormal>::Ptr cloud_with_normals2; 
      //*cloud_with_normals = pcl::PointCloud<pcl::PointNormal>(); 
      cloud_out->clear();
      pcl::copyPointCloud(*cloud_in, *cloud_out);
      pcl::copyPointCloud(*norms_in, *cloud_out); 
      //cloud_out = cloud_with_normals2;
      return 1;
    }


#if 0
    void init_NormalSphere()
    {
      NSphere_bin_count.resize(NSphere_binSizeSum[NSphere_binPhyMax+1],0.0);
      NSphere_bin_list.resize(NSphere_binSizeSum[NSphere_binPhyMax+1],pcl::IndicesPtr());
      NSphere_bin_label.resize(NSphere_binSizeSum[NSphere_binPhyMax+1],0);
      NSphere_bin_coreV.resize(NSphere_binSizeSum[NSphere_binPhyMax+1]);
      
      for (uint i = 0; i<= NSphere_binPhyMax; i++)
      {
	for (uint j = NSphere_binSizeSum[i]; j<NSphere_binSizeSum[i+1]; j++)
	{
	  NSphere_bin_center[j][0] = M_PI - i*10.0*M_PI/180.0;
	  NSphere_bin_center[j][1] = 2.0*M_PI/NSphere_binSize[i]*(j-NSphere_binSizeSum[i]);
	}
	
      }

      for (uint i = 0; i<NSphere_binSizeSum[NSphere_binPhyMax+1]; i++)	// in table_frame
      {
	float phi = NSphere_bin_center[i][0], theta = NSphere_bin_center[i][1];
	NSphere_bin_coreV[i] = tf::Point(cos(theta)*sin(phi),sin(theta)*sin(phi),cos(phi));
      }
      
    }
    
    uint count_binNormalSphere(float phi10 , float theta, size_t Pid)
    {
    
	uint phi_ = floor(phi10);	// step, 
	float phi_b = phi10-phi_; float phi_a = 1-phi_b;	// weight for bin a and b
	//27° ~ 2, a:0.3->(20°), b:0.7->(30°)
	//2° ~ 0, a:0.8->(0°), b:0.2->(10°)
//   	ROS_INFO_STREAM(phi10<<" "<<phi_<<" "<<phi_a<<" "<<phi_b);
 	if(phi10 < NSphere_binPhyMax+0.5)	
	  NSphere_allsum += 1;

	if(phi_ == 0)	// -5°~5°, 5°~15°
	{
	  NSphere_bin_count[0] += phi_a;
// 	    ROS_INFO_STREAM(phi_a);
	  
	  float theta60 = (theta / 60.0);
	  uint theta_ = floor(theta60);	// 0,1,2,3,4,5
	  float theta_b = theta60-theta_; float theta_a = 1-theta_b;	// weight for bin a and b
	  NSphere_bin_count[1+theta_] += phi_b*theta_a;
	  NSphere_bin_count[1+(theta_+1)%6] += phi_b*theta_b;
// 	    ROS_INFO_STREAM(1+theta_<<" "<<phi_b*theta_a<<" "<<1+(theta_+1)%6<<" "<<phi_b*theta_b);
	  
// 	  binNSphere_list[0]->push_back(Pid);
	}
	else if (phi_ == NSphere_binPhyMax)	// largest phi 
	{
	  float thetaX = (theta / (360.0/NSphere_binSize[phi_]));
	  uint theta_ = floor(thetaX);	// binIndex 0,1,2,3,4,5....
	  float theta_b = thetaX-theta_; float theta_a = 1-theta_b;	// weight for bin a and b
	  NSphere_bin_count[NSphere_binSizeSum[phi_]+theta_] += theta_a;
	  NSphere_bin_count[NSphere_binSizeSum[phi_]+(theta_+1)%NSphere_binSize[phi_]] += theta_b;
	} 
	else	// 
	{
	  float thetaX = (theta / (360.0/NSphere_binSize[phi_]));
	  uint theta_ = floor(thetaX);	// binIndex 0,1,2,3,4,5
	  float theta_b = thetaX-theta_; float theta_a = 1-theta_b;	// weight for bin a and b
	  NSphere_bin_count[NSphere_binSizeSum[phi_]+theta_] += phi_a*theta_a;
	  NSphere_bin_count[NSphere_binSizeSum[phi_]+(theta_+1)%NSphere_binSize[phi_]] += phi_a*theta_b;
// 	    ROS_INFO_STREAM(theta60<<" "<<theta_<<" "<<theta_a<<" "<<theta_b);
	  
	  thetaX = (theta / (360.0/NSphere_binSize[phi_+1]));
	  theta_ = floor(thetaX);	// binIndex 0,1,2,3,4,5,..11
	  theta_b = thetaX-theta_; theta_a = 1-theta_b;	// weight for bin a and b
	  NSphere_bin_count[NSphere_binSizeSum[phi_+1]+theta_] += phi_b*theta_a;
	  NSphere_bin_count[NSphere_binSizeSum[phi_+1]+(theta_+1)%NSphere_binSize[phi_+1]] += phi_b*theta_b;
// 	    ROS_INFO_STREAM(theta30<<" "<<theta_<<" "<<theta_a<<" "<<theta_b);
	}
	

	
	return 1;
    }
    
    
    void calc_NormalSphere()
    {
      calc_NormalSphere(normals);
    }
    
    void calc_NormalSphere(pcl::PointCloud<pcl::Normal>::ConstPtr normals_loc)
    {
      for (size_t i = 0; i < normals_loc->size() ; ++i)
      {
#if 0
	// use vector
	tf::Point N = tf::Point(normals->points[i].normal_x,normals->points[i].normal_y,normals->points[i].normal_z);
	
	float ang = pcl::rad2deg(tf::tfAngle(binNSphere_coreV[j],N));	// in degree : ang(°)
	if (ang>15)
	  break;
	else if (ang<5)
	  binNSphere_count += 1.0;
	else
#endif
	// use phi theta
// 	tf::Point N = tf::Point(normals->points[i].normal_x,normals->points[i].normal_y,normals->points[i].normal_z);
	float phi10 = 18.0-acos(normals_loc->points[i].normal_z) *18/M_PI;				// in 10degree : (*10°) , mostly will point to negative in table_frame
	if (isnan(phi10)||phi10>(NSphere_binPhyMax+0.5)) continue;
	float theta = atan2(normals_loc->points[i].normal_y,normals_loc->points[i].normal_x) *180/M_PI; // in degree : (°), -180°~180°
	if (theta<0) theta += 360;	// in degree : (°), 0°~360°
	
//   	ROS_INFO_STREAM(phi10<<" "<<theta);
	count_binNormalSphere(phi10, theta, i);
      }
      
    }    
    
    void calc_NormalSphere(const pcl::IndicesPtr normals_idx)
    {
      for (size_t ii = 0; ii < normals_idx->size() ; ++ii)
      {
	size_t i = normals_idx->at(ii);
#if 0
	// use vector
	tf::Point N = tf::Point(normals->points[i].normal_x,normals->points[i].normal_y,normals->points[i].normal_z);
	
	float ang = pcl::rad2deg(tf::tfAngle(binNSphere_coreV[j],N));	// in degree : ang(°)
	if (ang>15)
	  break;
	else if (ang<5)
	  binNSphere_count += 1.0;
	else
#endif
	// use phi theta
// 	tf::Point N = tf::Point(normals->points[i].normal_x,normals->points[i].normal_y,normals->points[i].normal_z);
	float phi10 = 18.0-acos(normals->points[i].normal_z) *18/M_PI;				// in 10degree : (*10°) , mostly will point to negative in table_frame
	if (isnan(phi10)||phi10>(NSphere_binPhyMax+0.5)) continue;
	float theta = atan2(normals->points[i].normal_y,normals->points[i].normal_x) *180/M_PI; // in degree : (°), -180°~180°
	if (theta<0) theta += 360;	// in degree : (°), 0°~360°
	
//   	ROS_INFO_STREAM(phi10<<" "<<theta);
	count_binNormalSphere(phi10, theta, i);
      }
      
    }
    
    bool label_NormalSphere_bin(uint binN, uint current_label, float bigbin_pct, tf::Point &viewAng, int depth)	//return the block and list of all cloud inside
    {
//       std::cout<<binN <<" : ";
      if (depth <= 0) return false;
      if (NSphere_bin_label[binN]!=0) 					return false;	// already registered
      if (NSphere_bin_count[binN]/NSphere_allsum < 0.1*bigbin_pct)	return false;	// is smaller than 5%
      if (NSphere_bin_count[binN]/NSphere_allsum < 0.7*bigbin_pct)	depth --;   
         
      NSphere_bin_label[binN] = current_label;
      viewAng = viewAng + NSphere_bin_coreV[binN]*NSphere_bin_count[binN];
      
      if (binN == 0)
      {
	label_NormalSphere_bin(1 , current_label, bigbin_pct, viewAng, depth);
	label_NormalSphere_bin(2 , current_label, bigbin_pct, viewAng, depth);
	label_NormalSphere_bin(3 , current_label, bigbin_pct, viewAng, depth);
	label_NormalSphere_bin(4 , current_label, bigbin_pct, viewAng, depth);
	label_NormalSphere_bin(5 , current_label, bigbin_pct, viewAng, depth);
	label_NormalSphere_bin(6 , current_label, bigbin_pct, viewAng, depth);
      }
      else
      {
	uint phi_ = std::upper_bound(NSphere_binSizeSum.begin(),NSphere_binSizeSum.end(), binN) - NSphere_binSizeSum.begin() -1;
	uint theta_ = binN - NSphere_binSizeSum[phi_];	float theta = (float)theta_ / NSphere_binSize[phi_];
 	
// 	std::cout<<binN <<' '<< phi_<<' '<< theta_<<" "<<NSphere_binSize[phi_]<<"\n";
	
	label_NormalSphere_bin(NSphere_binSizeSum[phi_]+(NSphere_binSize[phi_]+theta_-1)%NSphere_binSize[phi_], current_label, bigbin_pct, viewAng, depth);
	label_NormalSphere_bin(NSphere_binSizeSum[phi_]+(theta_+1)%NSphere_binSize[phi_], current_label, bigbin_pct, viewAng, depth);
	theta_ = floor(theta * NSphere_binSize[phi_-1]); 
	label_NormalSphere_bin(NSphere_binSizeSum[phi_-1]+(theta_)%NSphere_binSize[phi_-1], current_label, bigbin_pct, viewAng, depth);
	theta_ = ceil(theta * NSphere_binSize[phi_-1]); 
	label_NormalSphere_bin(NSphere_binSizeSum[phi_-1]+(theta_)%NSphere_binSize[phi_-1], current_label, bigbin_pct, viewAng, depth);
	theta_ = floor(theta * NSphere_binSize[phi_+1]);
	label_NormalSphere_bin(NSphere_binSizeSum[phi_+1]+(theta_)%NSphere_binSize[phi_+1], current_label, bigbin_pct, viewAng, depth);
	theta_ = ceil(theta * NSphere_binSize[phi_+1]);
	label_NormalSphere_bin(NSphere_binSizeSum[phi_+1]+(theta_)%NSphere_binSize[phi_+1], current_label, bigbin_pct, viewAng, depth);
	
      }

      return true;
    }
    
    uint get_clusterNormalSphere ()	// returns where most normals point towards
    {
      std::cout << "cluster"<<std::endl;
      std::vector<int> binNSphere_count_sort(NSphere_bin_count.size());
      std::size_t n(0);
      std::generate(std::begin(binNSphere_count_sort), std::end(binNSphere_count_sort), [&]{ return n++; });
      
      std::sort(  std::begin(binNSphere_count_sort), 
		  std::end(binNSphere_count_sort),
		  [&](int i1, int i2) { return NSphere_bin_count[i1] > NSphere_bin_count[i2]; } );    
      
      
      float bigbin_pct = NSphere_bin_count[binNSphere_count_sort[0]]/NSphere_allsum;
      float threadhold_expand  = 0.1 * bigbin_pct;
      float threadhold_cound_as_root = std::max(0.05, 2.0*threadhold_expand);
      
      
      float binSum_tmp = 0.0;
      uint bin83 = 0;
      for (bin83 = 0; bin83<binNSphere_count_sort.size(); bin83++)
      {
	uint v = binNSphere_count_sort[bin83];
	float portion = NSphere_bin_count[v]/NSphere_allsum;
	binSum_tmp += portion;
	if (portion< threadhold_cound_as_root) break;		// break if grow too slow (4% or less)
	
	std::cout<< std::fixed << std::setprecision(2)<<"bin."<< v << "\tcount = "<<NSphere_bin_count[v] <<" ~ "<<binSum_tmp*100<<"%\tphi = "<<NSphere_bin_center[v][0]*180/M_PI<<"\ttheta = "<<NSphere_bin_center[v][1]*180/M_PI<<'\n';
	if (binSum_tmp > 0.95) break;
      }
//       binNSphere_count_sort.erase(binNSphere_count_sort.begin()+bin83,binNSphere_count_sort.end());
      // sort all bins
      
      NSphere_viewAngles = {tf::Point(0,0,1)};
      NSphere_viewAngles_stf = { tf::StampedTransform(tf::Transform(q_u, -1 * v3_001), ros::Time::now(), "/table_frame", "/PjPl/0")};
      
      
      
      
      uint labelX = 1;
      /*
      for (uint i = 0; i < bin83; i++)		// larger angle tolorrance, lower demand for expanding
      {
	tf::Point viewAng = tf::Point(0,0,0);
	if (label_NormalSphere_bin(binNSphere_count_sort[i],labelX, bigbin_pct, viewAng,10)) 	
	{
	  std::cout<<"view "<<labelX<<" : "<<binNSphere_count_sort[i]<<"\n";
	  	  
	  viewAng.normalize();
	  NSphere_viewAngles.push_back(viewAng);
	  
	  float phi = asin(viewAng.z()), theta = atan2(viewAng.y(),viewAng.x()); 
	  tf::Transform oA (tf::Quaternion(tf::Vector3(0,0,1), theta) * tf::Quaternion(tf::Vector3(0,1,0), 1.5*M_PI-phi) , viewAng);
	  NSphere_viewAngles_stf.push_back( tf::StampedTransform(oA, ros::Time::now(), "/table_frame", "/PjPl/" + std::to_string(labelX)) );
	  
	  
	  labelX++;
	}
      }
      for (uint bb = 0; bb < NSphere_bin_label.size(); bb++) 	NSphere_bin_label[bb] = 0; 
      */
      for (uint i = 0; i < bin83; i++)		// smaller angle tolorrance, higher demand expanding
      {
	tf::Point viewAng = tf::Point(0,0,0);
	if (label_NormalSphere_bin(binNSphere_count_sort[i],labelX, bigbin_pct, viewAng,2)) 
	{
	  std::cout<<"view "<<labelX<<" : "<<binNSphere_count_sort[i]<<"\n";
	  	  
	  viewAng.normalize();
	  NSphere_viewAngles.push_back(viewAng);
	  
	  float phi = asin(viewAng.z()), theta = atan2(viewAng.y(),viewAng.x()); 
	  tf::Transform oA (tf::Quaternion(tf::Vector3(0,0,1), theta) * tf::Quaternion(tf::Vector3(0,1,0), 1.5*M_PI-phi) , viewAng);
	  NSphere_viewAngles_stf.push_back( tf::StampedTransform(oA, ros::Time::now(), "/table_frame", "/PjPl/" + std::to_string(labelX)) );
	  
	  
	  labelX++;
	}
	
      }
      
      
      return 0;
    }
#endif
      
      
#if 0        
    uint get_ProjectplainMapPcl (uint viewAngleN, pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_Pjr, float threathhold_angle = M_PI/18)	// returns an image of projected points with samilar normals to normal on normalsphere
    {
//       ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   projection - "<<viewAngleN);
      
      float threathhold_cos = cos(threathhold_angle);
      //resolution_projection; 
//       tf::Point vA = NSphere_viewAngles[viewAngleN];

      //tf::Quaternion oA (1,0,0,0);
//       float phi = asin(vA.z()), theta = atan2(vA.y(),vA.x()); 
      
      tf::Point pA (NSphere_viewAngles_stf[viewAngleN].getOrigin().normalized());
      tf::Quaternion qA (NSphere_viewAngles_stf[viewAngleN].getRotation());
      tf::Transform oA (qA.inverse(),v3_000);
      
      tf::Point pMC (oA * massCenter); 	pMC.setZ(0);
//       oA = tf::Transform(qA.inverse(),pMC);
      
      std::vector< std::pair <int, int> > mapList;
//      mapList.push_back(std::make_pair());		// projection of mass center
      
      int mapXmin=32767,mapXmax=-32767,mapYmin=32767,mapYmax=-32767;
      float z_min = 0; 
      for (size_t i : *idx_inlander)
      {
	pcl::Normal PN_pcl = normals->points[i];
	tf::Point PN (PN_pcl.normal_x,PN_pcl.normal_y,PN_pcl.normal_z);
	if (tf::tfDot(PN,pA) > threathhold_cos)	// if angles are close	//////////////shall relate to cup_dim
	{ 
	  pcl::PointXYZ P_pcl = cloud->points[i];
	  tf::Point P (P_pcl.x,P_pcl.y,P_pcl.z);
	  tf::Point xy = oA * P;
	  
	  int x = round(xy.x()/resolution_projection);
	  if (x < mapXmin) mapXmin = x;	  if (x > mapXmax) mapXmax = x;
	  int y = round(xy.y()/resolution_projection);
	  if (y < mapYmin) mapYmin = y;	  if (y > mapYmax) mapYmax = y;
	  
	  float z = xy.z();
	  if (z < z_min) z_min = z;
	  
	  mapList.push_back(std::make_pair (x, y));
	}
      }
      pA = -z_min * pA; 
//       NSphere_viewAngles_stf[viewAngleN].setOrigin(pA-pMC);
      NSphere_viewAngles_stf[viewAngleN].setOrigin(pA);
      
//       std::set< std::pair <int, int> > s ( mapList.begin(), mapList.end() );
//       mapList.assign( s.begin(), s.end() );
      
      size_t count = 0;
      pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_Pj (new pcl::PointCloud<pcl::PointXYZ>);
      cloud_Pjr->clear();
      
      int Xs = (mapXmax-mapXmin+1), Ys = (mapYmax-mapYmin+1);
      cloud_Pj->width = Xs;	cloud_Pjr->width = Xs;
      cloud_Pj->height = Ys;	cloud_Pjr->height = Ys;
//       cloud_Pj->resize(Xs*Ys);
      for (size_t i = 0; i<Xs*Ys; i++) 
      {
	cloud_Pj->points.push_back(PointXYZ_nan);
	cloud_Pjr->points.push_back(PointXYZ_nan);
      }
      for (auto Pt :  mapList)
      {
	int xx (Pt.first-mapXmin), yy (Pt.second-mapYmin);
	if (isnan(cloud_Pj->at(xx, yy).x))
	{
	  pcl::PointXYZ Ppj(Pt.first*resolution_projection, Pt.second*resolution_projection,0);
	  cloud_Pj->points[yy*Xs+xx] = Ppj;
	  count ++;
	}
      }
      
      pcl::IndicesPtr pointIdxInander_pp (new std::vector <int>);
      
      for (int x = 1; x<Xs-1; x++)
      for (int y = 1; y<Ys-1; y++)
      {	 
	size_t i = y*Xs+x;
	if (!isnan(cloud_Pj->points[i].x))
	{
	  int i1 = i-1, i2 = i+1, i3 = i-Xs, i4 = i+Xs;
	  if (!isnan(cloud_Pj->points[i1].x)&&!isnan(cloud_Pj->points[i2].x)&&!isnan(cloud_Pj->points[i3].x)&&!isnan(cloud_Pj->points[i4].x))
	  {
	    pointIdxInander_pp->push_back(i);	
	    cloud_Pjr->points[i] = cloud_Pj->points[i];
	  } 
	}	
      }

      
      
      cloud_Pjr->sensor_origin_ = Eigen::Vector4f(pA.x(),pA.y(),pA.z(),1.0);
      cloud_Pjr->sensor_orientation_ = Eigen::Quaternionf(qA.w(),qA.x(),qA.y(),qA.z());
      
//       *cloud_Pjr = *cloud_Pj;
      
//       std::cout << "projected to viewAngle "<< viewAngleN << " : " << count << " points \n";
      
      return mapList.size();
    }
    
    class iterator_O
    {
      public:
	float phy;	// atan2(dy,dx) slope of the two points
	int dx, dy;	// vector of p1p2, x2-x1,y2-y1
	float cosP, sinP;
	float dx05, dy05;    
	
	iterator_O(float _phy, int _dx, int _dy, float _cosP, float _sinP): phy(_phy), dx(_dx), dy(_dy), cosP(_cosP), sinP(_sinP)
	{
	  dx05 = 0.5*dx;	  dy05 = 0.5*dy;
	}
	
	iterator_O(int _dx, int _dy): dx(_dx), dy(_dy)
	{
	  phy = atan2(dy, dx);
	  cosP = cos(phy);	  sinP = sin(phy);
	  dx05 = 0.5*dx;	  dy05 = 0.5*dy;
	}      
    };
    
    std::vector<iterator_O> nominate__v_iterator_O;	// iterate half a circle
    
    class pair_by_iterator
    {
      public:
	uint itX;	// iterator
	float mx, my;	// vector of p1p2, x2-x1,y2-y1
	float d0M_pl;	// distance from (0,0) to perpendicular bisector (folding line)
	float d0M_pd;	// distance from (0,0) to the line p1p2
	uint xy1, xy2;
	
	pair_by_iterator(uint _itX, iterator_O it, int _ix1, int _iy1, uint _xy1, uint _xy2): itX(_itX), xy1(_xy1), xy2(_xy2)
	{
	  mx = it.dx05+_ix1;	my = it.dy05+_iy1;
	  d0M_pl = it.cosP*mx + it.sinP*my;
	  d0M_pd = -it.sinP*mx + it.cosP*my;
	}
    };
    
    uint nominate__set_v_iterator_O(float cfgY, std::vector<iterator_O> &v_iterator_O)
    {
      float R = cfgY/resolution_projection;
            
      float dt = asin(0.5/R);
      float theta(0.0);

      float dxx, dyy;

      v_iterator_O.clear();
#if 0
            
      int dx_c = 32767, dy_c = 32767;
      int dx_cc, dy_cc;
      int dx_f = 32767, dy_f = 32767;
      int dx_ff, dy_ff;
      
      while (theta < M_PI)
      {
	dxx = R*cos(theta); dyy = R*sin(theta);
	
	dx_cc = (dxx>=0)?ceil(dxx):floor(dxx);	
	dy_cc = (dyy>=0)?ceil(dyy):floor(dyy);
	  
	if ((dx_cc != dx_c) || (dy_cc != dy_c))
	{
	  dx_c = dx_cc;
	  dy_c = dy_cc;
	  v_iterator_O.push_back(iterator_O(dx_c,dy_c));
	  std::cout<<dx_cc<<","<<dy_cc <<"\n";
	}
	
	dx_ff = (int)dxx;	dy_ff = (int)dyy; 
	if ((dx_ff != dx_f) || (dy_ff != dy_f))
	{
	  dx_f = dx_ff;
	  dy_f = dy_ff;
	  v_iterator_O.push_back(iterator_O(dx_f,dy_f));
	  std::cout<<dx_ff<<","<<dy_ff <<"\n";	  
	}
	
	theta += dt;
      }
#else
      int dx_r = 32767, dy_r = 32767;
      int dx_rr, dy_rr;
      while (theta < M_PI)
      {
	dxx = R*cos(theta); dyy = R*sin(theta);
	
	dx_rr = round(dxx);	
	dy_rr = round(dyy);
	if (dx_rr<0 && dy_rr==0) break;
	if ((dx_rr != dx_r) || (dy_rr != dy_r))
	{
	  dx_r = dx_rr;
	  dy_r = dy_rr;
	  v_iterator_O.push_back(iterator_O(dx_r,dy_r));
//  	  std::cout<<dx_r<<","<<dy_r <<"\n";	  
	  
	}
	
	theta += dt;
      }
#endif
//       std::cout<<"v_iteratorO with "<< v_iterator_O.size() <<" vectors \n";	
    }
    
    uint nominate__searchPairs(pcl::PointCloud<pcl::PointXYZ>::ConstPtr cloud_Pjr, std::vector<iterator_O> v_iterator_O, std::vector <pair_by_iterator> &v_Pairs)
    {
      uint W = cloud_Pjr->width, H = cloud_Pjr->height;
      v_Pairs.clear();
      
      for (size_t iy = 0; iy<H; iy++)
      for (size_t ix = 0; ix<W; ix++)
      {
	uint xy = ix + iy*W;
	if (isnan(cloud_Pjr->at(xy).x)) continue;
	  
	for (uint it = 0; it < v_iterator_O.size(); it++)
	{
	  auto iterator = v_iterator_O[it];
	  uint ix2 = ix+iterator.dx , iy2 = iy+iterator.dy;
	  if ((ix2<0)||(ix2>=W)||(iy2>=H)) continue;	// out of range
	  uint xy2 =  ix2 + iy2*W;
	  if (isnan(cloud_Pjr->at(xy2).x)) continue;
// 	  std::cout<<ix <<","<< iy <<" - "<< ix2 <<","<< iy2 <<"\n";	
	  v_Pairs.push_back(pair_by_iterator(it, iterator, ix, iy,xy,xy2));
	  
	}
      }
      
      std::sort(v_Pairs.begin(), v_Pairs.end(), [](pair_by_iterator P1, pair_by_iterator P2) 
	    { return (P1.itX < P2.itX); } );
    }
    
    uint nominate__find_RectPair(std::vector<iterator_O> v_iterator_O, std::vector <pair_by_iterator> v_Pairs, std::vector < std::pair <int, int> > &v_RectPair, float cfgX_min, float R)
    {
      v_RectPair.clear();
      v_RectPair.push_back(std::make_pair(0,0));
      
      float X_min = cfgX_min/resolution_projection;
      
      float theta_limit = 5.0*deg2rad;		// tolorrance of 5°
//       std::cout<<"theta_limit = "<<theta_limit*rad2deg<<"°\n";
      
      for (uint i1 = 0; i1 < v_Pairs.size(); i1++)
      {
	
// 	std::cout<<"\n Pr "<< i1 <<" has neibours : ";
	
	pair_by_iterator Pr1 = v_Pairs[i1];
	
	uint d0M_pd_min = i1, d0M_pd_max = i1;
	
	std::vector <uint> v_PairIdx_sort {i1};
	
	uint i2 = i1; 
	while (1)
	{
	  i2 = (i2 + 1)%v_Pairs.size();
	  pair_by_iterator Pr2 = v_Pairs[i2];
	  int d_itX = abs(Pr2.itX - Pr1.itX+v_iterator_O.size())%v_iterator_O.size();
	  if (d_itX > 1) break;	// it~it2 are the region with same phy

	  v_PairIdx_sort.push_back(i2);
	}	  // it~it2 are the region with similar phy
	
	uint i11 = (i2 > i1)?i2:32767;
	
	while (1)
	{
	  i2 = (i2 + 1)%v_Pairs.size();
	  pair_by_iterator Pr2 = v_Pairs[i2];
	  float d_phy = fmod((v_iterator_O[Pr2.itX].phy - v_iterator_O[Pr1.itX].phy + M_PI),M_PI);
	  if (d_phy > theta_limit) break;	// it~it2 are the region with similar phy*/
// 	  int d_itX = abs(Pr2.itX - Pr1.itX+v_iterator_O.size())%v_iterator_O.size();
// 	  if (d_itX > 2) break;	// it~it2 are the region with similar phy
// 	  std::cout << i2 <<" ";

 	    v_PairIdx_sort.push_back(i2);
	}	  // it~it2 are the region with similar phy
	
// 	std::cout <<v_iterator_O[ v_Pairs[v_PairIdx_sort.back()].itX].phy*rad2deg<<"°  " << v_PairIdx_sort.size()<<"\n";
	if (v_PairIdx_sort.size() < 2) break;
	
	std::sort(  std::begin(v_PairIdx_sort), 
		    std::end(v_PairIdx_sort),
		    [&](int ii1, int ii2) { return v_Pairs[ii1].d0M_pl < v_Pairs[ii2].d0M_pl; } );    
	
// 	for (auto xx : v_PairIdx_sort) 	  std::cout << xx <<" ";
	
	// region i1~i2
	// looking for min-max pair-pairs (a rectangle)
	
	uint idx_pd_min = 0, idx_pd_max = 0;
	uint j1 = 0, j2 = 1;
	while (j2 < v_PairIdx_sort.size())
	{
	  const float j1_pl = v_Pairs[v_PairIdx_sort[j1]].d0M_pl;	  const float j2_pl = v_Pairs[v_PairIdx_sort[j2]].d0M_pl;
	  const float j1_pd = v_Pairs[v_PairIdx_sort[j1]].d0M_pd;	  const float j2_pd = v_Pairs[v_PairIdx_sort[j2]].d0M_pd;
	  
	  
	  if (j2_pl-j1_pl > 1)		// d0M_pl difference over 1 pixels, this region finished
	  {
	    
	    float dif_pd_minmax = fabs(v_Pairs[v_PairIdx_sort[idx_pd_max]].d0M_pd-v_Pairs[v_PairIdx_sort[idx_pd_min]].d0M_pd);
	    if (dif_pd_minmax > X_min)		// cfgX is big enough 
	    {
	      auto rt_back = v_RectPair.back();
	      if (rt_back.first != v_PairIdx_sort[idx_pd_min] || rt_back.second != v_PairIdx_sort[idx_pd_max])	// if not already detected
	      {
		const float idx_min_phy= v_iterator_O[v_Pairs[v_PairIdx_sort[idx_pd_min]].itX].phy;
		const float back_phy= v_iterator_O[v_Pairs[rt_back.first].itX].phy;
		const bool phy_diff = fabs(back_phy - idx_min_phy) > M_PI/12.0;			// exclude those with similar phy
		const float idx_min_pl = v_Pairs[v_PairIdx_sort[idx_pd_min]].d0M_pl;
		const float back_pl = v_Pairs[rt_back.first].d0M_pl;
		const bool d0M_pl_diff = fabs(back_pl - idx_min_pl) > 10;			// exclude those with similar d0M_pl
		if (phy_diff || d0M_pl_diff || v_RectPair.size() == 1) 						// if not similar -> nominate a new one	
		{
		  v_RectPair.push_back(std::make_pair(v_PairIdx_sort[idx_pd_min], v_PairIdx_sort[idx_pd_max]));
// 		  std::cout <<"     ["<< v_PairIdx_sort[idx_pd_min] <<" "<< v_PairIdx_sort[idx_pd_max] << "]\t"<<idx_min_phy*rad2deg<<"   "<<idx_min_pl<<"   "<<dif_pd_minmax<<"\n";		  
		}
		else									// if similar -> take the one with larger diff_pd
		{
		  float dif_pd_back = v_Pairs[rt_back.second].d0M_pd-v_Pairs[rt_back.first].d0M_pd;
		  if (dif_pd_minmax > dif_pd_back)
		  {
		    v_RectPair.pop_back();
		    v_RectPair.push_back(std::make_pair(v_PairIdx_sort[idx_pd_min], v_PairIdx_sort[idx_pd_max]));
// 		    std::cout <<"        {"<< v_PairIdx_sort[idx_pd_min] <<" "<< v_PairIdx_sort[idx_pd_max] << "}\t"<<idx_min_phy*rad2deg<<"   "<<idx_min_pl<<"   "<<dif_pd_minmax<<"\n";	
		  }
		}
	      }
	    }
	    
	    j1 ++;	// j1 = j2;
// 	    j1 = std::max(j1+1, std::min(idx_pd_min, idx_pd_max));
	    j2 = j1+1;
	    idx_pd_max = j1; 
	    idx_pd_min = j1; 
	  }
	  else 
	  {
	    if (j2_pd < v_Pairs[v_PairIdx_sort[idx_pd_min]].d0M_pd) idx_pd_min = j2;
	    if (j2_pd > v_Pairs[v_PairIdx_sort[idx_pd_max]].d0M_pd) idx_pd_max = j2;	  
	    j2++;
	  }
// 	  std::cout << j1 <<" "<< j2 << "\t";

	}
	
	if (i11>i1)	i1 = i11;
	else 		break;
      }    
      
      ////////////////////////////////////// all rectangles found
      
//       std::cout<<"\nall nominees:\n";
      for (auto it : v_RectPair) std::cout<<"\t["<<it.first<<" "<<it.second<< "]\t"<< v_iterator_O[v_Pairs[it.second].itX].phy * rad2deg<<"°\n";
      
    }
    
    uint nominate__RectPair_to_stf_table2cupbase0(float cfgZ, uint pr1, uint pr2, std::vector <pair_by_iterator> v_Pairs, std::vector<iterator_O> v_iterator_O, pcl::PointCloud<pcl::PointXYZ>::ConstPtr cloud_Pjr, float &cfgX, tf::StampedTransform &stf_table2cupbase0)
    {
      
      uint i = 37;
      
      tf::Point table_pjpl_v3 (cloud_Pjr->sensor_origin_[0], cloud_Pjr->sensor_origin_[1], cloud_Pjr->sensor_origin_[2]);
      tf::Quaternion table_pjpl_q (cloud_Pjr->sensor_orientation_.x(),cloud_Pjr->sensor_orientation_.y(),cloud_Pjr->sensor_orientation_.z(),cloud_Pjr->sensor_orientation_.w());
  
      tf::Transform tf_table_pjpl (table_pjpl_q, table_pjpl_v3);
      
      uint i1(v_Pairs[pr1].xy1),i2(v_Pairs[pr1].xy2),i3(v_Pairs[pr2].xy1),i4(v_Pairs[pr2].xy2);
//        ROS_INFO_STREAM(" "<<pr1<<" "<<pr2<<" ");
    
      pcl::PointXYZ pt1 = cloud_Pjr->at(i1),
		    pt2 = cloud_Pjr->at(i2),
		    pt3 = cloud_Pjr->at(i3),
		    pt4 = cloud_Pjr->at(i4);
		    
		    
      float cfgX2 = sqrt((pt1.x-pt3.x)*(pt1.x-pt3.x)+(pt1.y-pt3.y)*(pt1.y-pt3.y));
      float cfgX3 = sqrt((pt2.x-pt4.x)*(pt2.x-pt4.x)+(pt2.y-pt4.y)*(pt2.y-pt4.y));
      cfgX = 0.5*(cfgX2+cfgX3);
      
      float mx = 0.25* (pt1.x+pt2.x+pt3.x+pt4.x);
      float my = 0.25* (pt1.y+pt2.y+pt3.y+pt4.y);
      float theta = atan2((pt1.y+pt2.y-pt3.y-pt4.y),(pt1.x+pt2.x-pt3.x-pt4.x));
      tf::Quaternion q (v3_001, theta);
      
//       set_v_stf_Tool2CupBases_cfgXYZ(cfgX, cfgY, 0.01);
      tf::Transform tf_pjpl2cupbase0 (q, tf::Point(mx,my,-cfgZ));
//       stf_table2cupbase0.setRotation(q);
//       stf_table2cupbase0.setOrigin(tf::Point(mx,my,-get_stf_Tool2CupBases(1).getOrigin().z()));
            
      stf_table2cupbase0.child_frame_id_ = "/grip/"+std::to_string(i);
      stf_table2cupbase0.frame_id_ = "/table_frame";
      stf_table2cupbase0.stamp_ = ros::Time::now();
      stf_table2cupbase0.setData(tf_table_pjpl*tf_pjpl2cupbase0);
      
      
//       ROS_INFO_STREAM(" "<<mx<<" "<<my<<" "<<theta<< " " <<cfgX<<" " <<cfgX2<<" "<<cfgX3);
    }
  
    uint nominate__RectPair_to_msg_grip_tfs_cfg(float cfgY, float cfgZ, uint pr1, uint pr2, std::vector <pair_by_iterator> v_Pairs, std::vector<iterator_O> v_iterator_O, pcl::PointCloud<pcl::PointXYZ>::ConstPtr cloud_Pjr, yf_pcl_process::msg_grip_tfs_cfg &msg_grip_candidate)
    {
      tf::StampedTransform stf_tmp;
      float cfgX_out;
      
      nominate__RectPair_to_stf_table2cupbase0(cfgZ, pr1, pr2, v_Pairs, v_iterator_O,cloud_Pjr, cfgX_out, stf_tmp);
      msg_grip_candidate.cfgX = cfgX_out;	
      msg_grip_candidate.cfgY = cfgY;		
      msg_grip_candidate.cfgZ = cfgZ;		//////////////////////
      tf::transformStampedTFToMsg( stf_tmp , msg_grip_candidate.tfs_tabel2cupbase0 );
    }  
    
    uint nominate__get_v_grip_nominees_Rect_PjPl_cfgY(float cfgY, uint PjPl_N, pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_Pjr, std::vector< yf_pcl_process::msg_grip_tfs_cfg > &v_grip_nominees)	// nominate cadidates of grip stf according to projectplain
    {    
      float cfgX_min = 0.04;
      nominate__get_v_grip_nominees_Rect_PjPl_cfgY(cfgY, PjPl_N, cloud_Pjr, v_grip_nominees, cfgX_min, 0);
    }
    
    uint nominate__get_v_grip_nominees_Rect_PjPl_cfgY(float cfgY, uint PjPl_N, pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_Pjr, std::vector< yf_pcl_process::msg_grip_tfs_cfg > &v_grip_nominees, float cfgX_min, float cfgZ)	// nominate cadidates of grip stf according to projectplain
    {
      std::cout<<"nominating grips for Project Plain"<< PjPl_N <<"\n";
      
      get_ProjectplainMapPcl(PjPl_N, cloud_Pjr, M_PI/180*20);
      
      ////////////////////////////////////////////////////// constructing iterator
      uint W = cloud_Pjr->width, H = cloud_Pjr->height;
      
//       float cfgY(0.05), cfgX_min(0.05), cfgZ(0.01);

      float R = cfgY/resolution_projection; float X_min = cfgX_min/resolution_projection;
//       std::cout<<"'R = "<< R <<"\n";
//       std::vector<iterator_O> v_iterator_O;	// iterate half a circle

//       nominate__set_v_iterator_O(cfgY, v_iterator_O);
      if (nominate__v_iterator_O.size() == 0)
	nominate__set_v_iterator_O(cfgY, nominate__v_iterator_O);
      
      ////////////////////////////////////////////////////////// searching for pairs 

      std::vector <pair_by_iterator> v_Pairs {};
      nominate__searchPairs(cloud_Pjr, nominate__v_iterator_O, v_Pairs);
//       std::cout << v_Pairs.size() <<" pairs of points with distance R =cfgY = "<<cfgY<<"\n";
      /////////////////////////////////////////////////////////////// all pairs stored in v_l_Pairs
      
      std::vector <std::pair <int, int> > v_RectPair {std::make_pair(0,0)};
      nominate__find_RectPair(nominate__v_iterator_O, v_Pairs, v_RectPair, cfgX_min, R);
      ///////////////////////////////////////////////////////////////////// found all rectangles as candidates
      
      
      float cfgX_out;
      
      set_v_stf_Tool2CupBases_tfBase0(tf::Transform(tf::Quaternion(v3_100, M_PI/4), 0.1*v3_001));
//       set_v_stf_Tool2CupBases_cfgZ(0.03);
      yf_pcl_process::msg_grip_tfs_cfg msg_grip_candidate;
      for (auto it: v_RectPair)
      {
	nominate__RectPair_to_msg_grip_tfs_cfg(cfgY, cfgZ, it.first, it.second, v_Pairs, nominate__v_iterator_O,cloud_Pjr, msg_grip_candidate);
	v_grip_nominees.push_back(msg_grip_candidate);
      }
	
    }
    
    
    uint nominate__get_v_grip_nominees_Rect_all_cfgY(float cfgY, float cfgX_min, float cfgZ, std::vector< yf_pcl_process::msg_grip_tfs_cfg > &v_grip_nominees)
    {

      init_v_stf_Tool2CupBases();
      pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_pj (new pcl::PointCloud<pcl::PointXYZ>);

      for (uint PjPl_N = 1; PjPl_N < NSphere_viewAngles_stf.size(); PjPl_N++)
      {
	nominate__get_v_grip_nominees_Rect_PjPl_cfgY(cfgY, PjPl_N, cloud_pj, v_grip_nominees, cfgX_min, cfgZ);
      }
    }
    
#endif
    
    
    
    tf::Point calc_massCenter()
    {
//       pcl::removeNaNFromPointCloud(*cloud, *idx_valid);
      return calc_massCenter(cloud);
    }    
    
    tf::Point calc_massCenter(pcl::PointCloud<pcl::PointXYZ>::ConstPtr cloud_raw)
    {
      tf::Point CM(0,0,0);
      float countValid(0);
      
      pcl::PointXYZ p;
      for (size_t i = 0; i < cloud_raw->size(); i++)
      {
	float wight_xy = (normals->points[i].normal_z);
	p = cloud_raw->points[i];
	if (isnan(p.x) || isnan(wight_xy)) continue;
	countValid += wight_xy; // 1.0;
	CM = CM + wight_xy * tf::Point(p.x, p.y, 0.5*p.z);
      }
      
      std::cout<<countValid<<'\n';
	
      CM = CM / countValid;
      massCenter = CM;
      
      std::cout<<"Center of Mass : "<< CM.x()<<" "<< CM.y()<<" "<< CM.z()<<" \n";
      
      return CM;
    }
    
    bool save2_pcd()
    {
     pcl::io::savePCDFileASCII ("test_pcd.pcd", *cloud);
//      std::cerr << "Saved " << cloud_with_normals->points.size () << " data points to test_pcd.pcd." << std::endl;
    }
        
    bool save2_pcd_inlander()
    {
     pcl::io::savePCDFileASCII ("cloud_inlander.pcd", *cloud_inlander);
//      std::cerr << "Saved " << cloud_with_normals->points.size () << " data points to test_pcd.pcd." << std::endl;
    }
    
    void setCupDim(uint cupN_)
    {
      ros::NodeHandle priv_nh("~");
      std::string s_param = ("/cups/" + std::to_string(cupN_));
      if (cupN_ != 0)
      {
	if (	priv_nh.getParam(s_param+"/name",   cup_dim_.name)
	    && 	priv_nh.getParam(s_param+"/radius", cup_dim_.radius)
	    && 	priv_nh.getParam(s_param+"/lengthen", cup_dim_.lengthen)
	    && 	priv_nh.getParam(s_param+"/height", cup_dim_.height)
	    && 	priv_nh.getParam(s_param+"/stroke", cup_dim_.stroke)
	    && 	priv_nh.getParam(s_param+"/minCurvR", cup_dim_.minCurvR)
	    && 	priv_nh.getParam(s_param+"/bellows", cup_dim_.bellows)
	    && 	priv_nh.getParam(s_param+"/bend", cup_dim_.bend)) 
	{}
// 	  ROS_INFO_STREAM("load config '"<< s_param <<"'") ;
      }	
      else
      {
	cup_dim_.radius 	= 0.01;
	cup_dim_.lengthen	= 0.0;
	cup_dim_.height		= 0.01;
	cup_dim_.stroke 	= 0.05;
	cup_dim_.minCurvR	= 0.04;
	cup_dim_.bellows 	= 0.0;
	cup_dim_.bend 		= 0.05;
      }
      
      v_cup_dim_N.resize(5, cupN_);
      v_cup_dim.resize(5, cup_dim_);
    }    
        
    void setCupDim1234(uint cupN1_,uint cupN2_,uint cupN3_,uint cupN4_)
    {
      v_cup_dim_N.resize(5);
      v_cup_dim_N[1] = (cupN1_);
      v_cup_dim_N[2] = (cupN2_);
      v_cup_dim_N[3] = (cupN3_);
      v_cup_dim_N[4] = (cupN4_);
      
      v_cup_dim.resize(5, cup_dim_);
      v_cup_dim[1] = getCupDim(cupN1_);
      v_cup_dim[2] = getCupDim(cupN2_);
      v_cup_dim[3] = getCupDim(cupN3_);
      v_cup_dim[4] = getCupDim(cupN4_);
    }    
    
    yf_vacuum_cups::cup_dim getCupDim(uint cupN_)
    {
      ros::NodeHandle priv_nh("~");
      yf_vacuum_cups::cup_dim cupDim_2;
      std::string s_param = ("/cups/" + std::to_string(cupN_));
      if (cupN_ != 0)
      {
	if (	priv_nh.getParam(s_param+"/name",   cupDim_2.name)
	    && 	priv_nh.getParam(s_param+"/radius", cupDim_2.radius)
	    && 	priv_nh.getParam(s_param+"/lengthen", cupDim_2.lengthen)
	    && 	priv_nh.getParam(s_param+"/height", cupDim_2.height)
	    && 	priv_nh.getParam(s_param+"/stroke", cupDim_2.stroke)
	    && 	priv_nh.getParam(s_param+"/minCurvR", cupDim_2.minCurvR)
	    && 	priv_nh.getParam(s_param+"/bellows", cupDim_2.bellows)
	    && 	priv_nh.getParam(s_param+"/bend", cupDim_2.bend)) 
	{}
// 	  ROS_INFO_STREAM("load config '"<< s_param <<"'") ;
      }	
      else
      {
	cupDim_2.radius 	= 0.01;
	cupDim_2.lengthen	= 0.0;
	cupDim_2.height		= 0.01;
	cupDim_2.stroke 	= 0.05;
	cupDim_2.minCurvR	= 0.04;
	cupDim_2.bellows 	= 0.0;
	cupDim_2.bend 		= 0.05;
      }
      return cupDim_2;
    }
    
    bool get_Table(tf::Point &N_table0, float &d_table0)
    {
      float vox_r = 0.01f;
      
    ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   vox - ");
      pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_vox (new pcl::PointCloud<pcl::PointXYZ>);
      pcl::VoxelGrid<pcl::PointXYZ> sor;
      sor.setInputCloud (cloud);
      sor.setLeafSize (vox_r, vox_r, vox_r);
      sor.filter (*cloud_vox);
    ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   vox - finished");  
	
    
    ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   sac on vox - ");
      pcl::ModelCoefficients::Ptr vox_plane_coef (new pcl::ModelCoefficients);
      pcl::PointIndices::Ptr vox_plane_inliers (new pcl::PointIndices);
      pcl::PointCloud<pcl::PointXYZ>::Ptr outliers (new pcl::PointCloud<pcl::PointXYZ>);

      pcl::SACSegmentation<pcl::PointXYZ> segv;
      segv.setOptimizeCoefficients (true);
      segv.setModelType (pcl::SACMODEL_PLANE);
      segv.setMethodType (pcl::SAC_RANSAC);
      segv.setDistanceThreshold (0.02);
      segv.setMaxIterations(200);
      segv.setInputCloud (cloud_vox);
      segv.segment (*vox_plane_inliers, *vox_plane_coef);
      N_table0 = (tf::Point(vox_plane_coef->values[0],vox_plane_coef->values[1],vox_plane_coef->values[2])); d_table0 = vox_plane_coef->values[3];
    ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   sac on vox - finished"); 
    }
    
    tf::StampedTransform get_TfS_Sensor2Table()
    {
//       return tf::StampedTransform(tf_Sensor2Table, ros::Time::now(), "/camera_depth_optical_frame", "/table_frame");
      return stf_Sensor2Table;
    }
    
    tf::StampedTransform get_TfS_Sensor2Table(tf::Point &N_table0, float &d_table0) 
    {
      set_Tf_Sensor2Table(N_table0, d_table0);
//       return tf::StampedTransform(tf_Sensor2Table, ros::Time::now(), "/camera_depth_optical_frame", "/table_frame");
      return stf_Sensor2Table;
    }

    
    tf::Transform set_Tf_Sensor2Table(tf::Point &N_table0, float &d_table0) 
    {
      //tf_Sensor2Table.setIdentity();
      pcl::ModelCoefficients::Ptr coefficients_plane (new pcl::ModelCoefficients);

      N_table = N_table0; d_table=d_table0;
      tf::Point Pxyz = tf::Point(0,0,(float)-d_table0/N_table0.z());
      tf::Point Pnorm = N_table0;
      if (tf::tfDot(Pnorm,Pxyz)<0.0) 	Pnorm = -Pnorm;
      
      tf::Quaternion q;
      tf::Vector3 v;
//       tf::Point e_x (tf::Point(1,0,0)); tf::Point e_z (tf::Point(0,0,1));
      v = tf::tfCross(Pnorm,v3_001);    v.normalize();
      q = tf::Quaternion(v, -1.0*tf::tfAngle(Pnorm, v3_001)); 
      v = tf::quatRotate(q, v3_100); v.setZ(0);
      if (tf::tfDot(tf::tfCross(v3_100, v),Pnorm)>0.0)
	q = q*tf::Quaternion(v3_001, -1.0*tf::tfAngle(v3_100, v)); 
      else
	q = q*tf::Quaternion(v3_001, +1.0*tf::tfAngle(v3_100, v));
      //q.normalize();

      tf_Sensor2Table = tf::Transform(q,Pxyz);
      stf_Sensor2Table = tf::StampedTransform(tf_Sensor2Table, ros::Time::now(), "/camera_depth_optical_frame", "/table_frame");
      tf_Table2Sensor = tf_Sensor2Table.inverse();      
      stf_Table2Sensor = tf::StampedTransform(tf_Table2Sensor, ros::Time::now(), "/table_frame", "/camera_depth_optical_frame");
      
      return tf_Sensor2Table;
    }

    bool relocateCloud_toTableFrame(bool trimUnderTable) 			// this could be improved to be faster
    {    
      ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   relocate - ");
//       idx_valid->clear();
      pcl_ros::transformPointCloud(*cloud, *cloud, tf_Table2Sensor);
      if (trimUnderTable)
      {	for (size_t i = 0; i < cloud->size() ; ++i)
	  if ( cloud->points[ i ].z > 0.001 )
	    cloud->points[ i ] = PointXYZ_nan;
// 	  else
// 	    idx_valid.push_back(i);
      }
      tf::Quaternion q(tf_Table2Sensor.getRotation());
      tf::Point p(tf_Table2Sensor.getOrigin());
      
      cloud->sensor_origin_ = Eigen::Vector4f(p.x(),p.y(),p.z(),1.0);
      cloud->sensor_orientation_ = Eigen::Quaternionf(q.w(),q.x(),q.y(),q.z());
       
      normal_estimator.setViewPoint(p.x(),p.y(),p.z());
      ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   relocate - fin");  
      return true;
    }
      
    bool label_object_onTable(int x, int y, uint current_label, uint Pid_old = 0)	//return the block and list of all cloud inside
    {
//       ROS_INFO_STREAM(x<<"-"<<y);
      
      uint W (cloud->width), H (cloud->height); 
      if (x < 0 || x >= W) return false; // out of bounds
      if (y < 0 || y >= H) return false; // out of bounds
      
      uint Pid = y*W+x;
      if (label->points[Pid].label!=0) return false;	// already registered
      if (isnan(cloud->points[Pid].x)) 			// is nan
      {
	label->points[Pid_old].label = 127;
      	return false;
      }
      
      tf::Point pt (tf::Point(cloud->points[Pid].x,cloud->points[Pid].y,cloud->points[Pid].z));
      if ( (tf::tfDot(pt,N_table)+d_table)>-0.003 ) 	// under table
      {
	label->points[Pid_old].label = 127;
	return false;
      }
      
      if (x>trim_x_max) trim_x_max= x;
      if (x<trim_x_min) trim_x_min= x;
      if (y>trim_y_max) trim_y_max= y;
      if (y<trim_y_min) trim_y_min= y;
      
      label->points[Pid].label = current_label;
      
      label_object_onTable(x-1, y , current_label,Pid);
      label_object_onTable(x+1, y , current_label,Pid);
      label_object_onTable(x, y-1 , current_label,Pid);
      label_object_onTable(x, y+1 , current_label,Pid);
      
      return true;
    }
      
    void trim_cloud_label()	//return the block and list of all cloud inside
    {
      int W (cloud->width), H (cloud->height); 
      int W2 (trim_x_max-trim_x_min+1), H2 (trim_y_max-trim_y_min+1); 
      if (W2<0) return;

      ROS_INFO_STREAM(trim_x_min<<"-"<<trim_x_max<<" ; "<<trim_y_min<<"-"<<trim_y_max);
      pcl::PointCloud<pcl::PointXYZ>::Ptr cloud2 (new pcl::PointCloud<pcl::PointXYZ>);
      idx_valid->clear();
      cloud2->width = W2; cloud2->height = H2;
      uint ID = 0;
      for (uint y=trim_y_min; y<=trim_y_max; y++)
	for (uint x=trim_x_min; x<=trim_x_max; x++)
	{
	  uint Pid = y*W+x;
	  if (label->points[Pid].label ==0) 
	    cloud2->points.push_back(PointXYZ_nan);
	  else
	  {
	    if (label->points[Pid].label ==127) 
	      idx_border->push_back(ID);
	    cloud2->points.push_back(cloud->points[Pid]);
	    idx_valid->push_back(ID);
	  }
	  ID ++;
	}
	  
//       for (uint i=0; i<cloud->size(); i++) if (label->points[i].label ==0) cloud->points[i]= PointXYZ_nan; 
       ROS_INFO_STREAM(cloud2->size()<<" points in cloud with "<<idx_valid->size()<<" valid points");

      cloud->clear();
      *cloud = *cloud2;
    }
      
    bool calc_border_inlander(float curv_Mx_in = 0.004, float borderRadius = 0.008)	///////////////////////////////////////////
    {
    
//	pcl::copyPointCloud(*cloud, *cloud_inlander);
	*cloud_inlander = *cloud;
	idx_inlander->clear();
	
	curv_Mx = curv_Mx_in;
	
	tree_inlander.setInputCloud(cloud_inlander);
		//	better be place somewhere else as well, in case calc_border_inlander is skiped
	
	
	for (size_t i = 0; i < cloud->size (); ++i)
	{
	  if (!isnan(cloud->points[i].x))
	  if ((normals->points[i].curvature > curv_Mx))		// curvature = dT/ds ~=	theta*1/ds ~ 1/R
	  {
	    idx_border->push_back(i);
	    //cloud_border->push_back(cloud->points[i]);
	  }
	}
	std::cout<<"border contains "<<idx_border->size()<<std::endl;
	
//       ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   filtering - big curvature extracted");
	
	for (size_t i = 0; i < idx_border->size (); ++i)
	{
	  //if (!isnan(cloud->points[idx_border->at(i)].x))		// curvature = dT/ds ~=	theta*1/ds ~ 1/R
	  {
	  
	    std::vector<float> pointRadiusSquaredDistanceInlander;
	    pcl::IndicesPtr pointIdxInander (new std::vector <int>);
	    if ( tree_inlander.radiusSearch (cloud->points[idx_border->at(i)], borderRadius, *pointIdxInander, pointRadiusSquaredDistanceInlander) > 0 )
	    {
    //	  std::cout<<tree.radiusSearch (cloud->points[i], 0.016, *pointIdxInander, pointRadiusSquaredDistanceInlander)<<" ";
	      uint cur_over_count  = 0;
	      for (size_t ii = 0; ii < pointIdxInander->size (); ++ii)
	      {
		//idx_inlander->push_back(pointIdxInander->at(ii));
		cloud_inlander->points[ pointIdxInander->at(ii) ] = PointXYZ_nan;		// temporary set points inner-rim to nan
	      }
	    }
	    
	  }
	    //cloud_lN->points.push_back(normals->points[ (*idx_find_out)[i] ]);
	}
	
// 	pcl::removeNaNFromPointCloud(*cloud_inlander, *idx_inlander);
	for (size_t i = 0; i < cloud_inlander->size (); ++i)
	{
	  if (!isnan(cloud_inlander->at(i).x)) idx_inlander->push_back(i);
	}
	
	std::cout<<"inlanders contains "<<idx_inlander->size()<<std::endl;

//       ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   filtering - fin");
	      
    }
    
    pcl::PointCloud<pcl::PointXYZ>::Ptr get_cloud_border()
    {
      pcl::copyPointCloud(*cloud, *idx_border, *cloud_border);
      return cloud_border;
    }
    
    void set_stf_Table2Tool (tf::Transform tf_)
    {
      stf_Table2Tool = tf::StampedTransform(tf_, ros::Time::now(), "/table_frame", "/tool_frame");
    }   
    
    void set_stf_Table2Tool (tf::StampedTransform stf_)
    {
      stf_Table2Tool = tf::StampedTransform(stf_, ros::Time::now(), "/table_frame", "/tool_frame");
      //stf_Table2Tool = stf_;
    }
    
    void init_v_stf_Tool2CupBases()		// set_v_stf_Tool2CupBases
    {
      v_stf_Tool2CupBases.resize(5);
      set_v_stf_Tool2CupBases(tf::Transform(q_u,tf::Point(0,0,0.1)), 0.1,0.07,0.01);
    }

    void set_v_stf_Tool2CupBases(tf::Transform tf_tool2cupbase0, float cfgX, float cfgY = 0.07, float cfgZ = 0.01)		// set_v_stf_Tool2CupBases
    {
      v_stf_Tool2CupBases.resize(5);
      
      set_v_stf_Tool2CupBases_tfBase0(tf_tool2cupbase0);
      set_v_stf_Tool2CupBases_cfgXYZ(cfgX,cfgY,cfgZ);
      
//       float cfgX2(fabs(cfgX)/2.0), cfgY2(fabs(cfgY/2.0));
//       v_stf_Tool2CupBases[0] = tf::StampedTransform(tf_tool2cupbase0, ros::Time::now(),"/tool_frame","/cupbase_frame/0");	// suction orientation ref
//       v_stf_Tool2CupBases[1] = tf::StampedTransform(tf::Transform(q_u,tf::Point(-cfgX2,-cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/1");
//       v_stf_Tool2CupBases[2] = tf::StampedTransform(tf::Transform(q_u,tf::Point(-cfgX2, cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/2");
//       v_stf_Tool2CupBases[3] = tf::StampedTransform(tf::Transform(q_u,tf::Point( cfgX2,-cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/3");
//       v_stf_Tool2CupBases[4] = tf::StampedTransform(tf::Transform(q_u,tf::Point( cfgX2, cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/4");
    }
    
    void set_v_stf_Tool2CupBases_tfBase0(tf::Transform tf_tool2cupbase0)		// set_v_stf_Tool2CupBases
    {
//       v_stf_Tool2CupBases.resize(5);
      v_stf_Tool2CupBases[0] = tf::StampedTransform(tf_tool2cupbase0, ros::Time::now(),"/tool_frame","/cupbase_frame/0");	// suction orientation ref
    }
    
    void set_v_stf_Tool2CupBases_cfgXYZ(float cfgX, float cfgY, float cfgZ)		// set_v_stf_Tool2CupBases
    {
//       v_stf_Tool2CupBases.resize(5);
      float cfgX2(fabs(cfgX)/2.0), cfgY2(fabs(cfgY/2.0));
      v_stf_Tool2CupBases[1] = tf::StampedTransform(tf::Transform(q_u,tf::Point(-cfgX2,-cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/1");
      v_stf_Tool2CupBases[2] = tf::StampedTransform(tf::Transform(q_u,tf::Point(-cfgX2, cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/2");
      v_stf_Tool2CupBases[3] = tf::StampedTransform(tf::Transform(q_u,tf::Point( cfgX2,-cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/3");
      v_stf_Tool2CupBases[4] = tf::StampedTransform(tf::Transform(q_u,tf::Point( cfgX2, cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/4");
    }
    
    void set_v_stf_Tool2CupBases_cfgXY(float cfgX, float cfgY)		// set_v_stf_Tool2CupBases
    {
//       v_stf_Tool2CupBases.resize(5);
//       float cfgX2(fabs(cfgX)/2.0), cfgY2(fabs(cfgY/2.0));
      float cfgZ = v_stf_Tool2CupBases[1].getOrigin().z();
      set_v_stf_Tool2CupBases_cfgXYZ(cfgX,cfgY,cfgZ);
//       v_stf_Tool2CupBases[1] = tf::StampedTransform(tf::Transform(q_u,tf::Point(-cfgX2,-cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/1");
//       v_stf_Tool2CupBases[2] = tf::StampedTransform(tf::Transform(q_u,tf::Point(-cfgX2, cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/2");
//       v_stf_Tool2CupBases[3] = tf::StampedTransform(tf::Transform(q_u,tf::Point( cfgX2,-cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/3");
//       v_stf_Tool2CupBases[4] = tf::StampedTransform(tf::Transform(q_u,tf::Point( cfgX2, cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/4");
    }
    
    void set_v_stf_Tool2CupBases_cfgX(float cfgX)		// set_v_stf_Tool2CupBases
    {
//       v_stf_Tool2CupBases.resize(5);
      float cfgY = fabs(2.0*v_stf_Tool2CupBases[1].getOrigin().y());
//       float cfgX2(fabs(cfgX)/2.0), cfgY2(fabs(cfgY));
      float cfgZ = v_stf_Tool2CupBases[1].getOrigin().z();
      set_v_stf_Tool2CupBases_cfgXYZ(cfgX,cfgY,cfgZ);
//       v_stf_Tool2CupBases[1] = tf::StampedTransform(tf::Transform(q_u,tf::Point(-cfgX2,-cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/1");
//       v_stf_Tool2CupBases[2] = tf::StampedTransform(tf::Transform(q_u,tf::Point(-cfgX2, cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/2");
//       v_stf_Tool2CupBases[3] = tf::StampedTransform(tf::Transform(q_u,tf::Point( cfgX2,-cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/3");
//       v_stf_Tool2CupBases[4] = tf::StampedTransform(tf::Transform(q_u,tf::Point( cfgX2, cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/4");
    }
    
    void set_v_stf_Tool2CupBases_cfgZ(float cfgZ)		// set_v_stf_Tool2CupBases
    {
//       v_stf_Tool2CupBases.resize(5);
      float cfgX = fabs(2.0*v_stf_Tool2CupBases[1].getOrigin().x());
      float cfgY = fabs(2.0*v_stf_Tool2CupBases[1].getOrigin().y());
      set_v_stf_Tool2CupBases_cfgXYZ(cfgX,cfgY,cfgZ);
//       float cfgX2(fabs(cfgX)), cfgY2(fabs(cfgY));
//       v_stf_Tool2CupBases[1] = tf::StampedTransform(tf::Transform(q_u,tf::Point(-cfgX2,-cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/1");
//       v_stf_Tool2CupBases[2] = tf::StampedTransform(tf::Transform(q_u,tf::Point(-cfgX2, cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/2");
//       v_stf_Tool2CupBases[3] = tf::StampedTransform(tf::Transform(q_u,tf::Point( cfgX2,-cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/3");
//       v_stf_Tool2CupBases[4] = tf::StampedTransform(tf::Transform(q_u,tf::Point( cfgX2, cfgY2,cfgZ)), ros::Time::now(),"/cupbase_frame/0","/cupbase_frame/4");
    }
    
    tf::StampedTransform get_stf_Tool2CupBases(uint i)		// set_v_stf_Tool2CupBases
    {
      if (i<0 || i>5) return v_stf_Tool2CupBases[0];
      v_stf_Tool2CupBases[i].stamp_ = ros::Time::now();
      tf::StampedTransform stf_tmp(v_stf_Tool2CupBases[0]*v_stf_Tool2CupBases[i], ros::Time::now(),"/tool_frame","/cupbase_frame/"+std::to_string(i));
      return stf_tmp;
    }
        
    yf_vacuum_cups::msg_cup_draw genDrawMsg(const uint cupid_, const tf::StampedTransform stf_table2tool, const tf::StampedTransform stf_tool2cup, const uint cupN_= 0) 
    {
      
    }
    
    yf_vacuum_cups::msg_cup_draw genDrawMsg(const uint cupid_, const tf::StampedTransform stf_, const uint cupN_= 0) 
    {
      yf_vacuum_cups::msg_cup_draw cupDraw_msg;
      cupDraw_msg.cupId = cupid_; 
      tf::transformStampedTFToMsg(stf_, cupDraw_msg.transformstamped);    
      cupDraw_msg.cupN = cupN_;
      return cupDraw_msg;
    }
    
    yf_vacuum_cups::msg_cup_draw genDrawMsg(const uint cupid_, const tf::Transform tf_, const uint cupN_= 0) 
    {
      yf_vacuum_cups::msg_cup_draw cupDraw_msg;
      tf::StampedTransform stf_ = (tf::StampedTransform(tf_, ros::Time::now(), "/table_frame", "/cups_frame/"+std::to_string(cupid_)));
      cupDraw_msg.cupId = cupid_; 
      tf::transformStampedTFToMsg(stf_, cupDraw_msg.transformstamped);    
      cupDraw_msg.cupN = cupN_;
      return cupDraw_msg;
    }
    
    void draw_norm_mordel( pcl::PointNormal searchPointNorm, tf::Point N_axis, tf::Point K, pcl::ModelCoefficients::ConstPtr coefficients_cylinder , visualization_msgs::Marker &cylin, visualization_msgs::Marker &sPnorm)
    {     
      ROS_INFO_STREAM("draw_norm_mordel") ;
//      ros::NodeHandle priv_nh("~");
//      ros::Publisher vis_pub = priv_nh.advertise<visualization_msgs::Marker>( "cup_vis2", 10 , true);
      
      tf::Point vTmp; tf::Quaternion q;
//      visualization_msgs::Marker cylin, sPnorm;
      cylin.header.frame_id = sPnorm.header.frame_id = "/table_frame";
      cylin.header.stamp = sPnorm.header.stamp 	= ros::Time::now();
      cylin.ns = sPnorm.ns  =  "sucker";
      cylin.action = sPnorm.action = visualization_msgs::Marker::ADD;
      cylin.id = 9; sPnorm.id = 10;
      cylin.type = visualization_msgs::Marker::CYLINDER;
      cylin.scale.x =coefficients_cylinder->values[6]*2;	cylin.scale.y = coefficients_cylinder->values[6]*2; 	cylin.scale.z = 0.1;
      cylin.color.r = 0.7;	cylin.color.g = 0.7;	cylin.color.b = 0.7;	cylin.color.a = 0.3;
      sPnorm.type = visualization_msgs::Marker::ARROW;
      sPnorm.scale.x = 0.002;	sPnorm.scale.y = 0.004;		sPnorm.scale.z = 0.0;
      sPnorm.color.r = 1.0;	sPnorm.color.g = 0.0;		sPnorm.color.b = 0.8;		sPnorm.color.a = 0.8;
      geometry_msgs::Pose pose1;
      tf::Transform tf_d1;
      tf_d1.setOrigin(K);
      vTmp = N_axis.cross(v3_001);
      vTmp.normalize();
      q = tf::Quaternion(vTmp, -1.0*acos(N_axis.dot(v3_001)/N_axis.length ())); //////////////////
      tf_d1.setRotation(q);
      tf::poseTFToMsg(tf_d1, pose1);
      cylin.pose = pose1;
      
      geometry_msgs::Point searchPointMsg,searchPointMsg2;
      searchPointMsg.x = searchPointNorm.x; searchPointMsg.y = searchPointNorm.y; searchPointMsg.z = searchPointNorm.z;
      searchPointMsg2.x=searchPointNorm.x+searchPointNorm.normal_x*0.02; searchPointMsg2.y=searchPointNorm.y+searchPointNorm.normal_y*0.02; searchPointMsg2.z=searchPointNorm.z+searchPointNorm.normal_z*0.02;
      sPnorm.points.push_back(searchPointMsg);    
      sPnorm.points.push_back(searchPointMsg2); 
  
//      vis_pub.publish(cylin);
//      vis_pub.publish(sPnorm);
      
//       ros::spin();
    }
    
     void draw_CenterOfMass(visualization_msgs::Marker &CM)
    {     
      ROS_INFO_STREAM("draw_CenterOfMass") ;
      
      float r1 = 0.006;
      visualization_msgs::Marker cm;
      cm.header.frame_id = "/table_frame";
      cm.header.stamp 	= ros::Time::now();
      cm.ns  =  "CenterOfMass";
      cm.action = visualization_msgs::Marker::ADD;
      cm.id = 400;
      cm.type = visualization_msgs::Marker::SPHERE;
      cm.scale.x = r1;	cm.scale.y = r1;		cm.scale.z = r1;
      cm.pose.position.x = massCenter.x();
      cm.pose.position.y = massCenter.y();
      cm.pose.position.z = massCenter.z();
      cm.color.r = 1;	cm.color.g = 1;	cm.color.b = 1;	cm.color.a = 1;
      CM = cm;
    }
    
    
    void draw_NormalSphere_projection(std::vector<visualization_msgs::Marker> &porjectionPlain)
    {     
      ROS_INFO_STREAM("draw_NormalSphere_projection") ;
      
      float d1 = 0.2;
      
      for (uint i = 1; i<NSphere_viewAngles_stf.size(); i++)
      {
	visualization_msgs::Marker plainX;
// 	std::string frameName = "/PjPl/" + std::to_string(i);
	std::string frameName = NSphere_viewAngles_stf[i].child_frame_id_;
	plainX.header.frame_id = frameName;
	plainX.header.stamp 	= ros::Time::now();
	plainX.ns  =  "NormalSphere_projection";
	plainX.action = visualization_msgs::Marker::ADD;
	plainX.id = i+300;
	plainX.type = visualization_msgs::Marker::CUBE;
	plainX.scale.x = 0.15;	plainX.scale.y = 0.2;		plainX.scale.z = 0.000;
	if (i == 1)
	  {	plainX.color.r = 1;	plainX.color.g = 0.5;	plainX.color.b = 0.5;	plainX.color.a = 0.15;}
	else if (i == 2)
	  {	plainX.color.r = 1;	plainX.color.g = 1;	plainX.color.b = 0.4;	plainX.color.a = 0.15;}
	else if (i == 3)
	  {	plainX.color.r = 0.5;	plainX.color.g = 1;	plainX.color.b = 0.5;	plainX.color.a = 0.15;}
 	else if (i == 4)
	  {	plainX.color.r = 0.5;	plainX.color.g = 0.5;	plainX.color.b = 1;	plainX.color.a = 0.15;}
	else
	  {	plainX.color.r = 1;	plainX.color.g = 0.4;	plainX.color.b = 1;	plainX.color.a = 0.15;}
	
// 	tf::Point vA = NSphere_viewAngles[i];
	geometry_msgs::Pose P;
	
// 	P.position.x = vA.x() * d1; 
// 	P.position.y = vA.y() * d1;
// 	P.position.z = vA.z() * d1;
	
	tf::Quaternion oA;
	float phi, theta; 
// 	phi = asin(vA.z()); theta = atan2(vA.y(),vA.x()); // 
// 	oA = tf::Quaternion(tf::Vector3(0,0,1), theta) * tf::Quaternion(tf::Vector3(0,1,0), M_PI-phi) ;
// 	P.orientation.x = oA.x();
// 	P.orientation.y = oA.y();
// 	P.orientation.z = oA.z();
// 	P.orientation.w = oA.w();
	
	plainX.pose = P;
	porjectionPlain.push_back(plainX);
      }
    }
    
};

class Cups : public yf_V
{
  
};

class NormalSphere : public yf_V
{  
  public:
    
    uint NSphere_binSize[11] = {1,6,12,18,24,28, 31, 34, 35, 36, 35}; // based on 2*pi*sin(phi)/10° 
    std::vector<uint> NSphere_binSizeSum {0,1,7,19,37,61,89,120,154,189,225,260};
    uint NSphere_binPhyMax = 7;	// x*10°, from 0°~75°, can be changed
    std::vector<float> NSphere_bin_count;		// normals belonging to bin(phi, theta)
    float NSphere_allsum = 0;
    std::vector<pcl::IndicesPtr> NSphere_bin_list;		// list of all points (idx) whose normals belonging to bin(phi, theta)
//     tf::Point NSphere_bin_coreV[260];	// unit vectors of the core of each bin // in table_frame
    std::vector<tf::Point> NSphere_bin_coreV;
    float NSphere_bin_center[260][2];	// bin(phi, theta)
    std::vector<uint> NSphere_bin_label;	// bin(label)
    

    NormalSphere()
    {};
    
    NormalSphere(yf_V &V_)
    {
      this->cloud = V_.cloud;
      this->normals = V_.normals;
      this->cloud_with_normals = V_.cloud_with_normals;
      this->cloud_border = V_.cloud_border;
      this->cloud_inlander = V_.cloud_inlander;
      this->idx_valid = V_.idx_valid;
      this->idx_border = V_.idx_border;
      this->idx_inlander = V_.idx_inlander;

      this->stf_Table2Tool = V_.stf_Table2Tool;

    };
  
    
    void init_NormalSphere()
    {
      NSphere_bin_count.resize(NSphere_binSizeSum[NSphere_binPhyMax+1],0.0);
      NSphere_bin_list.resize(NSphere_binSizeSum[NSphere_binPhyMax+1],pcl::IndicesPtr());
      NSphere_bin_label.resize(NSphere_binSizeSum[NSphere_binPhyMax+1],0);
      NSphere_bin_coreV.resize(NSphere_binSizeSum[NSphere_binPhyMax+1]);
      
      for (uint i = 0; i<= NSphere_binPhyMax; i++)
      {
	for (uint j = NSphere_binSizeSum[i]; j<NSphere_binSizeSum[i+1]; j++)
	{
	  NSphere_bin_center[j][0] = M_PI - i*10.0*M_PI/180.0;
	  NSphere_bin_center[j][1] = 2.0*M_PI/NSphere_binSize[i]*(j-NSphere_binSizeSum[i]);
	}
	
      }

      for (uint i = 0; i<NSphere_binSizeSum[NSphere_binPhyMax+1]; i++)	// in table_frame
      {
	float phi = NSphere_bin_center[i][0], theta = NSphere_bin_center[i][1];
	NSphere_bin_coreV[i] = tf::Point(cos(theta)*sin(phi),sin(theta)*sin(phi),cos(phi));
      }
      
    }
    
    uint count_binNormalSphere(float phi10 , float theta, size_t Pid)
    {
    
	uint phi_ = floor(phi10);	// step, 
	float phi_b = phi10-phi_; float phi_a = 1-phi_b;	// weight for bin a and b
	//27° ~ 2, a:0.3->(20°), b:0.7->(30°)
	//2° ~ 0, a:0.8->(0°), b:0.2->(10°)
//   	ROS_INFO_STREAM(phi10<<" "<<phi_<<" "<<phi_a<<" "<<phi_b);
 	if(phi10 < NSphere_binPhyMax+0.5)	
	  NSphere_allsum += 1;

	if(phi_ == 0)	// -5°~5°, 5°~15°
	{
	  NSphere_bin_count[0] += phi_a;
// 	    ROS_INFO_STREAM(phi_a);
	  
	  float theta60 = (theta / 60.0);
	  uint theta_ = floor(theta60);	// 0,1,2,3,4,5
	  float theta_b = theta60-theta_; float theta_a = 1-theta_b;	// weight for bin a and b
	  NSphere_bin_count[1+theta_] += phi_b*theta_a;
	  NSphere_bin_count[1+(theta_+1)%6] += phi_b*theta_b;
// 	    ROS_INFO_STREAM(1+theta_<<" "<<phi_b*theta_a<<" "<<1+(theta_+1)%6<<" "<<phi_b*theta_b);
	  
// 	  binNSphere_list[0]->push_back(Pid);
	}
	else if (phi_ == NSphere_binPhyMax)	// largest phi 
	{
	  float thetaX = (theta / (360.0/NSphere_binSize[phi_]));
	  uint theta_ = floor(thetaX);	// binIndex 0,1,2,3,4,5....
	  float theta_b = thetaX-theta_; float theta_a = 1-theta_b;	// weight for bin a and b
	  NSphere_bin_count[NSphere_binSizeSum[phi_]+theta_] += theta_a;
	  NSphere_bin_count[NSphere_binSizeSum[phi_]+(theta_+1)%NSphere_binSize[phi_]] += theta_b;
	} 
	else	// 
	{
	  float thetaX = (theta / (360.0/NSphere_binSize[phi_]));
	  uint theta_ = floor(thetaX);	// binIndex 0,1,2,3,4,5
	  float theta_b = thetaX-theta_; float theta_a = 1-theta_b;	// weight for bin a and b
	  NSphere_bin_count[NSphere_binSizeSum[phi_]+theta_] += phi_a*theta_a;
	  NSphere_bin_count[NSphere_binSizeSum[phi_]+(theta_+1)%NSphere_binSize[phi_]] += phi_a*theta_b;
// 	    ROS_INFO_STREAM(theta60<<" "<<theta_<<" "<<theta_a<<" "<<theta_b);
	  
	  thetaX = (theta / (360.0/NSphere_binSize[phi_+1]));
	  theta_ = floor(thetaX);	// binIndex 0,1,2,3,4,5,..11
	  theta_b = thetaX-theta_; theta_a = 1-theta_b;	// weight for bin a and b
	  NSphere_bin_count[NSphere_binSizeSum[phi_+1]+theta_] += phi_b*theta_a;
	  NSphere_bin_count[NSphere_binSizeSum[phi_+1]+(theta_+1)%NSphere_binSize[phi_+1]] += phi_b*theta_b;
// 	    ROS_INFO_STREAM(theta30<<" "<<theta_<<" "<<theta_a<<" "<<theta_b);
	}
	

	
	return 1;
    }
    
    
    void calc_NormalSphere()
    {
      calc_NormalSphere(normals);
    }
    
    void calc_NormalSphere(pcl::PointCloud<pcl::Normal>::ConstPtr normals_loc)
    {
      for (size_t i = 0; i < normals_loc->size() ; ++i)
      {
#if 0
	// use vector
	tf::Point N = tf::Point(normals->points[i].normal_x,normals->points[i].normal_y,normals->points[i].normal_z);
	
	float ang = pcl::rad2deg(tf::tfAngle(binNSphere_coreV[j],N));	// in degree : ang(°)
	if (ang>15)
	  break;
	else if (ang<5)
	  binNSphere_count += 1.0;
	else
#endif
	// use phi theta
// 	tf::Point N = tf::Point(normals->points[i].normal_x,normals->points[i].normal_y,normals->points[i].normal_z);
	float phi10 = 18.0-acos(normals_loc->points[i].normal_z) *18/M_PI;				// in 10degree : (*10°) , mostly will point to negative in table_frame
	if (isnan(phi10)||phi10>(NSphere_binPhyMax+0.5)) continue;
	float theta = atan2(normals_loc->points[i].normal_y,normals_loc->points[i].normal_x) *180/M_PI; // in degree : (°), -180°~180°
	if (theta<0) theta += 360;	// in degree : (°), 0°~360°
	
//   	ROS_INFO_STREAM(phi10<<" "<<theta);
	count_binNormalSphere(phi10, theta, i);
      }
      
    }    
    
    void calc_NormalSphere(const pcl::IndicesPtr normals_idx)
    {
      for (size_t ii = 0; ii < normals_idx->size() ; ++ii)
      {
	size_t i = normals_idx->at(ii);
#if 0
	// use vector
	tf::Point N = tf::Point(normals->points[i].normal_x,normals->points[i].normal_y,normals->points[i].normal_z);
	
	float ang = pcl::rad2deg(tf::tfAngle(binNSphere_coreV[j],N));	// in degree : ang(°)
	if (ang>15)
	  break;
	else if (ang<5)
	  binNSphere_count += 1.0;
	else
#endif
	// use phi theta
// 	tf::Point N = tf::Point(normals->points[i].normal_x,normals->points[i].normal_y,normals->points[i].normal_z);
	float phi10 = 18.0-acos(normals->points[i].normal_z) *18/M_PI;				// in 10degree : (*10°) , mostly will point to negative in table_frame
	if (isnan(phi10)||phi10>(NSphere_binPhyMax+0.5)) continue;
	float theta = atan2(normals->points[i].normal_y,normals->points[i].normal_x) *180/M_PI; // in degree : (°), -180°~180°
	if (theta<0) theta += 360;	// in degree : (°), 0°~360°
	
//   	ROS_INFO_STREAM(phi10<<" "<<theta);
	count_binNormalSphere(phi10, theta, i);
      }
      
    }
    
    bool label_NormalSphere_bin(uint binN, uint current_label, float bigbin_pct, tf::Point &viewAng, int depth)	//return the block and list of all cloud inside
    {
//       std::cout<<binN <<" : ";
      if (depth <= 0) return false;
      if (NSphere_bin_label[binN]!=0) 					return false;	// already registered
      if (NSphere_bin_count[binN]/NSphere_allsum < 0.1*bigbin_pct)	return false;	// is smaller than 5%
      if (NSphere_bin_count[binN]/NSphere_allsum < 0.7*bigbin_pct)	depth --;   
         
      NSphere_bin_label[binN] = current_label;
      viewAng = viewAng + NSphere_bin_coreV[binN]*NSphere_bin_count[binN];
      
      if (binN == 0)
      {
	label_NormalSphere_bin(1 , current_label, bigbin_pct, viewAng, depth);
	label_NormalSphere_bin(2 , current_label, bigbin_pct, viewAng, depth);
	label_NormalSphere_bin(3 , current_label, bigbin_pct, viewAng, depth);
	label_NormalSphere_bin(4 , current_label, bigbin_pct, viewAng, depth);
	label_NormalSphere_bin(5 , current_label, bigbin_pct, viewAng, depth);
	label_NormalSphere_bin(6 , current_label, bigbin_pct, viewAng, depth);
      }
      else
      {
	uint phi_ = std::upper_bound(NSphere_binSizeSum.begin(),NSphere_binSizeSum.end(), binN) - NSphere_binSizeSum.begin() -1;
	uint theta_ = binN - NSphere_binSizeSum[phi_];	float theta = (float)theta_ / NSphere_binSize[phi_];
 	
// 	std::cout<<binN <<' '<< phi_<<' '<< theta_<<" "<<NSphere_binSize[phi_]<<"\n";
	
	label_NormalSphere_bin(NSphere_binSizeSum[phi_]+(NSphere_binSize[phi_]+theta_-1)%NSphere_binSize[phi_], current_label, bigbin_pct, viewAng, depth);
	label_NormalSphere_bin(NSphere_binSizeSum[phi_]+(theta_+1)%NSphere_binSize[phi_], current_label, bigbin_pct, viewAng, depth);
	theta_ = floor(theta * NSphere_binSize[phi_-1]); 
	label_NormalSphere_bin(NSphere_binSizeSum[phi_-1]+(theta_)%NSphere_binSize[phi_-1], current_label, bigbin_pct, viewAng, depth);
	theta_ = ceil(theta * NSphere_binSize[phi_-1]); 
	label_NormalSphere_bin(NSphere_binSizeSum[phi_-1]+(theta_)%NSphere_binSize[phi_-1], current_label, bigbin_pct, viewAng, depth);
	theta_ = floor(theta * NSphere_binSize[phi_+1]);
	label_NormalSphere_bin(NSphere_binSizeSum[phi_+1]+(theta_)%NSphere_binSize[phi_+1], current_label, bigbin_pct, viewAng, depth);
	theta_ = ceil(theta * NSphere_binSize[phi_+1]);
	label_NormalSphere_bin(NSphere_binSizeSum[phi_+1]+(theta_)%NSphere_binSize[phi_+1], current_label, bigbin_pct, viewAng, depth);
	
      }

      return true;
    }
    
    uint get_clusterNormalSphere ()	// returns where most normals point towards
    {
      std::cout << "cluster"<<std::endl;
      std::vector<int> binNSphere_count_sort(NSphere_bin_count.size());
      std::size_t n(0);
      std::generate(std::begin(binNSphere_count_sort), std::end(binNSphere_count_sort), [&]{ return n++; });
      
      std::sort(  std::begin(binNSphere_count_sort), 
		  std::end(binNSphere_count_sort),
		  [&](int i1, int i2) { return NSphere_bin_count[i1] > NSphere_bin_count[i2]; } );    
      
      
      float bigbin_pct = NSphere_bin_count[binNSphere_count_sort[0]]/NSphere_allsum;
      float threadhold_expand  = 0.1 * bigbin_pct;
      float threadhold_cound_as_root = std::max(0.05, 2.0*threadhold_expand);
      
      
      float binSum_tmp = 0.0;
      uint bin83 = 0;
      for (bin83 = 0; bin83<binNSphere_count_sort.size(); bin83++)
      {
	uint v = binNSphere_count_sort[bin83];
	float portion = NSphere_bin_count[v]/NSphere_allsum;
	binSum_tmp += portion;
	if (portion< threadhold_cound_as_root) break;		// break if grow too slow (4% or less)
	
	std::cout<< std::fixed << std::setprecision(2)<<"bin."<< v << "\tcount = "<<NSphere_bin_count[v] <<" ~ "<<binSum_tmp*100<<"%\tphi = "<<NSphere_bin_center[v][0]*180/M_PI<<"\ttheta = "<<NSphere_bin_center[v][1]*180/M_PI<<'\n';
	if (binSum_tmp > 0.95) break;
      }
//       binNSphere_count_sort.erase(binNSphere_count_sort.begin()+bin83,binNSphere_count_sort.end());
      // sort all bins
      
      NSphere_viewAngles = {tf::Point(0,0,1)};
      NSphere_viewAngles_stf = { tf::StampedTransform(tf::Transform(q_u, -1 * v3_001), ros::Time::now(), "/table_frame", "/PjPl/0")};
      
      
      
      
      uint labelX = 1;
      /*
      for (uint i = 0; i < bin83; i++)		// larger angle tolorrance, lower demand for expanding
      {
	tf::Point viewAng = tf::Point(0,0,0);
	if (label_NormalSphere_bin(binNSphere_count_sort[i],labelX, bigbin_pct, viewAng,10)) 	
	{
	  std::cout<<"view "<<labelX<<" : "<<binNSphere_count_sort[i]<<"\n";
	  	  
	  viewAng.normalize();
	  NSphere_viewAngles.push_back(viewAng);
	  
	  float phi = asin(viewAng.z()), theta = atan2(viewAng.y(),viewAng.x()); 
	  tf::Transform oA (tf::Quaternion(tf::Vector3(0,0,1), theta) * tf::Quaternion(tf::Vector3(0,1,0), 1.5*M_PI-phi) , viewAng);
	  NSphere_viewAngles_stf.push_back( tf::StampedTransform(oA, ros::Time::now(), "/table_frame", "/PjPl/" + std::to_string(labelX)) );
	  
	  
	  labelX++;
	}
      }
      for (uint bb = 0; bb < NSphere_bin_label.size(); bb++) 	NSphere_bin_label[bb] = 0; 
      */
      for (uint i = 0; i < bin83; i++)		// smaller angle tolorrance, higher demand expanding
      {
	tf::Point viewAng = tf::Point(0,0,0);
	if (label_NormalSphere_bin(binNSphere_count_sort[i],labelX, bigbin_pct, viewAng,2)) 
	{
	  std::cout<<"view "<<labelX<<" : "<<binNSphere_count_sort[i]<<"\n";
	  	  
	  viewAng.normalize();
	  NSphere_viewAngles.push_back(viewAng);
	  
	  float phi = asin(viewAng.z()), theta = atan2(viewAng.y(),viewAng.x()); 
	  tf::Transform oA (tf::Quaternion(tf::Vector3(0,0,1), theta) * tf::Quaternion(tf::Vector3(0,1,0), 1.5*M_PI-phi) , viewAng);
	  NSphere_viewAngles_stf.push_back( tf::StampedTransform(oA, ros::Time::now(), "/table_frame", "/PjPl/" + std::to_string(labelX)) );
	  
	  
	  labelX++;
	}
	
      }
      
      
      return 0;
    }
            
    void save_viewAngles(yf_V &V_)
    {
      V_.NSphere_viewAngles = this->NSphere_viewAngles;
      V_.NSphere_viewAngles_stf = this->NSphere_viewAngles_stf;
    }
    

     void draw_NormalSphere(std::vector<visualization_msgs::Marker> &arraw)
    {     
      ROS_INFO_STREAM("draw_NormalSphere") ;
      
      float r1 = 0.07, r2 = 0.08;
      
      for (uint i = 0; i<NSphere_bin_count.size(); i++)
      {
	visualization_msgs::Marker arrawX;
	arrawX.header.frame_id = "/table_frame";
	arrawX.header.stamp 	= ros::Time::now();
	arrawX.ns  =  "NormalSphere";
	arrawX.action = visualization_msgs::Marker::ADD;
	arrawX.id = i;
	arrawX.type = visualization_msgs::Marker::ARROW;
	arrawX.scale.x = 0.002;	arrawX.scale.y = 0.004;		arrawX.scale.z = 0.0;
	if (NSphere_bin_count[i] < 10) 
	  {	arrawX.color.r = 0.5;	arrawX.color.g = 0.5;	arrawX.color.b = 0.5;	arrawX.color.a = 0.3;}
	else if (NSphere_bin_label[i] == 0)
	  {	arrawX.color.r = 0.8;	arrawX.color.g = 0.8;	arrawX.color.b = 0.8;	arrawX.color.a = 0.8;}
	else if (NSphere_bin_label[i] == 1)
	  {	arrawX.color.r = 1;	arrawX.color.g = 0.5;	arrawX.color.b = 0.5;	arrawX.color.a = 0.8;}
	else if (NSphere_bin_label[i] == 2)
	  {	arrawX.color.r = 1;	arrawX.color.g = 1;	arrawX.color.b = 0.4;	arrawX.color.a = 0.8;}
	else if (NSphere_bin_label[i] == 3)
	  {	arrawX.color.r = 0.5;	arrawX.color.g = 1;	arrawX.color.b = 0.5;	arrawX.color.a = 0.8;}
	else if (NSphere_bin_label[i] == 4)
	  {	arrawX.color.r = 0.5;	arrawX.color.g = 0.5;	arrawX.color.b = 1;	arrawX.color.a = 0.8;}
	else
	  {	arrawX.color.r = 1;	arrawX.color.g = 0.4;	arrawX.color.b = 1;	arrawX.color.a = 0.8;}
	
	geometry_msgs::Point Pzero;
	Pzero.x = Pzero.y = Pzero.z = 0;
	geometry_msgs::Point N0;
	N0.x=NSphere_bin_coreV[i].x()*r1; N0.y=NSphere_bin_coreV[i].y()*r1; N0.z=NSphere_bin_coreV[i].z()*r1;
	
	
	r2 = 0.000 + 0.04*NSphere_bin_count[i]/(*std::max_element(NSphere_bin_count.begin(), NSphere_bin_count.end()));
	geometry_msgs::Point N1;
	N1.x=NSphere_bin_coreV[i].x()*r2+N0.x; N1.y=NSphere_bin_coreV[i].y()*r2+N0.y; N1.z=NSphere_bin_coreV[i].z()*r2+N0.z;
	
	arrawX.points.push_back(N0);    
	arrawX.points.push_back(N1); 
	arraw.push_back(arrawX);
      }
    }
                   
};


class nominate : public yf_V
{
  public:
    
    float resolution_projection = 0.005; // in meter, 0.002 ~>2mm
    
    nominate()
    {};
    
    nominate(yf_V &V_)
    {
      this->cloud = V_.cloud;
      this->normals = V_.normals;
      this->cloud_with_normals = V_.cloud_with_normals;
      this->cloud_border = V_.cloud_border;
      this->cloud_inlander = V_.cloud_inlander;
      this->idx_valid = V_.idx_valid;
      this->idx_border = V_.idx_border;
      this->idx_inlander = V_.idx_inlander;

      this->massCenter = V_.massCenter;
      this->stf_Table2Tool = V_.stf_Table2Tool;
      
      this->v_stf_Tool2CupBases = V_.v_stf_Tool2CupBases;
      this->v_cup_dim_N = V_.v_cup_dim_N;
      this->v_cup_dim = V_.v_cup_dim;
      

      this->NSphere_viewAngles = V_.NSphere_viewAngles;
      this->NSphere_viewAngles_stf = V_.NSphere_viewAngles_stf;
	
      init_v_stf_Tool2CupBases();
    };
    
    class iterator_O
    {
      public:
	float phy;	// atan2(dy,dx) slope of the two points
	int dx, dy;	// vector of p1p2, x2-x1,y2-y1
	float cosP, sinP;
	float dx05, dy05;    
	
	iterator_O(float _phy, int _dx, int _dy, float _cosP, float _sinP): phy(_phy), dx(_dx), dy(_dy), cosP(_cosP), sinP(_sinP)
	{
	  dx05 = 0.5*dx;	  dy05 = 0.5*dy;
	}
	
	iterator_O(int _dx, int _dy): dx(_dx), dy(_dy)
	{
	  phy = atan2(dy, dx);
	  cosP = cos(phy);	  sinP = sin(phy);
	  dx05 = 0.5*dx;	  dy05 = 0.5*dy;
	}      
    };
    
    std::vector<iterator_O> nominate__v_iterator_O;	// iterate half a circle
    
    class pair_by_iterator
    {
      public:
	uint itX;	// iterator
	float mx, my;	// vector of p1p2, x2-x1,y2-y1
	float d0M_pl;	// distance from (0,0) to perpendicular bisector (folding line)
	float d0M_pd;	// distance from (0,0) to the line p1p2
	uint xy1, xy2;
	
	pair_by_iterator(uint _itX, iterator_O it, int _ix1, int _iy1, uint _xy1, uint _xy2): itX(_itX), xy1(_xy1), xy2(_xy2)
	{
	  mx = it.dx05+_ix1;	my = it.dy05+_iy1;
	  d0M_pl = it.cosP*mx + it.sinP*my;
	  d0M_pd = -it.sinP*mx + it.cosP*my;
	}
    };
    
    uint nominate__set_v_iterator_O(float cfgY, std::vector<iterator_O> &v_iterator_O)
    {
      float R = cfgY/resolution_projection;
            
      float dt = asin(0.5/R);
      float theta(0.0);

      float dxx, dyy;

      v_iterator_O.clear();
#if 0
            
      int dx_c = 32767, dy_c = 32767;
      int dx_cc, dy_cc;
      int dx_f = 32767, dy_f = 32767;
      int dx_ff, dy_ff;
      
      while (theta < M_PI)
      {
	dxx = R*cos(theta); dyy = R*sin(theta);
	
	dx_cc = (dxx>=0)?ceil(dxx):floor(dxx);	
	dy_cc = (dyy>=0)?ceil(dyy):floor(dyy);
	  
	if ((dx_cc != dx_c) || (dy_cc != dy_c))
	{
	  dx_c = dx_cc;
	  dy_c = dy_cc;
	  v_iterator_O.push_back(iterator_O(dx_c,dy_c));
	  std::cout<<dx_cc<<","<<dy_cc <<"\n";
	}
	
	dx_ff = (int)dxx;	dy_ff = (int)dyy; 
	if ((dx_ff != dx_f) || (dy_ff != dy_f))
	{
	  dx_f = dx_ff;
	  dy_f = dy_ff;
	  v_iterator_O.push_back(iterator_O(dx_f,dy_f));
	  std::cout<<dx_ff<<","<<dy_ff <<"\n";	  
	}
	
	theta += dt;
      }
#else
      int dx_r = 32767, dy_r = 32767;
      int dx_rr, dy_rr;
      while (theta < M_PI)
      {
	dxx = R*cos(theta); dyy = R*sin(theta);
	
	dx_rr = round(dxx);	
	dy_rr = round(dyy);
	if (dx_rr<0 && dy_rr==0) break;
	if ((dx_rr != dx_r) || (dy_rr != dy_r))
	{
	  dx_r = dx_rr;
	  dy_r = dy_rr;
	  v_iterator_O.push_back(iterator_O(dx_r,dy_r));
//  	  std::cout<<dx_r<<","<<dy_r <<"\n";	  
	  
	}
	
	theta += dt;
      }
#endif
//       std::cout<<"v_iteratorO with "<< v_iterator_O.size() <<" vectors \n";	
    }
           
    uint get_ProjectplainMapPcl (uint viewAngleN, pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_Pjr, float threathhold_angle = M_PI/18)	// returns an image of projected points with samilar normals to normal on normalsphere
    {
      ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   projection - "<<viewAngleN);
      
      float threathhold_cos = cos(threathhold_angle);
      //resolution_projection; 
//       tf::Point vA = NSphere_viewAngles[viewAngleN];

      //tf::Quaternion oA (1,0,0,0);
//       float phi = asin(vA.z()), theta = atan2(vA.y(),vA.x()); 
      
      tf::Point pA (NSphere_viewAngles_stf[viewAngleN].getOrigin().normalized());
      tf::Quaternion qA (NSphere_viewAngles_stf[viewAngleN].getRotation());
      tf::Transform oA (qA.inverse(),v3_000);
      
      tf::Point pMC (oA * massCenter); 	
      std::cout << "MC projected: "<< pMC.x()<<"  "<< pMC.y()<<"  "<< pMC.z()<<"  \n";
      pMC.setZ(0);
      
//       oA = tf::Transform(q_u,-pMC) * oA ;
      
      std::vector< std::pair <int, int> > mapList;
//      mapList.push_back(std::make_pair());		// projection of mass center
      
      int mapXmin=32767,mapXmax=-32767,mapYmin=32767,mapYmax=-32767;
      float z_min = 0; 
      for (size_t i : *idx_inlander)
      {
	pcl::Normal PN_pcl = normals->points[i];
	tf::Point PN (PN_pcl.normal_x,PN_pcl.normal_y,PN_pcl.normal_z);
	if (tf::tfDot(PN,pA) > threathhold_cos)	// if angles are close	//////////////shall relate to cup_dim
	{ 
	  pcl::PointXYZ P_pcl = cloud->points[i];
	  tf::Point P (P_pcl.x,P_pcl.y,P_pcl.z);
	  tf::Point xy = oA * P;
	  
	  int x = round(xy.x()/resolution_projection);
	  if (x < mapXmin) mapXmin = x;	  if (x > mapXmax) mapXmax = x;
	  int y = round(xy.y()/resolution_projection);
	  if (y < mapYmin) mapYmin = y;	  if (y > mapYmax) mapYmax = y;
	  
	  float z = xy.z();
	  if (z < z_min) z_min = z;
	  
	  mapList.push_back(std::make_pair (x, y));
	}
      }
//       pA = -z_min * pA + tf::Transform(qA, v3_000)*pMC;
      pA = -z_min * pA;
//       std::cout << "pA projection: "<< pA.x()<<"  "<< pA.y()<<"  "<< pA.z()<<"  \n";
//       std::cout << "xy projection:   Xmn "<< mapXmin<<"    Xmx "<< mapXmax<<"   Ymn "<< mapYmin<<"   Ymx "<<mapYmax<<"  \n";
//       NSphere_viewAngles_stf[viewAngleN].setOrigin(pA-pMC);
      NSphere_viewAngles_stf[viewAngleN].setOrigin(pA);
//       NSphere_viewAngles_stf[viewAngleN].setData(oA);
      
//       std::set< std::pair <int, int> > s ( mapList.begin(), mapList.end() );
//       mapList.assign( s.begin(), s.end() );
      
      ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   projection - "<<viewAngleN << "   - reset viewangle");
      
      size_t count = 0;
      pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_Pj (new pcl::PointCloud<pcl::PointXYZ>);
      cloud_Pjr->clear();
      
      int Xs = (mapXmax-mapXmin+1), Ys = (mapYmax-mapYmin+1);
      cloud_Pj->width = Xs;	cloud_Pjr->width = Xs;
      cloud_Pj->height = Ys;	cloud_Pjr->height = Ys;
//       cloud_Pj->resize(Xs*Ys);
      for (size_t i = 0; i<Xs*Ys; i++) 
      {
	cloud_Pj->points.push_back(PointXYZ_nan);
	cloud_Pjr->points.push_back(PointXYZ_nan);
      }
      for (auto Pt :  mapList)
      {
	int xx (Pt.first-mapXmin), yy (Pt.second-mapYmin);
	if (isnan(cloud_Pj->at(xx, yy).x))
	{
	  pcl::PointXYZ Ppj(Pt.first*resolution_projection, Pt.second*resolution_projection,0);
	  cloud_Pj->points[yy*Xs+xx] = Ppj;
	  count ++;
	}
      }
      
      pcl::IndicesPtr pointIdxInander_pp (new std::vector <int>);
      
      for (int x = 1; x<Xs-1; x++)
      for (int y = 1; y<Ys-1; y++)
      {	 
	size_t i = y*Xs+x;
	if (!isnan(cloud_Pj->points[i].x))
	{
	  int i1 = i-1, i2 = i+1, i3 = i-Xs, i4 = i+Xs;
	  if (!isnan(cloud_Pj->points[i1].x)&&!isnan(cloud_Pj->points[i2].x)&&!isnan(cloud_Pj->points[i3].x)&&!isnan(cloud_Pj->points[i4].x))
	  {
	    pointIdxInander_pp->push_back(i);	
	    cloud_Pjr->points[i] = cloud_Pj->points[i];
	  } 
	}	
      }

      
      
      cloud_Pjr->sensor_origin_ = Eigen::Vector4f(pA.x(),pA.y(),pA.z(),1.0);
      cloud_Pjr->sensor_orientation_ = Eigen::Quaternionf(qA.w(),qA.x(),qA.y(),qA.z());
      
//       *cloud_Pjr = *cloud_Pj;
      
//       std::cout << "projected to viewAngle "<< viewAngleN << " : " << count << " points \n";
      
      ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   projection - "<<viewAngleN << "   - fin");
      return mapList.size();
    }
    
    uint nominate__searchPairs(pcl::PointCloud<pcl::PointXYZ>::ConstPtr cloud_Pjr, std::vector<iterator_O> v_iterator_O, std::vector <pair_by_iterator> &v_Pairs)
    {
      uint W = cloud_Pjr->width, H = cloud_Pjr->height;
      v_Pairs.clear();
      
      for (size_t iy = 0; iy<H; iy++)
      for (size_t ix = 0; ix<W; ix++)
      {
	uint xy = ix + iy*W;
	if (isnan(cloud_Pjr->at(xy).x)) continue;
	  
	for (uint it = 0; it < v_iterator_O.size(); it++)
	{
	  auto iterator = v_iterator_O[it];
	  uint ix2 = ix+iterator.dx , iy2 = iy+iterator.dy;
	  if ((ix2<0)||(ix2>=W)||(iy2>=H)) continue;	// out of range
	  uint xy2 =  ix2 + iy2*W;
	  if (isnan(cloud_Pjr->at(xy2).x)) continue;
// 	  std::cout<<ix <<","<< iy <<" - "<< ix2 <<","<< iy2 <<"\n";	
	  v_Pairs.push_back(pair_by_iterator(it, iterator, ix, iy,xy,xy2));
	  
	}
      }
      
      std::sort(v_Pairs.begin(), v_Pairs.end(), [](pair_by_iterator P1, pair_by_iterator P2) 
	    { return (P1.itX < P2.itX); } );
    }
    
    uint nominate__find_RectPair(std::vector<iterator_O> v_iterator_O, std::vector <pair_by_iterator> v_Pairs, std::vector < std::pair <int, int> > &v_RectPair, float cfgX_min, float R)
    {
      v_RectPair.clear();
      v_RectPair.push_back(std::make_pair(0,0));
      
      float X_min = cfgX_min/resolution_projection;
      
      float theta_limit = 5.0*deg2rad;		// tolorrance of 5°
//       std::cout<<"theta_limit = "<<theta_limit*rad2deg<<"°\n";
      
      for (uint i1 = 0; i1 < v_Pairs.size(); i1++)
      {
	
// 	std::cout<<"\n Pr "<< i1 <<" has neibours : ";
	
	pair_by_iterator Pr1 = v_Pairs[i1];
	
	uint d0M_pd_min = i1, d0M_pd_max = i1;
	
	std::vector <uint> v_PairIdx_sort {i1};
	
	uint i2 = i1; 
	while (1)
	{
	  i2 = (i2 + 1)%v_Pairs.size();
	  pair_by_iterator Pr2 = v_Pairs[i2];
	  int d_itX = abs(Pr2.itX - Pr1.itX+v_iterator_O.size())%v_iterator_O.size();
	  if (d_itX > 1) break;	// it~it2 are the region with same phy

	  v_PairIdx_sort.push_back(i2);
	}	  // it~it2 are the region with similar phy
	
	uint i11 = (i2 > i1)?i2:32767;
	
	while (1)
	{
	  i2 = (i2 + 1)%v_Pairs.size();
	  pair_by_iterator Pr2 = v_Pairs[i2];
	  float d_phy = fmod((v_iterator_O[Pr2.itX].phy - v_iterator_O[Pr1.itX].phy + M_PI),M_PI);
	  if (d_phy > theta_limit) break;	// it~it2 are the region with similar phy*/
// 	  int d_itX = abs(Pr2.itX - Pr1.itX+v_iterator_O.size())%v_iterator_O.size();
// 	  if (d_itX > 2) break;	// it~it2 are the region with similar phy
// 	  std::cout << i2 <<" ";

 	    v_PairIdx_sort.push_back(i2);
	}	  // it~it2 are the region with similar phy
	
// 	std::cout <<v_iterator_O[ v_Pairs[v_PairIdx_sort.back()].itX].phy*rad2deg<<"°  " << v_PairIdx_sort.size()<<"\n";
	if (v_PairIdx_sort.size() < 2) break;
	
	std::sort(  std::begin(v_PairIdx_sort), 
		    std::end(v_PairIdx_sort),
		    [&](int ii1, int ii2) { return v_Pairs[ii1].d0M_pl < v_Pairs[ii2].d0M_pl; } );    
	
// 	for (auto xx : v_PairIdx_sort) 	  std::cout << xx <<" ";
	
	// region i1~i2
	// looking for min-max pair-pairs (a rectangle)
	
	uint idx_pd_min = 0, idx_pd_max = 0;
	uint j1 = 0, j2 = 1;
	while (j2 < v_PairIdx_sort.size())
	{
	  const float j1_pl = v_Pairs[v_PairIdx_sort[j1]].d0M_pl;	  const float j2_pl = v_Pairs[v_PairIdx_sort[j2]].d0M_pl;
	  const float j1_pd = v_Pairs[v_PairIdx_sort[j1]].d0M_pd;	  const float j2_pd = v_Pairs[v_PairIdx_sort[j2]].d0M_pd;
	  
	  
	  if (j2_pl-j1_pl > 1)		// d0M_pl difference over 1 pixels, this region finished
	  {
	    
	    float dif_pd_minmax = fabs(v_Pairs[v_PairIdx_sort[idx_pd_max]].d0M_pd-v_Pairs[v_PairIdx_sort[idx_pd_min]].d0M_pd);
	    if (dif_pd_minmax > X_min)		// cfgX is big enough 
	    {
	      auto rt_back = v_RectPair.back();
	      if (rt_back.first != v_PairIdx_sort[idx_pd_min] || rt_back.second != v_PairIdx_sort[idx_pd_max])	// if not already detected
	      {
		const float idx_min_phy= v_iterator_O[v_Pairs[v_PairIdx_sort[idx_pd_min]].itX].phy;
		const float back_phy= v_iterator_O[v_Pairs[rt_back.first].itX].phy;
		const bool phy_diff = fabs(back_phy - idx_min_phy) > M_PI/12.0;			// exclude those with similar phy
		const float idx_min_pl = v_Pairs[v_PairIdx_sort[idx_pd_min]].d0M_pl;
		const float back_pl = v_Pairs[rt_back.first].d0M_pl;
		const bool d0M_pl_diff = fabs(back_pl - idx_min_pl) > 10;			// exclude those with similar d0M_pl
		if (phy_diff || d0M_pl_diff || v_RectPair.size() == 1) 						// if not similar -> nominate a new one	
		{
		  v_RectPair.push_back(std::make_pair(v_PairIdx_sort[idx_pd_min], v_PairIdx_sort[idx_pd_max]));
// 		  std::cout <<"     ["<< v_PairIdx_sort[idx_pd_min] <<" "<< v_PairIdx_sort[idx_pd_max] << "]\t"<<idx_min_phy*rad2deg<<"   "<<idx_min_pl<<"   "<<dif_pd_minmax<<"\n";		  
		}
		else									// if similar -> take the one with larger diff_pd
		{
		  float dif_pd_back = v_Pairs[rt_back.second].d0M_pd-v_Pairs[rt_back.first].d0M_pd;
		  if (dif_pd_minmax > dif_pd_back)
		  {
		    v_RectPair.pop_back();
		    v_RectPair.push_back(std::make_pair(v_PairIdx_sort[idx_pd_min], v_PairIdx_sort[idx_pd_max]));
// 		    std::cout <<"        {"<< v_PairIdx_sort[idx_pd_min] <<" "<< v_PairIdx_sort[idx_pd_max] << "}\t"<<idx_min_phy*rad2deg<<"   "<<idx_min_pl<<"   "<<dif_pd_minmax<<"\n";	
		  }
		}
	      }
	    }
	    
	    j1 ++;	// j1 = j2;
// 	    j1 = std::max(j1+1, std::min(idx_pd_min, idx_pd_max));
	    j2 = j1+1;
	    idx_pd_max = j1; 
	    idx_pd_min = j1; 
	  }
	  else 
	  {
	    if (j2_pd < v_Pairs[v_PairIdx_sort[idx_pd_min]].d0M_pd) idx_pd_min = j2;
	    if (j2_pd > v_Pairs[v_PairIdx_sort[idx_pd_max]].d0M_pd) idx_pd_max = j2;	  
	    j2++;
	  }
// 	  std::cout << j1 <<" "<< j2 << "\t";

	}
	
	if (i11>i1)	i1 = i11;
	else 		break;
      }    
      
      ////////////////////////////////////// all rectangles found
      
//       std::cout<<"\nall nominees:\n";
      for (auto it : v_RectPair) std::cout<<"\t["<<it.first<<" "<<it.second<< "]\t"<< v_iterator_O[v_Pairs[it.second].itX].phy * rad2deg<<"°\n";
      
    }
    
    uint nominate__RectPair_to_stf_table2cupbase0(float cfgZ, uint pr1, uint pr2, std::vector <pair_by_iterator> v_Pairs, std::vector<iterator_O> v_iterator_O, pcl::PointCloud<pcl::PointXYZ>::ConstPtr cloud_Pjr, float &cfgX, tf::StampedTransform &stf_table2cupbase0)
    {
      
      uint i = 37;
      
      tf::Point table_pjpl_v3 (cloud_Pjr->sensor_origin_[0], cloud_Pjr->sensor_origin_[1], cloud_Pjr->sensor_origin_[2]);
      tf::Quaternion table_pjpl_q (cloud_Pjr->sensor_orientation_.x(),cloud_Pjr->sensor_orientation_.y(),cloud_Pjr->sensor_orientation_.z(),cloud_Pjr->sensor_orientation_.w());
  
      tf::Transform tf_table_pjpl (table_pjpl_q, table_pjpl_v3);
      
      uint i1(v_Pairs[pr1].xy1),i2(v_Pairs[pr1].xy2),i3(v_Pairs[pr2].xy1),i4(v_Pairs[pr2].xy2);
//        ROS_INFO_STREAM(" "<<pr1<<" "<<pr2<<" ");
    
      pcl::PointXYZ pt1 = cloud_Pjr->at(i1),
		    pt2 = cloud_Pjr->at(i2),
		    pt3 = cloud_Pjr->at(i3),
		    pt4 = cloud_Pjr->at(i4);
		    
		    
      float cfgX2 = sqrt((pt1.x-pt3.x)*(pt1.x-pt3.x)+(pt1.y-pt3.y)*(pt1.y-pt3.y));
      float cfgX3 = sqrt((pt2.x-pt4.x)*(pt2.x-pt4.x)+(pt2.y-pt4.y)*(pt2.y-pt4.y));
      cfgX = 0.5*(cfgX2+cfgX3);
      
      float mx = 0.25* (pt1.x+pt2.x+pt3.x+pt4.x);
      float my = 0.25* (pt1.y+pt2.y+pt3.y+pt4.y);
      float theta = atan2((pt1.y+pt2.y-pt3.y-pt4.y),(pt1.x+pt2.x-pt3.x-pt4.x));
      tf::Quaternion q (v3_001, theta);
      
//       set_v_stf_Tool2CupBases_cfgXYZ(cfgX, cfgY, 0.01);
      tf::Transform tf_pjpl2cupbase0 (q, tf::Point(mx,my,-cfgZ));
//       stf_table2cupbase0.setRotation(q);
//       stf_table2cupbase0.setOrigin(tf::Point(mx,my,-get_stf_Tool2CupBases(1).getOrigin().z()));
            
      stf_table2cupbase0.child_frame_id_ = "/grip/"+std::to_string(i);
      stf_table2cupbase0.frame_id_ = "/table_frame";
      stf_table2cupbase0.stamp_ = ros::Time::now();
      stf_table2cupbase0.setData(tf_table_pjpl*tf_pjpl2cupbase0);
      
      
//       ROS_INFO_STREAM(" "<<mx<<" "<<my<<" "<<theta<< " " <<cfgX<<" " <<cfgX2<<" "<<cfgX3);
    }
  
    uint nominate__RectPair_to_msg_grip_tfs_cfg(float cfgY, float cfgZ, uint pr1, uint pr2, std::vector <pair_by_iterator> v_Pairs, std::vector<iterator_O> v_iterator_O, pcl::PointCloud<pcl::PointXYZ>::ConstPtr cloud_Pjr, yf_pcl_process::msg_grip_tfs_cfg &msg_grip_candidate)
    {
      tf::StampedTransform stf_tmp;
      float cfgX_out;
      
      nominate__RectPair_to_stf_table2cupbase0(cfgZ, pr1, pr2, v_Pairs, v_iterator_O,cloud_Pjr, cfgX_out, stf_tmp);
      
      
      msg_grip_candidate.cfgX = cfgX_out;	
      msg_grip_candidate.cfgY = cfgY;		
      msg_grip_candidate.cfgZ = cfgZ;	
      //////////////////////
      msg_grip_candidate.cupOn.resize(5);
      msg_grip_candidate.cupOn[0]  =7;
      msg_grip_candidate.cupOn[1]  =1;
      msg_grip_candidate.cupOn[2]  =2;
      msg_grip_candidate.cupOn[3]  =3;
      msg_grip_candidate.cupOn[4]  =4;
//       msg_grip_candidate.cupOn.push_back(17);
//       msg_grip_candidate.cupOn.push_back(1);
//       msg_grip_candidate.cupOn.push_back(2);
//       msg_grip_candidate.cupOn.push_back(3);
//       msg_grip_candidate.cupOn.push_back(4);
      
      tf::transformStampedTFToMsg( stf_tmp , msg_grip_candidate.tfs_tabel2cupbase0 );
    }  
    
    uint nominate__get_v_grip_nominees_Rect_PjPl_cfgY(float cfgY, uint PjPl_N, pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_Pjr, std::vector< yf_pcl_process::msg_grip_tfs_cfg > &v_grip_nominees)	// nominate cadidates of grip stf according to projectplain
    {    
      float cfgX_min = 0.04;
      nominate__get_v_grip_nominees_Rect_PjPl_cfgY(cfgY, PjPl_N, cloud_Pjr, v_grip_nominees, cfgX_min, 0);
    }
    
    uint nominate__get_v_grip_nominees_Rect_PjPl_cfgY(float cfgY, uint PjPl_N, pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_Pjr, std::vector< yf_pcl_process::msg_grip_tfs_cfg > &v_grip_nominees, float cfgX_min, float cfgZ)	// nominate cadidates of grip stf according to projectplain
    {
      std::cout<<"nominating grips for Project Plain"<< PjPl_N <<"\n";
      
      get_ProjectplainMapPcl(PjPl_N, cloud_Pjr, M_PI/180*20);
      
      ////////////////////////////////////////////////////// constructing iterator
      uint W = cloud_Pjr->width, H = cloud_Pjr->height;
      
//       float cfgY(0.05), cfgX_min(0.05), cfgZ(0.01);

      float R = cfgY/resolution_projection; float X_min = cfgX_min/resolution_projection;
//       std::cout<<"'R = "<< R <<"\n";
//       std::vector<iterator_O> v_iterator_O;	// iterate half a circle

//       nominate__set_v_iterator_O(cfgY, v_iterator_O);
      if (nominate__v_iterator_O.size() == 0)
	nominate__set_v_iterator_O(cfgY, nominate__v_iterator_O);
      
      ////////////////////////////////////////////////////////// searching for pairs 

      std::vector <pair_by_iterator> v_Pairs {};
      nominate__searchPairs(cloud_Pjr, nominate__v_iterator_O, v_Pairs);
//       std::cout << v_Pairs.size() <<" pairs of points with distance R =cfgY = "<<cfgY<<"\n";
      /////////////////////////////////////////////////////////////// all pairs stored in v_l_Pairs
      
      std::vector <std::pair <int, int> > v_RectPair {std::make_pair(0,0)};
      nominate__find_RectPair(nominate__v_iterator_O, v_Pairs, v_RectPair, cfgX_min, R);
      ///////////////////////////////////////////////////////////////////// found all rectangles as candidates
      
      
      float cfgX_out;
      
      set_v_stf_Tool2CupBases_tfBase0(tf::Transform(tf::Quaternion(v3_100, M_PI/4), 0.1*v3_001));
//       set_v_stf_Tool2CupBases_cfgZ(0.03);
      yf_pcl_process::msg_grip_tfs_cfg msg_grip_candidate;
      uint i = 1;
      for (auto it: v_RectPair)
      {
	nominate__RectPair_to_msg_grip_tfs_cfg(cfgY, cfgZ, it.first, it.second, v_Pairs, nominate__v_iterator_O,cloud_Pjr, msg_grip_candidate);
	std::cout<<msg_grip_candidate.cupOn[0]<< "  =====================\n";
	
	msg_grip_candidate.name = "Grip" + std::to_string(v_grip_nominees.size());
	v_grip_nominees.push_back(msg_grip_candidate);
      }
	
    }
    
    uint nominate__get_v_grip_nominees_Rect_all_cfgY(float cfgY, float cfgX_min, float cfgZ, std::vector< yf_pcl_process::msg_grip_tfs_cfg > &v_grip_nominees)
    {

      init_v_stf_Tool2CupBases();
      pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_pj (new pcl::PointCloud<pcl::PointXYZ>);

      for (uint PjPl_N = 1; PjPl_N < NSphere_viewAngles_stf.size(); PjPl_N++)
      {
	nominate__get_v_grip_nominees_Rect_PjPl_cfgY(cfgY, PjPl_N, cloud_pj, v_grip_nominees, cfgX_min, cfgZ);
      }
    }
      
    void save_viewAngles(yf_V &V_)
    {
//       V_.NSphere_viewAngles = this->NSphere_viewAngles;
      V_.NSphere_viewAngles_stf = this->NSphere_viewAngles_stf;
    }
      
};



class maneuverGrip : public yf_V
{
//    
  protected:
    yf_pcl_process::msg_grip_tfs_cfg msg_grip_in;
    yf_pcl_process::msg_grip_tfs_cfg msg_grip_now;
    
  public:
    yf_pcl_process::msg_grip_tfs_cfg msg_grip_out;
    yf_pcl_process::msg_grip_tfs_cfg msg_grip_tend;
    
    std::vector < pcl::IndicesPtr > v_idx_ring ;
    std::vector < pcl::IndicesPtr > v_idx_ring_inlander ;
    std::vector < tf::Transform > v_tf_table2cupbase ;
    std::vector < tf::StampedTransform > v_stf_table2ring ;
    std::vector < tf::StampedTransform > v_v3_norm_ring ;
    std::vector < uint > v_cupOn ;
    
//     std::vector < float > v_dz ;
    
    maneuverGrip()    {};
    
    maneuverGrip(yf_V &V_)
    {
      this->cloud = V_.cloud;
      this->normals = V_.normals;
      this->cloud_with_normals = V_.cloud_with_normals;
      this->cloud_border = V_.cloud_border;
      this->cloud_inlander = V_.cloud_inlander;
      this->idx_valid = V_.idx_valid;
      this->idx_border = V_.idx_border;
      this->idx_inlander = V_.idx_inlander;

      this->massCenter = V_.massCenter;
//       this->stf_Table2Tool = V_.stf_Table2Tool;
      
      this->v_stf_Tool2CupBases[0] = V_.v_stf_Tool2CupBases[0];
      this->v_cup_dim_N = V_.v_cup_dim_N;
      this->v_cup_dim = V_.v_cup_dim;
      this->cup_dim_ = V_.cup_dim_;
      
      tree_cloud.setInputCloud(cloud);
      tree_inlander.setInputCloud(cloud_inlander);
      
      v_idx_ring.resize(5);
      v_stf_table2ring.resize(5);
      v_tf_table2cupbase.resize(5);
      v_v3_norm_ring.resize(5);
      v_cupOn.resize(5);
      
//       v_dz.resize(5);
    };
    
    uint print_MsgGrip( yf_pcl_process::msg_grip_tfs_cfg msg_grip_ )
    {
      std::cout<<"\nGrip name : " <<msg_grip_.name<<"\n";
      std::cout<<std::setprecision(1)<<"  Grip cfg  : x." <<msg_grip_.cfgX*100<<"cm  y."<<msg_grip_.cfgY*100<<"cm  z."<<msg_grip_.cfgZ*100<<"cm\n";
      std::cout<<"  Grip on?  : " <<msg_grip_.cupOn[1]<<" "<<msg_grip_.cupOn[2]<<" "<<msg_grip_.cupOn[3]<<" "<<msg_grip_.cupOn[4]<<" "<<"\n";
     
      
    }
    
    uint set_MsgGrip( yf_pcl_process::msg_grip_tfs_cfg msg_grip_ )
    {
      msg_grip_in = msg_grip_;
      msg_grip_now = msg_grip_;
      tf::StampedTransform stf_tabel2cupbase0;
      tf::transformStampedMsgToTF(msg_grip_in.tfs_tabel2cupbase0, stf_tabel2cupbase0);
      set_v_stf_Tool2CupBases_cfgXYZ(msg_grip_in.cfgX, msg_grip_in.cfgY, msg_grip_in.cfgZ);
      set_stf_Table2Tool(stf_tabel2cupbase0*v_stf_Tool2CupBases[0].inverse()); 
      
      v_tf_table2cupbase.resize(v_stf_Tool2CupBases.size());
      v_tf_table2cupbase[0] = stf_tabel2cupbase0;
      for (uint i = 1; i < v_stf_table2ring.size(); i++)
      {
	v_cupOn[i] = msg_grip_in.cupOn[i];
// 	if (v_cupOn[i])
	  v_tf_table2cupbase[i] = stf_tabel2cupbase0*v_stf_Tool2CupBases[i];
// 	else 
// 	  v_tf_table2cupbase[i] = tf_u;
      }
    }    
    
    uint apply_MsgGrip( yf_pcl_process::msg_grip_tfs_cfg msg_grip_ )
    {
      set_MsgGrip(msg_grip_);

      apply_MsgGrip();
    }
    
    uint apply_MsgGrip()
    {
//       get_tf_to_ring_cupX(1);
//       get_tf_to_ring_cupX(2);
//       get_tf_to_ring_cupX(3);
//       get_tf_to_ring_cupX(4);
      
      setget_tf_to_ring_cupX(1);
      setget_tf_to_ring_cupX(2);
      setget_tf_to_ring_cupX(3);
      setget_tf_to_ring_cupX(4);
      
      
//       fit_MsgGrip();
      
//       get_tf_to_ring_cupX(1);
//       get_tf_to_ring_cupX(2);
//       get_tf_to_ring_cupX(3);
//       get_tf_to_ring_cupX(4);

      
    }
    
    float findall_tf_table2ring_near_MsgGrip()
    {
      float L;
      L = find_tf_table2ring_near_MsgGrip(1);
      L = std::max(find_tf_table2ring_near_MsgGrip(2),L);
      L = std::max(find_tf_table2ring_near_MsgGrip(3),L);
      L = std::max(find_tf_table2ring_near_MsgGrip(4),L);
      return L;
    }    
    
    float find_tf_table2ring_near_MsgGrip(uint cupX)
    {
	pcl::IndicesPtr idx_find_out (new std::vector <int>); 
	std::vector<float> dump;
	
	tf::Point searchPoint_ (v_tf_table2cupbase[cupX].getOrigin());
	pcl::PointXYZ searchPoint(searchPoint_.x(),searchPoint_.y(),searchPoint_.z());
	
	tree_inlander.nearestKSearch (searchPoint, 1, *idx_find_out, dump);
	int id_center = idx_find_out->at(0); 	
	pcl::PointXYZ Pt_center_ = cloud->points[id_center];
	tf::Point Pt_center(Pt_center_.x,Pt_center_.y,Pt_center_.z);
	
	pcl::Normal N_center_ = normals->points[id_center];
	tf::Point N_center(N_center_.normal_x,N_center_.normal_y,N_center_.normal_z);
	
// 	pcl::IndicesPtr idx_ring (new std::vector <int>);	// segmentation of surface which (may) have contact with the vacuum cup

// 	idx_ring->insert(idx_ring->begin(),id_center);
// 	*idx_ring = {id_center};
	
// 	v_idx_ring[cupX]->insert(v_idx_ring[cupX]->begin(),id_center);
	v_stf_table2ring[cupX].setOrigin(Pt_center);
// 	std::cout <<"cupX "<< cupX<<": "<< tf::tfDot(N_center,(Pt_center-searchPoint_))<<"   ";
      return fabs(tf::tfDot(N_center,(Pt_center-searchPoint_)));
      return (Pt_center-searchPoint_).length();
    }
        
        
    float fit_MsgGrip()
    {
      float d;
      return fit_MsgGrip( d );
    }
      
    float fit_MsgGrip( float &d )
    {
//     ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   start fitting -");
      tf::Point Y_center; // center of contact points
      tf::Point X_center; // center of configured cupbase points
      tf::Point XY; // center of configured cupbase points
      Eigen::MatrixXd X(3,4);
      Eigen::MatrixXd Y(3,4);
      
      
      X_center = (v_tf_table2cupbase[1].getOrigin()+v_tf_table2cupbase[2].getOrigin()+v_tf_table2cupbase[3].getOrigin()+v_tf_table2cupbase[4].getOrigin())*0.25; // center of configured cupbase points
      Y_center = (v_stf_table2ring[1].getOrigin()+v_stf_table2ring[2].getOrigin()+v_stf_table2ring[3].getOrigin()+v_stf_table2ring[4].getOrigin())*0.25; // center of contact points
      XY = (Y_center - X_center);
      
      for (uint i = 1; i < 5; i++)
      {
	tf::Point Ptmp = v_tf_table2cupbase[i].getOrigin();
	X.block<3,1>(0,i-1) << Ptmp.x()-X_center.x(), Ptmp.y()-X_center.y(), Ptmp.z()-X_center.z();
	Ptmp = v_stf_table2ring[i].getOrigin();
	Y.block<3,1>(0,i-1) << Ptmp.x()-Y_center.x(), Ptmp.y()-Y_center.y(), Ptmp.z()-Y_center.z();
	// set a conter in case only 3 cups are active///////////////
      }
      
//       std::cout<<std::setprecision(6) <<"\n ****************  X \n"<< X  <<"\n";
//       std::cout<<std::setprecision(6) <<"\n ****************  Y \n"<< Y <<"\n";
      
      Eigen::MatrixXd H = Y*(X.transpose()); 
      Eigen::JacobiSVD<Eigen::MatrixXd> svd(H, Eigen::ComputeThinU | Eigen::ComputeThinV);
      const Eigen::MatrixXd U = svd.matrixU();
      const Eigen::MatrixXd V = svd.matrixV();
      Eigen::Matrix3d S ;  S<< 1,0,0,0,1,0,0,0,(U*V.transpose()).determinant();
      const Eigen::MatrixXd R = U*S*V.transpose();
      
      tf::Matrix3x3 MR( R(0,0),R(0,1),R(0,2),
			R(1,0),R(1,1),R(1,2),
			R(2,0),R(2,1),R(2,2));
      tf::Quaternion Q; 
      MR.getRotation(Q);
      
      tf::Quaternion Q2(v_tf_table2cupbase[0].getRotation());
      tf::Transform Tr2 (Q2.inverse(), v3_000);
      tf::Transform TR (Q*Q2, XY);
      
      Eigen::MatrixXd D = (Y - R*X);
      d = D.norm();
//         std::cout<<std::setprecision(6) <<"fitting error is : d = "<< d << "   ,   D = \n" <<D<<"\n";
//        std::cout<<std::setprecision(6) <<"fitting error is : d = "<< d << "\n";
      
      tf::StampedTransform stf_table2cupbase00 (v_tf_table2cupbase[0]*Tr2*TR, ros::Time::now(),"/table_frame","/Maneuver_grip/");
      v_tf_table2cupbase[0] = stf_table2cupbase00;
      set_stf_Table2Tool(stf_table2cupbase00*v_stf_Tool2CupBases[0].inverse());
      
      // save the fitted stf_table2cupbase00 to msg_grip_now
      tf::transformStampedTFToMsg( stf_table2cupbase00 , msg_grip_now.tfs_tabel2cupbase0 );
      
      
//       msg_grip_now.cfgX = 0.15;
//       apply_MsgGrip(msg_grip_now);
      
//     ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   start fitting - fin");
      return d; 	// return fitting rate
    }
  
    yf_pcl_process::msg_grip_tfs_cfg move_xy (yf_pcl_process::msg_grip_tfs_cfg msg, int dir, float delta)
    {
      yf_pcl_process::msg_grip_tfs_cfg rt = msg;
      std::ostringstream st;
      st<<std::fixed<<std::setprecision(1)<<1000*delta;
      rt.name = rt.name + " xy_" + std::to_string(dir) + ":"+st.str()+";";
      float theta = dir*0.25*M_PI;
      tf::Point v3_d(delta*cos(theta),delta*sin(theta),0);
      tf::Transform tf_d(q_u, v3_d);
      tf::StampedTransform stf_tabel2cupbase0;
      tf::transformStampedMsgToTF(msg_grip_in.tfs_tabel2cupbase0, stf_tabel2cupbase0);
      
      stf_tabel2cupbase0.setData( stf_tabel2cupbase0 * tf_d );
      tf::transformStampedTFToMsg(stf_tabel2cupbase0, rt.tfs_tabel2cupbase0);
      
      return rt;
    }
      
    yf_pcl_process::msg_grip_tfs_cfg move_theta (yf_pcl_process::msg_grip_tfs_cfg msg, float delta)
    {
      yf_pcl_process::msg_grip_tfs_cfg rt = msg;
      std::ostringstream st;
      st<<std::fixed<<std::setprecision(1)<<delta*rad2deg;
      rt.name = rt.name + " Th:"+st.str()+"°;";
      tf::Transform tf_d(tf::Quaternion(v3_001, delta), v3_000);
      tf::StampedTransform stf_tabel2cupbase0;
      tf::transformStampedMsgToTF(msg_grip_in.tfs_tabel2cupbase0, stf_tabel2cupbase0);
      
      stf_tabel2cupbase0.setData( stf_tabel2cupbase0 * tf_d );
      tf::transformStampedTFToMsg(stf_tabel2cupbase0, rt.tfs_tabel2cupbase0);
      
      return rt;
    }
  
    yf_pcl_process::msg_grip_tfs_cfg move_cfgX (yf_pcl_process::msg_grip_tfs_cfg msg, float delta)
    {
      yf_pcl_process::msg_grip_tfs_cfg rt = msg;
      std::ostringstream st;
      st<<std::fixed<<std::setprecision(1)<<1000*delta;
      rt.name = rt.name + " cX:"+st.str()+";";

      rt.cfgX += delta;
      
      return rt;
    }
    
    
    class cupPath		// optional directions of movement
    {
      public:
	uint dirN = 8;
	std::vector<float> v_path {0.0,0.0, 0.0,0.0,  0.0,0.0, 0.0,0.0} ;	// maped in 8 directions, 0°, 45° ...... 270° , 315°, 1:path ~ 0:blocked [-22.5°,22.5°), [22.5°,45°)......
// 	std::vector<tf::Point> v_dir;	// maped in 8 directions, 0°, 45° ...... 270° , 315°, 1:path ~ 0:blocked [-22.5°,22.5°), [22.5°,45°)......
// 	tf::Point screw;			// torque applied to cup according to cupbaseframe[0]      
	
	cupPath(uint k = 8) : dirN(k)
	{
	  v_path.resize(k, 0.0);
// 	  v_dir.resize(k);
	  float rt2 = sqrt(2);
// 	  v_dir[0] = tf::Point(1,0,0);
	  //{v3_100,tf::Point(rt2,rt2,0), v3_010,tf::Point(-rt2,rt2,0),  -v3_100,tf::Point(-rt2,-rt2,0), -v3_010,tf::Point(rt2,-rt2,0)};
	};
	
	uint erase()
	{
	  auto ers  = [](float &a){ a = 0.0; };
	  for (auto &it : v_path)
	    ers(it);
	}
    };
    
    class Grip_Perform
    {
      public:
	yf_pcl_process::msg_grip_tfs_cfg grip;
	bool got_Perform;
	
	std::vector <float> v_rz;	// angular deviation between cupBase and ring
	std::vector <float> v_dxy;	// distance between cupbase and ring center in xy
	std::vector <cupPath> v_path;
	float fitRate;
	
	uint interations;
// 	Grip_Perform *dad;
// 	std::vector<Grip_Perform*> kids;
	
	uint bad; 
	
	Grip_Perform(yf_pcl_process::msg_grip_tfs_cfg grip_) 
	: grip(grip_), got_Perform(false)
	{};
    };
    
    uint print_Grip_Perform (const Grip_Perform & obj)
    {
      // write obj to stream
      print_MsgGrip(obj.grip);
      
      std::cout << "Evaluation:\n  fitRate: " << obj.fitRate << "  \n";
      
      for (uint i = 1; i<obj.v_path.size(); i++)
      {
	std::cout <<"  Gripper "<< i << ":  v_path: ";
	for (auto it : obj.v_path[i].v_path)
	  std::cout <<std::setprecision(1)<< it << "  ";
	
	std::cout <<std::setprecision(3)<< ";  dz: " << obj.v_rz[i] * rad2deg<< "°";
	std::cout <<std::setprecision(1)<< ";  dxy: " << obj.v_dxy[i] * 1000<< "mm\n";
      }
      
      std::cout <<"\n";
      
//       std::cout << "Tree:\n  " << (obj.dad)->grip.name << "  \n";
      
      return 0;
    }
    
    float try_Grip_get_Perform(Grip_Perform &result_)
    {
      try_Grip_get_Perform(result_.grip, result_);
    }
      
    float try_Grip_get_Perform(yf_pcl_process::msg_grip_tfs_cfg grip_, Grip_Perform &result_)
    {
//       std::cout << "\n\n++++++++++++++++++++++try_Grip_get_Perform+++++++++++++++++++++\n  ";
	
      // init grip 
      if (result_.got_Perform) return 1.0;
      result_.grip = grip_;
      set_MsgGrip(grip_);
      
      // try fitting
      float L;
      L = findall_tf_table2ring_near_MsgGrip();
//       std::cout << "L = "<< L << "\n";
      
      fit_MsgGrip(result_.fitRate);
//       if (result_.fitRate > 0.01)
//       {
// 	std::cout << "  ----------------- bad fitting d\n";
// 	result_.bad  = 1;
//       }
       
//       L = findall_tf_table2ring_near_MsgGrip();

      result_.v_dxy.resize(5);
      result_.v_dxy[1] = find_tf_table2ring_near_MsgGrip(1);
      result_.v_dxy[2] = find_tf_table2ring_near_MsgGrip(2);
      result_.v_dxy[3] = find_tf_table2ring_near_MsgGrip(3);
      result_.v_dxy[4] = find_tf_table2ring_near_MsgGrip(4);
      
//       std::cout << "L = "<< L << "\n";
//       if (L > 0.002) 
//       {
// 	std::cout << "  ----------------- bad fitting L\n";
// 	result_.bad  = 1;
//       }
      
      // look for rings
      result_.v_path.resize(5);
      result_.v_rz.resize(5);
      for (uint i = 1; i < 5; i++)
      {
	float dz;
	tf::Transform tf_table2ring = get_trsf_to_ring (get_idx_ring(i), v_tf_table2cupbase[i], v_cup_dim[i], dz);
	v_stf_table2ring[i] = tf::StampedTransform(tf_table2ring, ros::Time::now(),"/tool_frame","/cups_frame/"+std::to_string(i));
	result_.v_path[i] = get_cupPath(i);
	result_.v_rz[i] = dz;
      }	
      
      
      result_.got_Perform = true;
    }   
    
    int compare_Grip_Perform (const Grip_Perform &A, const Grip_Perform &B)	// if A better than B , a>b
    {
//      yf_pcl_process::msg_grip_tfs_cfg grip;
// 	std::vector <float> v_rz;	// angular deviation between cupBase and ring
// 	std::vector <float> v_dxy;	// distance between cupbase and ring center in xy
// 	std::vector <cupPath> v_path;
// 	float fitRate;
// 	
// 	uint interations;
// 	
// 	uint bad; 
      uint improved = 1;
      uint toobad = 0;
      
      if (A.v_rz.size() == B.v_rz.size() && A.v_rz.size() == 5)
	for (uint i = 1; i<5; i++)	// angle dif
	{
// 	  if (A.v_rz[i] > 0.174) return 0;	
	  if (B.v_rz[i] > 0.08)
	  {
	    if (A.v_rz[i] < B.v_rz[i]-0.04) 	improved += 1; 	// if angle deviation get over 2.3° closer
	    if (A.v_rz[i] > B.v_rz[i]+0.04) 	improved -= 2; 	// if angle deviation get over 2.3° away
	  }
	    
	    
	  if (B.v_dxy[i] > 0.002){
	    if (A.v_dxy[i] < B.v_dxy[i]-0.001) 	improved += 10; 	// if fitting get over 1mm closer
	    if (A.v_dxy[i] > B.v_dxy[i]+0.001) 	improved -= 20; 	// if fitting get over 1mm away
	  }
	  
	  float sumA = 0, sumB = 0;	// 0.0 ~ 8.0
	  for (auto &p : A.v_path[i].v_path)	sumA += p;
	  for (auto &p : B.v_path[i].v_path)	sumB += p;
	  
	  {
	    if (sumA > sumB +0.8) 		improved += 100; 	// if path is better than "not too much worse"
	    if (sumA < sumB -0.8) 		improved -= 200; 	// if path is better than "not too much worse"
	  }
	}
	
      return improved;
      
    }
    
    
    cupPath get_cupPath (uint cupX)
    {
      if (v_idx_ring[cupX]->size()<2) setget_tf_to_ring_cupX(cupX);	// init idx_ring and stf for cupX
      tf::Transform tf_ringX (v_stf_table2ring[cupX].inverse());
      pcl::PointXYZ pt0 = cloud->at(v_idx_ring[cupX]->at(0));
      ///////////////////	check the overlap of idx_ring and cloud_inlander
      float ring_count = v_idx_ring[cupX]->size();
      
      
      cupPath cP, cPsum;
      uint inlander_sum = 0;
      for (uint i = 1; i<ring_count; i++)
      {
	uint idx = v_idx_ring[cupX]->at(i);
	
	pcl::PointXYZ ptBarrier = cloud->at(idx);
	tf::Point tfP_barrier (ptBarrier.x,ptBarrier.y,ptBarrier.z);
	tfP_barrier = tf_ringX*tfP_barrier;
	float theta = atan2(tfP_barrier.y(),tfP_barrier.x());
	uint pathN = round(theta*rad2deg/45);
	pathN = pathN % 8;
	cPsum.v_path[pathN] += 1.0;
	
	if (isnan(cloud_inlander->at(idx).x))		cP.v_path[pathN] += 1.0;
	else 
	{  
// 	  tf::Point Pnorm(normals->at(idx).normal_x,normals->at(idx).normal_y,normals->at(idx).normal_z);
// 	  if ((tf_ringX*Pnorm).z() < 0.997564)			// < cos(4°)
// 	  {
// 	    std::cout<< (tf_ringX*Pnorm).z()<<"  ";
// 	    cP.v_path[pathN] += 1.0;
// 	  }
	}
      }
      for (uint i = 0; i<cP.v_path.size(); i++) cP.v_path[i] = 1.0 - cP.v_path[i]/cPsum.v_path[i];
      
//       std::cout << "\n cup "<<cupX<<": \n";      
//       for (uint i = 0; i<cP.v_path.size(); i++) std::cout<<std::setprecision(1)<<"cP"<<i<<" : "<<cP.v_path[i]<<"\t";
      
      return cP;
    }
    
//     std::vector< yf_pcl_process::msg_grip_tfs_cfg> get_v_msg_grip_tend(std::vector< yf_pcl_process::msg_grip_tfs_cfg> & v_Rt)
    uint get_v_msg_grip_tend_copy1(std::vector< yf_pcl_process::msg_grip_tfs_cfg> & v_Rt)
    {
//       std::vector< yf_pcl_process::msg_grip_tfs_cfg> v_Rt ;
      yf_pcl_process::msg_grip_tfs_cfg rt = msg_grip_now;
      // rt contains tend of maneuver in those dimensions: x, y, theta, cfgX
      
      auto min12 = [](float a, float &min1, float &min2)	// ranking 1.st min and 2.nd min
      {
	  if      (a<min1)	{ min2 = min1; min1 = a; }
	  else if (a<min2) 	{ min2 = a;}
      };      
      
      auto min123 = [](float a, float &min1, float &min2, float &min3)	// ranking 1.st min and 2.nd min
      {
	  if      (a<min1)	{ min3 = min2; min2 = min1; min1 = a; }
	  else if (a<min2) 	{ min3 = min2; min2 = a; }
	  else if (a<min3) 	{ min3 = a;}
      };      
      
      auto max12 = [](float a, float &max1, float &max2)	// ranking 1.st min and 2.nd min
      {
	  if      (a>max1)	{ max2 = max1; max1 = a; }
	  else if (a>max2) 	{ max2 = a;}
      };
      
      std::vector < cupPath > v_cupPath;
      v_cupPath.resize(5);
      for (uint i = 1; i < 5; i++)
      {
	v_cupPath[i] = get_cupPath(i);
      }
      
      
      // look for movement of x,y
      std::cout<<"\nmaneuver x,y : ";
      cupPath cupPath_Can = cupPath();
      
      {
	float K;	float k2;	 float a;
	for (uint i = 0; i< 8; i++)
	{
	  K = 7; k2 = 7;
	  a = v_cupPath[1].v_path[i]; 	min12(a, K, k2);
	  a = v_cupPath[2].v_path[i];	min12(a, K, k2);
	  a = v_cupPath[3].v_path[i];	min12(a, K, k2);
	  a = v_cupPath[4].v_path[i];	min12(a, K, k2);
	  
	  cupPath_Can.v_path[i] = 0.5*(k2+K);
	  std::cout<<cupPath_Can.v_path[i]<<"   ";
	  
	  if (cupPath_Can.v_path[i] > 0.66)
	  {
	    v_Rt.push_back(move_xy(msg_grip_now, i, cupPath_Can.v_path[i] * 0.005));
	  }
	  
	}
      }
      // look for movement of theta
      std::cout<<"\nmaneuver theta : ";
      float theta_pls, theta_mns;
      
      float alpha = atan2(msg_grip_now.cfgY, msg_grip_now.cfgX);
//       std::cout<<std::setprecision(4)<<"\n cfgX: "<<msg_grip_now.cfgX<<"     cfgY: "<<msg_grip_now.cfgY<<"     alpha: "<< alpha*rad2deg << "\n";
      
      float pathN = alpha*rad2deg/45;
      uint pathN_ceil = ceil(pathN)  ;		uint pathN_flor = floor(pathN) ;	
      float t = pathN - pathN_flor;
//       std::cout<<std::setprecision(4)<<"\n pathN: "<<pathN<<"     pathN_ceil: "<<pathN_ceil<<"     pathN_flor: "<< pathN_flor<<"     t: "<< t << "\n";
            
      // take the 2.nd min as tendency of rotation (theta)
      if (pathN_flor == 0) 
      {
	float K;	float k2;	 float a;
      // anti-clock, + theta: 
	K = 7; k2 = 7;
	
	a = v_cupPath[1].v_path[6]*(1-t)+v_cupPath[1].v_path[7]*t;	min12(a, K, k2);
	a = v_cupPath[2].v_path[6]*(1-t)+v_cupPath[2].v_path[5]*t;	min12(a, K, k2);
	a = v_cupPath[3].v_path[2]*(1-t)+v_cupPath[3].v_path[1]*t;	min12(a, K, k2);
	a = v_cupPath[4].v_path[2]*(1-t)+v_cupPath[4].v_path[3]*t;	min12(a, K, k2);
	theta_pls = 0.5*(k2+K);
	
      // clock,      - theta: 
	K = 7; k2 = 7;
	a = v_cupPath[1].v_path[2]*(1-t)+v_cupPath[1].v_path[3]*t;	min12(a, K, k2);
	a = v_cupPath[2].v_path[2]*(1-t)+v_cupPath[2].v_path[1]*t;	min12(a, K, k2);
	a = v_cupPath[3].v_path[6]*(1-t)+v_cupPath[3].v_path[5]*t;	min12(a, K, k2);
	a = v_cupPath[4].v_path[6]*(1-t)+v_cupPath[4].v_path[7]*t;	min12(a, K, k2);
	theta_mns = 0.5*(k2+K);
	
      }
      else 
      {
	float K;	float k2;	 float a;
      // anti-clock, + theta: 
	K = 7; k2 = 7;
	a = v_cupPath[1].v_path[0]*t+v_cupPath[1].v_path[7]*(1-t);	min12(a, K, k2);
	a = v_cupPath[2].v_path[4]*t+v_cupPath[2].v_path[5]*(1-t);	min12(a, K, k2);
	a = v_cupPath[3].v_path[0]*t+v_cupPath[3].v_path[1]*(1-t);	min12(a, K, k2);
	a = v_cupPath[4].v_path[4]*t+v_cupPath[4].v_path[3]*(1-t);	min12(a, K, k2);
	theta_pls = 0.5*(k2+K);
	
      // clock,      - theta: 
	K = 7; k2 = 7;
	a = v_cupPath[1].v_path[4]*t+v_cupPath[1].v_path[3]*(1-t);	min12(a, K, k2);
	a = v_cupPath[2].v_path[0]*t+v_cupPath[2].v_path[1]*(1-t);	min12(a, K, k2);
	a = v_cupPath[3].v_path[4]*t+v_cupPath[3].v_path[5]*(1-t);	min12(a, K, k2);
	a = v_cupPath[4].v_path[0]*t+v_cupPath[4].v_path[7]*(1-t);	min12(a, K, k2);
	theta_mns = 0.5*(k2+K);
	
      }
      std::cout<<std::setprecision(4)<<"\n theta_pls: "<<theta_pls<<"     theta_mns: "<<theta_mns<<"\n";
      if (theta_pls > 0.66)
      {
	v_Rt.push_back(move_theta(msg_grip_now, theta_pls * 0.05)); 	//rotate 3°
      }
      if (theta_mns > 0.66)
      {
	v_Rt.push_back(move_theta(msg_grip_now, -theta_mns * 0.05));
      }
      
      // look for movement of cfgX
      std::cout<<"\nmaneuver cfgX : ";
      float cfgX_pls, cfgX_mns;
      {
	float K;	float k2;	 float a;
      // clamping inward, - cfgX: 
	K = 7; k2 = 7;
	a = v_cupPath[1].v_path[0] + v_cupPath[3].v_path[4];	min12(a, K, k2);
	a = v_cupPath[2].v_path[0] + v_cupPath[4].v_path[4];	min12(a, K, k2);
// 	a = v_cupPath[3].v_path[4];	min12(a, K, k2);
// 	a = v_cupPath[4].v_path[4];	min12(a, K, k2);
	
	cfgX_mns = K;
	
      // spread out,      + cfgX: 
	K = 7; k2 = 7;
	a = v_cupPath[1].v_path[4] + v_cupPath[3].v_path[0];	min12(a, K, k2);
	a = v_cupPath[2].v_path[4] + v_cupPath[4].v_path[0];	min12(a, K, k2);
// 	a = v_cupPath[3].v_path[0];	min12(a, K, k2);
// 	a = v_cupPath[4].v_path[0];	min12(a, K, k2);
	
	cfgX_pls = K;
	
      }
      std::cout<<std::setprecision(4)<<"\n cfg+: "<<cfgX_pls<<"     cfgX-: "<<cfgX_mns<<"\n";
      if (cfgX_pls > 0.66)
      {
	v_Rt.push_back(move_cfgX(msg_grip_now, cfgX_pls * 0.005)); 	//rotate 3°
      }
      if (cfgX_mns > 0.66)
      {
	v_Rt.push_back(move_cfgX(msg_grip_now, -cfgX_mns * 0.005));
      }
      
//       msg_grip_now.cfgX;
      
      std::cout<<"\n v_Rt "<<v_Rt.size()<<"\n";
      
      return 1;
    }
    
    float get_v_msg_grip_tend(std::vector< maneuverGrip::Grip_Perform> & v_Rt)
    {// return 0:fail to extend, x:extensions, -1:good enough
//       std::vector< yf_pcl_process::msg_grip_tfs_cfg> v_Rt ;
      yf_pcl_process::msg_grip_tfs_cfg rt = msg_grip_now;
      // rt contains tend of maneuver in those dimensions: x, y, theta, cfgX
      
      auto min12 = [](float a, float &min1, float &min2)	// ranking 1.st min and 2.nd min
      {
	  if      (a<min1)	{ min2 = min1; min1 = a; }
	  else if (a<min2) 	{ min2 = a;}
      };      
      
//       auto min123 = [](float a, float &min1, float &min2, float &min3)	// ranking 1.st min and 2.nd min
//       {
// 	  if      (a<min1)	{ min3 = min2; min2 = min1; min1 = a; }
// 	  else if (a<min2) 	{ min3 = min2; min2 = a; }
// 	  else if (a<min3) 	{ min3 = a;}
//       };      
      
//       auto max12 = [](float a, float &max1, float &max2)	// ranking 1.st min and 2.nd min
//       {
// 	  if      (a>max1)	{ max2 = max1; max1 = a; }
// 	  else if (a>max2) 	{ max2 = a;}
//       };
      
      std::vector < cupPath > v_cupPath;
      v_cupPath.resize(5);
      for (uint i = 1; i < 5; i++)
      {
	v_cupPath[i] = get_cupPath(i);
      }
      
      
      // look for movement of x,y
      std::cout<<"\nmaneuver x,y : ";
      cupPath cupPath_Can = cupPath();
      
      float path_sum = 0;
      {
	float K;	float k2;	 float a;
	for (uint i = 0; i< 8; i++)
	{
	  K = 7; k2 = 7;
	  a = v_cupPath[1].v_path[i]; 	min12(a, K, k2);
	  a = v_cupPath[2].v_path[i];	min12(a, K, k2);
	  a = v_cupPath[3].v_path[i];	min12(a, K, k2);
	  a = v_cupPath[4].v_path[i];	min12(a, K, k2);
	  
	  cupPath_Can.v_path[i] = 0.5*(k2+K);
	  path_sum += cupPath_Can.v_path[i];
	}
      }
      
      // check ring quality
      if ( path_sum > 0.8*8) return path_sum;   ////////////////// if good enough, stop maneuver and return current stage
      
      // look for movement of theta
      std::cout<<"\nmaneuver theta : ";
      float theta_pls, theta_mns;
      
      float alpha = atan2(msg_grip_now.cfgY, msg_grip_now.cfgX);
//       std::cout<<std::setprecision(4)<<"\n cfgX: "<<msg_grip_now.cfgX<<"     cfgY: "<<msg_grip_now.cfgY<<"     alpha: "<< alpha*rad2deg << "\n";
      
      float pathN = alpha*rad2deg/45;
      uint pathN_ceil = ceil(pathN)  ;		uint pathN_flor = floor(pathN) ;	
      float t = pathN - pathN_flor;
//       std::cout<<std::setprecision(4)<<"\n pathN: "<<pathN<<"     pathN_ceil: "<<pathN_ceil<<"     pathN_flor: "<< pathN_flor<<"     t: "<< t << "\n";
            
      // take the 2.nd min as tendency of rotation (theta)
      if (pathN_flor == 0) 
      {
	float K;	float k2;	 float a, b;	
      // anti-clock, + theta: 
	K = 7; k2 = 7;
	
	a = std::min(v_cupPath[1].v_path[6]*(1-t)+v_cupPath[1].v_path[7]*t, v_cupPath[2].v_path[6]*(1-t)+v_cupPath[2].v_path[5]*t);
	b = std::min(v_cupPath[3].v_path[2]*(1-t)+v_cupPath[3].v_path[1]*t, v_cupPath[4].v_path[2]*(1-t)+v_cupPath[4].v_path[3]*t);
	theta_pls = std::max(a,b);
	
      // clock,      - theta: 
	K = 7; k2 = 7;
	
	a = std::min(v_cupPath[2].v_path[2]*(1-t)+v_cupPath[2].v_path[1]*t, v_cupPath[2].v_path[2]*(1-t)+v_cupPath[2].v_path[1]*t);
	b = std::min(v_cupPath[3].v_path[6]*(1-t)+v_cupPath[3].v_path[5]*t, v_cupPath[4].v_path[6]*(1-t)+v_cupPath[4].v_path[7]*t);
	theta_mns = std::max(a,b);
	
      }
      else 
      {
	float K;	float k2;	 float a, b;
      // anti-clock, + theta: 
	K = 7; k2 = 7;
	a = std::min(v_cupPath[1].v_path[0]*t+v_cupPath[1].v_path[7]*(1-t), v_cupPath[3].v_path[0]*t+v_cupPath[3].v_path[1]*(1-t));
	b = std::min(v_cupPath[2].v_path[4]*t+v_cupPath[2].v_path[5]*(1-t), v_cupPath[4].v_path[4]*t+v_cupPath[4].v_path[3]*(1-t));
	theta_pls = std::max(a,b);
	
      // clock,      - theta: 
	K = 7; k2 = 7;
	a = std::min(v_cupPath[1].v_path[4]*t+v_cupPath[1].v_path[3]*(1-t), v_cupPath[3].v_path[4]*t+v_cupPath[3].v_path[5]*(1-t));
	b = std::min(v_cupPath[2].v_path[0]*t+v_cupPath[2].v_path[1]*(1-t), v_cupPath[4].v_path[0]*t+v_cupPath[4].v_path[7]*(1-t));
	theta_mns = std::max(a,b);
	
      }
      
      
      // look for movement of cfgX
      std::cout<<"\nmaneuver cfgX : ";
      float cfgX_pls, cfgX_mns;
      {
	float K;	float k2;	 float a;
      // clamping inward, - cfgX: 
	K = 7; k2 = 7;
	a = v_cupPath[1].v_path[0] + v_cupPath[3].v_path[4];	min12(a, K, k2);
	a = v_cupPath[2].v_path[0] + v_cupPath[4].v_path[4];	min12(a, K, k2);
	cfgX_mns = K;
	
      // spread out,      + cfgX: 
	K = 7; k2 = 7;
	a = v_cupPath[1].v_path[4] + v_cupPath[3].v_path[0];	min12(a, K, k2);
	a = v_cupPath[2].v_path[4] + v_cupPath[4].v_path[0];	min12(a, K, k2);
	cfgX_pls = K;
	
      }

      v_Rt.clear();////////////////////////////
      v_Rt.push_back(maneuverGrip::Grip_Perform(msg_grip_now));
      
      uint tendN = 0;
      for (uint i = 0; i< 8; i++)
      {
	std::cout<<cupPath_Can.v_path[i]<<"   ";
	if (cupPath_Can.v_path[i] > 0.75)
	{
	  std::cout << "move_xy."<<i<<" : "<< cupPath_Can.v_path[i] * 0.005 << std::endl;
	  tendN++;
	  maneuverGrip::Grip_Perform Rt(move_xy(msg_grip_now, i, cupPath_Can.v_path[i] * 0.005));
	  v_Rt.push_back(Rt);
	}
      }
      
      std::cout<<std::setprecision(4)<<"\n theta_pls: "<<theta_pls<<"     theta_mns: "<<theta_mns<<"\n";
      if (theta_pls > 0.75)
      {
	std::cout << "move_theta : +"<< theta_pls * 0.05 << std::endl;
	  tendN++;
	maneuverGrip::Grip_Perform Rt( move_theta(msg_grip_now, theta_pls * 0.05) );//rotate 3°
	v_Rt.push_back(Rt);
      }
      if (theta_mns > 0.75)
      {
	std::cout << "move_theta : "<< -theta_mns * 0.05 << std::endl;
	  tendN++;	
	maneuverGrip::Grip_Perform Rt( move_theta(msg_grip_now, -theta_mns * 0.05) );
	v_Rt.push_back(Rt);
      }

      std::cout<<std::setprecision(4)<<"\n cfg+: "<<cfgX_pls<<"     cfgX-: "<<cfgX_mns<<"\n";
      if (cfgX_pls > 0.88)
      {
	std::cout << "move_cfgX : +"<< cfgX_pls * 0.01 << std::endl;
	  tendN++;
  	maneuverGrip::Grip_Perform Rt( move_cfgX(msg_grip_now, cfgX_pls * 0.005) );//
	v_Rt.push_back(Rt);
      }
      if (cfgX_mns > 0.88)
//       if (tendN < 3)	// only try reducing cfgX when there're no much options
      {
	std::cout << "move_cfgX : "<< cfgX_mns * 0.01 << std::endl;
	  tendN++;
	maneuverGrip::Grip_Perform Rt( move_cfgX(msg_grip_now, -cfgX_mns * 0.005) );
	v_Rt.push_back(Rt);
      }
      
//       msg_grip_now.cfgX;
      
      std::cout<<"\n v_Rt "<<v_Rt.size()<<"\n";
      
      return path_sum;
    }
    
    float get_v_GP_for_gp(maneuverGrip::Grip_Perform &GP_in, std::vector< maneuverGrip::Grip_Perform> & v_Rt)
    {
      
      yf_pcl_process::msg_grip_tfs_cfg rt = GP_in.grip;
      print_Grip_Perform(GP_in);
      // rt contains tend of maneuver in those dimensions: x, y, theta, cfgX
      
      auto min12 = [](float a, float &min1, float &min2)	// ranking 1.st min and 2.nd min
      {
	  if      (a<min1)	{ min2 = min1; min1 = a; }
	  else if (a<min2) 	{ min2 = a;}
      };      
      
      std::vector < cupPath > v_cupPath;
      v_cupPath.resize(5);
      for (uint i = 1; i < 5; i++)
      {
	v_cupPath[i] = GP_in.v_path[i];
      }
      
      
      // look for movement of x,y
      std::cout<<"\nmaneuver x,y : ";
      cupPath cupPath_Can = cupPath();
      
      float path_sum = 0;
      {
	float K;	float k2;	 float a;
	for (uint i = 0; i< 8; i++)
	{
	  K = 7; k2 = 7;
	  a = v_cupPath[1].v_path[i]; 	min12(a, K, k2);
	  a = v_cupPath[2].v_path[i];	min12(a, K, k2);
	  a = v_cupPath[3].v_path[i];	min12(a, K, k2);
	  a = v_cupPath[4].v_path[i];	min12(a, K, k2);
	  
	  cupPath_Can.v_path[i] = 0.5*(k2+K);
	  path_sum += cupPath_Can.v_path[i];
	}
      }
      
      // check ring quality
//       if ( path_sum > 0.8*8) return path_sum;   ////////////////// if good enough, stop maneuver and return current stage
      
      // look for movement of theta
      std::cout<<"\nmaneuver theta : ";
      float theta_pls, theta_mns;
      
      float alpha = atan2(rt.cfgY, rt.cfgX);
//       std::cout<<std::setprecision(4)<<"\n cfgX: "<<rt.cfgX<<"     cfgY: "<<rt.cfgY<<"     alpha: "<< alpha*rad2deg << "\n";
      
      float pathN = alpha*rad2deg/45;
      uint pathN_ceil = ceil(pathN)  ;		uint pathN_flor = floor(pathN) ;	
      float t = pathN - pathN_flor;
//       std::cout<<std::setprecision(4)<<"\n pathN: "<<pathN<<"     pathN_ceil: "<<pathN_ceil<<"     pathN_flor: "<< pathN_flor<<"     t: "<< t << "\n";
            
      // take the 2.nd min as tendency of rotation (theta)
      if (pathN_flor == 0) 
      {
	float K;	float k2;	 float a, b;	
      // anti-clock, + theta: 
	K = 7; k2 = 7;
	
	a = std::min(v_cupPath[1].v_path[6]*(1-t)+v_cupPath[1].v_path[7]*t, v_cupPath[2].v_path[6]*(1-t)+v_cupPath[2].v_path[5]*t);
	b = std::min(v_cupPath[3].v_path[2]*(1-t)+v_cupPath[3].v_path[1]*t, v_cupPath[4].v_path[2]*(1-t)+v_cupPath[4].v_path[3]*t);
	theta_pls = std::max(a,b);
	
      // clock,      - theta: 
	K = 7; k2 = 7;
	
	a = std::min(v_cupPath[2].v_path[2]*(1-t)+v_cupPath[2].v_path[1]*t, v_cupPath[2].v_path[2]*(1-t)+v_cupPath[2].v_path[1]*t);
	b = std::min(v_cupPath[3].v_path[6]*(1-t)+v_cupPath[3].v_path[5]*t, v_cupPath[4].v_path[6]*(1-t)+v_cupPath[4].v_path[7]*t);
	theta_mns = std::max(a,b);
	
      }
      else 
      {
	float K;	float k2;	 float a, b;
      // anti-clock, + theta: 
	K = 7; k2 = 7;
	a = std::min(v_cupPath[1].v_path[0]*t+v_cupPath[1].v_path[7]*(1-t), v_cupPath[3].v_path[0]*t+v_cupPath[3].v_path[1]*(1-t));
	b = std::min(v_cupPath[2].v_path[4]*t+v_cupPath[2].v_path[5]*(1-t), v_cupPath[4].v_path[4]*t+v_cupPath[4].v_path[3]*(1-t));
	theta_pls = std::max(a,b);
	
      // clock,      - theta: 
	K = 7; k2 = 7;
	a = std::min(v_cupPath[1].v_path[4]*t+v_cupPath[1].v_path[3]*(1-t), v_cupPath[3].v_path[4]*t+v_cupPath[3].v_path[5]*(1-t));
	b = std::min(v_cupPath[2].v_path[0]*t+v_cupPath[2].v_path[1]*(1-t), v_cupPath[4].v_path[0]*t+v_cupPath[4].v_path[7]*(1-t));
	theta_mns = std::max(a,b);
	
      }
      
      
      // look for movement of cfgX
      std::cout<<"\nmaneuver cfgX : ";
      float cfgX_pls, cfgX_mns;
      {
	float K;	float k2;	 float a;
      // clamping inward, - cfgX: 
	K = 7; k2 = 7;
	a = v_cupPath[1].v_path[0] + v_cupPath[3].v_path[4];	min12(a, K, k2);
	a = v_cupPath[2].v_path[0] + v_cupPath[4].v_path[4];	min12(a, K, k2);
	cfgX_mns = K;
	
      // spread out,      + cfgX: 
	K = 7; k2 = 7;
	a = v_cupPath[1].v_path[4] + v_cupPath[3].v_path[0];	min12(a, K, k2);
	a = v_cupPath[2].v_path[4] + v_cupPath[4].v_path[0];	min12(a, K, k2);
	cfgX_pls = K;
	
      }

      v_Rt.clear();////////////////////////////
//       v_Rt.push_back(maneuverGrip::Grip_Perform(rt));
      v_Rt.push_back(GP_in);

//       std::cout<<"GP_in is =";
//       print_Grip_Perform(GP_in);
      
      uint tendN = 0;
      for (uint i = 0; i< 8; i++)
      {
	std::cout<<cupPath_Can.v_path[i]<<"   ";
	if (cupPath_Can.v_path[i] > 0.75)
	{
	  std::cout << "move_xy."<<i<<" : "<< cupPath_Can.v_path[i] * 0.005 << std::endl;
	  tendN++;
	  maneuverGrip::Grip_Perform Rt(move_xy(rt, i, cupPath_Can.v_path[i] * 0.005));
// 	  Rt.dad = &GP_in;
	  v_Rt.push_back(Rt);
// 	  GP_in.kids.push_back( &( v_Rt.back() ) );
	}
      }
      
      std::cout<<std::setprecision(4)<<"\n theta_pls: "<<theta_pls<<"     theta_mns: "<<theta_mns<<"\n";
      if (theta_pls > 0.7)
      {
	std::cout << "move_theta : +"<< theta_pls * 0.05 << std::endl;
	  tendN++;
	maneuverGrip::Grip_Perform Rt( move_theta(rt, theta_pls * 0.03) );//rotate 3°
// 	  Rt.dad = &GP_in;
	  v_Rt.push_back(Rt);
// 	  GP_in.kids.push_back( &( v_Rt.back() ) );
      }
      if (theta_mns > 0.7)
      {
	std::cout << "move_theta : "<< -theta_mns * 0.05 << std::endl;
	  tendN++;	
	maneuverGrip::Grip_Perform Rt( move_theta(rt, -theta_mns * 0.03) );
// 	  Rt.dad = &GP_in;
	  v_Rt.push_back(Rt);
// 	  GP_in.kids.push_back( &( v_Rt.back() ) );
      }

      std::cout<<std::setprecision(4)<<"\n cfg+: "<<cfgX_pls<<"     cfgX-: "<<cfgX_mns<<"\n";
      if (cfgX_pls > 0.88)
      {
	std::cout << "move_cfgX : +"<< cfgX_pls * 0.005 << std::endl;
	  tendN++;
  	maneuverGrip::Grip_Perform Rt( move_cfgX(rt, cfgX_pls * 0.005) );//
// 	  Rt.dad = &GP_in;
	  v_Rt.push_back(Rt);
// 	  GP_in.kids.push_back( &( v_Rt.back() ) );
      }
      if (cfgX_mns > 0.88)
//       if (tendN < 3)	// only try reducing cfgX when there're no much options
      {
	std::cout << "move_cfgX : "<< cfgX_mns * 0.005 << std::endl;
	  tendN++;
	maneuverGrip::Grip_Perform Rt( move_cfgX(rt, -cfgX_mns * 0.005) );
// 	  Rt.dad = &GP_in;
	  v_Rt.push_back(Rt);
// 	  GP_in.kids.push_back( &( v_Rt.back() ) );
      }
      
//       msg_grip_now.cfgX;
      
      std::cout<<"\n v_Rt "<<v_Rt.size()<<"\n";
      
      return path_sum;      
    }
    
    float trim_leaf_GP(std::vector < maneuverGrip::Grip_Perform > & v_Rt_GP)
    {
      if (v_Rt_GP.size()<1) return 0.0;
      std::vector <uint> toErase = {};
      int improve;
      
      try_Grip_get_Perform(v_Rt_GP[0]);
      print_Grip_Perform (v_Rt_GP[0]);
      
      for (uint i = 1; i < v_Rt_GP.size(); i++)
      {
	try_Grip_get_Perform(v_Rt_GP[i]);
//  	print_Grip_Perform (v_Rt_GP[i]);
	
// 	if (v_Rt_GP[i].bad) toErase.push_back(i);
	
// 	std::cout << "compare "<< i << "  \n";
 	improve = compare_Grip_Perform(v_Rt_GP[i], v_Rt_GP[0]);
	std::cout << "compare "<< i << "  : "<<v_Rt_GP[i].grip.name<<"  \timprove: " <<improve<<" \t-> ";
 	if (improve < 1) 
	{
	  std::cout << "erase "<< i << "\n";
 	  toErase.push_back(i);
	}
	else
	{
	  std::cout << "aprove "<< i << "\n";
	}
	// if obj is bad or there are no improvement
// 	break;
      }
      
       for (int i = toErase.size()-1; i>=0; i--)
       {
// 	  std::cout << "erase "<< toErase[i] << "  ";
	  v_Rt_GP.erase(v_Rt_GP.begin()+toErase[i]);
       }
       std::cout <<"\n --------------- AFTER ERASE --------------- \n";
       for (uint i = 1; i < v_Rt_GP.size(); i++)
       {
         print_Grip_Perform (v_Rt_GP[i]);
       }
    }    
    
    float apply_tend(yf_pcl_process::msg_grip_tfs_cfg Rt_Msg)
    {
       std::cout << "apply_tend  ";
       
      float fitRate;
      set_MsgGrip(Rt_Msg);
//        std::cout << "set  ";
      apply_MsgGrip();
//        std::cout << "apply_MsgGrip  ";
      fitRate = fit_MsgGrip();
//        std::cout << "fit_MsgGrip  ";
    }
    
    
    class cupTend		// tendancy of movement, avoiding obstacles according to cupHinder
    {
      public:
	tf::Point poke;		// linear force applied to cup according to cupbaseframe[N]
	tf::Point screw;		// torque applied to cup according to cupbaseframe[0]      
	
	cupTend(): poke(tf::Point(0,0,0)),screw(tf::Point(0,0,0)) 		{};
	cupTend(tf::Point poke_, tf::Point screw_): poke(poke_), screw(screw_) 	{};
    };
    
    cupTend set_cupTend(tf::Point poke_, int cupX)
    {
      cupTend tmp;
      tmp.poke = poke_;
      tf::Point L = v_stf_Tool2CupBases[cupX].getOrigin();
      tmp.screw = tf::tfCross(L, poke_);
      return tmp;
    }
    
    cupTend get_cupTend_rand (uint cupX)
    {
      setget_tf_to_ring_cupX(cupX);	// init idx_ring and stf for cupX
      // v_idx_ring(cupX) & v_stf_table2ring[cupX] available now
      get_cupPath(cupX);
      
    }
    
/////////////////////////////basis
    pcl::IndicesPtr get_idx_ring(uint cupX)    
    {
      tf::Point searchPoint = v_tf_table2cupbase[cupX].getOrigin();
      pcl::IndicesPtr idx_ring = get_idx_ring(searchPoint, v_cup_dim[cupX]);  
      v_idx_ring[cupX] = pcl::IndicesPtr(idx_ring);
      return idx_ring;
    }
/*    
    pcl::IndicesPtr get_idx_ring(tf::Point searchPoint )    
    { 
      pcl::PointXYZ searchPoint2(searchPoint.x(),searchPoint.y(),searchPoint.z());
      return get_idx_ring(searchPoint2, cup_dim_);  
    }*/

    pcl::IndicesPtr get_idx_ring(tf::Point searchPoint, yf_vacuum_cups::cup_dim cup_lc )
    { 
      pcl::PointXYZ searchPoint2(searchPoint.x(),searchPoint.y(),searchPoint.z());
      return get_idx_ring(searchPoint2, cup_lc);  
    }    
    
//     pcl::IndicesPtr get_idx_ring(pcl::PointXYZ searchPoint )    {      return get_idx_ring(searchPoint, cup_dim_);    }
    
    pcl::IndicesPtr get_idx_ring(pcl::PointXYZ searchPoint, yf_vacuum_cups::cup_dim cup_lc )
    {
//       std::cout <<" get_idx_ring :" << ros::Time::now()-RosTimeBegin << " ~ ";
	float rim_in = 0.95*cup_lc.radius-0.0014, rim_out = 1.05*(cup_lc.radius+0.5*cup_lc.lengthen)+0.0014;	// setting search region for the contact rim
	if (rim_in < 0.005) rim_in = 0.0;
	
	pcl::IndicesPtr idx_find_out (new std::vector <int>), idx_find_in (new std::vector <int>); 
	pcl::IndicesPtr idx_ring (new std::vector <int>);	// segmentation of surface which (may) have contact with the vacuum cup
	std::vector<float> dump;
	
// 	tree_inlander.setInputCloud(cloud, idx_inlander);
	
	tree_inlander.nearestKSearch (searchPoint, 1, *idx_find_out, dump);
	size_t id_center = idx_find_out->at(0); 	pcl::PointXYZ Pt_center = cloud->points[id_center];
	
	if ( tree_cloud.radiusSearch (Pt_center, rim_out, *idx_find_out, dump) > 0 )	{}	//nullptr
#if 0
	if ( tree_cloud.radiusSearch (Pt_center, rim_in, *idx_find_in, dump) > 0 )	{}
	std::set_difference(idx_find_out->begin(), idx_find_out->end(), idx_find_in->begin(), idx_find_in->end(), 
			    std::inserter(*idx_ring, idx_ring->begin()));
#else
	*idx_ring = *idx_find_out;
#endif
	
	idx_ring->insert(idx_ring->begin(),id_center);
	
//       std::cout<<ros::Time::now()-RosTimeBegin<<"\n";

      return idx_ring;
    }

    tf::Transform get_tf_to_ring_cupX(uint cupX)
    {
      tf::Transform tf_table2ring = get_trsf_to_ring (get_idx_ring(cupX), v_tf_table2cupbase[cupX], v_cup_dim[cupX]);
//       v_stf_table2ring[cupX] = tf::StampedTransform(tf_table2ring, ros::Time::now(),"/tool_frame","/cups_frame/"+std::to_string(cupX));
      return tf_table2ring;
    }
    
    tf::Transform setget_tf_to_ring_cupX(uint cupX)
    {
      tf::Transform tf_table2ring = get_trsf_to_ring (get_idx_ring(cupX), v_tf_table2cupbase[cupX], v_cup_dim[cupX]);
      v_stf_table2ring[cupX] = tf::StampedTransform(tf_table2ring, ros::Time::now(),"/tool_frame","/cups_frame/"+std::to_string(cupX));
      return tf_table2ring;
    }
    
    tf::Transform get_trsf_to_ring (pcl::IndicesPtr idx_ring, tf::Transform tf_tool_loc, yf_vacuum_cups::cup_dim cup_lc)
    {
      float dz;
      return get_trsf_to_ring (idx_ring, tf_tool_loc, cup_lc, dz);
    }
    
    tf::Transform get_trsf_to_ring (pcl::IndicesPtr idx_ring, tf::Transform tf_tool_loc, yf_vacuum_cups::cup_dim cup_lc, float &dz)	// return the transform from frame to ring, regarding the best fit of cylinder
    {
      float theta, phi;
      tf::Point Pxyz = tf::Point(cloud->points[idx_ring->at(0)].x,cloud->points[idx_ring->at(0)].y,cloud->points[idx_ring->at(0)].z);
      
      float tmpfit;
      tf::Point Pnorm = get_v3_norm_ring(idx_ring, cup_lc, tmpfit, dz);
      
      tf::Quaternion q;
      tf::Vector3 v;
      tf::Point e_z (0,0,1);
      e_z = tf_tool_loc*e_z; 
      v = tf::tfCross(Pnorm,e_z);    v.normalize();
      q = tf::Quaternion(v, -1.0*tf::tfAngle(Pnorm, e_z));
      q = q * tf_tool_loc.getRotation();

      tf::Transform tf_Znorm = tf::Transform(q,Pxyz);
      return tf_Znorm;
    }
    
//     tf::Transform get_trsf_to_ring(pcl::IndicesPtr idx_ring)	// return the transform from frame to ring
//     {
//       return get_trsf_to_ring(idx_ring, stf_Table2Tool);
//     }
    /*
    tf::StampedTransform get_trsf_to_ring2 (pcl::IndicesPtr idx_ring, tf::Transform tf_tool_loc)	// return the transform from frame to ring, regarding the best fit of cylinder
    {
      float theta, phi;
      tf::Point Pxyz = tf::Point(cloud->points[idx_ring->at(0)].x,cloud->points[idx_ring->at(0)].y,cloud->points[idx_ring->at(0)].z);
      tf::Point Pnorm = get_v3_norm_ring(idx_ring);
      
      tf::Quaternion q;
      tf::Vector3 v;
      tf::Point e_z (0,0,1);
      e_z = tf_tool_loc*e_z; 
      v = tf::tfCross(Pnorm,e_z);    v.normalize();
      q = tf::Quaternion(v, -1.0*tf::tfAngle(Pnorm, e_z));
      q = q * tf_tool_loc.getRotation();

      tf::Transform tf_Znorm = tf::Transform(q,Pxyz);
      return tf::StampedTransform(tf_Znorm, ros::Time::now(),"/tool_frame","/keineAhnung");
    }
    
    tf::StampedTransform get_trsf_to_ring2 (pcl::IndicesPtr idx_ring)	// return the transform from frame to ring
    {
      return get_trsf_to_ring2(idx_ring, stf_Table2Tool);
    }*/
    
    tf::Point get_v3_norm_ring(pcl::IndicesPtr idx_ring, yf_vacuum_cups::cup_dim cup_lc)
    {
      float tmpfit, tmpdz;
      return get_v3_norm_ring(idx_ring, cup_lc, tmpfit, tmpdz);
    }
    
    tf::Point get_v3_norm_ring(pcl::IndicesPtr idx_ring, yf_vacuum_cups::cup_dim cup_lc, float &fitRate, float &dz)
    {

      tf::Point Pxyz = tf::Point(cloud->points[idx_ring->at(0)].x,cloud->points[idx_ring->at(0)].y,cloud->points[idx_ring->at(0)].z);
      tf::Point Pnorm2 = tf::Point(normals->points[idx_ring->at(0)].normal_x,normals->points[idx_ring->at(0)].normal_y,normals->points[idx_ring->at(0)].normal_z);
      fitRate = 0;
      if (idx_ring->size() < 3) return -Pnorm2;
      
//     ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   SAC plane");
//       pcl::SACSegmentationFromNormals<pcl::PointXYZ, pcl::Normal> seg; 
      pcl::SACSegmentation<pcl::PointXYZ> seg; 
      pcl::ModelCoefficients::Ptr coefficients_plane (new pcl::ModelCoefficients);
      pcl::PointIndices::Ptr inliers_plane (new pcl::PointIndices);
	
      seg.setOptimizeCoefficients (true);
      seg.setModelType (pcl::SACMODEL_PLANE);
      seg.setMethodType (pcl::SAC_RANSAC);
      seg.setMaxIterations (100);
//       seg.setEpsAngle(0.052);		// 3°
      seg.setDistanceThreshold (cup_lc.bend/2);		// plane deformation allowance
//       seg.setDistanceThreshold (0.0001);		// plane deformation allowance
      seg.setInputCloud (cloud);
//       seg.setInputNormals (normals);		//cloud_lN
      seg.setIndices(idx_ring);
      seg.segment (*inliers_plane, *coefficients_plane);
//     ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   SAC plane - fin");
    
//       std::cerr << "inliners: " << inliers_plane->indices.size() << "/"<< idx_ring->size() << std::endl;
      fitRate = (float) inliers_plane->indices.size()/idx_ring->size();
//       *idx_ring = inliers_plane->indices;
      tf::Point Pnorm = tf::Point(tf::Point(coefficients_plane->values[0],coefficients_plane->values[1],coefficients_plane->values[2]));
      dz = tf::tfAngle(Pnorm, -Pnorm2);
      if (dz>M_PI_2) 	{Pnorm = -Pnorm; dz = M_PI - dz; }
      return Pnorm;
    }
    
//     pcl::PointCloud<pcl::PointXYZ>::Ptr get_cloud_trsf_ring(pcl::PointXYZ P)    
//     {      return get_cloud_trsf_ring(P, cup_dim_);    }
    
//     pcl::PointCloud<pcl::PointXYZ>::Ptr get_cloud_trsf_ring(pcl::PointXYZ P, yf_vacuum_cups::cup_dim cup_lc)
//     {
//       pcl::IndicesPtr idx_ring = get_idx_ring(P, cup_lc);
//       tf::Transform tf_Znorm = get_trsf_to_ring(idx_ring, cup_lc);
//       return get_cloud_trsf_ring(idx_ring);
//     }
// 
//     pcl::PointCloud<pcl::PointXYZ>::Ptr get_cloud_trsf_ring(pcl::IndicesPtr idx_ring, yf_vacuum_cups::cup_dim cup_lc)
//     {
//       tf::Transform tf_Znorm = get_trsf_to_ring(idx_ring, cup_lc);
//       pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_ring (new pcl::PointCloud<pcl::PointXYZ>(*cloud, *(idx_ring)));
// 
//       pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_tfed (new pcl::PointCloud<pcl::PointXYZ>);
//       pcl_ros::transformPointCloud(*cloud_ring, *cloud_tfed, tf_Znorm.inverse());
//       return cloud_tfed;
//       
//     }
    
        
};

void yf_visualize_curvature(pcl::PointCloud<pcl::PointXYZ>::ConstPtr cloud_in_xyz, pcl::PointCloud<pcl::Normal>::ConstPtr cloud_in_norm, pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_out_xyzi)
{
//  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   visualizing curvature - ");
//    pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_with_I (new pcl::PointCloud<pcl::PointXYZI>);
  cloud_out_xyzi->resize(cloud_in_xyz->size ());
  cloud_out_xyzi->height = cloud_in_xyz->height;
  cloud_out_xyzi->width = cloud_in_xyz->width;
    for (size_t i = 0; i < cloud_in_xyz->size (); ++i)
    {
      pcl::PointXYZI ptxyzrgb;
      ptxyzrgb.x = cloud_in_xyz->points[i].x; ptxyzrgb.y = cloud_in_xyz->points[i].y; ptxyzrgb.z = cloud_in_xyz->points[i].z;
      ptxyzrgb.intensity = (cloud_in_norm->points[i].curvature);
      cloud_out_xyzi->points[i]=(ptxyzrgb);
    }
//  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   visualizing curvature - fin");    
}

int
main (int argc, char** argv)
{
  
  ros::init (argc, argv, "calc_Grip");
  ros::NodeHandle nh; 
  ros::NodeHandle priv_nh("~");
//  
  ros::Publisher Pub_ = nh.advertise<sensor_msgs::PointCloud2>("/surface_gen", 1, true);
  ros::Publisher Pub_ring = nh.advertise<sensor_msgs::PointCloud2>("/surface_gen_ring", 1, true);
  ros::Publisher Pub_ring2 = nh.advertise<sensor_msgs::PointCloud2>("/surface_gen_ring2", 1, true);
  ros::Publisher Pub_tfed = nh.advertise<sensor_msgs::PointCloud2>("/surface_gen_tfed", 1, true);
  ros::Publisher Pub_withI = nh.advertise<sensor_msgs::PointCloud2>("/surface_gen_withI", 1, true);
  ros::Publisher Pub_filtered = nh.advertise<sensor_msgs::PointCloud2>("/surface_gen_filtered", 1, true);
  ros::Publisher Pub_phidz = nh.advertise<sensor_msgs::PointCloud2>("/surface_gen_phidz", 1, true);
  ros::Publisher Pub_inlander = nh.advertise<sensor_msgs::PointCloud2>("/surface_gen_inlander", 1, true);
  ros::Publisher Pub_border = nh.advertise<sensor_msgs::PointCloud2>("/surface_gen_border", 1, true);
  ros::Publisher Pub_vox = nh.advertise<sensor_msgs::PointCloud2>("/surface_gen_vox", 1, true);
  ros::Publisher Pub_sac1 = nh.advertise<sensor_msgs::PointCloud2>("/surface_gen_sac1", 1, true);
  ros::Publisher Pub_on = nh.advertise<sensor_msgs::PointCloud2>("/surface_gen_on", 1, true);
  ros::Publisher Pub_DrawCups = nh.advertise<yf_vacuum_cups::msg_cup_draw>("/cup_draw", 1, true);
  
   float f_nan = std::numeric_limits<float>::quiet_NaN();
   pcl::PointXYZ PointXYZ_nan (f_nan,f_nan,f_nan);
  
  uint width = 320, height = 240;
  float cur_x = 1, cur_y = -1, phs_x = -0.5, phs_y = -0.5;
  float z_height = 0.02;
  float noise_a = 0.0002, noise_b = 0.0005;
  
  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZ>);
  
  
    std::string filename ("e40.pcd");
  ROS_INFO_STREAM("   point cloud generated");
  if (1) 
  {
    tf::Transform tf_load_xz;
    tf_load_xz = tf::Transform(tf::Quaternion(tf::Vector3(1,0,0),-0.5*M_PI),tf::Vector3(0,0,0.00));
    tf_load_xz = tf::Transform(tf::Quaternion(tf::Vector3(0,0,1),-0.5*M_PI),tf::Vector3(0,0,0.0))*tf_load_xz;
    
    
    if (priv_nh.getParam("file", filename))
      ROS_INFO_STREAM ("read file "<<filename);
    
    if (pcl::io::loadPCDFile<pcl::PointXYZ> (filename, *cloud) == -1) //* load the file
    {
      ROS_INFO_STREAM ("Couldn't read file "<<filename);
      return (-1);
    }    
    else
    {
      height = cloud->height;
      width = cloud->width;
      //pcl_ros::transformPointCloud(*cloud, *cloud, tf_load_xz);
    }
  ROS_INFO_STREAM("point cloud loaded : "<<filename);
  }
  
  
  //////////////////////////////////////////////////////////////////////////////////////
  ros::Time RosTimeBegin = ros::Time::now();
    yf_V Vtmp(cloud);
  //////////////////////////////////////////////////////////////////////////////////////  

    tf::Point N_table; float d_table;
    //Vtmp.setInputCloud(cloud);
    Vtmp.get_Table(N_table, d_table);
    
    Vtmp.set_Tf_Sensor2Table(N_table, d_table);
        
    
        int px = (int)(0.78*width), py = (int)(0.79*height);
    
    if (priv_nh.getParam("px", px)&&priv_nh.getParam("py",py))
      ROS_INFO_STREAM ("px="<<px<<"  py="<<py);

  bool found = false;
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   trim - ");
    float an=0,rr = 0;
    while (rr < 0.5)
    {
      int xx = (rr*cos(an)+0.5) * Vtmp.cloud->width;
      int yy = (rr*sin(an)+0.5) *Vtmp.cloud->height;
      if (Vtmp.label_object_onTable(xx,yy,1)) break;
      an += pcl::deg2rad(45.0);
      if (an > pcl::deg2rad(360.0)) {rr += 0.05; an = 0; }
    }
      
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   trim - all labeled");
    Vtmp.trim_cloud_label();
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   trim - fin");
    
    Vtmp.relocateCloud_toTableFrame(false); 
    
    
//     Vtmp.save2_pcd();
    
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   calculate normal - ");
    
    pcl::PointCloud <pcl::Normal>::Ptr normals (new pcl::PointCloud <pcl::Normal>);    
    
//     Vtmp.setInputCloud(cloud);
    Vtmp.calc_norm();
    normals = Vtmp.normals;
    ROS_INFO_STREAM(normals->size()<<"   normals calculated  - ");
    
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   calculate normal - fin");
  
  
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   calculate Mass Center -");
    Vtmp.calc_massCenter();
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   calculate Mass Center - fin");
  

  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   filtering - big curvature extracted");
    Vtmp.setCupDim(3);
//     Vtmp.setCupDim1234(7,7,7,7);	// set each cup seperately
    float borderMargin = Vtmp.cup_dim_.radius + 0.5 * Vtmp.cup_dim_.lengthen + 0.001;	// margin from border
    Vtmp.calc_border_inlander(0.002, borderMargin);	// curvature limit, radius of remove
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   filtering - fin");
        
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   calculate NormalSphere -");
    
    NormalSphere NS(Vtmp);
  
    NS.init_NormalSphere();
    NS.calc_NormalSphere(NS.idx_inlander);
    
    ROS_INFO_STREAM("sum_all_norms = "<<NS.NSphere_allsum);
    
    
    NS.get_clusterNormalSphere();
    
    NS.save_viewAngles(Vtmp);
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   calculate NormalSphere - fin");
  
  
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   projection - fin");
    
    Vtmp.init_v_stf_Tool2CupBases();
    std::vector< yf_pcl_process::msg_grip_tfs_cfg > v_grip_nominees;
    
//     Vtmp.nominate__get_v_grip_nominees_Rect_all_cfgY(0.07, 0.04, 0.01, v_grip_nominees);

    nominate nM(Vtmp);
    nM.nominate__get_v_grip_nominees_Rect_all_cfgY(0.06, 0.04, 0.0, v_grip_nominees);
    nM.save_viewAngles(Vtmp);
    
     pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_pj1 (new pcl::PointCloud<pcl::PointXYZ>);
//      nM.get_ProjectplainMapPcl(1,cloud_pj1, M_PI/180*20);
//     pcl::io::savePCDFileASCII ("cloud_pj1.pcd", *cloud_pj1);
    
    
    uint iii = 7;
//     Vtmp.set_v_stf_Tool2CupBases_cfgXYZ(v_grip_nominees[iii].cfgX, v_grip_nominees[iii].cfgY, v_grip_nominees[iii].cfgZ);
//     tf::StampedTransform stf_tmp;
//     tf::transformStampedMsgToTF(v_grip_nominees[iii].tfs_tabel2cupbase0, stf_tmp);
//     Vtmp.set_stf_Table2Tool(stf_tmp*Vtmp.v_stf_Tool2CupBases[0].inverse());

    
    
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   projection - fin");
  

  
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   set_MsgGrip  - fin"<<v_grip_nominees[iii].cupOn[2]);
  maneuverGrip mG(Vtmp);
  
  mG.set_v_stf_Tool2CupBases_tfBase0(tf::Transform(tf::Quaternion(Vtmp.v3_100,0.5)*tf::Quaternion(Vtmp.v3_010,0.7), tf::Point(0.02,-0.04,0.03)));	// a ramdom configuration of gripper
  
  mG.set_MsgGrip(v_grip_nominees[iii]);
  
  
//   mG.find_tf_table2ring_near_MsgGrip(1);
//   mG.find_tf_table2ring_near_MsgGrip(2);
//   mG.find_tf_table2ring_near_MsgGrip(3);
//   mG.find_tf_table2ring_near_MsgGrip(4);
  std::cout <<  "overall distance is " <<mG.findall_tf_table2ring_near_MsgGrip();
  mG.fit_MsgGrip();
  
  mG.apply_MsgGrip();
  
//   mG.get_cupPath(1);
//   mG.get_cupPath(2);
//   mG.get_cupPath(3);
//   mG.get_cupPath(4);
  /*
  std::vector< yf_pcl_process::msg_grip_tfs_cfg> v_msgGrip2;*/
  std::vector< maneuverGrip::Grip_Perform > v_Grip_perform2 {};
  std::vector< maneuverGrip::Grip_Perform > v_Grip_perform3 {};
  mG.get_v_msg_grip_tend(v_Grip_perform2);
   mG.trim_leaf_GP( v_Grip_perform2);
   std::cout <<  "\n000000000000000000000\n ";
//    mG.get_v_msg_grip_tend(v_Grip_perform2);
   mG.get_v_GP_for_gp(v_Grip_perform2[1],v_Grip_perform3);
   mG.trim_leaf_GP( v_Grip_perform3);
   std::cout <<  "\n111111111111111111111111\n ";
   /*
    mG.print_Grip_Perform(v_Grip_perform3[0]);
    mG.print_Grip_Perform(v_Grip_perform3[1]);
   std::cout <<  "\n11111111111111111111111122222222222222222\n ";*/

   mG.get_v_GP_for_gp(v_Grip_perform3[1],v_Grip_perform2);
   mG.trim_leaf_GP( v_Grip_perform2);
   std::cout <<  "\n 222222222222222222222222\n ";
   mG.get_v_GP_for_gp(v_Grip_perform2[1],v_Grip_perform3);
   mG.trim_leaf_GP( v_Grip_perform3);
   
   std::cout <<  "\n 3333333333333333\n ";
   mG.get_v_GP_for_gp(v_Grip_perform3[1],v_Grip_perform2);
   mG.trim_leaf_GP( v_Grip_perform2);
   
   std::cout <<  "\n 44444444444444444444444444\n ";
   mG.get_v_GP_for_gp(v_Grip_perform2[1],v_Grip_perform3);
   mG.trim_leaf_GP( v_Grip_perform3);
      
   std::cout <<  "\n 5555555555555555555\n ";
   mG.get_v_GP_for_gp(v_Grip_perform3[1],v_Grip_perform2);
   mG.trim_leaf_GP( v_Grip_perform2);
   
   std::cout <<  "\n 666666666666666666666666666\n ";
   mG.get_v_GP_for_gp(v_Grip_perform2[1],v_Grip_perform3);
   mG.trim_leaf_GP( v_Grip_perform3);
   
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   sim - start \n");
  
    yf_vacuum_cups::cup_dim cup_dim_ ;
    cup_dim_.radius = 0.015;	cup_dim_.lengthen = 0.030;	cup_dim_.bellows = 1.5;		cup_dim_.stroke = 0.008;	cup_dim_.bend = 0.002;	
//    cup_dim_.radius = 0.0125;	cup_dim_.lengthen = 0.0;	cup_dim_.bellows = 3.0;		cup_dim_.stroke = 0.030;	cup_dim_.bend = 0.004;

    
    pcl::IndicesPtr idx_allring (new std::vector <int>);
    idx_allring->insert(idx_allring->end(), mG.v_idx_ring[1]->begin(), mG.v_idx_ring[1]->end());
    idx_allring->insert(idx_allring->end(), mG.v_idx_ring[2]->begin(), mG.v_idx_ring[2]->end());
    idx_allring->insert(idx_allring->end(), mG.v_idx_ring[3]->begin(), mG.v_idx_ring[3]->end());
    idx_allring->insert(idx_allring->end(), mG.v_idx_ring[4]->begin(), mG.v_idx_ring[4]->end());
//     std::cout << "idx_allring.size is "<< idx_allring->size()<<"\n";
//     for (auto it: *idx_allring) std::cout<<it<<"\t";
    
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_allring (new pcl::PointCloud<pcl::PointXYZ>);
    pcl::copyPointCloud(*Vtmp.cloud, *idx_allring, *cloud_allring);
//     std::cout << "cloud_allring.size is "<< cloud_allring->size()<<"\n";
    
    ros::Publisher pub_visCM = nh.advertise<visualization_msgs::Marker>( "visCM", 2 );
    ros::Publisher pub_visNS = nh.advertise<visualization_msgs::Marker>( "visNS", 260 );
    ros::Publisher pub_visNSPP = nh.advertise<visualization_msgs::Marker>( "visNSPP", 20 );
    visualization_msgs::Marker cylin, sPnorm;
  
//    pcl::PointXYZ searchPoint1 = cloud->points[170433];
//     pcl::PointXYZ searchPoint2 = cloud->points[205022];
//     tf::Transform tf_tool1 (tf::Transform(tf::Quaternion(tf::Vector3(1,0,0),0),tf::Vector3(-0.06,-0.00,-0.2)));
//     tf_tool1 = tf_tool1*(tf::Transform(tf::Quaternion(tf::Vector3(0,0,1),0.9),tf::Vector3(0,0,0)));
//     tf::StampedTransform stf_Table2Tool (tf::StampedTransform(tf_tool1,ros::Time::now(),"/table_frame","/tool_frame"));
//     Vtmp.set_stf_Table2Tool(tf_tool1);
    ROS_INFO_STREAM("set tool table frames");
//     tf::Transform tf_ring1 = mG.get_tf_to_ring_cupX(1);
//     tf::Transform tf_ring2 = mG.get_tf_to_ring_cupX(2);
//     tf::Transform tf_ring3 = mG.get_tf_to_ring_cupX(3);
//     tf::Transform tf_ring4 = mG.get_tf_to_ring_cupX(4);
    
    tf::Transform tf_ring1 = mG.v_stf_table2ring[1];
    tf::Transform tf_ring2 = mG.v_stf_table2ring[2];
    tf::Transform tf_ring3 = mG.v_stf_table2ring[3];
    tf::Transform tf_ring4 = mG.v_stf_table2ring[4];
  
//     Vtmp.save2_pcd_inlander();
    
//     ros::ServiceClient client = nh.serviceClient<yf_vacuum_cups::srv_draw_cup>("/draw_cup_srv/draw");
//     yf_vacuum_cups::srv_draw_cup srvD, srvD2;
    
//     srvD.request.transformstamped.header.frame_id = "/table_frame";
//     srvD.request.transformstamped.child_frame_id = "/cups_frame/1";
//     srvD.request.cupN = 3;
//     srvD2.request.cupN = 7;
//     tf::transformTFToMsg(tf_suck_X, srvD.request.transformstamped.transform);			// tf_suck_X is the tf of suction to be exported
//     tf::StampedTransform tfs_suck_X = (tf::StampedTransform(tf_ring1, ros::Time::now(), "/table_frame", "/cups_frame_1"));
//     tf::transformStampedTFToMsg(tfs_suck_X, srvD.request.transformstamped);			// tf_suck_X is the tf of suction to be exported
  
//     if (client.call(srvD))	ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   drawing called");
//     if (client.call(srvD2))	ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   drawing called");
   
    
    
#if 1
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   visualizing curvature - ");
    pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_with_I (new pcl::PointCloud<pcl::PointXYZI>);
    yf_visualize_curvature((Vtmp.cloud), Vtmp.normals, cloud_with_I);   
  ROS_INFO_STREAM(ros::Time::now()-RosTimeBegin<<"   visualizing curvature - fin");    
#endif  
    
  static tf::TransformBroadcaster br;
  tf::StampedTransform stf_Viewer(tf::Transform(tf::Quaternion(1,0,0,0),tf::Point(0,0,0)),ros::Time::now(),"/table_frame","/table_viewer_frame");
  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_l (new pcl::PointCloud<pcl::PointXYZ>);  

  visualization_msgs::Marker CM_outputt;
  Vtmp.draw_CenterOfMass(CM_outputt);
  std::vector<visualization_msgs::Marker> arraw_outputt;
  NS.draw_NormalSphere(arraw_outputt);
  std::vector<visualization_msgs::Marker> projectionPlain_outputt;
   Vtmp.draw_NormalSphere_projection(projectionPlain_outputt);

    Vtmp.combine_cloud_normal();
//     pcl::io::savePCDFileASCII (filename+"__.pcd", *(Vtmp.cloud_with_normals));
    
  uint vis_counter = 0;
  ros::Rate r(20);
  while (ros::ok())
  {
//  
//     vis_counter++;
//     vis_counter = vis_counter% Vtmp.binNormalSphere_count.size();
//           arraw_outputt[vis_counter].header.stamp 	= ros::Time::now();
//       pub_visNS.publish(arraw_outputt[vis_counter]);
    
      CM_outputt.header.stamp 	= ros::Time::now();
      pub_visCM.publish(CM_outputt);
  
    
    for (uint i = 0; i<arraw_outputt.size(); i++)
    {
      arraw_outputt[i].header.stamp 	= ros::Time::now();
      pub_visNS.publish(arraw_outputt[i]);
    }
    
    
    for (uint i = 0; i<projectionPlain_outputt.size(); i++)
    {
      Vtmp.NSphere_viewAngles_stf[i+1].stamp_ 	= ros::Time::now();
      br.sendTransform(Vtmp.NSphere_viewAngles_stf[i+1]);
     
      projectionPlain_outputt[i].header.stamp 	= ros::Time::now();
      pub_visNSPP.publish(projectionPlain_outputt[i]);
    }
    
    stf_Viewer.stamp_ = ros::Time::now();
     br.sendTransform(stf_Viewer);
     
    Vtmp.stf_Sensor2Table.stamp_ =  ros::Time::now();
     br.sendTransform(Vtmp.stf_Sensor2Table);
     
    mG.stf_Table2Tool.stamp_ = ros::Time::now();
     br.sendTransform(mG.stf_Table2Tool);
     
     br.sendTransform(mG.v_stf_Tool2CupBases[0]);
     br.sendTransform(mG.v_stf_Tool2CupBases[1]);
     br.sendTransform(mG.v_stf_Tool2CupBases[2]);
     br.sendTransform(mG.v_stf_Tool2CupBases[3]);
     br.sendTransform(mG.v_stf_Tool2CupBases[4]);
     
    
    Pub_DrawCups.publish(Vtmp.genDrawMsg(1,tf_ring1,Vtmp.v_cup_dim_N[1]));
    r.sleep();
    Pub_DrawCups.publish(Vtmp.genDrawMsg(2,tf_ring2,Vtmp.v_cup_dim_N[2]));
    r.sleep();
    Pub_DrawCups.publish(Vtmp.genDrawMsg(3,tf_ring3,Vtmp.v_cup_dim_N[3]));
    r.sleep();
    Pub_DrawCups.publish(Vtmp.genDrawMsg(4,tf_ring4,Vtmp.v_cup_dim_N[4]));
    r.sleep();
    
//      vis_pub.publish(cylin);
//      vis_pub.publish(sPnorm);
    
    sensor_msgs::PointCloud2 outputt;
    
    pcl::toROSMsg(*cloud, outputt);
    outputt.header.frame_id = "/table_frame";
    Pub_.publish(outputt);
    
    pcl::toROSMsg(*cloud_pj1, outputt);
    outputt.header.frame_id = "/PjPl/1";
    Pub_ring.publish(outputt);
    
    pcl::toROSMsg(*cloud_allring, outputt);
    outputt.header.frame_id = "/table_frame";
    Pub_ring2.publish(outputt);
    
    pcl::toROSMsg(*(Vtmp.get_cloud_border()), outputt);
    outputt.header.frame_id = "/table_frame";
    Pub_border.publish(outputt);
    
//     pcl::toROSMsg(*cloud_tfed, outputt);
//     outputt.header.frame_id = "/table_frame";
//     Pub_tfed.publish(outputt);
    
    pcl::toROSMsg(*cloud_with_I, outputt);
    outputt.header.frame_id = "/table_frame";
    Pub_withI.publish(outputt);
    
//     pcl::toROSMsg(*cloud_phidz, outputt);
//     outputt.header.frame_id = "/table_frame";
//     Pub_phidz.publish(outputt);
    
    pcl::toROSMsg(*(Vtmp.cloud_inlander), outputt);
    outputt.header.frame_id = "/table_frame";
    Pub_inlander.publish(outputt);
    
    
//     pcl::toROSMsg(*cloud_vox, outputt);
//     outputt.header.frame_id = "/table_frame";
//     Pub_vox.publish(outputt);
    
  
    ros::spinOnce();
  }
    ROS_INFO("published _ all finished");
  
//  viewer.showCloud(colored_cloud);
//  while (!viewer.wasStopped ()) {}

  return (0);
}
