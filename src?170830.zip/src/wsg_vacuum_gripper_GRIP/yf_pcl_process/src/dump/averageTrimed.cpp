#include <ros/ros.h>
#include "std_msgs/String.h"
#include <sstream>
#include <cmath>
#include <sensor_msgs/PointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>

#include <iostream>
#include <pcl/ModelCoefficients.h>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/filters/extract_indices.h>


#include <yf_pcl_process/pc2_array.h>
#include <yf_pcl_process/srv_get_avgPC.h>

const float f_nan = NAN;
const pcl::PointXYZ PointXYZ_nan = pcl::PointXYZ(NAN,NAN,NAN);
const float rad2deg = 180/M_PI, deg2rad = M_PI/180;

uint ha = 0;
    
uint trim_x_min= 640, trim_y_min= 480, trim_x_max= 0, trim_y_max= 0;
sensor_msgs::PointCloud2 outputtX;
pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_avg10 (new pcl::PointCloud<pcl::PointXYZ>);
pcl::PointCloud<pcl::Label>::Ptr cloud_label (new pcl::PointCloud<pcl::Label>);

class Average_of_N
{
  protected:
    ros::NodeHandle n_; 
  private:

    ros::Publisher pub_;
    ros::Subscriber sub_;  
    std::vector<pcl::PointCloud<pcl::PointXYZ>::Ptr> cloud10;
    int N;
    int scale;
    
  public:
    Average_of_N()
    {
      //std::cerr << "10 ave: " << std::endl;
      //Topic you want to publish
      pub_ = n_.advertise<sensor_msgs::PointCloud2>("/cloud_avg", 10, true);

      //Topic you want to subscribe
      std::string inputTopic ("/camera/depth/points");
      sub_ = n_.subscribe(inputTopic, 10, &Average_of_N::callback_averaging, this);
      
      
      ros::NodeHandle priv_nh("~");
      if (priv_nh.getParam ("N", N))
      {
        ROS_INFO_STREAM ("average of " << N << " :");
      }
      else if (n_.getParam ("N", N))
      {
	ROS_WARN_STREAM ("Non-private N parameter is DEPRECATED: "
			<< N);
      }
      else N = 10;
      
      if (priv_nh.getParam ("scale", scale))
      {
        ROS_INFO_STREAM ("scale of " << scale << " :");
      }
      else if (n_.getParam ("scale", scale))
      {
	ROS_WARN_STREAM ("Non-private scale parameter is DEPRECATED: "
			<< scale);
      }
      else scale = 5;  		// strange for the realsense VF0810, its 5 times downscaled
    }
    
    bool label_object_onTable(int x, int y, uint current_label, uint Pid_old = 0)	//return the block and list of all cloud inside
    {
//        ROS_INFO_STREAM(x<<"-"<<y);
      
      uint W (cloud_avg10->width), H (cloud_avg10->height); 
      if (x < 0 || x >= W) return false; // out of bounds
      if (y < 0 || y >= H) return false; // out of bounds
      
      uint Pid = y*W+x;
      if (cloud_label->points[Pid].label!=0) return false;	// already registered
      if (isnan(cloud_avg10->points[Pid].x)) 			// is nan
      {
	cloud_label->points[Pid_old].label = 999;
      	return false;
      }
            
      if (x>trim_x_max) trim_x_max= x;
      if (x<trim_x_min) trim_x_min= x;
      if (y>trim_y_max) trim_y_max= y;
      if (y<trim_y_min) trim_y_min= y;
      
      
      cloud_label->points[Pid].label = current_label;
      
      label_object_onTable(x-1, y , current_label,Pid);
      label_object_onTable(x+1, y , current_label,Pid);
      label_object_onTable(x, y-1 , current_label,Pid);
      label_object_onTable(x, y+1 , current_label,Pid);
      
      return true;
    }
      
    void trim_cloud_label()	//return the block and list of all cloud inside
    {
      int W (cloud_avg10->width), H (cloud_avg10->height); 
      int W2 (trim_x_max-trim_x_min+1), H2 (trim_y_max-trim_y_min+1); 
      if (W2<0) return;

      std::cout<<"  ("<< trim_x_min<<"-"<<trim_x_max<<" , "<<trim_y_min<<"-"<<trim_y_max<<")";
      pcl::PointCloud<pcl::PointXYZ>::Ptr cloud2 (new pcl::PointCloud<pcl::PointXYZ>);
      cloud2->width = W2; cloud2->height = H2;
      uint ID = 0;
      for (uint y=trim_y_min; y<=trim_y_max; y++)
	for (uint x=trim_x_min; x<=trim_x_max; x++)
	{
	  uint Pid = y*W+x;
	  if (cloud_label->points[Pid].label == 0) 
	    cloud2->points.push_back(PointXYZ_nan);
	  else
	    cloud2->points.push_back(cloud_avg10->points[Pid]);
	  ID ++;
	}
	  
//       for (uint i=0; i<cloud->size(); i++) if (label->points[i].label ==0) cloud->points[i]= PointXYZ_nan; 

      cloud_avg10->clear();
      *cloud_avg10 = *cloud2;
    }
      

    
    
    void callback_averaging(const sensor_msgs::PointCloud2ConstPtr &input_cloud) //cloud blob right??
    {
      //std::cerr << "10 ave: callback " << std::endl;
      pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_new (new pcl::PointCloud<pcl::PointXYZ>);
      
    std::cerr << "\noutput : " ;
      
       pcl::fromROSMsg(*input_cloud, *cloud_new);
      cloud_avg10->clear(); 
      cloud_avg10->resize(cloud_new->size());
      cloud_avg10->width = cloud_new->width;
      cloud_avg10->height = cloud_new->height;
      
      cloud10.push_back(cloud_new);
      if (cloud10.size() > N) cloud10.erase (cloud10.begin());
      
      
      // publish all segments into pointcloud2_array
//       pcl_seg::pc2_array msg;
// //       msg.header.stamp = ros::Time::now();
      std::string inputt_frame_id = ("/" + input_cloud->header.frame_id);
//	std::cout << inputt_frame_id << std::endl;
//       msg.header.frame_id = inputt_frame_id;
      
      if (ha) 
	std::cout<< "  . ";
      else
	std::cout<< " .  ";
      ha = (ha+1)%2;
      
      uint k = 0;
      for(auto const& it : cloud10) 
      {
	k++;
	std::cout << k << " ";
	for (size_t i=0; i<cloud_new->size(); i++)
	{
	  cloud_avg10->points[i].x += (it->points[i].x)/cloud10.size()*scale;
	  cloud_avg10->points[i].y += (it->points[i].y)/cloud10.size()*scale;
	  cloud_avg10->points[i].z += (it->points[i].z)/cloud10.size()*scale;
	}
      }
      
      cloud_label->clear() ;
      cloud_label->resize(cloud_avg10->size()) ;
      trim_x_min= 640, trim_y_min= 480, trim_x_max= 0, trim_y_max= 0;
      
    float an=0,rr = 0;
    uint detected = 0;
    while (rr < 0.5)
    {
      int xx = (rr*cos(an)+0.5) * cloud_avg10->width;
      int yy = (rr*sin(an)+0.5) * cloud_avg10->height;
      if (label_object_onTable(xx,yy,1)) detected++;
      an += 15.0 * deg2rad;
      if (an > 2.0*M_PI) {rr += 0.02; an = 0; }
    }
    if (detected)
      trim_cloud_label();
    else
    {
      cloud_avg10->width = 1;
      cloud_avg10->height = 1;
      cloud_avg10->resize(1);
    }
	
      std::cout<< "    size : "<<cloud_avg10->width<<"*"<<cloud_avg10->height<<" = "<< cloud_avg10->size();

      
    pcl::toROSMsg(*cloud_avg10, outputtX);
      outputtX.header.frame_id = inputt_frame_id;
      outputtX.header.stamp = ros::Time::now();
//       outputtX.width = cloud_avg10->width;
//       outputtX.height = cloud_avg10->height;
    pub_.publish(outputtX);
    }
};

bool get_avgPointCloud_Srv(yf_pcl_process::srv_get_avgPC::Request &req, yf_pcl_process::srv_get_avgPC::Response &res)
{
  res.error = 1;
  if (req.caller > 0)
  {
    res.error = 1;
    if (outputtX.width > 0) 
    {
      std::cerr << "srv_get_avgPC called" << std::endl;  
//       res.avg_cloud = outputtX;
      pcl::toROSMsg(*cloud_avg10, res.avg_cloud);
      res.avg_cloud.header.frame_id = outputtX.header.frame_id;
      res.avg_cloud.header.stamp = ros::Time::now();
      res.avg_cloud.width = cloud_avg10->width;
      res.avg_cloud.height = cloud_avg10->height;
      
      res.error = 0;      
      return 1;
    }
  }
  std::cerr << "caling srv_get_avgPC failed" << std::endl;  
  return 0;
};



int
main (int argc, char** argv)
{ 
  std::cerr << "using Average_of_N" << std::endl;

  ros::init (argc, argv, "Average_of_N", ros::init_options::AnonymousName);
  ros::NodeHandle nh("~");
  
  uint takt = 0;
    ros::ServiceServer get_avgPointCloud = nh.advertiseService("/srv_get_avgPC", get_avgPointCloud_Srv);
    Average_of_N SAPObject;
    
        
    ros::spin();
  
  return (0);
}