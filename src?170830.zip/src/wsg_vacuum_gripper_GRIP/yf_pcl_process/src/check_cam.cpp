#include <cmath>
#include <limits>
#include <iostream>
#include <typeinfo>
#include <iomanip>
#include <ctime>

#include <ros/ros.h>
#include <rosbag/bag.h>
#include <rosbag/view.h>

#include <visualization_msgs/Marker.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>

#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/project_inliers.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/search/search.h>
#include <pcl/search/kdtree.h>
#include <pcl/search/organized.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/features/integral_image_normal.h>
#include "pcl_ros/transforms.h"
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/extract_polygonal_prism_data.h>
#include <pcl/segmentation/region_growing.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl/surface/concave_hull.h>
#include <pcl/segmentation/organized_multi_plane_segmentation.h>
#include <pcl/segmentation/organized_connected_component_segmentation.h>
#include <pcl/segmentation/planar_region.h>
#include <pcl/segmentation/comparator.h>
#include <pcl/impl/point_types.hpp>

#include <tf/LinearMath/Vector3.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <tf_conversions/tf_eigen.h>
/*
#include <Eigen/Core> 
#include <Eigen/Geometry> 
#include <Eigen/SVD>
#include <Eigen/Dense>*/

#include <yf_vacuum_cups/cup_dim.h>
#include <yf_vacuum_cups/srv_draw_cup.h>
#include <yf_vacuum_cups/msg_cup_draw.h>
#include <yf_pcl_process/msg_Grip.h>
#include <yf_pcl_process/srv_get_avgPC.h>

// #include "class_yf_V.h"
// #include "class_NormalSphere.h"
// #include "class_nominate.h"
// #include "class_maneuverGrip.h"
// #include "fn_yf_visualize_curvature.h"


// class sub_calcGrip_


int
main (int argc, char** argv)
{
  
  ros::init (argc, argv, "calc_Grip");
  ros::NodeHandle nh; 
  ros::NodeHandle priv_nh("~");

   float f_nan = std::numeric_limits<float>::quiet_NaN();
   pcl::PointXYZ PointXYZ_nan (f_nan,f_nan,f_nan);
  
  
  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZ>);
 
  {
        tf::StampedTransform stf_Flange2Sensor;
    tf::TransformListener listener;
    bool yep = true;
    listener.waitForTransform("/tool_link", "/adapter_sr300_base_link", ros::Time(0), ros::Duration(1));
    try { listener.lookupTransform("/tool_link", "/adapter_sr300_base_link", ros::Time(0), stf_Flange2Sensor);    }    
    catch (tf::TransformException &ex) { ROS_ERROR("%s",ex.what());    yep = false;	}
    if (yep)
    {
//       std::cout << "got robot stf: stf_Flange2Sensor =\n";
      std::cout << std::fixed << std::setprecision(7) << "tool adapter_sr300_base_link height:  "<< stf_Flange2Sensor.getOrigin().z()<<"\n";
    } 
  }
  
while (1)
{
  std::string filename (std::to_string(ros::Time::now().sec));
  if (1) 
  {    
    ros::ServiceClient client = nh.serviceClient<yf_pcl_process::srv_get_avgPC>("/srv_get_avgPC");

    yf_pcl_process::srv_get_avgPC srvD;
    srvD.request.caller = 7;
    
    if (client.call(srvD))
    {
//       ROS_INFO("called current Scene as Point Cloud");
      pcl::moveFromROSMsg(srvD.response.avg_cloud, *cloud); 	
//       std::cout << "cloud->size(): " << cloud->height <<" * "<< cloud->width <<"\n";
      
    }
    else
    {
//       ROS_ERROR("Failed to call up current Scene as Point Cloud");
      return 1;
    }
  }
  
  std::vector <double> V = {};
  
  for (uint i = 0; i<cloud->size(); i++)
  {
    if (!isnan(cloud->at(i).z))
    {
      V.push_back(cloud->at(i).z);
      
    }
  }
  
  double sum = std::accumulate(V.begin(), V.end(), 0.0);
  double mean = sum / V.size();
  
  std::vector<double> diff(V.size());
  std::transform(V.begin(), V.end(), diff.begin(),
		std::bind2nd(std::minus<double>(), mean));
  double sq_sum = std::inner_product(diff.begin(), diff.end(), diff.begin(), 0.0);
  double stdev = std::sqrt(sq_sum / V.size());

  
  
    pcl::io::savePCDFileASCII (filename+"_p.pcd", *cloud);
  
   
  //////////////////////////////////////////////////////////////////////////////////////  
    
    tf::StampedTransform stf_Table2Sensor;
    tf::TransformListener listener;
    bool yep = true;
    listener.waitForTransform("/r5_cell_table_link", "/camera_depth_optical_frame", ros::Time(0), ros::Duration(1));
    try { listener.lookupTransform("/r5_cell_table_link", "/camera_depth_optical_frame", ros::Time(0), stf_Table2Sensor);    }    
    catch (tf::TransformException &ex) { ROS_ERROR("%s",ex.what());    yep = false;	}
    if (yep)
    {
//       std::cout << "got robot stf: stf_Table2Sensor =\n";
//       std::cout << std::fixed << std::setprecision(4) << "hight:"<< stf_Table2Sensor.getOrigin().z()<<"\t";
    } 
    

  std::cout << mean << "\t"<<stf_Table2Sensor.getOrigin().z() <<"\t"<<stdev<<std::endl;

//   sleep(1);
  
}
    ros::spin();
  return (0);
}
