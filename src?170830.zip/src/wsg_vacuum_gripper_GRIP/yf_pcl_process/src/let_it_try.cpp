#include <cmath>
#include <limits>
#include <iostream>
#include <typeinfo>
#include <iomanip>
#include <ctime>

#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>

#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>

#include <tf/LinearMath/Vector3.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <tf_conversions/tf_eigen.h>

#include <visualization_msgs/Marker.h>

#include <yf_pcl_process/msg_Grip.h>
#include <yf_pcl_process/srv_get_avgPC.h>
#include <yf_pcl_process/srv_get_GRIPS.h> 

#include <yf_movements/act_MoveTowardSuctionAction.h>
#include <actionlib/client/simple_action_client.h>
#include <actionlib/client/terminal_state.h>

int
main (int argc, char** argv)
{
  std::cerr << "using calcGrip_server" << std::endl;
  ros::init (argc, argv, "calc_Grip", ros::init_options::AnonymousName);
  ros::NodeHandlePtr nh = boost::make_shared<ros::NodeHandle>();
  
  actionlib::SimpleActionClient<yf_movements::act_MoveTowardSuctionAction> ac("ACTION_Robot_try_Grip");
  bool finished_before_timeout;
  yf_movements::act_MoveTowardSuctionGoal goal_move;
  
  ros::ServiceClient calcGrip_client = nh->serviceClient<yf_pcl_process::srv_get_GRIPS>("/srv_CalcGrip");
  yf_pcl_process::srv_get_GRIPS srv_calcgrip; 
  
  int homing = -1;
  
  ros::NodeHandle priv_nh("~");
  if (priv_nh.getParam ("homing", homing)) {}
    else homing = -1;
    
  if (priv_nh.getParam ("cfgY", srv_calcgrip.request.cfgY)) {}
    else srv_calcgrip.request.cfgY = 0.070;
  if (priv_nh.getParam ("cfgX_min", srv_calcgrip.request.cfgX_min)) {}
    else srv_calcgrip.request.cfgX_min = 0.030;
  if (priv_nh.getParam ("cfgX_max", srv_calcgrip.request.cfgX_max)) {}
    else srv_calcgrip.request.cfgX_max = 0.210;
  if (priv_nh.getParam ("cup_name", srv_calcgrip.request.cup_name.data)) {}
    else srv_calcgrip.request.cup_name.data = "FSG_18_HT1_60_M5_AG";
    
    
  float curvature_limit2 = 0.007;
  if (priv_nh.getParam ("curvature_limit2", curvature_limit2)) {}
    else curvature_limit2 = 0.007;
    
    
  float z_offset = 0;
  if (priv_nh.getParam ("z_offset", z_offset)) 
  {
    std::cout << "\033[94m""\033[1m" "maneuverGrip" "z_offset "<<z_offset << " mm\033[0m\n"; 
    z_offset = 0.001 * z_offset;
  }
  
  
  int manuver2_count_min = 0;
  if (priv_nh.getParam ("manuver2_count_min", manuver2_count_min) ) { std::cout << "\033[94m""\033[1m""manuver2_count_min " << manuver2_count_min << "\033[0m""\n"; }
  int manuver2_count_max = 7;
  if (priv_nh.getParam ("manuver2_count_max", manuver2_count_max) ) { std::cout << "\033[94m""\033[1m""manuver2_count_max " << manuver2_count_max << "\033[0m""\n"; }
  
    
  //////////////////// move home
  
  ROS_INFO("Waiting for action server to start.");
  ac.waitForServer(ros::Duration(5.0));

  ROS_INFO("Action server started, sending goal.");
  
  if (homing < 10 && homing >= 0)
  {
  //   goal_move.command = 000;	// go home 0
    goal_move.command = homing;
    
    ac.sendGoal(goal_move);
    finished_before_timeout = ac.waitForResult(ros::Duration(7.0));
    
    if (finished_before_timeout)
    {
      actionlib::SimpleClientGoalState state = ac.getState();
      ROS_INFO("Action finished: %s",state.toString().c_str());
    }
    else
    {
      ROS_ERROR("Action did not finish before the time out.");
      return 0;
    }
  }
  


  

  //////////////////// calc grips (rough)

  srv_calcgrip.request.order = 31;
  srv_calcgrip.request.maneuvers_max = 1;
  srv_calcgrip.request.maneuvers_min = 1;
  srv_calcgrip.request.curvature_limit = 0.02;
  srv_calcgrip.request.update_Transforms = 1;

  if (calcGrip_client.call(srv_calcgrip))
  {
    ROS_WARN_STREAM("called calcGrip : got "<< srv_calcgrip.response.v_grips.size() << " grips candidates.");
  }
  else
  {
    ROS_ERROR("Failed to call up calcGrip");
    return 0;
  }  

  //////////////////////  move to have a better look
//   return 0;
  
    if(1)
    {     
      goal_move.command = 50;
      goal_move.grip = srv_calcgrip.response.v_grips[0];
      goal_move.z_offset = z_offset;
      
      ac.sendGoal(goal_move);

      //等待行为返回
      bool finished_before_timeout = ac.waitForResult(ros::Duration(10.0));

      if (finished_before_timeout)
      {
	actionlib::SimpleClientGoalState state = ac.getState();
	ROS_INFO("Action finished: %s",state.toString().c_str());
      }
      else
      {
	ROS_INFO("Action did not finish before the time out.");
	
      }
//       ros::shutdown();
//       spin_thread.join();
    }
    
    sleep(1);

  //////////////////// calc grips (fine)

  srv_calcgrip.request.order = 101;
  srv_calcgrip.request.maneuvers_min = manuver2_count_min;
  srv_calcgrip.request.maneuvers_max = manuver2_count_max;
  srv_calcgrip.request.curvature_limit = curvature_limit2;
  srv_calcgrip.request.update_Transforms = 0;

  if (calcGrip_client.call(srv_calcgrip))
  {
    ROS_WARN_STREAM("called calcGrip : got "<< srv_calcgrip.response.v_grips.size() << " grips candidates.");
  }
  else
  {
    ROS_ERROR("Failed to call up calcGrip");
    return 0;
  }  
  
  if (srv_calcgrip.response.v_grips.size() < 1) 
  {
    return 0;
  }
  //////////////////////  move to grip
//   return 0;
    if(srv_calcgrip.response.v_scores[0] > 0.3 )
    {     
      goal_move.command = 100;
      goal_move.grip = srv_calcgrip.response.v_grips[0];
      goal_move.z_offset = z_offset;
      
      ac.sendGoal(goal_move);

      //等待行为返回
      bool finished_before_timeout = ac.waitForResult(ros::Duration(15.0));

      if (finished_before_timeout)
      {
	actionlib::SimpleClientGoalState state = ac.getState();
	ROS_INFO("Action finished: %s",state.toString().c_str());
      }
      else
	ROS_INFO("Action did not finish before the time out.");

//       ros::shutdown();
//       spin_thread.join();
    }
    
  
  ros::spinOnce();
  
  return (1);
}