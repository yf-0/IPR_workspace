#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/features/integral_image_normal.h>

#include <iostream>
#include <vector>
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>
#include <pcl/search/search.h>
#include <pcl/search/kdtree.h>
#include <pcl/features/normal_3d.h>
//#include <pcl/visualization/cloud_viewer.h>
#include <pcl/filters/passthrough.h>
#include <pcl/segmentation/region_growing.h>
#include <pcl/filters/extract_indices.h>

int
main (int argc, char** argv)
{
  
  ros::init (argc, argv, "pcl_seg_p1");
  ros::NodeHandle nh;  
//   
  
  ros::Rate r(1);
  while (ros::ok())
  {
	pcl::toROSMsg(*colored_cloud, outputtX);
	outputtX.header.frame_id = "/camera_link";
        pub3.publish(outputtX);    
	
	
  pcl::toROSMsg(*cloud, outputtX);
	outputtX.header.frame_id = "/camera_link";
  pub2.publish(outputtX);
        std::cout<<outputtX.width*outputtX.height<<std::endl;
	
	pcl::PointIndices::Ptr inliers (new pcl::PointIndices ());
	*inliers=(clusters[0]);
	extract.setIndices (inliers);
	extract.filter (*cloudOut);
	
	pcl::toROSMsg(*cloudOut, outputtX);
	std::cout << outputtX.width << "*" << outputtX.height<< std::endl;
	outputtX.header.frame_id = "/camera_link";
	pub1 = nh.advertise<sensor_msgs::PointCloud2>("/pcl_seg/rg1", 1);
	pub1.publish(outputtX);
	
	*inliers=(clusters[2]);
	extract.setIndices (inliers);
	extract.filter (*cloudOut);
	
	pcl::toROSMsg(*cloudOut, outputtX);
	std::cout << outputtX.width << "*" << outputtX.height<< std::endl;
	outputtX.header.frame_id = "/camera_link";
	pub2 = nh.advertise<sensor_msgs::PointCloud2>("/pcl_seg/rg2", 1);
	pub2.publish(outputtX);
  
	ros::spinOnce();
	r.sleep();
  }
  
//  viewer.showCloud(colored_cloud);
//  while (!viewer.wasStopped ()) {}

  return (0);
}