#include <ros/ros.h>
#include "std_msgs/String.h"
#include <sstream>
#include <cmath>
#include <sensor_msgs/PointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>

#include <iostream>
#include <pcl/ModelCoefficients.h>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/filters/extract_indices.h>


#include <yf_acquire_cloud/pc2_array.h>
#include <yf_acquire_cloud/srv_get_avgPC.h>

const float f_nan = NAN;
const pcl::PointXYZ PointXYZ_nan = pcl::PointXYZ(NAN,NAN,NAN);
const float rad2deg = 180/M_PI, deg2rad = M_PI/180;

uint ha = 0;
    
sensor_msgs::PointCloud2 outputtX;
sensor_msgs::PointCloud2 outputtX2;
pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_avg10 (new pcl::PointCloud<pcl::PointXYZ>);

class Average_of_N
{
  protected:
    ros::NodeHandle n_; 
  private:

    ros::Publisher pub_;
    ros::Publisher pub_2;
    ros::Subscriber sub_;  
    std::vector<pcl::PointCloud<pcl::PointXYZ>::Ptr> cloud10;
    int N;
    double scale_xy, scale_z, z_offset;
    
  public:
    Average_of_N()
    {
      //std::cerr << "10 ave: " << std::endl;
      //Topic you want to publish
      pub_ = n_.advertise<sensor_msgs::PointCloud2>("/cloud_avg", 10, true);
      pub_2 = n_.advertise<sensor_msgs::PointCloud2>("/cloud_scl", 10, true);

      //Topic you want to subscribe
      std::string inputTopic ("/camera/depth/points");
      sub_ = n_.subscribe(inputTopic, 10, &Average_of_N::callback_averaging, this);
      
      
      ros::NodeHandle priv_nh("~");
      
      if (priv_nh.getParam ("scale_xy", scale_xy))
      {
        ROS_INFO_STREAM ("private scale_xy parameter is DEPRECATED: " << scale_xy << " :");
      }
      else if (n_.getParam ("scale_xy", scale_xy))
      {
	ROS_WARN_STREAM ("Non-private scale_xy parameter is DEPRECATED: "<< scale_xy);
      }
      else
      {
	scale_xy = 1.0;  		// strange for the realsense VF0810, its 5 times downscaled
	ROS_WARN_STREAM ("default scale_xy parameter is DEPRECATED: "<< scale_xy);	
      }
      
      if (priv_nh.getParam ("scale_z", scale_z))
      {
        ROS_INFO_STREAM ("private scale_z parameter is DEPRECATED: " << scale_z << " :");
      }
      else if (n_.getParam ("scale_z", scale_z))
      {
	ROS_WARN_STREAM ("Non-private scale_z parameter is DEPRECATED: "<< scale_z);
      }
      else
      {
	scale_z = 1.0;  		
	ROS_WARN_STREAM ("default scale_z parameter is DEPRECATED: "<< scale_z);	
      }
      
      if (priv_nh.getParam ("N", N))
      {
        ROS_INFO_STREAM ("private N parameter is DEPRECATED: " << N << " :");
      }
      else if (n_.getParam ("N", N))
      {
	ROS_WARN_STREAM ("Non-private N parameter is DEPRECATED: "<< N);
      }
      else 
      {
	N = 10;
	ROS_WARN_STREAM ("default N parameter is DEPRECATED: "<< N);	
      }
      
      if (priv_nh.getParam ("z_offset", z_offset))
      {
        ROS_INFO_STREAM ("private z_offset parameter is DEPRECATED: " << z_offset << " :");
      }
      else if (n_.getParam ("z_offset", z_offset))
      {
	ROS_WARN_STREAM ("Non-private z_offset parameter is DEPRECATED: "<< z_offset);
      }
      else 
      {
	z_offset = 10;
	ROS_WARN_STREAM ("default z_offset parameter is DEPRECATED: "<< z_offset);	
      }
    }
        
    void callback_averaging(const sensor_msgs::PointCloud2ConstPtr &input_cloud) //cloud blob right??
    {
      //std::cerr << "10 ave: callback " << std::endl;
      pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_new (new pcl::PointCloud<pcl::PointXYZ>);
      
    std::cerr << "\nout : " ;
      
       pcl::fromROSMsg(*input_cloud, *cloud_new);
      cloud_avg10->clear(); 
      cloud_avg10->resize(cloud_new->size());
      cloud_avg10->width = cloud_new->width;
      cloud_avg10->height = cloud_new->height;
      
      cloud10.push_back(cloud_new);
      if (cloud10.size() > N) cloud10.erase (cloud10.begin());
      
      
      // publish all segments into pointcloud2_array
//       pcl_seg::pc2_array msg;
// //       msg.header.stamp = ros::Time::now();
      std::string inputt_frame_id = ("/" + input_cloud->header.frame_id);
//	std::cout << inputt_frame_id << std::endl;
//       msg.header.frame_id = inputt_frame_id;
      
      if (ha) 
	std::cout<< "  . ";
      else
	std::cout<< " .  ";
      ha = (ha+1)%2;
      
      double factor = scale_xy;
      for (size_t i=0; i<cloud_new->size(); i++)
      {
	if (cloud_new->points[i].z <= 0.00001f) 
	{
	  cloud_new->points[i].x = std::numeric_limits<double>::quiet_NaN();
	  cloud_new->points[i].y = std::numeric_limits<double>::quiet_NaN();
	  cloud_new->points[i].z = std::numeric_limits<double>::quiet_NaN();  
	}
	else
	{
	  cloud_new->points[i].x = cloud_new->points[i].x*scale_xy;
	  cloud_new->points[i].y = cloud_new->points[i].y*scale_xy;
	  cloud_new->points[i].z = cloud_new->points[i].z*scale_z + z_offset;  
	}

      }
          
    pcl::toROSMsg(*cloud_new, outputtX2);
      outputtX2.header.frame_id = inputt_frame_id;
//       outputtX2.header.stamp = ros::Time::now()-ros::Duration(1);
      outputtX2.header.stamp = ros::Time::now();
    pub_2.publish(outputtX2);
      
      uint k = 0;
      for (size_t i=0; i<cloud_new->size(); i++)
      {
// 	k++;
	for(auto const& it : cloud10) 
	{	
// 	  if (isnan(it->points[i].z) || isnan(cloud_avg10->points[i].z)) 
// 	  {
// 	    cloud_avg10->points[i] = PointXYZ_nan; 
// 	    break;
// 	  }
// 	  else
	  {
	    cloud_avg10->points[i].x += (it->points[i].x);
	    cloud_avg10->points[i].y += (it->points[i].y);
	    cloud_avg10->points[i].z += (it->points[i].z);
	  }
	}
      }
      
      std::cout << cloud10.size() << " ";
      
      factor = (double)1.0/cloud10.size();
      for (size_t i=0; i<cloud_new->size(); i++)
      {
	cloud_avg10->points[i].x = cloud_avg10->points[i].x*factor;
	cloud_avg10->points[i].y = cloud_avg10->points[i].y*factor;
	cloud_avg10->points[i].z = cloud_avg10->points[i].z*factor;
      }
  
    std::cout<< "    size : "<<cloud_avg10->width<<" * "<<cloud_avg10->height<<" = "<< cloud_avg10->size();

      
    pcl::toROSMsg(*cloud_avg10, outputtX);
      outputtX.header.frame_id = inputt_frame_id;
      outputtX.header.stamp = ros::Time::now();
//       outputtX.width = cloud_avg10->width;
//       outputtX.height = cloud_avg10->height;
    pub_.publish(outputtX);

    }
};

bool get_avgPointCloud_Srv(yf_acquire_cloud::srv_get_avgPC::Request &req, yf_acquire_cloud::srv_get_avgPC::Response &res)
{
  res.error = 1;
  if (req.caller > 0)
  {
    res.error = 1;
    if (outputtX.width > 0) 
    {
      std::cerr << "\nsrv_get_avgPC called" ;  
//       res.avg_cloud = outputtX;
      pcl::toROSMsg(*cloud_avg10, res.avg_cloud);
      res.avg_cloud.header.frame_id = outputtX.header.frame_id;
      res.avg_cloud.header.stamp = ros::Time::now();
      res.avg_cloud.width = cloud_avg10->width;
      res.avg_cloud.height = cloud_avg10->height;
      
      res.error = 0;      
      return 1;
    }
  }
  std::cerr << "\ncaling srv_get_avgPC failed" ;  
  return 0;
};



int
main (int argc, char** argv)
{ 
  std::cerr << "using Average_of_N" << std::endl;

  ros::init (argc, argv, "Average_of_N", ros::init_options::AnonymousName);
  ros::NodeHandle nh("~");
  
  uint takt = 0;
    ros::ServiceServer get_avgPointCloud = nh.advertiseService("/srv_get_avgPC", get_avgPointCloud_Srv);
    Average_of_N SAPObject;
    
        
    ros::spin();
  
  return (0);
}