import rospy
from __future__ import print_function

import actionlib
import yf_movements.msg

def tryGrip_Client():
    client = actionlib.SimpleActionClient('Robot_try_Grip_client_py', yf_movements.msg.act_MoveTowardSuctionAction)
  
    client.waitForServer()
    goal = yf_movements.msg.act_MoveTowardSuctionGoal(order = 5)

    client.sendGoal(goal)
  
    client.waitForResult()

    return client.get_result()

if __name__ == '__main__':
    try:
        # Initializes a rospy node so that the SimpleActionClient can
        # publish and subscribe over ROS.
        rospy.init_node('Robot_try_Grip_client_py')
        result = tryGrip_Client()
        print("Result:", ', ')
    except rospy.ROSInterruptException:
        print("program interrupted before completion", file=sys.stderr)