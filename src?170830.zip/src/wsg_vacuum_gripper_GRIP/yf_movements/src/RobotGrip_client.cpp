#include <cmath>
#include <limits>
#include <iostream>

#include <ros/ros.h>
#include <actionlib/client/simple_action_client.h>
#include <actionlib/client/terminal_state.h>
#include <boost/thread.hpp>

#include <tf/LinearMath/Vector3.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <tf_conversions/tf_eigen.h>
#include <tf/transform_listener.h>

#include <sensor_msgs/JointState.h>
#include <std_msgs/Float64MultiArray.h>

#include <yf_pcl_process/msg_Grip.h>
#include <industrial_kuka_ros/CartesianPose.h>
#include "fn_tf_2_Float64MultiArray.h"

#include <yf_movements/act_MoveTowardSuctionAction.h>

void spinThread()
{
  ros::spin();
}


int main(int argc, char** argv)
{
  ros::init(argc, argv, "Robot_try_Grip_test");

  // 创建一个行为客户端
  actionlib::SimpleActionClient<yf_movements::act_MoveTowardSuctionAction> ac("ACTION_Robot_try_Grip");
  boost::thread spin_thread(&spinThread);

  ROS_INFO("Waiting for action server to start.");
  ac.waitForServer();

  ROS_INFO("Action server started, sending goal.");
  // 发送目标到行为
  yf_movements::act_MoveTowardSuctionGoal goal;
  goal.command = 100;
  goal.grip.cfgX = 0.090;
  goal.grip.tfs_tabel2cupbase0.header.frame_id = "/world";
  goal.grip.tfs_tabel2cupbase0.child_frame_id = "/Maneuver_grip/";
//   tf::StampedTransform stf_world2cupbase0 (tf::Transform(tf::Quaternion(tf::Vector3(1, 0.5, 0.8), M_PI_4), tf::Point(0.8, 0, 0.9)), ros::Time::now(), "/world", "/Maneuver_grip/");
  tf::StampedTransform stf_world2cupbase0 (tf::Transform(tf::Quaternion(tf::Vector3(1, -0.7, 0.10), 170.0*M_PI/180.0), tf::Point(0.7, 0, 0.90)), ros::Time::now(), "/world", "/Maneuver_grip/");
  stf_world2cupbase0.setData(stf_world2cupbase0
     * tf::Transform(tf::Quaternion(tf::Vector3(0, 0, 1), M_PI_2), tf::Point(0, 0, 0))   );
  tf::transformStampedTFToMsg(stf_world2cupbase0, goal.grip.tfs_tabel2cupbase0);
  
  ac.sendGoal(goal);

  //等待行为返回
  bool finished_before_timeout = ac.waitForResult(ros::Duration(15.0));

  if (finished_before_timeout)
  {
    actionlib::SimpleClientGoalState state = ac.getState();
    ROS_INFO("Action finished: %s",state.toString().c_str());
  }
  else
    ROS_INFO("Action did not finish before the time out.");

  // 关闭节点，在退出前加入线程
  ros::shutdown();
  spin_thread.join();

  return 0;
}