#include <ros/ros.h>
#include "std_msgs/String.h"
#include "wsg50_common/Move.h"
#include "std_srvs/Empty.h"

//------------------------------------------------------------------------
// Local macros
//------------------------------------------------------------------------


//------------------------------------------------------------------------
// Typedefs, enums, structs
//------------------------------------------------------------------------

#define GRIPPER_MAX_OPEN 110.0
#define GRIPPER_MIN_OPEN 0.0


/**
 * The main function
 */

int main( int argc, char **argv )
{   ros::init(argc, argv, "wsg50_client");
   ros::NodeHandle nh("~");

    //	move, grasp, release 		wsg50_common::Move
    //	homing, stop, ack 		std_srvs::Empty
    //	move_incrementally 		wsg50_common::Incr
    //	set_acceleration, set_force 	wsg50_common::Conf
    ros::ServiceClient wsg_client;
    if ( ros::service::exists ("/wsg50/move", false))
    {
      wsg_client = nh.serviceClient<wsg50_common::Move>("/wsg50/move");
      ROS_INFO("_ip : /wsg50/move");
    }
    else if ( ros::service::exists ("/wsg50_driver/move", false))
    {
      wsg_client = nh.serviceClient<wsg50_common::Move>("/wsg50_driver/move");
      ROS_INFO(".launch : /wsg50_driver/move");
    }
    else if ( ros::service::exists ("/wsg50/move", false))
    {
      wsg_client = nh.serviceClient<wsg50_common::Move>("/wsg50/move");
      ROS_INFO("_ip : /wsg50/move");
    }
    else if ( ros::service::exists ("/wsg50_driver/move", false))
    {
      wsg_client = nh.serviceClient<wsg50_common::Move>("/wsg50_driver/move");
      ROS_INFO(".launch : /wsg50_driver/move");
    }
    else if ( ros::service::exists ("/wsg50_common/Move", false))
    {
      wsg_client = nh.serviceClient<wsg50_common::Move>("/wsg50_common/Move");
      ROS_INFO(".launch : /wsg50_common/Move");
    }
    else 
    {
      ROS_ERROR("calling srv failed");
    }
    
    wsg50_common::Move foo;
    foo.request.width = 40.0f;
    foo.request.speed = 300.0f;
    
    if (wsg_client.call(foo))
    {
      ROS_INFO("moved");
    }
    else
    {
      ROS_ERROR("Failed to call service");
      return 1;
    }

    return 0;

}