#include <ros/ros.h>
#include <actionlib/client/simple_action_client.h>

#include "geometry_msgs/TransformStamped.h"
#include <tf/LinearMath/Vector3.h>
#include <tf/transform_datatypes.h>
#include <tf/LinearMath/Vector3.h>
#include <tf/transform_datatypes.h>

#include <tf/LinearMath/Transform.h>
#include <control_msgs/FollowJointTrajectoryAction.h>
#include <moveit/robot_model_loader/robot_model_loader.h>
#include <moveit/planning_interface/planning_interface.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <moveit/move_group_interface/move_group.h>
#include <moveit/robot_state/robot_state.h>
#include <moveit/robot_trajectory/robot_trajectory.h> 

#include <moveit_msgs/GetPositionIK.h>
#include <moveit_msgs/DisplayTrajectory.h>

class RobotArm
{
private:
  ros::NodeHandle nh_;
  // Action client for the joint trajectory action used to trigger the arm movement action
  actionlib::SimpleActionClient<control_msgs::FollowJointTrajectoryAction> trajectory_action_; 
  moveit::planning_interface::MoveGroup group;
//   moveit::planning_interface::PlanningSceneInterface planning_scene_interface;
  robot_model::RobotModelPtr kinematic_model;
  
  ros::Publisher display_publisher = nh_.advertise<moveit_msgs::DisplayTrajectory>("/move_group/display_planned_path", 1, true);
  moveit_msgs::DisplayTrajectory display_trajectory;
  
public:
  //! Initialize the action client and wait for action server to come up
  RobotArm() :
    nh_("~"),
//     trajectory_action_("/execute_trajectory", true)
    trajectory_action_("/position_trajectory_controller/follow_joint_trajectory", true),
    group("arm")
  {
    trajectory_action_.waitForServer();
    ROS_INFO("Connected to server"); 
//       *group = new moveit::planning_interface::MoveGroup ("arm");
//     kinematic_model = robot_model_loader.getModel();
//     ROS_INFO("Model frame: %s", kinematic_model->getModelFrame().c_str());
    
    // wait for action server to come up
//     unsigned int k = 0;
//     while(!trajectory_action_.waitForServer(ros::Duration(1.0))){
//       ROS_INFO("Waiting for the joint_trajectory_action server");
// //       if (k++<10) break;
//     }
    
//     while(!IK_client.exists())
//     {
//       ROS_INFO("Waiting for service");
//       sleep(1.0);
//     }
//     IK_srv.request.ik_request.group_name  =  "arm";
//     IK_srv.request.ik_request.ik_link_name  =  "joint_a6";
//     IK_srv.request.ik_request.timeout  =  ros::Duration(0.1);
//     IK_srv.request.ik_request.attempts  =  1;

//     ROS_INFO("Reference frame: %s", group.getPlanningFrame().c_str());
//     ROS_INFO("Reference frame: %s", group.getEndEffectorLink().c_str());
  }

  //! Sends the command to start a given trajectory
  void startTrajectory(control_msgs::FollowJointTrajectoryGoal goal)
  {
    // When to start the trajectory: 1s from now
    goal.trajectory.header.stamp = ros::Time::now() + ros::Duration(1.0);
    trajectory_action_.sendGoal(goal);
    ROS_INFO("Sent Goal");
  }

  //! Generates a simple trajectory with two waypoints, used as an example
  /*! Note that this trajectory contains two waypoints, joined together
    as a single trajectory. Alternatively, each of these waypoints could
    be in its own trajectory - a trajectory can have one or more waypoints
    depending on the desired application.
  */
  control_msgs::FollowJointTrajectoryGoal armExtensionTrajectory()
  {
    ROS_INFO("armExtensionTrajectory");
    //our goal variable
    control_msgs::FollowJointTrajectoryGoal goal;

    // First, the joint names, which apply to all waypoints
    goal.trajectory.joint_names.push_back("joint_a1");
    goal.trajectory.joint_names.push_back("joint_a2");
    goal.trajectory.joint_names.push_back("joint_a3");
    goal.trajectory.joint_names.push_back("joint_a4");
    goal.trajectory.joint_names.push_back("joint_a5");
    goal.trajectory.joint_names.push_back("joint_a6");
//     goal.trajectory.joint_names.push_back("joint_a6-tool0");
    //goal.trajectory.joint_names.push_back("l_gripper_aft_joint");

    std::vector <geometry_msgs::Pose> waypoints;
    geometry_msgs::Pose target_pose1;
    robot_state::RobotState start_state(*group.getCurrentState());
    tf::Transform tf1 (tf::Quaternion(tf::Vector3(0,0,1),1), tf::Vector3(0.5,0.5,0.5));
    tf::poseTFToMsg(tf1, target_pose1);
    waypoints.push_back(target_pose1);
    target_pose1.position.z += 0.2;
    waypoints.push_back(target_pose1);
    target_pose1.position.x += 0.2;
    waypoints.push_back(target_pose1);
    target_pose1.position.y -= 0.2;
    waypoints.push_back(target_pose1);
    
    const robot_state::JointModelGroup *joint_model_group = start_state.getJointModelGroup(group.getName());

    for (auto it : waypoints)
    {
      start_state.setFromIK(joint_model_group, it);
      std::cout << start_state;
    }
  
//     sleep(10.0);
//     if (1)
//     {
//       ROS_INFO("Visualizing plan 1 (again)");
//       display_trajectory.trajectory_start = my_plan.start_state_;
//       display_trajectory.trajectory.push_back(my_plan.trajectory_);
//       display_publisher.publish(display_trajectory);
//       /* Sleep to give Rviz time to visualize the plan. */
//       sleep(5.0);
//     }

    
    // We will have two waypoints in this goal trajectory
     goal.trajectory.points.resize(2);
// 
  ROS_INFO("WP 0");
//     // First trajectory point
//     // Positions
    int ind = 0;
    goal.trajectory.points[ind].positions.resize(6);
    goal.trajectory.points[ind].positions[0] = 0.0;
    goal.trajectory.points[ind].positions[1] = -M_PI_2;
    goal.trajectory.points[ind].positions[2] = -M_PI_2;
    goal.trajectory.points[ind].positions[3] = 0.0;
    goal.trajectory.points[ind].positions[4] = M_PI_2;
    goal.trajectory.points[ind].positions[5] = 0.0;
// //     goal.trajectory.points[ind].positions[6] = 0.0;
//     //    goal.trajectory.points[ind].positions[7] = 0.0;

    //Velocities
    goal.trajectory.points[ind].velocities.resize(6);
    for (size_t j = 0; j < 7; ++j)
    {
      goal.trajectory.points[ind].velocities[j] = 1.0;
    }
    // To be reached 1 second after starting along the trajectory
    goal.trajectory.points[ind].time_from_start = ros::Duration(1.0);

    
  ROS_INFO("WP 1");
    // Second trajectory point
    // Positions
    ind += 1;
    goal.trajectory.points[ind].positions.resize(6);
    goal.trajectory.points[ind].positions[0] = 0.0;
    goal.trajectory.points[ind].positions[1] = -M_PI_2;
    goal.trajectory.points[ind].positions[2] = -M_PI_2;
    goal.trajectory.points[ind].positions[3] = 0.0;
    goal.trajectory.points[ind].positions[4] = M_PI_2;
    goal.trajectory.points[ind].positions[5] = 0.0;
    // Velocities
    goal.trajectory.points[ind].velocities.resize(6);
    for (size_t j = 0; j < 7; ++j)
    {
      goal.trajectory.points[ind].velocities[j] = 0.3;
    }
    // To be reached 2 seconds after starting along the trajectory
    goal.trajectory.points[ind].time_from_start = ros::Duration(5.0);
    

  ROS_INFO("WP 2");
    //we are done; return the goal
    return goal;
  }

  //! Returns the current state of the action
  actionlib::SimpleClientGoalState getState()
  {
//     return trajectory_action_.getState();
  }

};

int main(int argc, char** argv)
{
  // Init the ROS node
  ros::init(argc, argv, "robot_driver");

  ROS_INFO("Simple Trajectory");
  RobotArm arm;
  // Start the trajectory
  arm.startTrajectory(arm.armExtensionTrajectory());
  // Wait for trajectory completion
  while(!arm.getState().isDone() && ros::ok())
  {
    usleep(50000);
  }

  return 0;
}