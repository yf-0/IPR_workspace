#include <cmath>
#include <limits>
#include <iostream>

#include <ros/ros.h>
#include <rosbag/bag.h>
#include <rosbag/view.h>

#include <tf/LinearMath/Vector3.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <tf_conversions/tf_eigen.h>
#include <tf/transform_listener.h>

#include <sensor_msgs/JointState.h>
#include <std_msgs/Float64MultiArray.h>

#include <yf_pcl_process/msg_Grip.h>
#include <industrial_kuka_ros/CartesianPose.h>
#include "fn_tf_2_Float64MultiArray.h"


int
main (int argc, char** argv)
{
  
  ros::init (argc, argv, "Robot_try_Grip");
  ros::NodeHandle nh; 
  ros::NodeHandle priv_nh("~");
//  
  ros::Publisher Pub_Pose_ = nh.advertise<std_msgs::Float64MultiArray>("/rsi_node/set_cartesian_pose", 1, true);
  ros::Publisher Pub_Pose_2 = nh.advertise<std_msgs::Float64MultiArray>("/lalala", 1, true);
  /*
  /cartesian_state			sensor_msgs/JointState
  /joint_states				sensor_msgs/JointState
  /rsi_node/IPCartesianVelPosAndVel	sensor_msgs/JointState
  /rsi_node/final_state_reached		std_msgs/Int16
  /rsi_node/set_cartesian_pose		std_msgs/Float64MultiArray
  /rsi_node/set_cartesian_velocity	std_msgs/Float64MultiArray
  /rsi_node/set_cartesian_pose_relative	industrial_kuka_ros/CartesianPose
  /rsi_node/set_joint_position		std_msgs/Float64MultiArray
  */
  
  tf::TransformListener listener;
  tf::StampedTransform stf_world_flange;
  
  //   std_msgs::Float64MultiArray CartesianPose_A {0.8,0.0,1,-90,0,180};
  std_msgs::Float64MultiArray CartesianPose_X;
  std_msgs::Float64MultiArray CartesianPose_A;
  CartesianPose_A.data = {0.8,0.0,1,3,7,170};
  std_msgs::Float64MultiArray CartesianPose_B;
  CartesianPose_B.data = {0.8,0.0,1.1,2,4,-175};
//   CartesianPose_A.layout.data_offset = 0;
//   CartesianPose_A.layout.dim = 6;
//   monitor_current_CartesianPose monitor;
  ros::Rate r(0.2);
  
  for (;ros::ok();)
  {
    try { listener.lookupTransform("/kr5_link1", "/kr5_flansch",ros::Time(0), stf_world_flange);    }    
    catch (tf::TransformException &ex) { ROS_ERROR("%s",ex.what());    }
    
    std::cout << std::fixed << std::setprecision(4) << "{ (" << stf_world_flange.getOrigin().x()<<", "<< stf_world_flange.getOrigin().y()<<", "<< stf_world_flange.getOrigin().z()<<"), ("
	      << stf_world_flange.getRotation().w() << " | "<< stf_world_flange.getRotation().x()<<", "<< stf_world_flange.getRotation().y()<<", "<< stf_world_flange.getRotation().z()<<") }\n";
    
    tf_2_Float64MultiArray(stf_world_flange, CartesianPose_X);	      
    Pub_Pose_2.publish(CartesianPose_X);
	      
	      
    Pub_Pose_.publish(CartesianPose_A);
    
    r.sleep();
    
    
    
    try { listener.lookupTransform("/kr5_link1", "/kr5_flansch",ros::Time(0), stf_world_flange);    }    
    catch (tf::TransformException &ex) { ROS_ERROR("%s",ex.what());    }
    
    std::cout << std::fixed << std::setprecision(4) << "{ (" << stf_world_flange.getOrigin().x()<<", "<< stf_world_flange.getOrigin().y()<<", "<< stf_world_flange.getOrigin().z()<<"), ("
	      << stf_world_flange.getRotation().w() << " | "<< stf_world_flange.getRotation().x()<<", "<< stf_world_flange.getRotation().y()<<", "<< stf_world_flange.getRotation().z()<<") }\n";
    
    
    Pub_Pose_.publish(CartesianPose_B);
    
    r.sleep();
    ros::spinOnce();
  }
  
}