#include <cmath>
#include <limits>
#include <iostream>

#include <ros/ros.h>
#include <tf/transform_listener.h>
#include <tf/transform_broadcaster.h>


tf::Transform tf_F_CB0 ( tf::Transform( 
				  tf::Quaternion(tf::Vector3(0,0,1), 0), 
				  tf::Vector3(0.0,0.0,0.1))
		     );

float cfgX_offset; 

class TransformSender
{
private:
  tf::StampedTransform transform_;
  
public:
  ros::NodeHandle node_;
  //constructor
  TransformSender(ros::Time time)
  { 
    transform_ = tf::StampedTransform(tf_F_CB0, time, "/kr5_flansch", "/camera_depth_optical_frame");
  };
  
  //Clean up ros connections
  ~TransformSender() { }

  //A pointer to the rosTFServer class
  tf::TransformBroadcaster broadcaster;



  // A function to call to send data periodically
  void send (ros::Time time) {
    transform_.stamp_ = time;
    broadcaster.sendTransform(transform_);
  };


};

int
main (int argc, char** argv)
{
   ros::init (argc, argv, "sending_griperfinger", ros::init_options::AnonymousName);

   ros::Duration sleeper(0.1);
   
   TransformSender tf_sender(ros::Time() + sleeper);
   
  while(tf_sender.node_.ok())
  {
    tf_sender.send(ros::Time::now() + sleeper);
      
    sleeper.sleep();
//     ros::spinOnce();
  }
  return 0;
  
}



//sending_griperfinger.launch