/*********************************************************************
 * Software License Agreement (BSD License)
 *
 *  Copyright (c) 2013, SRI International
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * Neither the name of SRI International nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *********************************************************************/

/* Author: Sachin Chitta */
#include <cmath>
#include <tf/LinearMath/Vector3.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>

#include <moveit/move_group_interface/move_group.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>

#include <moveit_msgs/DisplayRobotState.h>
#include <moveit_msgs/DisplayTrajectory.h>

#include <moveit_msgs/AttachedCollisionObject.h>
#include <moveit_msgs/CollisionObject.h>
#include <moveit/trajectory_processing/iterative_time_parameterization.h>
#include <moveit/trajectory_processing/spline_parameterization.h>

int main(int argc, char **argv)
{
  ros::init(argc, argv, "move_group_interface_tutorial");
  ros::NodeHandle node_handle;  
  ros::AsyncSpinner spinner(1);
  spinner.start();
  static tf::TransformBroadcaster br;

  /* This sleep is ONLY to allow Rviz to come up */
  sleep(1.0);
  bool success = false;
  // BEGIN_TUTORIAL
  // 
  // Setup
  // ^^^^^
  // 
  // The :move_group_interface:`MoveGroup` class can be easily 
  // setup using just the name
  // of the group you would like to control and plan for.
  moveit::planning_interface::MoveGroup group("arm");

  // We will use the :planning_scene_interface:`PlanningSceneInterface`
  // class to deal directly with the world.
  moveit::planning_interface::PlanningSceneInterface planning_scene_interface;  

  // (Optional) Create a publisher for visualizing plans in Rviz.
//   ros::Publisher display_publisher = node_handle.advertise<moveit_msgs::DisplayTrajectory>("/move_group/display_planned_path", 1, true);
//   moveit_msgs::DisplayTrajectory display_trajectory;
  
  
//   ROS_INFO("333333333333");

  // Getting Basic Information
  // ^^^^^^^^^^^^^^^^^^^^^^^^^
  //
  // We can print the name of the reference frame for this robot.
  ROS_INFO("Reference frame getPlanningFrame: %s", group.getPlanningFrame().c_str());
  
  // We can also print the name of the end-effector link for this group.
  ROS_INFO("Reference frame getEndEffectorLink: %s", group.getEndEffectorLink().c_str());

  // Planning to a Pose goal
  // ^^^^^^^^^^^^^^^^^^^^^^^
  // We can plan a motion for this group to a desired pose for the 
  // end-effector.
  
  geometry_msgs::PoseStamped current_pose = group.getCurrentPose();
  std::cout << current_pose;
  
  tf::Transform tf1(tf::Quaternion(tf::Point(1,0,0), M_PI), tf::Point(0.8,0,1.5));
  tf::Transform tf2(tf::Quaternion(tf::Point(1,0,0), 0), tf::Point(0,0,-0.2));
  tf::Transform tf3(tf::Quaternion(tf::Point(1,0,0), 0), tf::Point(0,0.2,0));
  tf::Transform tf4(tf::Quaternion(tf::Point(1,0,0), 0), tf::Point(0.2,0,0));

  br.sendTransform(tf::StampedTransform(tf1, ros::Time::now(), "world", "tf1"));
   
  moveit::planning_interface::MoveGroup::Plan my_plan;
  geometry_msgs::Pose target_pose1;
  
  tf::poseTFToMsg(tf1*tf2*tf3, target_pose1); 
  group.setPoseTarget(current_pose.pose);
  success = group.plan(my_plan);
  group.move();
  sleep(2.0);
  
  tf::poseTFToMsg(tf1*tf2*tf4, target_pose1);
  current_pose.pose.position.x += 0.1;
  group.setPoseTarget(current_pose);
//   group.setPoseTarget(target_pose1);
  
  success = group.plan(my_plan);
  group.move();
  sleep(2.0);
  
  tf::poseTFToMsg(tf1*tf2, target_pose1); 
  group.setPoseTarget(target_pose1);
  success = group.plan(my_plan);
  group.move();
  sleep(2.0);


  tf::poseTFToMsg(tf1, target_pose1); 
  group.setPoseTarget(target_pose1);
  success = group.plan(my_plan);
  group.move();
  sleep(2.0);  
  
  std::cout <<"=================================================\n";
  std::cout <<"=================================================\n";
  std::cout <<"=================================================\n";
  std::cout <<"=================================================\n";
  std::cout <<"=================================================\n";
  
  // Now, we call the planner to compute the plan
  // and visualize it.
  // Note that we are just planning, not asking move_group 
  // to actually move the robot.
//     success = group.plan(my_plan);

//   ROS_INFO("Visualizing plan 1 (pose goal) %s",success?"":"FAILED");    
  /* Sleep to give Rviz time to visualize the plan. */
//   group.clearPathConstraints();

  // Cartesian Paths
  // ^^^^^^^^^^^^^^^
  // You can plan a cartesian path directly by specifying a list of waypoints 
  // for the end-effector to go through. Note that we are starting 
  // from the new start state above.  The initial pose (start state) does not
  // need to be added to the waypoint list.
 
  robot_state::RobotState start_state(*group.getCurrentState());
  geometry_msgs::Pose start_pose2;
  tf::poseTFToMsg(tf1, start_pose2);
  
//   const robot_state::JointModelGroup *joint_model_group = start_state.getJointModelGroup(group.getName());
//   start_state.setFromIK(joint_model_group, start_pose2);
   group.setStartState(start_state);  
//   group.setStartState(*group.getCurrentState());  
  
  std::vector<geometry_msgs::Pose> waypoints;

  waypoints.push_back(group.getCurrentPose().pose);
    
  geometry_msgs::Pose target_pose3 = start_pose2;
//   waypoints.push_back(current_pose.pose);
  waypoints.push_back(target_pose3);
  
  target_pose3.position.x += 0.3;
  waypoints.push_back(target_pose3);  // up and out

  target_pose3.position.y -= 0.3;
  waypoints.push_back(target_pose3);  // left

  target_pose3.position.x -= 0.3;
  waypoints.push_back(target_pose3);  // down and right (back to start)
  
  target_pose3.position.y += 0.3;
  waypoints.push_back(target_pose3);  // down and right (back to start)

  uint k = 0;
  for (auto it : waypoints)
  {
    std::cout << "                           "<< k++<<"\n" << it;
  }
  
  
//   We want the cartesian path to be interpolated at a resolution of 1 cm
//   which is why we will specify 0.01 as the max step in cartesian
//   translation.  We will specify the jump threshold as 0.0, effectively
//   disabling it.
  moveit_msgs::RobotTrajectory trajectory;
  double fraction = group.computeCartesianPath(waypoints,
                                               0.01,  // eef_step
                                               0.0,   // jump_threshold
                                               trajectory);
  ROS_INFO("Visualizing plan 4 (cartesian path) (%.2f%% acheived)", fraction * 100.0);    

  
  for(uint i = 0; i < trajectory.joint_trajectory.points.size(); i++)
  {
	  int joint_count = trajectory.joint_trajectory.points[i].positions.size();
	  std::vector<double> empty;
	  trajectory.joint_trajectory.points[i].velocities = empty;
	  trajectory.joint_trajectory.points[i].accelerations = empty;
	  trajectory.joint_trajectory.points[i].effort = empty;
  }
  
//   	The trajectory needs to be modified so it will include velocities as well.
// 	First to create a RobotTrajectory object
	robot_trajectory::RobotTrajectory rt(group.getCurrentState()->getRobotModel(), "arm");

// 	Second get a RobotTrajectory from trajectory
	rt.setRobotTrajectoryMsg(*group.getCurrentState(), trajectory);
	
// 	Thrid create a IterativeParabolicTimeParameterization object
	trajectory_processing::IterativeParabolicTimeParameterization iptp;
	trajectory_processing::SplineParameterization spline_tp;
// 	Fourth compute computeTimeStamps
	if(!spline_tp.computeTimeStamps(rt,0.5,0.5))
	{
		return moveit_msgs::MoveItErrorCodes::PLANNING_FAILED;
		ROS_ERROR("Can't compute velocities!");
	}
	
// 	Get RobotTrajectory_msg from RobotTrajectory
	rt.getRobotTrajectoryMsg(trajectory);
  

  group.setMaxAccelerationScalingFactor(1);
  group.setMaxVelocityScalingFactor(1);
  my_plan.trajectory_ = trajectory;
//   group.plan(my_plan);
  group.execute(my_plan);
//     group.move();  
  
  /* Sleep to give Rviz time to visualize the plan. */
//   if (0)
//   {
// //     ROS_INFO("Visualizing plan 1 (again)");    
//     display_trajectory.trajectory_start = my_plan.start_state_;
//     display_trajectory.trajectory.push_back(my_plan.trajectory_);
//     display_publisher.publish(display_trajectory);
//     /* Sleep to give Rviz time to visualize the plan. */
//      sleep(5.0);
//   }
  sleep(15.0);


  ros::shutdown();  
  return 0;
}