#include <ros/ros.h>
#include "std_msgs/String.h"
#include <sstream>
#include "sensor_msgs/JointState.h"

#include <iostream>


class follower
{
  protected:
    ros::NodeHandle n_; 
  private:

    ros::Publisher pub_;
    ros::Subscriber sub1_,sub2_;  
    sensor_msgs::JointState JS_arm;
    
  public:
    follower()
    {
      //std::cerr << "10 ave: " << std::endl;
      //Topic you want to publish
//       pub_ = n_.advertise<sensor_msgs::JointState>("/joint_state", 10, true);
      pub_ = n_.advertise<sensor_msgs::JointState>("/joint_states", 10);

      //Topic you want to subscribe
      std::string inputTopic1 ("/joint_states");
      sub1_ = n_.subscribe(inputTopic1, 10, &follower::callback1, this);
      std::string inputTopic2 ("/wsg_joint_states");
      sub2_ = n_.subscribe(inputTopic2, 10, &follower::callback2, this);
      
    }
    
    void callback1(const sensor_msgs::JointState input_js) 
    {
      JS_arm = input_js;
//      pub_.publish(input_cloud);
      
      std::cout << ".";
    }
    
    void callback2(const sensor_msgs::JointState input_js) 
    {
      JS_arm.position[6] = input_js.position[0];
      JS_arm.position[7] = input_js.position[1];
      pub_.publish(JS_arm);
      std::cout << "refreshed\n";
    }
};

int
main (int argc, char** argv)
{ 

  ros::init (argc, argv, "follower", ros::init_options::AnonymousName);
  ros::NodeHandle nh("~");
  
  uint takt = 0;
    follower SAPObject;
    
        
    ros::spin();
  
  return (0);
}