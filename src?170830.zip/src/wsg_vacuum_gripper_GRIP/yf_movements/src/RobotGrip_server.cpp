#include <cmath>
#include <limits>
#include <iostream>

#include <ros/ros.h>
#include <actionlib/server/simple_action_server.h>

#include <tf/LinearMath/Vector3.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <tf_conversions/tf_eigen.h>
#include <tf/transform_listener.h>

#include "std_srvs/Empty.h"
#include "std_srvs/Trigger.h"
#include <sensor_msgs/JointState.h>
#include <std_msgs/Float64MultiArray.h>


#include <moveit/move_group_interface/move_group.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <moveit_msgs/DisplayRobotState.h>
#include <moveit_msgs/DisplayTrajectory.h>
#include <moveit/trajectory_processing/iterative_time_parameterization.h>
#include <moveit/trajectory_processing/spline_parameterization.h>
#include <moveit/macros/console_colors.h>

#include <control_msgs/FollowJointTrajectoryAction.h>
#include "control_msgs/FollowJointTrajectoryActionGoal.h"
#include "control_msgs/FollowJointTrajectoryActionResult.h"
#include "control_msgs/FollowJointTrajectoryActionFeedback.h"

#include <transmission_interface/simple_transmission.h>
#include <transmission_interface/transmission_interface.h>


#include <yf_pcl_process/msg_Grip.h>
#include <industrial_kuka_ros/CartesianPose.h>
#include "fn_tf_2_Float64MultiArray.h"
// #include <../../src/weiss_wsg50/wsg50_driver/include/wsg_50/functions_can.h>

#include <yf_movements/act_MoveTowardSuctionAction.h>

#include "wsg50_common/Status.h"
#include "wsg50_common/Conf.h"
#include "wsg50_common/Move.h"
// #include "yf_movements/Foo.h"

#include <rpi_gpio/DigitalWrite.h>


static float speed_factor; 
static int   local_vacuum;

void pop_front(std::vector<geometry_msgs::Pose>& vec)
{
    assert(!vec.empty());
    vec.erase(vec.begin());
}

class MoveTowardSuctionAction
{
protected:
    
  ros::NodeHandle nh_;
  actionlib::SimpleActionServer<yf_movements::act_MoveTowardSuctionAction> as_;
  moveit::planning_interface::MoveGroup group_arm;
  moveit::planning_interface::MoveGroup::Plan arm_plan;
  
  std::string action_name_;
  int data_count_;
  yf_pcl_process::msg_Grip goal_Grip;
  
  yf_movements::act_MoveTowardSuctionActionFeedback feedback_;
  yf_movements::act_MoveTowardSuctionActionResult result_;
  
  
  tf::TransformBroadcaster br;
  ros::Subscriber sub_;

  //	move, grasp, release 		wsg_50_common::Move
  //	homing, stop, ack 		std_srvs::Empty
  //	move_incrementally 		wsg_50_common::Incr
  //	set_acceleration, set_force 	wsg_50_common::Conf
  ros::ServiceClient wsg_client;
  ros::ServiceClient gpio_client;
  
//   tf::Transform tf_;
  tf::Transform tf_z180;
  tf::Transform tf_backZ_230;
  tf::Transform tf_backZ_200;
  tf::Transform tf_backZ_170;
  tf::Transform tf_backZ_050;
  tf::Transform tf_plusX_025;
//   tf::StampedTransform stf_world_flange;
  tf::StampedTransform stf_world_tabel;
  tf::StampedTransform stf_camera_tool;
  tf::Transform tf_poseOffset;
  
//   tf::StampedTransform stf_x2cupbase0;
  tf::StampedTransform stf_cupbase0_flange;
  
  
  float cfg_wsg_X;
  float cfg_wsg_offset = -30.0;		//	mm
  
//   std_msgs::Float64MultiArray CartesianPose_X;
//   std_msgs::Float64MultiArray CartesianPose_A;
//   std_msgs::Float64MultiArray CartesianPose_B;

  
public:
    
  MoveTowardSuctionAction(std::string name) : 
    group_arm("arm"),
    as_(nh_, name, false),
    action_name_(name)
  {
    as_.start();
    //register the goal and feeback callbacks
    as_.registerGoalCallback(boost::bind(&MoveTowardSuctionAction::goalCB, this));
    as_.registerPreemptCallback(boost::bind(&MoveTowardSuctionAction::preemptCB, this));

    //subscribe to the data topic of interest
    sub_ = nh_.subscribe("/random_number", 1, &MoveTowardSuctionAction::analysisCB, this);
    as_.start();
   
    tf_z180      = tf::Transform(tf::Quaternion(tf::Point(0,0,1), M_PI), tf::Point(0,0,0));
    tf_backZ_230 = tf::Transform(tf::Quaternion::getIdentity(), tf::Point(0,0,-0.23));
    tf_backZ_200 = tf::Transform(tf::Quaternion::getIdentity(), tf::Point(0,0,-0.20));
    tf_backZ_170 = tf::Transform(tf::Quaternion::getIdentity(), tf::Point(0,0,-0.17));
    tf_backZ_050 = tf::Transform(tf::Quaternion::getIdentity(), tf::Point(0,0,-0.050));
    tf_plusX_025 = tf::Transform(tf::Quaternion::getIdentity(), tf::Point(0.025,0,0.0));
    
    tf::TransformListener listener;
//     sleep();
    //////////////////////////////////////// to get static world to table
      try {
	listener.waitForTransform("world", "r5_cell_table_link", ros::Time(0), ros::Duration(1) );
	listener.lookupTransform("world", "r5_cell_table_link", ros::Time(0), stf_world_tabel);
      } 
      catch (tf::TransformException ex) {
	  ROS_ERROR("%s",ex.what());	
  //       <origin xyz="0.82 -0.25 0" rpy="0 0 ${M_PI/2}" />
	  stf_world_tabel = tf::StampedTransform(tf::Transform(tf::Quaternion(tf::Point(0,0,1), M_PI_2), tf::Point(0.82,-0.25,0.706)), ros::Time::now(),"world","table_frame_M");
      }
      stf_world_tabel.child_frame_id_ = "table_frame_M";
      std::cout << "\033[36m" "stf_world_tabel : acquired:\n" 
	<< std::fixed << std::setprecision(4) << "{ (" << stf_world_tabel.getOrigin().x()<<", "<< stf_world_tabel.getOrigin().y()<<", "<< stf_world_tabel.getOrigin().z()<<"), ("
					               << stf_world_tabel.getRotation().x()<<", "<< stf_world_tabel.getRotation().y()<<", "<< stf_world_tabel.getRotation().z()<< " | "<< stf_world_tabel.getRotation().w()<<") }\n" "\033[0m";
    //////////////////////////////////////// 
        
    ///////////////////////////////// to get suction centre to flange
      try {
	listener.waitForTransform("wsg50_palm_link", "tool0", ros::Time(0), ros::Duration(1) );
	listener.lookupTransform("wsg50_palm_link", "tool0", ros::Time(0), stf_cupbase0_flange);
      } 
      catch (tf::TransformException ex) {
	  ("%s",ex.what());	
	  stf_cupbase0_flange = tf::StampedTransform(tf::Transform(tf::Quaternion(tf::Point(0,0,1), 0.125*M_PI), tf::Point(0,0,-0.03)), ros::Time::now(),"/wsg50_palm_link","/tool0");
      }    
      std::cout << "\033[36m" "stf_wsg_palm_flange : acquired:\n" 
	<< std::fixed << std::setprecision(4) << "{ (" << stf_cupbase0_flange.getOrigin().x()<<", "<< stf_cupbase0_flange.getOrigin().y()<<", "<< stf_cupbase0_flange.getOrigin().z()<<"), ("
					      << stf_cupbase0_flange.getRotation().x()<<", "<< stf_cupbase0_flange.getRotation().y()<<", "<< stf_cupbase0_flange.getRotation().z()<< " | "<< stf_cupbase0_flange.getRotation().w()<<") }\n" "\033[0m";
      
      tf::StampedTransform stf_;
      try {
	listener.waitForTransform("right_1_suction_cup_tcp_link", "wsg50_palm_link",  ros::Time(0), ros::Duration(1) );
	listener.lookupTransform("right_1_suction_cup_tcp_link", "wsg50_palm_link", ros::Time(0), stf_);
      } 
      catch (tf::TransformException ex) {
	  ROS_ERROR("%s",ex.what());
	  stf_.setData( tf::Transform(tf::Quaternion(tf::Point(0,0,1), 0), tf::Point(0,0,-0.20)) );
      }
      stf_.setData( tf::Transform(tf::Quaternion::getIdentity(), tf::Point(0,0,stf_.getOrigin().getZ())) );
      stf_cupbase0_flange.setData(stf_cupbase0_flange*stf_);
      std::cout << "\033[36m" "stf_cupbase0_flange : acquired:\n" 
	<< std::fixed << std::setprecision(4) << "{ (" << stf_cupbase0_flange.getOrigin().x()<<", "<< stf_cupbase0_flange.getOrigin().y()<<", "<< stf_cupbase0_flange.getOrigin().z()<<"), ("
					      << stf_cupbase0_flange.getRotation().x()<<", "<< stf_cupbase0_flange.getRotation().y()<<", "<< stf_cupbase0_flange.getRotation().z()<< " | "<< stf_cupbase0_flange.getRotation().w()<<") }\n" "\033[0m";


      ///////////////////////////////////
    
    ///////////////////////////////// to get tf from cam to flange
      try {
	listener.waitForTransform("camera_depth_optical_frame", "tool0", ros::Time(0), ros::Duration(1) );
	listener.lookupTransform("camera_depth_optical_frame", "tool0", ros::Time(0), stf_camera_tool);
      } 
      catch (tf::TransformException ex) {
	  ROS_ERROR("%s",ex.what());	
 	  stf_camera_tool = tf::StampedTransform(tf::Transform(tf::Quaternion(0.0000, 0.0000, 0.9239, -0.3827), tf::Point(-0.0250, -0.0400, -0.1250)), ros::Time::now(),"camera_frame","tool0");
      }    
      stf_camera_tool.setData(stf_camera_tool * tf_plusX_025); 
      std::cout << "\033[36m" "stf_camera_tool : acquired:\n"
        << std::fixed << std::setprecision(4) << "{ (" << stf_camera_tool.getOrigin().x()<<", "<< stf_camera_tool.getOrigin().y()<<", "<< stf_camera_tool.getOrigin().z()<<"), ("
		<< stf_camera_tool.getRotation().x()<<", "<< stf_camera_tool.getRotation().y()<<", "<< stf_camera_tool.getRotation().z()<< " | "<< stf_camera_tool.getRotation().w()<<") }\n" "\033[0m";
    ///////////////////////////////////
  
      
    // We can print the name of the reference frame for this robot.
    ROS_INFO("Reference frame getPlanningFrame: %s", group_arm.getPlanningFrame().c_str());
    // We can also print the name of the end-effector link for this group.
    ROS_INFO("Reference frame getEndEffectorLink: %s", group_arm.getEndEffectorLink().c_str());
    group_arm.setMaxAccelerationScalingFactor(1.0);
    group_arm.setMaxVelocityScalingFactor(speed_factor);
//     group_arm.setGoalOrientationTolerance(0.0001);
//     group_arm.setGoalTolerance();
    

//     if ( ros::service::waitForService ("/wsg50_driver/set_force", ros::Duration(3)))
//     {
//       wsg_client = nh_.serviceClient<wsg50_common::Conf>("/wsg50_driver/set_force");
//       ROS_INFO("cfg gripper force : /wsg50_driver/set_force");
//     }
//     else 
//     {
//       ROS_ERROR("set cfg gripper force failed");
//     }
//     
//     wsg50_common::Conf foof;
//     foof.request.val = 19.1;	// cfg_wsg_X
//     if (wsg_client.call(foof))
//     {
//       ROS_INFO("call wsg service 'set_force'");
//     }
    
    
    if ( ros::service::waitForService ("/wsg50_driver/move", ros::Duration(3)))
    {
      wsg_client = nh_.serviceClient<wsg50_common::Move>("/wsg50_driver/move");
      ROS_INFO("set srv : /wsg50_driver/move");
    }
    else 
    {
      ROS_ERROR("set srv : /wsg50_driver/move failed");
    }
    
    
    if ( ros::service::waitForService ("/rpi_gpio/set_pin", ros::Duration(3)))
    {
      gpio_client = nh_.serviceClient<rpi_gpio::DigitalWrite>("/rpi_gpio/set_pin");
      ROS_INFO("set srv : /rpi_gpio/set_pin");
    }
    else 
    {
      ROS_ERROR("set srv : /rpi_gpio/set_pin failed");
    }
    
    printf( "\033[92m" "MoveTowardSuctionAction is configured\n\n" "\033[0m");
    
  }

  ~MoveTowardSuctionAction(void)
  {
  }  
  
  float move_p2p(const tf::Transform targetTF, const double max_velocity_scaling_factor = 1.0, const double max_acceleration_scaling_factor = 0.3 )
  {
    geometry_msgs::Pose targetPose;
    tf::poseTFToMsg(targetTF, targetPose); 
    move_p2p(targetPose, max_velocity_scaling_factor, max_acceleration_scaling_factor);
  }  
  
    
  float move_p2p(geometry_msgs::Pose &targetPose, const double max_velocity_scaling_factor = 1.0, const double max_acceleration_scaling_factor = 0.3 )
  {
//     std::cout << "group_arm.getGoalJointTolerance " << group_arm.getGoalJointTolerance() << "\n";
//     std::cout << "group_arm.getGoalOrientationTolerance " << group_arm.getGoalOrientationTolerance() << "\n";
//     std::cout << "group_arm.getGoalPositionTolerance " << group_arm.getGoalPositionTolerance() << "\n";
//     std::cout << "group_arm.getPlanningTime() " << group_arm.getPlanningTime() << "\n";
    group_arm.setMaxVelocityScalingFactor(max_velocity_scaling_factor*speed_factor);
    group_arm.setMaxAccelerationScalingFactor(max_acceleration_scaling_factor);
    group_arm.setPoseTarget(targetPose);
    group_arm.move();
    
//       group_arm.setPoseTarget(targetPose);
//       group_arm.move();
	
  }

  float move_linear(const tf::Transform targetTF, const double max_velocity_scaling_factor = 0.7, const double max_acceleration_scaling_factor = 0.3 )
  {
    geometry_msgs::Pose targetPose;
    tf::poseTFToMsg(targetTF, targetPose); 
    move_linear(targetPose, max_velocity_scaling_factor, max_acceleration_scaling_factor);
  }  
  
    
  float move_linear(geometry_msgs::Pose &targetPose, const double max_velocity_scaling_factor = 0.7, const double max_acceleration_scaling_factor = 0.3 )
  {
//     std::cout << "group_arm.getGoalJointTolerance " << group_arm.getGoalJointTolerance() << "\n";
//     std::cout << "group_arm.getGoalOrientationTolerance " << group_arm.getGoalOrientationTolerance() << "\n";
//     std::cout << "group_arm.getGoalPositionTolerance " << group_arm.getGoalPositionTolerance() << "\n";
    moveit_msgs::RobotTrajectory trajectory;
    group_arm.startStateMonitor();
    std::vector<geometry_msgs::Pose> waypoints = {group_arm.getCurrentPose().pose, targetPose};
    moveit::planning_interface::MoveGroup::Plan my_plan_;
    double fraction = plan_for_trajectory(waypoints, my_plan_, max_velocity_scaling_factor, max_acceleration_scaling_factor);
    if (fraction < 1)
    {
      group_arm.execute(my_plan_);
      group_arm.setPoseTarget(targetPose);
      group_arm.move();
      return fraction;
    }    
    group_arm.execute(my_plan_);
    
//       group_arm.setPoseTarget(targetPose);
//       group_arm.move();

    return fraction;
  }
  
  float plan_for_linear(geometry_msgs::Pose &targetPose, moveit::planning_interface::MoveGroup::Plan &my_plan, const double max_velocity_scaling_factor = 0.7, const double max_acceleration_scaling_factor = 0.3 )
  {
    moveit_msgs::RobotTrajectory trajectory;
    group_arm.startStateMonitor();
    std::vector<geometry_msgs::Pose> waypoints = {group_arm.getCurrentPose().pose, targetPose};

    double fraction = plan_for_trajectory(waypoints, my_plan, max_velocity_scaling_factor, max_acceleration_scaling_factor);
    return fraction;
  }
  
  float plan_for_trajectory(std::vector<geometry_msgs::Pose> &waypoints, moveit::planning_interface::MoveGroup::Plan &my_plan, const double max_velocity_scaling_factor = 0.7, const double max_acceleration_scaling_factor = 0.3 )
  {
    moveit_msgs::RobotTrajectory trajectory;
    double fraction = group_arm.computeCartesianPath(waypoints,
						      0.01,  // eef_step
						      0.0,   // jump_threshold
						      trajectory);
    ROS_INFO("cartesian path (%.2f%% acheived)", fraction * 100.0);    

    std::vector<double> empty;
    for(uint i = 0; i < trajectory.joint_trajectory.points.size(); i++)
    {
      int joint_count = trajectory.joint_trajectory.points[i].positions.size();
      trajectory.joint_trajectory.points[i].velocities = empty;
      trajectory.joint_trajectory.points[i].accelerations = empty;
      trajectory.joint_trajectory.points[i].effort = empty;
    }

//   	The trajectory needs to be modified so it will include velocities as well.
// 	First to create a RobotTrajectory object
    group_arm.startStateMonitor();
    robot_trajectory::RobotTrajectory rt(group_arm.getCurrentState()->getRobotModel(), "arm");

// 	Second get a RobotTrajectory from trajectory
    rt.setRobotTrajectoryMsg(*group_arm.getCurrentState(), trajectory);
    
// 	Thrid create a IterativeParabolicTimeParameterization object
    trajectory_processing::IterativeParabolicTimeParameterization iptp;
    trajectory_processing::SplineParameterization spline_tp;
// 	Fourth compute computeTimeStamps
    if(!spline_tp.computeTimeStamps(rt,max_velocity_scaling_factor*speed_factor, max_acceleration_scaling_factor))
    {
      ROS_ERROR("Can't compute velocities!");
    }
// 	Get RobotTrajectory_msg from RobotTrajectory
    rt.getRobotTrajectoryMsg(trajectory);
    trajectory.joint_trajectory.header.stamp = ros::Time::now();
//     for (auto &it : trajectory.joint_trajectory.points)
//     {
//       it.time_from_start += ros::Duration(0.7);
//     }
      my_plan.trajectory_ = trajectory;	
//     std::cout << trajectory;
    return fraction;
  }
  
  
  
  void goalCB_grip(float z_offset = 0)
  {	// execute approach and grip
    std::cout << "\033[1m\033[93m""execute approach and grip""\033[0m\n";
    

    //////////////////////////////////////////////////////////
    // cup ON 
    unsigned int cup1=0, cup2=0, cup3=0, cup4=0; 	      
    cup1 = goal_Grip.cupOn[1]>0;      
    cup2 = goal_Grip.cupOn[2]>0;      
    cup3 = goal_Grip.cupOn[3]>0;      
    cup4 = goal_Grip.cupOn[4]>0;

    ///////////////////////////////////////////////////////////
    
    tf::StampedTransform goalstf_x2cupbase0;
    tf::transformStampedMsgToTF(goal_Grip.tfs_tabel2cupbase0, goalstf_x2cupbase0);
    
    bool success = true;
    ////////////////////////////////////////////////////////
    
    cfg_wsg_X = 1000.0 * goal_Grip.cfgX + cfg_wsg_offset;
    if (abs(cfg_wsg_X-0.0)<0.01) cfg_wsg_X = 0.01;
    if (abs(cfg_wsg_X-210.0)<0.01) cfg_wsg_X = 209.99;
    
    wsg50_common::Move wsg_caller;
    wsg_caller.request.width = 209.99;	// cfg_wsg_X
    wsg_caller.request.speed = 300.0f;
    if (wsg_client.call(wsg_caller))
    {      
      ROS_INFO("call wsg service 'open'");
    }
    else
    {
      success = false;
      ROS_ERROR("call wsg service failed");
    }
    
    //////////////////////////////////////////////////////////

    
    tf::StampedTransform goalstf_world2cupbase0;
    tf::StampedTransform goalstf_world_flange;
  
    if (goal_Grip.tfs_tabel2cupbase0.header.frame_id == "/table_frame" || goal_Grip.tfs_tabel2cupbase0.header.frame_id == "table_frame")
    {
      std::cout << "\033[33m""target pose according to table_frame\033[0m\n";
      goalstf_world2cupbase0 = tf::StampedTransform(stf_world_tabel * goalstf_x2cupbase0, ros::Time::now(),"/world","/grip-1");
//       stf_world_flange = tf::StampedTransform(stf_world_tabel * goalstf_x2cupbase0 * stf_cupbase0_flange, ros::Time::now(),"/world","/flange/1_");
    }
    else if(goal_Grip.tfs_tabel2cupbase0.header.frame_id == "/world" || goal_Grip.tfs_tabel2cupbase0.header.frame_id == "world")
    {
      std::cout << "\033[33""target pose maccording to world\033[0m\n";
      goalstf_world2cupbase0 = tf::StampedTransform(goalstf_x2cupbase0, ros::Time::now(),"/world","/grip-1");
//       stf_world_flange = tf::StampedTransform(goalstf_x2cupbase0 * stf_cupbase0_flange, ros::Time::now(),"/world","/flange/1_");
    }
    else return;
    
    tf::Transform tf_CurrentPose_flange;
    tf::poseMsgToTF(group_arm.getCurrentPose().pose, tf_CurrentPose_flange); 
    tf::Transform tf_CurrentPose_cupbase0 = tf_CurrentPose_flange * stf_cupbase0_flange.inverse();
    
    tf::Transform tf_diff = tf_CurrentPose_cupbase0.inverse() * goalstf_world2cupbase0;
    double R,P,Y;    tf::Matrix3x3(tf_diff.getRotation()).getRPY(R,P,Y);
    if (fabs(Y)>M_PI_2)
    {// extra 180°
      std::cout << "\033[94m""Yaw form current pose is "<< Y*180.0/M_PI <<"°  Yaw will be compensated\n""\033[0m";
      goalstf_world2cupbase0.setData(goalstf_world2cupbase0 * tf_z180); 
          
      cup1 = goal_Grip.cupOn[4]>0;      
      cup2 = goal_Grip.cupOn[3]>0;      
      cup3 = goal_Grip.cupOn[2]>0;      
      cup4 = goal_Grip.cupOn[1]>0;
    } 
    goalstf_world_flange = tf::StampedTransform(goalstf_world2cupbase0 * stf_cupbase0_flange, ros::Time::now(),"/world","/flange/1_");
    
//     stf_world_flange.setData(stf_world_flange);
    
//     std::cout << "goalstf_x2cupbase0 \n" << goal_Grip.tfs_tabel2cupbase0;

//     br.sendTransform(goalstf_world2cupbase0);
    std::cout << "goalstf_world2cupbase0 : ";
    std::cout << std::fixed << std::setprecision(4) << "{ (" << goalstf_world2cupbase0.getOrigin().x()<<", "<< goalstf_world2cupbase0.getOrigin().y()<<", "<< goalstf_world2cupbase0.getOrigin().z()<<"), ("
	      << goalstf_world2cupbase0.getRotation().x()<<", "<< goalstf_world2cupbase0.getRotation().y()<<", "<< goalstf_world2cupbase0.getRotation().z()<< " | "<< goalstf_world2cupbase0.getRotation().w()<<") }\n";
//     br.sendTransform(goalstf_world_flange);
    std::cout << "goalstf_world_flange : ";
    std::cout << std::fixed << std::setprecision(4) << "{ (" << goalstf_world_flange.getOrigin().x()<<", "<< goalstf_world_flange.getOrigin().y()<<", "<< goalstf_world_flange.getOrigin().z()<<"), ("
	      << goalstf_world_flange.getRotation().x()<<", "<< goalstf_world_flange.getRotation().y()<<", "<< goalstf_world_flange.getRotation().z()<< " | "<< goalstf_world_flange.getRotation().w()<<") }\n";

//     geometry_msgs::Pose target_pose1;
    
      

    //////////////////////////////////////////////////////////	      
	      
//     move_p2p(goalstf_world_flange*tf_backZ_200, 1, 1);
//     ros::Duration(0.50).sleep();
//     sleep(2);
    
    //////////////////////////////////////////////////////////
    // move to above
    move_p2p(goalstf_world_flange*tf_backZ_170, 1, 0.9);
    ros::Duration(0.10).sleep();
    
    //////////////////////////////////////////////////////////
    // close wsg fingers
    wsg_caller.request.width = cfg_wsg_X;	// cfg_wsg_X
    wsg_caller.request.speed = 300.0f;
    std::cout << "cfg_wsg_X = " << cfg_wsg_X <<"\n";
    if (wsg_client.call(wsg_caller))
    {      
      ROS_INFO("call wsg service 'move'");
    }
    else
    {
      success = false;
      ROS_ERROR("call wsg service failed");
    }


    //////////////////////////////////////////////////////////    
    // get vacuum
    rpi_gpio::DigitalWrite gpio_caller;
    if (local_vacuum) 
    {
      gpio_caller.request.pin = 17;	gpio_caller.request.state = 1;		gpio_client.call(gpio_caller);
    }
    else {
//       gpio_caller.request.pin = 17;	gpio_caller.request.state = 0;		gpio_client.call(gpio_caller);
      std_srvs::Trigger Trigger_client;
      ros::service::waitForService("/vacuum_pim60/suck", ros::Duration(0.3));
      if (ros::service::call("/vacuum_pim60/suck", Trigger_client)) 
      {
	std::cout << "\033[92m""\033[1m" "----------- VACUUM!!! -----------\033[0m\n"; 
      }      
      else 
      {
	ROS_ERROR("Vacuum missing, please check vacuum source on Beaglebone");
      }
    }

    //////////////////////////////////////////////////////////    
    // touch down
    if (z_offset > 0.03) 
    {
      ROS_ERROR("z_offset too large (over 3cm), reseting it to 0");
    }
    tf::Transform tf_z_offset (tf::Quaternion::getIdentity(), tf::Point(0,0,z_offset));
    move_linear(goalstf_world_flange * tf_z_offset, 0.5, 0.7);

    ros::Duration(0.10).sleep();

    //////////////////////////////////////////////////////////
    // open valve and suck
    gpio_caller.request.pin = 24;	gpio_caller.request.state = cup1;	gpio_client.call(gpio_caller);
    gpio_caller.request.pin = 23;	gpio_caller.request.state = cup2;	gpio_client.call(gpio_caller);
    gpio_caller.request.pin = 22;	gpio_caller.request.state = cup3;	gpio_client.call(gpio_caller);
    gpio_caller.request.pin = 27;	gpio_caller.request.state = cup4;	gpio_client.call(gpio_caller);
    std::cout << "\033[92m""\033[1m" "----------- SUCTION!!! -----------\033[0m\n"; 
    
    
    //////////////////////////////////////////////////////////
    
    data_count_ = 0;
    
    if(success)
    {
      ROS_INFO("%s: Succeeded", action_name_.c_str());
      // set the action state to succeeded
      as_.setSucceeded();
    }
    
//     int kk = 17;
//     std::cout << "\033[1m\033[96m" << kk << " seconds before releasing suction""\033[0m\n";
//     for ( ; kk>0; kk--)
//     {
//       ros::Duration(1.0).sleep();
//       std::cout << "\033[1m\033[94m"<< kk <<"\033[0m\n";
//     }
//     gpio_caller.request.pin = 24;	gpio_caller.request.state = 0;	gpio_client.call(gpio_caller);
//     gpio_caller.request.pin = 23;	gpio_caller.request.state = 0;	gpio_client.call(gpio_caller);
//     gpio_caller.request.pin = 22;	gpio_caller.request.state = 0;	gpio_client.call(gpio_caller);
//     gpio_caller.request.pin = 27;	gpio_caller.request.state = 0;	gpio_client.call(gpio_caller);
//     std::cout << "\033[1m\033[96m" << kk << " vacuum valves off!""\033[0m\n";
     
    return;
  }

  void goalCB_homePose(int homeX = 0)
  {	// move back to home position
    std::cout << "\033[1m\033[93m""move back to home position""\033[0m\n";
    
    /////////////////////////////////////////////////////////
    


//     tf::Transform goalstf_world_flange(tf::Quaternion(0.7071, -0.7071, 0.0000 , 0.0000), tf::Point(1.150, 0.000, 1.40));
    tf::Transform goalstf_world_flange(tf::Quaternion(0.7071, -0.7071, 0.0000 , 0.0000), tf::Point(0.8000, -0.00, 1.4460));
    
    if (homeX%10 == 0)
      goalstf_world_flange = tf::Transform(tf::Quaternion(0.7071, -0.7071, 0.0000 , 0.0000), tf::Point(0.8000, -0.00, 1.4460));
    else if (homeX%10 == 1)
      goalstf_world_flange = tf::Transform(tf::Quaternion(0.7071, -0.7071, 0.0000 , 0.0000), tf::Point(1.150, -0.00, 1.40));
    else if (homeX%10 == 2)
      goalstf_world_flange = tf::Transform(tf::Quaternion(0.7071, -0.7071, 0.0000 , 0.0000), tf::Point(1.150, -0.20, 1.35));
    else if (homeX%10 == 3)
      goalstf_world_flange = tf::Transform(tf::Quaternion(0.7071, -0.7071, 0.0000 , 0.0000), tf::Point(1.150, -0.00, 1.25));
    else if (homeX%10 == 4)
      goalstf_world_flange = tf::Transform(tf::Quaternion(0.8, -0.6, 0.0000 , 0.0000), tf::Point(1.000, -0.15, 1.350));
    else if (homeX%10 == 5)
      goalstf_world_flange = tf::Transform(tf::Quaternion(0.8, -0.6, 0.0000 , 0.0000), tf::Point(1.000, -0.15, 1.20));
    else if (homeX%10 == 6)
      goalstf_world_flange = tf::Transform(tf::Quaternion(0.8, -0.6, 0.0000 , 0.0000), tf::Point(1.000, -0.15, 1.450));
    else if (homeX%10 == 7)
      goalstf_world_flange = tf::Transform(tf::Quaternion(0.8, -0.6, 0.0000 , 0.0000), tf::Point(0.650, 0.2, 1.200));
    
    /////////////////////////////////////
    move_p2p(goalstf_world_flange, 1, 1);
    
    
    ////////////////////////////////////////////////////////

    
    if (homeX >= 10)	// move back and do nothing
    { 
      // blow 
      if (!local_vacuum)
      {
	std_srvs::Trigger Trigger_client;
	ros::service::waitForService("/vacuum_pim60/release", ros::Duration(0.3));
	if (ros::service::call("/vacuum_pim60/release", Trigger_client)) 
	{
	  std::cout << "\033[94m""\033[1m" "----------- RELEASE!!! -----------\033[0m\n"; 
	}
      }
      ros::Duration(0.5).sleep();
      
    
    // must shut off the pump and valves, unless you wanna burn the up-board like i did again.....

      rpi_gpio::DigitalWrite gpio_caller;
      gpio_caller.request.pin = 17;	gpio_caller.request.state = 0;		gpio_client.call(gpio_caller);
      gpio_caller.request.pin = 24;	gpio_caller.request.state = 0;		gpio_client.call(gpio_caller);
      gpio_caller.request.pin = 23;	gpio_caller.request.state = 0;		gpio_client.call(gpio_caller);
      gpio_caller.request.pin = 22;	gpio_caller.request.state = 0;		gpio_client.call(gpio_caller);
      gpio_caller.request.pin = 27;	gpio_caller.request.state = 0;		gpio_client.call(gpio_caller);
      std::cout << "\033[94m""\033[1m" "----------- pumps off -----------\033[0m\n"; 
      ros::Duration(1).sleep();    
      
      //////////////////////////////////////////////////////////
      wsg50_common::Move wsg_caller;
      wsg_caller.request.width = 209.99;	// cfg_wsg_X
      wsg_caller.request.speed = 200.0f;
      if (wsg_client.call(wsg_caller))
      {      
	ROS_INFO("call wsg service 'open'");
      }
      else
      {
  //       success = false;
	ROS_ERROR("call wsg service failed");
      }
    }

    //////////////////////////////////////////////////////////
    
    if(1)
    {
      ROS_INFO("%s: Succeeded", action_name_.c_str());
      // set the action state to succeeded
      as_.setSucceeded();
    }
  }

  void goalCB_lookcloser()
  {	// move back to home position
    std::cout << "\033[1m\033[93m""move back to lookcloser position""\033[0m\n";
    
    
    tf::StampedTransform goalstf_x2cupbase0;
    tf::transformStampedMsgToTF(goal_Grip.tfs_tabel2cupbase0, goalstf_x2cupbase0);
    
    bool success = true;
    ////////////////////////////////////////////////////////

    wsg50_common::Move wsg_caller;
    wsg_caller.request.width = 209.99;	// cfg_wsg_X
    wsg_caller.request.speed = 300.0f;
    if (wsg_client.call(wsg_caller))
    {      
      ROS_INFO("call wsg service 'open'");
    }
    else
    {
      success = false;
      ROS_ERROR("call wsg service failed");
    }
    
    //////////////////////////////////////////////////////////
    
    tf::StampedTransform goalstf_world2cupbase0;
    tf::StampedTransform goalstf_world_flange;
  
    if (goal_Grip.tfs_tabel2cupbase0.header.frame_id == "/table_frame" || goal_Grip.tfs_tabel2cupbase0.header.frame_id == "table_frame")
    {
      std::cout << "\033[33m""target pose according to table_frame\033[0m\n";
      goalstf_world2cupbase0 = tf::StampedTransform(stf_world_tabel * goalstf_x2cupbase0, ros::Time::now(),"/world","/look-1");
//       stf_world_flange = tf::StampedTransform(stf_world_tabel * goalstf_x2cupbase0 * stf_cupbase0_flange, ros::Time::now(),"/world","/flange/1_");
    }
    else if(goal_Grip.tfs_tabel2cupbase0.header.frame_id == "/world" || goal_Grip.tfs_tabel2cupbase0.header.frame_id == "world")
    {
      std::cout << "\033[33m""target pose according to world\033[0m\n";
      goalstf_world2cupbase0 = tf::StampedTransform(goalstf_x2cupbase0, ros::Time::now(),"/world","/look-1");
//       stf_world_flange = tf::StampedTransform(goalstf_x2cupbase0 * stf_cupbase0_flange, ros::Time::now(),"/world","/flange/1_");
    }
    else return;
    
    
    tf::Transform tf_CurrentPose_flange;
    tf::poseMsgToTF(group_arm.getCurrentPose().pose, tf_CurrentPose_flange); 
    tf::Transform tf_CurrentPose_cupbase0 = tf_CurrentPose_flange * stf_cupbase0_flange.inverse();
    
    tf::Transform tf_diff = tf_CurrentPose_cupbase0.inverse() * goalstf_world2cupbase0;
    double R,P,Y;    tf::Matrix3x3(tf_diff.getRotation()).getRPY(R,P,Y);
    if (fabs(Y)>M_PI_2)
    {// extra 180°
      std::cout << "\033[94m""Yaw form current pose is "<< Y*180.0/M_PI <<"°  Yaw will be compensated\n""\033[0m";
      goalstf_world2cupbase0.setData(goalstf_world2cupbase0 * tf_z180);
    }     
//     goalstf_world_flange = tf::StampedTransform(goalstf_world2cupbase0 * tf_z180 * tf_backZ_170 * stf_camera_tool, ros::Time::now(),"/world","/flange/1_");// set other distancés?
    goalstf_world_flange = tf::StampedTransform(goalstf_world2cupbase0 * tf_z180 * tf_backZ_230 * stf_camera_tool, ros::Time::now(),"/world","/flange/1_");
    
//     std::cout << "goalstf_x2cupbase0 \n" << goal_Grip.tfs_tabel2cupbase0;

//     br.sendTransform(goalstf_world2cupbase0);
    std::cout << "goalstf_world2cupbase0 : ";
    std::cout << std::fixed << std::setprecision(4) << "{ (" << goalstf_world2cupbase0.getOrigin().x()<<", "<< goalstf_world2cupbase0.getOrigin().y()<<", "<< goalstf_world2cupbase0.getOrigin().z()<<"), ("
	      << goalstf_world2cupbase0.getRotation().x()<<", "<< goalstf_world2cupbase0.getRotation().y()<<", "<< goalstf_world2cupbase0.getRotation().z()<< " | "<< goalstf_world2cupbase0.getRotation().w()<<") }\n";

//     br.sendTransform(goalstf_world_flange);
    std::cout << std::fixed << std::setprecision(4) << "goalstf_world_flange : { (" << goalstf_world_flange.getOrigin().x()<<", "<< goalstf_world_flange.getOrigin().y()<<", "<< goalstf_world_flange.getOrigin().z()<<"), ("
	      << goalstf_world_flange.getRotation().x()<<", "<< goalstf_world_flange.getRotation().y()<<", "<< goalstf_world_flange.getRotation().z()<< " | "<< goalstf_world_flange.getRotation().w()<<") }\n";

    move_p2p(goalstf_world_flange, 1, 1);
    ros::Duration(0.20).sleep();
    
    if(success)
    {
      ROS_INFO("%s: Succeeded", action_name_.c_str());
      // set the action state to succeeded
      as_.setSucceeded();
    }
    
    return;
  }
  
  void goalCB()
  {
    moveit::planning_interface::PlanningSceneInterface planning_scene_interface;
    // reset helper variables
    auto NewGoal = as_.acceptNewGoal();
    
    if (NewGoal->command == 0)
    {
      goalCB_homePose(0);
    }
    else if (NewGoal->command < 10 && NewGoal->command > 0)
    {
      goalCB_homePose(NewGoal->command);
    }
    else if (NewGoal->command < 20 && NewGoal->command >= 10)
    {
      goalCB_homePose(NewGoal->command);
    }
    
    else if (NewGoal->command == 100)
    {
      goal_Grip = NewGoal->grip;
      goalCB_grip(NewGoal->z_offset);
    }
    else if (NewGoal->command == 50)
    {
      goal_Grip = NewGoal->grip;
      goalCB_lookcloser();
    }
    else
    {
      ROS_ERROR("action's goal.command not valid. 0:home, 100:grip");
    }
    /*
    tf::transformStampedMsgToTF(goal_Grip.tfs_tabel2cupbase0, stf_x2cupbase0);
    
//     std::vector<geometry_msgs::Pose> waypoints;
//     waypoints.push_back(group_arm.getCurrentPose().pose);
//     uint k = 0;
    
    bool success = true;
    ////////////////////////////////////////////////////////
    
    cfg_wsg_X = 1000.0 * goal_Grip.cfgX + cfg_wsg_offset;
    if (abs(cfg_wsg_X-0.0)<0.01) cfg_wsg_X = 0.01;
    if (abs(cfg_wsg_X-210.0)<0.01) cfg_wsg_X = 209.99;
    
    wsg50_common::Move wsg_caller;
    wsg_caller.request.width = 209.99;	// cfg_wsg_X
    wsg_caller.request.speed = 300.0f;
    if (wsg_client.call(wsg_caller))
    {      
      ROS_INFO("call wsg service 'open'");
    }
    else
    {
      success = false;
      ROS_ERROR("call wsg service failed");
    }
    
    //////////////////////////////////////////////////////////
    
    
    if (goal_Grip.tfs_tabel2cupbase0.header.frame_id == "/table_frame" || goal_Grip.tfs_tabel2cupbase0.header.frame_id == "table_frame")
    {
      ROS_WARN("according to table_frame");
      stf_world_flange = tf::StampedTransform(stf_world_tabel * stf_x2cupbase0 * stf_cupbase0_flange, ros::Time::now(),"/world","/flange/1_");
    }
    else if(goal_Grip.tfs_tabel2cupbase0.header.frame_id == "/world" || goal_Grip.tfs_tabel2cupbase0.header.frame_id == "world")
    {
      ROS_WARN("according to world");
      stf_world_flange = tf::StampedTransform(stf_x2cupbase0 * stf_cupbase0_flange, ros::Time::now(),"/world","/flange/1_");
    }
    else return;
    
    br.sendTransform(stf_x2cupbase0);
    br.sendTransform(stf_world_flange);
    std::cout << std::fixed << std::setprecision(4) << "{ (" << stf_world_flange.getOrigin().x()<<", "<< stf_world_flange.getOrigin().y()<<", "<< stf_world_flange.getOrigin().z()<<"), ("
	      << stf_world_flange.getRotation().x()<<", "<< stf_world_flange.getRotation().y()<<", "<< stf_world_flange.getRotation().z()<< " | "<< stf_world_flange.getRotation().w()<<") }\n";

//     geometry_msgs::Pose target_pose1;
    
    move_linear(stf_world_flange*tf_backZ_200,0.9,0.9);
    sleep(2);
     
    wsg_caller.request.width = cfg_wsg_X;	// cfg_wsg_X
    wsg_caller.request.speed = 300.0f;
    std::cout << "cfg_wsg_X = " << cfg_wsg_X <<"\n";
    if (wsg_client.call(wsg_caller))
    {      
      ROS_INFO("call wsg service 'move'");
    }
    else
    {
      success = false;
      ROS_ERROR("call wsg service failed");
    }
//     
//     pop_front(waypoints);

//     plan_for_trajectory(waypoints, arm_plan,0.3,0.3);
    
//     plan_for_linear(target_pose1, arm_plan,0.9,0.9);
//     group_arm.execute(arm_plan);
    move_linear(stf_world_flange*tf_backZ_050,0.5,0.5);
    
//     group_arm.setPoseTarget(target_pose1);	  
//     success = group_arm.plan(arm_plan);    
//     if (success) 
//     {
//       group_arm.execute(arm_plan);
//     }
    sleep(2);
    
//     tf::poseTFToMsg(stf_world_flange, target_pose1); 
//     group_arm.setPoseTarget(target_pose1);	
//     waypoints.clear();
//     waypoints.push_back(group_arm.getCurrentPose().pose);
//     waypoints.push_back(target_pose1);
    
//     for (auto it : waypoints)
//     {
//       std::cout << "                           "<< k++<<"\n" << it;
//     }
    
    move_linear(stf_world_flange,0.1,0.1);

    sleep(2);
    
    data_count_ = 0;
    
    if(success)
    {
      ROS_INFO("%s: Succeeded", action_name_.c_str());
      // set the action state to succeeded
      as_.setSucceeded();
    }
    */

    
    return;
  }

  void preemptCB()
  {
    ROS_INFO("%s: Preempted", action_name_.c_str());
    // set the action state to preempted
    as_.setPreempted();
  }

  void analysisCB(const yf_pcl_process::msg_Grip::ConstPtr& msg)
  {
    // make sure that the action hasn't been canceled
    std::cout << ".";
    if (!as_.isActive())
      return;
    
    /*
    feedback_.sample = data_count_;
    feedback_.data = msg->data;
    //compute the std_dev and mean of the data 
    sum_ += msg->data;
    feedback_.mean = sum_ / data_count_;
    sum_sq_ += pow(msg->data, 2);
    feedback_.std_dev = sqrt(fabs((sum_sq_/data_count_) - pow(feedback_.mean, 2)));*/
//     as_.publishFeedback(feedback_);


    if(data_count_++ > 1000) 
    {
//       result_.vacuum_exist = feedback_.vacuum_exist;
//       result_.distance2touch = feedback_.distance2touch;

      if(1)	//result_.distance2touch < 0.0
      {
        ROS_INFO("%s: Aborted", action_name_.c_str());
        //set the action state to aborted
//         as_.setAborted(result_);
        as_.setAborted();
      }
      else 
      {
        ROS_INFO("%s: Succeeded", action_name_.c_str());
        // set the action state to succeeded
//         as_.setSucceeded(result_);
        as_.setSucceeded();
      }
    } 

  }
  
  
};


int main(int argc, char** argv)
{
  ros::init(argc, argv, "Robot_try_Grip");
  
  ros::NodeHandle priv_nh("~");
  if (priv_nh.getParam ("speed_factor", speed_factor)) {}
    else speed_factor = 1.0;
  
  if (priv_nh.getParam ("local_vacuum", local_vacuum)) {}
    else local_vacuum = 1;
    
  if (speed_factor > 1.0 || speed_factor < 0)
    speed_factor = 1.0;
    
  ros::AsyncSpinner spinner(1);
  spinner.start();

  ROS_INFO("Robot_try_Grip : on");
//   MoveTowardSuctionAction MoveTowardSuction_action_obj(ros::this_node::getName());
  MoveTowardSuctionAction MoveTowardSuction_action_obj("ACTION_Robot_try_Grip");
  ros::spin();

  return 0;
}