#include <ros/ros.h>
#include "std_msgs/String.h"
#include "std_srvs/Empty.h"

#include <yf_movements/act_MoveTowardSuctionAction.h>
#include <actionlib/client/simple_action_client.h>
#include <actionlib/client/terminal_state.h>
#include <boost/thread.hpp>




void spinThread()
{
  ros::spin();
}

int main( int argc, char **argv )
{   ros::init(argc, argv, "wsg50_client");
   ros::NodeHandle nh("~");

   
    int homing = -1;
    if (nh.getParam ("homing", homing)) {}
    else homing = -1;
    
    
    
      actionlib::SimpleActionClient<yf_movements::act_MoveTowardSuctionAction> ac("ACTION_Robot_try_Grip");
      boost::thread spin_thread(&spinThread); 
      ROS_INFO("Waiting for action server to start.");
      ac.waitForServer();

      ROS_INFO("Action server started, sending goal.");
     
      yf_movements::act_MoveTowardSuctionGoal goal;
      goal.command = homing;
      
      ac.sendGoal(goal);

     
      bool finished_before_timeout = ac.waitForResult(ros::Duration(7.0));

      if (finished_before_timeout)
      {
	actionlib::SimpleClientGoalState state = ac.getState();
	ROS_INFO("Action finished: %s",state.toString().c_str());
      }
      else
	ROS_INFO("Action did not finish before the time out.");

      // 关闭节点，在退出前加入线程
      ros::shutdown();
      spin_thread.join();

    return 0;

}