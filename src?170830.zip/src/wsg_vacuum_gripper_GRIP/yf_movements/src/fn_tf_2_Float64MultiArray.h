#include <ros/ros.h>
#include <tf/LinearMath/Vector3.h>
#include <tf_conversions/tf_eigen.h>
#include <std_msgs/Float64MultiArray.h>


void tf_2_Float64MultiArray (tf::StampedTransform stf_, std_msgs::Float64MultiArray &ary_)
{
  double r2d = 180/M_PI;
  tf::Point Pos(stf_.getOrigin());
  double r,p,y;
  stf_.getBasis().getRPY (r,p,y);
  ary_.data = {Pos.x(),Pos.y(),Pos.z(),y*r2d,p*r2d,r*r2d};
};

void tf_2_Float64MultiArray (tf::Transform tf_, std_msgs::Float64MultiArray &ary_)
{
  double r2d = 180/M_PI;
  tf::Point Pos(tf_.getOrigin());
  double r,p,y;
  tf_.getBasis().getRPY (r,p,y);
  ary_.data = {Pos.x(),Pos.y(),Pos.z(),y*r2d,p*r2d,r*r2d};
};


void tf_2_Float64MultiArray (geometry_msgs::TransformStamped tfs_, std_msgs::Float64MultiArray &ary_)
{
  tf::StampedTransform stf_;
  tf::transformStampedMsgToTF(tfs_, stf_);
  tf_2_Float64MultiArray(stf_, ary_);
}


std_msgs::Float64MultiArray tf_2_Float64MultiArray (tf::StampedTransform stf_)
{
  std_msgs::Float64MultiArray ary_;
  tf_2_Float64MultiArray (stf_, ary_);
  return ary_;
}

std_msgs::Float64MultiArray tf_2_Float64MultiArray (tf::Transform stf_)
{
  std_msgs::Float64MultiArray ary_;
  tf_2_Float64MultiArray (stf_, ary_);
  return ary_;
}


std_msgs::Float64MultiArray tf_2_Float64MultiArray (geometry_msgs::TransformStamped tfs_)
{
  std_msgs::Float64MultiArray ary_;
  tf_2_Float64MultiArray (tfs_, ary_);
  return ary_;
}
